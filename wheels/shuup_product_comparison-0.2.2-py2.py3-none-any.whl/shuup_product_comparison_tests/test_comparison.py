# -*- coding: utf-8 -*-
# This file is part of Shuup Product Comparison.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
import json

import pytest
from django.core.urlresolvers import reverse
from django.test.client import Client
from django.utils.translation import activate

from shuup.core.models import Attribute, ProductAttribute
from shuup.testing import factories

DEFAULT_USER_PWD = "ADMIN"


@pytest.mark.django_db
def test_add_remove():
    shop, products, client = _setup_comparison_test()

    # add all 5 products to comparison
    for ix, product in enumerate(products, 1):
        comparison_add_url = reverse("shuup:comparison_add", kwargs=dict(pk=product.pk))
        response = client.post(comparison_add_url)
        assert response.status_code == 200
        result = json.loads(response.content.decode("utf-8"))

        # it is not possible to add more than 4 products to comparison
        if ix > 4:
            assert result["error"] == (
                "Cannot compare more than four (4) products at the same time. "
                "Please remove one to compare this product."
            )
        else:
            assert result["ok"]

            if ix == 1:
                # try to add the same product again
                response = client.post(comparison_add_url)
                assert response.status_code == 200
                result = json.loads(response.content.decode("utf-8"))
                assert result["error"] == "Product already in comparison."

    assert str(products[0].id) in client.session["product_comparison"]
    assert str(products[1].id) in client.session["product_comparison"]
    assert str(products[2].id) in client.session["product_comparison"]
    assert str(products[3].id) in client.session["product_comparison"]
    assert str(products[4].id) not in client.session["product_comparison"]

    # remove the first product of the comparison
    response = client.post(reverse("shuup:comparison_remove", kwargs=dict(pk=products[0].pk)))
    assert response.status_code == 200
    result = json.loads(response.content.decode("utf-8"))
    assert result["ok"]
    assert str(products[0].id) not in client.session["product_comparison"]

    # there is 3 products for comparison
    assert len(client.session["product_comparison"]) == 3

    # remove all products
    response = client.post(reverse("shuup:comparison_remove", kwargs=dict(pk="all")))
    assert response.status_code == 200
    result = json.loads(response.content.decode("utf-8"))
    assert result["ok"]
    assert not client.session["product_comparison"]


@pytest.mark.django_db
def test_comparison_quickview():
    shop, products, client = _setup_comparison_test()
    _add_for_comparison(client, products[:4])
    response = client.get(reverse("shuup:comparison_quickview"))
    assert response.status_code == 200
    data = response.content.decode("utf-8")
    assert "comparison-list" in data

    for product in products[:4]:
        assert reverse("shuup:product", kwargs=dict(pk=product.id, slug=product.slug)) in data
        assert 'data-product-id="%d"' % product.id in data

    # remove all products from comparison
    response = client.post(reverse("shuup:comparison_remove", kwargs=dict(pk="all")))
    assert response.status_code == 200

    response = client.get(reverse("shuup:comparison_quickview"))
    assert response.status_code == 200
    data = response.content.decode("utf-8")
    assert "Nothing to compare" in data


@pytest.mark.parametrize("compare_number", [1, 2, 3, 4])
@pytest.mark.django_db
def test_compare_product_view(compare_number):
    shop, products, client = _setup_comparison_test()
    _add_for_comparison(client, products[:compare_number])
    response = client.get(reverse("shuup:comparison_view"))
    assert response.status_code == 200
    data = response.content.decode("utf-8")
    assert "product-comparison-card" in data

    for product in products[:compare_number]:
        assert reverse("shuup:product", kwargs=dict(pk=product.id, slug=product.slug)) in data
        assert 'data-product-id="%d"' % product.id in data

    # remove all products from comparison
    response = client.post(reverse("shuup:comparison_remove", kwargs=dict(pk="all")))
    assert response.status_code == 200

    response = client.get(reverse("shuup:comparison_view"))
    assert response.status_code == 200
    data = response.content.decode("utf-8")
    assert "You don't have any products added into comparison." in data


def _add_for_comparison(client, products):
    for product in products:
        comparison_add_url = reverse("shuup:comparison_add", kwargs=dict(pk=product.pk))
        response = client.post(comparison_add_url)
        assert response.status_code == 200
        result = json.loads(response.content.decode("utf-8"))
        assert result["ok"]


def _setup_comparison_test():
    activate("en")
    shop = factories.get_default_shop()
    category = factories.get_default_category()

    user = factories.create_random_user("en")
    user.set_password(DEFAULT_USER_PWD)
    user.save()

    product_type = factories.get_default_product_type()
    products = []
    for x in range(5):
        product = factories.create_product(
            "product-%d" % x,
            shop=shop,
            supplier=factories.get_default_supplier(),
            default_price=x,
            name="Product %d" % x,
            type=product_type
        )
        shop_product = product.get_shop_instance(shop)
        shop_product.categories.add(category)
        products.append(product)

        attribute1 = Attribute.objects.get(identifier="awesome")
        attribute2 = Attribute.objects.get(identifier="bogomips")
        ProductAttribute.objects.create(attribute=attribute1, product=product, numeric_value=1)
        ProductAttribute.objects.create(attribute=attribute2, product=product, numeric_value=x)

    client = Client()
    client.login(username=user.username, password=DEFAULT_USER_PWD)

    return shop, products, client
