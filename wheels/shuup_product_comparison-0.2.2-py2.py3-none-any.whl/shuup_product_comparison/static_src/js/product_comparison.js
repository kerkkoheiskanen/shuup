/**
 * This file is part of Product Comparison.
 *
 * Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
 *
 * This source code is licensed under the AGPLv3 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// make sure jQuery is available
if (typeof window.$ === "function") {
    $(document).ready(function() {
        const ShuupProductComparison = window.ShuupProductComparison;
        $(".shuup-product-compare-add").click(function(e){
            e.preventDefault();
            const productId = $(this).attr("data-product-id");
            const reload = $(this).data("reload");
            ShuupProductComparison.addProductToComparison(productId, reload);
        });

        $(document).on("click", ".shuup-product-comparison-remove", function(e) {
            e.preventDefault();
            const productId = $(this).data("product-id");
            const reload = $(this).data("reload");
            ShuupProductComparison.removeProductFromComparison(productId, reload);
        });

        $(document).on("click", ".shuup-product-comparison-remove-all", function(e){
            e.preventDefault();
            ShuupProductComparison.removeProductFromComparison("all", false);
        });
    });
}
