/**
 * This file is part of Product Comparison.
 *
 * Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
 *
 * This source code is licensed under the AGPLv3 license found in the
 * LICENSE file in the root directory of this source tree.
 */
window.ShuupProductComparison = {
    flashMessage: function(messageType, message, icon = "") {
        var type = interpolate("alert-%s", [messageType]);
        var msg = interpolate("<div class='%s'>", [interpolate("fade flash wishlist-alert alert %s", [type])]);
        msg += interpolate("<p><i class='%s'></i> %s</p>", [interpolate("glyphicon %s", [icon]), message]);
        msg += "</div>";
        msg = $(msg);
        $("body").append(msg);
        msg.addClass("in");
        setTimeout(function(){
            $("body .wishlist-alert").removeClass("in");
        }, 2000);
    },
    reloadQuickViews: function() {
        $.ajax({
            url: "/compare/quick-view/",
            method: "GET",
            success: function(response){
                $(".product-comparison").each(function(idx, elem) {
                    $(elem).html(response);
                });
            }
        });
    },
    query: function(method, productId, reload) {
        var that = this;
        var url = interpolate("/compare/%s/%s", [method, productId]);
        $.ajax({
            url,
            method: "GET",
            success: function(response){
                if(reload === 1) {
                    location.reload();
                }
                if (response.error) {
                    that.flashMessage("danger", response.error);
                }
                else {
                    var msg = (method === "add" ?
                        gettext("Product added to comparison") :
                        gettext("Product removed from comparison")
                    );
                    that.flashMessage("success", msg, "glyphicon-ok");
                }
                that.reloadQuickViews();
            }
        });
    },
    addProductToComparison: function(productId, reload) {
        this.query("add", productId, reload);
    },
    removeProductFromComparison: function(productId, reload) {
        this.query("remove", productId, reload);
    },
};
