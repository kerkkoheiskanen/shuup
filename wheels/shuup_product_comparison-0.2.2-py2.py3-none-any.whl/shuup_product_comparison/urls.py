# -*- coding: utf-8 -*-
# This file is part of Shuup Product Comparison.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.conf.urls import url

from .views import (
    add_product_to_compare, product_comparison_quickview, ProductCompareView,
    remove_product_from_compare
)

urlpatterns = [
    url(r"compare/$", ProductCompareView.as_view(), name="comparison_view"),
    url(r"^compare/add/(?P<pk>\d+)/$", add_product_to_compare, name="comparison_add"),
    url(r"^compare/remove/(?P<pk>\w+)/$", remove_product_from_compare, name="comparison_remove"),
    url(r"^compare/quick-view/$", product_comparison_quickview, name="comparison_quickview"),
]
