# -*- coding: utf-8 -*-
# This file is part of Shuup Product Comparison.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.http import HttpResponse, JsonResponse
from django.template.loader import get_template
from django.utils.encoding import force_text
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _
from django.views.generic import TemplateView

from shuup.core.models import Product
from shuup.front.utils.product import get_product_context

from .models import ComparableAttribute

COMPARED_ATTRIBUTES = [
    ("sku", _("SKU")),
    ("manufacturer", _("Manufacturer")),
    ("description", _("Description")),
]


class ProductCompareView(TemplateView):
    template_name = "shuup_product_comparison/compare.jinja"

    def get_context_data(self, **kwargs):
        context = super(ProductCompareView, self).get_context_data(**kwargs)
        compared_products = self.request.session.get("product_comparison", set([]))
        context["col_cls"] = self.get_column_class(compared_products)
        products = Product.objects.filter(id__in=compared_products)
        products_data = []
        for product in products:
            data = get_product_context(self.request, product)
            data["attribute_values"] = {}
            for attr in data["attributes"]:
                data["attribute_values"][attr.attribute.identifier] = attr.formatted_value
            products_data.append(data)
        context["products"] = products_data
        context["default_attributes"] = COMPARED_ATTRIBUTES  # from somewhere else in future?
        context["comparable_attributes"] = ComparableAttribute.objects.all()
        return context

    def get_column_class(self, compared_products):
        cplen = len(compared_products)
        if cplen == 4:
            return "col-md-2"
        if cplen == 3:
            return "col-md-3"
        if cplen == 2:
            return "col-md-5"
        return "col-md-10"


def add_product_to_compare(request, pk):
    compared_products = request.session.get("product_comparison", set([]))
    response = {}
    if len(compared_products) >= 4:
        response["error"] = force_text(_("Cannot compare more than four (4) products at the same time. "
                                         "Please remove one to compare this product."))
        return JsonResponse(response)

    if pk in compared_products:
        response["error"] = force_text(_("Product already in comparison."))
        return JsonResponse(response)

    compared_products.add(pk)
    request.session["product_comparison"] = compared_products
    return JsonResponse({"ok": True})


def remove_product_from_compare(request, pk):
    compared_products = request.session.get("product_comparison", set([]))
    if pk == 'all':
        compared_products = set([])
    elif pk in compared_products:
        compared_products.remove(pk)
    request.session["product_comparison"] = compared_products
    return JsonResponse({"ok": True})


def product_comparison_quickview(request):
    product_ids = request.session.get("product_comparison")
    context = {}
    if product_ids:
        context["products"] = Product.objects.filter(pk__in=product_ids)
    context["request"] = request
    template = get_template("shuup_product_comparison/plugins/comparison_view.jinja")
    return HttpResponse(mark_safe(template.render(context=context)))
