# -*- coding: utf-8 -*-
# This file is part of Shuup Product Comparison.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django import forms
from django.utils.translation import ugettext_lazy as _

from shuup.admin.form_modifier import FormModifier

from .models import ComparableAttribute


class AttributeFormExtension(FormModifier):
    def get_extra_fields(self, object=None):
        initial = None
        if object:
            initial = ComparableAttribute.objects.filter(attribute=object).exists()
        return [("comparable",
                forms.BooleanField(
                    help_text=_("Comparable fields will be visible in the product comparison"),
                    required=False,
                    initial=initial
                )
            ),
        ]

    def form_valid_hook(self, form, object):
        comparable = form.cleaned_data.get("comparable", False)
        if comparable:
            ComparableAttribute.objects.get_or_create(attribute=object)
        else:
            ComparableAttribute.objects.filter(attribute=object).delete()
