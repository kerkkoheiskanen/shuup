# -*- coding: utf-8 -*-
# This file is part of Shuup Product Comparison.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_product_comparison"
    label = "shuup_product_comparison"
    provides = {
        "xtheme_plugin": [
            "shuup_product_comparison.plugins:ComparisonAddPlugin",
            "shuup_product_comparison.plugins:ShowComparisonPlugin",
        ],
        "xtheme_resource_injection": ["shuup_product_comparison.plugins:add_resources"],
        "front_urls": ["shuup_product_comparison.urls:urlpatterns"],
        "admin_extend_attribute_form": ["shuup_product_comparison.forms.AttributeFormExtension"]
    }
