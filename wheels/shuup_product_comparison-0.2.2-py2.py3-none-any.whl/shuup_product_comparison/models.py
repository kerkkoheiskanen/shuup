# -*- coding: utf-8 -*-
# This file is part of Shuup Product Comparison.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.db import models
from django.utils.translation import ugettext_lazy as _

from shuup.core.models import Attribute


class ComparableAttribute(models.Model):
    attribute = models.OneToOneField(Attribute,
                                     related_name='comparable', verbose_name=_('attribute'), primary_key=True)
