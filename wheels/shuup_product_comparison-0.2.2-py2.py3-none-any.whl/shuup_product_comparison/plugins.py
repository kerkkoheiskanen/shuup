# -*- coding: utf-8 -*-
# This file is part of Shuup Product Comparison.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django import forms
from django.templatetags.static import static
from django.utils.translation import ugettext_lazy as _

from shuup.core.models import Product
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.resources import add_resource


class ComparisonAddPlugin(TemplatedPlugin):
    identifier = "shuup_product_comparison.comparison_add"
    name = _("Product Comparison")
    template_name = "shuup_product_comparison/plugins/add_to_compare.jinja"
    required_context_variables = ['shop_product']

    fields = [
        ("show_text", forms.BooleanField(
            label=_("Show text next to icon"),
            required=False,
            initial=True,
        )),
    ]

    def get_context_data(self, context):
        context = super(ComparisonAddPlugin, self).get_context_data(context)
        context["show_text"] = self.config.get("show_text", True)
        return context


class ShowComparisonPlugin(TemplatedPlugin):
    identifier = "shuup_product_comparison.comparison_view"
    name = _("Product Comparison view")
    template_name = "shuup_product_comparison/plugins/comparison_view.jinja"

    def get_context_data(self, context):
        context = super(ShowComparisonPlugin, self).get_context_data(context)
        product_ids = context["request"].session.get("product_comparison")
        context["products"] = (Product.objects.filter(pk__in=product_ids) if product_ids else [])
        return context


def add_resources(context, content):
    request = context.get("request")
    if request:
        match = request.resolver_match
        # not a view match or the app is Shuup Admin
        if not match or match.app_name == "shuup_admin":
            return

    if not context.get("view"):
        return

    add_resource(context, "head_end", "%s?v=0.2.2.css" % static("shuup_product_comparison/css/style.css"))
    add_resource(context, "body_end", "%s?v=0.2.2.js" % static("shuup_product_comparison/js/scripts.js"))
