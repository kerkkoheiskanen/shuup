import pytest
from shuup.core.models import ProductMode, ProductPackageLink
from shuup.testing import factories
from shuup.testing.utils import apply_request_middleware

from shuup_subscriptions.checkout import SubscriptionBasket


@pytest.mark.django_db
def test_basket(rf):
    (shop, supplier, product, plan) = get_data()
    price = shop.create_price
    request = apply_request_middleware(rf.get("/"))

    basket = SubscriptionBasket(request)
    basket.add_product(supplier, shop, product, quantity=1)
    line = basket.get_subscription_parent_line()
    assert line
    assert line.quantity == 1
    assert line.price == price(0)
    assert basket.get_subscription_product() == product
    assert basket.total_price == price(0)
    basket.set_plan(plan)
    assert basket.total_price == price('9.95')
    assert basket.get_subscription_parent_line().price == price('9.95')


def get_data():
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    child1 = factories.create_product('CHILD1', shop, supplier, '11.50')
    child2 = factories.create_product('CHILD2', shop, supplier, '2.45')
    subs_product = factories.create_product('SUBS', shop, supplier)
    ProductPackageLink.objects.create(
        parent=subs_product, child=child1, quantity=0.5)
    ProductPackageLink.objects.create(
        parent=subs_product, child=child2, quantity=2)
    plan = subs_product.plans.create(
        shop=shop,
        is_active=True,
        amount=shop.create_price('9.95'))
    subs_product.save()
    assert subs_product.mode == ProductMode.SUBSCRIPTION
    return (shop, supplier, subs_product, plan)
