# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.


class TrialProvider(object):

    def __init__(self, subscription):
        self.subscription = subscription

    def is_in_trial_period(self, date):
        subscription = self.subscription
        if not subscription.plan.trial_period:
            return False
        start_date = subscription.start_date
        trial_end_date = subscription.get_free_trial_end_date()
        return (start_date <= date <= trial_end_date)

    def get_free_trial_end_date(self):
        return self.subscription.plan.get_free_trial_end_date(self.subscription)
