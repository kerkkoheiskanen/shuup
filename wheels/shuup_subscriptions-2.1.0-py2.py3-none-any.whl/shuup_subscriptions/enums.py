# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum


class PlanInterval(Enum):
    DAY = "day"
    WEEK = "week"
    TWO_WEEKS = "two_weeks"
    MONTH = "month"
    YEAR = "year"

    class Labels:
        DAY = _("daily")
        WEEK = _("weekly")
        TWO_WEEKS = _("every two weeks")
        MONTH = _("monthly")
        YEAR = _("yearly")


class SubscriptionCancellationMethod(Enum):
    IMMEDIATELY = 1
    PERIOD_END = 2
