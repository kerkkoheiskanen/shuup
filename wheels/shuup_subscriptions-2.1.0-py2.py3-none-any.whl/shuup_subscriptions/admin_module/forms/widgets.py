# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.core.urlresolvers import reverse_lazy
from shuup.admin.forms.widgets import QuickAddRelatedObjectMultiSelect


class QuickAddPlanSelect(QuickAddRelatedObjectMultiSelect):
    url = reverse_lazy("shuup_admin:subscription.plan.new")


class QuickPaymentProcessorPlanSelect(QuickAddRelatedObjectMultiSelect):
    url = reverse_lazy("shuup_admin:subscription.payment_processor_plan.new")
