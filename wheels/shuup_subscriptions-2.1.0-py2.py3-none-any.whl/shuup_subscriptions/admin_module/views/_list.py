# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.toolbar import NewActionButton, SettingsActionButton, Toolbar
from shuup.admin.utils.picotable import (
    Column, TextFilter, true_or_false_filter)
from shuup.admin.utils.views import PicotableListView

from shuup_subscriptions.models import Plan, Subscription, SubscriptionPayment


def _get_plan_name(plan):
    return plan.safe_translation_getter('name') or '{}'.format(plan)


class PlanListView(PicotableListView):
    model = Plan

    default_columns = [
        Column(
            "name", _("Name"), sort_field="translations__name",
            display=_get_plan_name,
            filter_config=TextFilter(filter_field="translations__name", placeholder=_("Filter by name..."))
        ),
        Column("is_active", _("Enabled"), filter_config=true_or_false_filter),
        Column("amount", _("Amount"), sort_field="amount_value"),
        Column("interval", _("Interval")),
    ]

    def get_toolbar(self):
        return Toolbar([
            NewActionButton("shuup_admin:subscription.plan.new"),
            SettingsActionButton.for_model(Plan, return_url="subscription.plan")
        ])


class SubscriptionListView(PicotableListView):
    model = Subscription

    default_columns = [
        Column(
            'subject', _("Subject"),
            sort_field="ordered_in_line__text",
            filter_config=TextFilter(
                filter_field="ordered_in_line__text",
                placeholder=_("Filter by subject..."))),
        Column(
            "plan", _(u"Plan"),
            filter_config=TextFilter(filter_field="plan__translations__name", placeholder=_("Filter by name..."))
        ),
        Column(
            "customer", _("Customer"),
            sort_field="customer",
            filter_config=TextFilter(filter_field="customer__email", placeholder=_("Filter by email..."))
        ),
        Column("start_date", _("Start Date")),
        Column("end_date", _("End Date")),
    ]

    def get_toolbar(self):
        return Toolbar([
            SettingsActionButton.for_model(Subscription, return_url="subscription.sub")
        ])


class SubscriptionPaymentListView(PicotableListView):
    model = SubscriptionPayment

    default_columns = [
        Column("subscription", _("Subscription"), sort_field="subscription"),
        Column("amount", _("Amount"), sort_field="amount_value"),
    ]

    def get_toolbar(self):
        return Toolbar([
            NewActionButton("shuup_admin:subscription.payment.new"),
            SettingsActionButton.for_model(Plan, return_url="subscription.payment")
        ])
