# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from shuup.core.models import ProductMode, ProductPackageLink

from ..models import Plan


def ensure_product_mode(sender, instance, *args, **kwargs):
    if ProductPackageLink.objects.filter(parent=instance).exists():
        if Plan.objects.filter(products__in=[instance]).exists():
            instance.mode = ProductMode.SUBSCRIPTION
            instance.external_url = None
            instance.variation_children.clear()
