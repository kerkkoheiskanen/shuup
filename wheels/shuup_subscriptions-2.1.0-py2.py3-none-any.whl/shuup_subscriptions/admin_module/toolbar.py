# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _
from shuup.admin.toolbar import DropdownItem


class ProductToolbarActionItem(DropdownItem):
    def __init__(self, object, **kwargs):
        is_parent = object.is_subscription_parent()
        kwargs["icon"] = "fa fa-female"
        kwargs["text"] = _("Manage subscription") if is_parent else _("Convert to a Subscription Product")
        kwargs["url"] = reverse("shuup_admin:subscription.subscription_product.edit", kwargs={"pk": object.pk})
        super(ProductToolbarActionItem, self).__init__(**kwargs)
