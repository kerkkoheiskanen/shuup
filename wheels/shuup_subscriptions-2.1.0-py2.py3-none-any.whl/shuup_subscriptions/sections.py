# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import Section

from shuup_subscriptions.models import SubscriptionPayment


class SubscriptionInformationSection(Section):
    identifier = "subscription_data"
    name = _("Information")
    icon = "fa-info-circle"
    template = "shuup_subscriptions/admin/subscriptions/sections/subscription.jinja"
    order = 1

    @staticmethod
    def visible_for_object(subscription):
        return bool(subscription.pk)


class SubscriptionContentsSection(Section):
    identifier = "subscription_contents"
    name = _("Subscribed products")
    icon = "fa-shopping-cart"
    template = "shuup_subscriptions/admin/subscriptions/sections/products.jinja"
    order = 2

    @staticmethod
    def visible_for_object(subscription):
        return bool(subscription.pk)

    @staticmethod
    def get_context_data(subscription):
        return subscription.get_contents()


class SubscriptionPaymentsSection(Section):
    identifier = "subscription_payments"
    name = _("Payments")
    icon = "fa-money"
    template = "shuup_subscriptions/admin/subscriptions/sections/payments.jinja"
    order = 3

    @staticmethod
    def visible_for_object(subscription):
        return bool(subscription.pk)

    @staticmethod
    def get_context_data(subscription):
        return SubscriptionPayment.objects.filter(subscription=subscription).distinct()[:100]
