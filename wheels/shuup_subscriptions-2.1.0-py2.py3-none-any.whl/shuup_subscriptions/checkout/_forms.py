# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _

from ..models import Plan


class SubscriptionPlanForm(forms.Form):
    plan = forms.ModelChoiceField(queryset=Plan.objects.none(), required=True, label=_("Plan"))

    def __init__(self, **kwargs):
        self.shop = kwargs.pop("shop")
        self.product = kwargs.pop("product")
        super(SubscriptionPlanForm, self).__init__(**kwargs)
        self.fields['plan'].queryset = self._get_plans()

    def _get_plans(self):
        return Plan.objects.active().filter(shop=self.shop, products__in=[self.product])

    def clean_plan(self):
        plan = self.cleaned_data["plan"]
        if not plan.is_valid_for_shop_and_product(self.shop, self.product):
            raise ValidationError(_("Plan is no longer available."))
        return plan
