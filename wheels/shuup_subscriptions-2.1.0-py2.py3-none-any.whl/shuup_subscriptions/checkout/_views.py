# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from shuup.front.basket import get_basket
from shuup.front.checkout import CheckoutProcess
from shuup.front.views.checkout import DefaultCheckoutView

from ..utils import classproperty
from ._basket import SubscriptionBasket


class SubscriptionCheckoutProcess(CheckoutProcess):
    @property
    def basket(self):
        return get_basket(
            self.phase_kwargs['request'],
            basket_name='subscription_basket',
            basket_class=SubscriptionBasket)


class SubscriptionCheckoutView(DefaultCheckoutView):
    url_namespace = "shuup:subscription_checkout"
    process_class = SubscriptionCheckoutProcess
    initial_phase = "subscription_plan"
    empty_phase_spec = None

    @classproperty
    @classmethod
    def phase_specs(cls):
        return [
            'shuup_subscriptions.checkout:SubscriptionPlanPhase',
        ] + super(SubscriptionCheckoutView, cls).phase_specs

    def get_url(self, **kwargs):
        kwargs.setdefault('product_id', self.kwargs.get('product_id'))
        return super(SubscriptionCheckoutView, self).get_url(**kwargs)
