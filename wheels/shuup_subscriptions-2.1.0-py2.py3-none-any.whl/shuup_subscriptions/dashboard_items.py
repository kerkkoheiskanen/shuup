# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the AGPLv3 license found in the
# LICENSE file in the root directory of this source tree.
from django.utils.translation import ugettext_lazy as _
from shuup.front.utils.dashboard import DashboardItem

from shuup_subscriptions.models import Subscription


class SubscriptionItem(DashboardItem):
    template_name = "shuup_subscriptions/front/dashboard_item.jinja"
    title = _("Subscriptions")
    icon = "fa fa-repeat"
    _url = "shuup:subscription.list"

    def get_context(self):
        context = super(SubscriptionItem, self).get_context()
        context["subscriptions"] = Subscription.objects.filter(customer=self.request.customer)
        return context
