# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from django.conf import settings
from shuup.admin.form_part import TemplatedFormDef
from shuup.admin.modules.products.forms import ProductImageMediaFormSet
from shuup.admin.modules.products.views.edit import \
    ProductBaseFormPart as BaseProductBaseFormPart
from shuup.admin.modules.products.views.edit import \
    ProductImageMediaFormPart as BaseProductImageMediaFormPart
from shuup.admin.modules.products.views.edit import \
    ShopProductFormPart as BaseShopProductFormPart
from shuup.core.models import ShippingMode

from shuup_multivendor.admin_module.forms.product import (
    VendorProductBaseForm, VendorShopProductForm
)


class VendorProductBaseFormPart(BaseProductBaseFormPart):
    def get_form_defs(self):
        yield TemplatedFormDef(
            "base",
            VendorProductBaseForm,
            template_name="shuup_multivendor/admin/products/_edit_base_form.jinja",
            required=True,
            kwargs={
                "instance": self.object.product,
                "languages": settings.LANGUAGES,
                "initial": self.get_initial(),
                "request": self.request
            }
        )
        yield TemplatedFormDef(
            "base_extra",
            forms.Form,
            template_name="shuup_multivendor/admin/products/_edit_extra_base_form.jinja",
            required=False
        )

    def get_initial(self):
        initial = super(VendorProductBaseFormPart, self).get_initial() or {}
        if not self.object.pk:
            if not initial.get("shipping_mode"):
                initial["shipping_mode"] = ShippingMode.NOT_SHIPPED
        return initial


class VendorShopProductFormPart(BaseShopProductFormPart):
    def get_form_defs(self):
        yield TemplatedFormDef(
            "shop%d" % self.shop.pk,
            VendorShopProductForm,
            template_name="shuup_multivendor/admin/products/_edit_shop_form.jinja",
            required=True,
            kwargs={
                "instance": self.object,
                "initial": self.get_initial(),
                "request": self.request,
                "languages": settings.LANGUAGES
            }
        )

        # the hidden extra form template that uses ShopProductForm
        yield TemplatedFormDef(
            "shop%d_extra" % self.shop.pk,
            forms.Form,
            template_name="shuup_multivendor/admin/products/_edit_extra_shop_form.jinja",
            required=False
        )


class VendorProductImageMediaFormPart(BaseProductImageMediaFormPart):
    formset = ProductImageMediaFormSet

    def get_form_defs(self):
        if not self.object.pk:
            return

        yield TemplatedFormDef(
            self.name,
            self.formset,
            template_name="shuup_multivendor/admin/products/_edit_media_form.jinja",
            required=False,
            kwargs={
                "product": self.object.product,
                "languages": settings.LANGUAGES,
                "request": self.request
            }
        )
