# -​*- coding: utf-8 -*​-
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType
from django.core.management import BaseCommand


class Command(BaseCommand):
    def handle(self, *args, **options):
        content_type = ContentType.objects.get_by_natural_key("shuup_multivendor", "supplieruser")
        Permission.objects.get_or_create(
            codename="manage_vendors", name="Can manage vendors", content_type=content_type)
        Permission.objects.get_or_create(
            codename="manage_orders", name="Can manage orders", content_type=content_type)
        Permission.objects.get_or_create(
            codename="manage_products", name="Can manage products", content_type=content_type)
        Permission.objects.get_or_create(
            codename="vendor_reports", name="Can generate vendor reports", content_type=content_type)
