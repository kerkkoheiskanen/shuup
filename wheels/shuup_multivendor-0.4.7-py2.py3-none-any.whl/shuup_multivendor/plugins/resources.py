# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from shuup.utils.djangoenv import has_installed
from shuup.xtheme.models import ThemeSettings
from shuup.xtheme.resources import add_resource


def add_resources(context, content):
    if not has_installed("shuup_sunrise_theme"):
        return

    from shuup_sunrise_theme.theme import ShuupSunriseTheme

    view_class = getattr(context["view"], "__class__", None) if context.get("view") else None
    if not view_class:
        return

    theme_settings = ThemeSettings.objects.filter(shop=context["request"].shop, active=True).first()
    is_sunrise = (theme_settings and theme_settings.theme_identifier == ShuupSunriseTheme.identifier)
    if getattr(view_class, "__name__", "") == "SupplierView" and is_sunrise:
        add_resource(context, "head_end", "%sshuup_multivendor/front.css?v=0.4.7.css" % settings.STATIC_URL)
