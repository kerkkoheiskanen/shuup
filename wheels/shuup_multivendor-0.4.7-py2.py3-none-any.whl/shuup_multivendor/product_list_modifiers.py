# -*- coding: utf-8 -*-
from decimal import Decimal

from django import forms
from django.conf import settings
from django.db.models import Q
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import Supplier
from shuup.front.forms.product_list_modifiers import SimpleProductListModifier
from shuup.front.utils.sorts_and_filters import (
    get_configuration, get_form_field_label
)
from shuup.utils.i18n import format_number

from shuup_multivendor.models import DistanceUnit


class VendorDistanceProductListFilter(SimpleProductListModifier):
    is_active_key = "filter_products_by_vendor_distance"
    is_active_label = _("Filter products by vendor distance")
    ordering_key = "filter_products_by_vendor_distance_ordering"
    ordering_label = _("Ordering for filter by vendor distance")
    choices_key = "filter_products_by_vendor_distance_choices_key"

    def get_fields(self, request, category=None):
        configuration = get_configuration(request.shop, category)
        choices = configuration.get(self.choices_key)
        distance_unit = DistanceUnit(settings.SHUUP_MULTIVENDOR_VENDOR_DISTANCE_UNIT)

        if not choices or not request.customer:
            return

        address_field = "default_{}".format(settings.SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS)
        address = getattr(request.customer, address_field, None)
        if not address:
            return

        latitude = address.latitude
        longitude = address.longitude
        if not (latitude and longitude):
            return

        field_choices = [(None, "-------")] + get_distance_ranges(choices.split(","), distance_unit)
        return [
            ("vendor_dist", forms.ChoiceField(
                required=False,
                choices=field_choices,
                label=get_form_field_label("vendor_dist", _("Vendor distance"))
            ))
        ]

    def get_filters(self, request, data):
        vendor_dist = data.get("vendor_dist")
        if not vendor_dist or not request.customer:
            return

        min_dist, max_dist = vendor_dist.split("-", 1)
        min_dist = Decimal(min_dist or 0)
        max_dist = Decimal(max_dist or 0)

        suppliers = Supplier.objects.filter(
            vendor_distances__contact=request.customer,
            shops=request.shop
        )
        if min_dist:
            suppliers = suppliers.filter(vendor_distances__distance__gte=min_dist)
        if max_dist:
            suppliers = suppliers.filter(vendor_distances__distance__lte=max_dist)

        return Q(shop_products__suppliers__in=suppliers)

    def get_admin_fields(self):
        default_fields = super(VendorDistanceProductListFilter, self).get_admin_fields()
        default_fields[0][1].help_text = _("Check this to allow products to be filtered by vendor distance.")
        default_fields[1][1].help_text = _(
            "Use a numeric value to set the order in which the vendor distance filter will appear on the "
            "product listing page."
        )
        choices = forms.CharField(
            label=_("Distances"),
            required=False,
            help_text=_("Enter a comma-separated list of distance ranges, e.g. 5,7.5,15.")
        )
        return default_fields + [
            (self.choices_key, choices)
        ]


def get_distance_ranges(distance_ranges, distance_unit):
    ranges = []
    if not distance_ranges or len(distance_ranges) < 2:
        return ranges

    for index, distance in enumerate(distance_ranges):
        if not distance:
            continue

        if index == 0:
            ranges.append(
                ("-%s" % distance, _("Under {min_limit} {unit}").format(
                    min_limit=format_number(distance),
                    unit=force_text(distance_unit).lower()
                ))
            )
        else:
            ranges.append(
                (
                    "%s-%s" % (distance_ranges[index-1], distance),
                    _("{min} {unit} to {max} {unit}").format(
                        min=format_number(distance_ranges[index-1]),
                        max=format_number(distance),
                        unit=force_text(distance_unit).lower()
                    )
                )
            )
            # the latest
            if index == len(distance_ranges) - 1:
                ranges.append(
                    ("%s-" % distance, _("{max_limit} {unit} & Above").format(
                        max_limit=distance,
                        unit=force_text(distance_unit).lower()
                    ))
                )

    return ranges


class VendorMapFilter(SimpleProductListModifier):
    is_active_key = "filter_products_by_vendor_map"
    is_active_label = _("Filter products by selected vendor on map")
    ordering_key = "ordering_products_by_vendor_map"

    def should_use(self, configuration):
        if not configuration:
            return
        return bool(configuration.get(self.is_active_key))

    def get_fields(self, request, category=None):
        return [
            ("vendor_map", forms.IntegerField(
                required=False,
                widget=forms.HiddenInput()
            ))
        ]

    def get_filters(self, request, data):
        vendor_map = data.get("vendor_map")
        if vendor_map:
            return Q(shop_products__suppliers__id=vendor_map)

    def get_admin_fields(self):
        return [
            (self.is_active_key, forms.BooleanField(label=self.is_active_label, required=False))
        ]
