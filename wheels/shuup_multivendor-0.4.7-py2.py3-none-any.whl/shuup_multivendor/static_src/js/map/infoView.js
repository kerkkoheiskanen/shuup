import m from "mithril";
import { getFormattedDistance } from "./utils";

function formatVendorAddress(address) {
    return [
        address.street,
        address.street2,
        address.street3,
        address.postal_code
    ].filter(value => value).join(", ");
}

export default {
    view(vnode) {
        const { vendor, showBrowseButton } = vnode.attrs;
        return m(".map-info-view",
            m(".vendor-details",
                vendor.logo ? m(".vendor-logo", m("img.vendor-logo-img", { src: vendor.logo })) : null,
                m("vendor-name-address",
                    m("p.vendor-name",
                        m("a", { href: vendor.detail_url }, m("strong", vendor.name))
                    ),
                    !!vendor.distance && (
                        m("p.vendor-distance.text-muted",
                            m.trust(interpolate(
                                gettext("Distance: <strong>%s</strong>"),
                                [getFormattedDistance(vendor.distance)]
                            ))
                        )
                    ),
                    m("p.vendor-address", formatVendorAddress(vendor.contact_address)),
                    !!vendor.number_of_products && (
                        m("p.vendor-items.text-muted",
                            m.trust(interpolate(
                                gettext("Number of products: <strong>%s</strong>"),
                                [vendor.number_of_products]
                            ))
                        )
                    )
                )
            ),
            showBrowseButton && (
                m(".vendor-action",
                    m("button.btn.btn-sm.btn-primary.btn-block", {
                        onclick: (e) => {
                            e.preventDefault();
                            vnode.attrs.onBrowsePress();
                        }
                    }, gettext("Browse products"))
                )
            )
        );
    }
};
