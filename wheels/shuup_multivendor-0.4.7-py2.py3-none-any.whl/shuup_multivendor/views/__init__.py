# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from .login import LoginView
from .map import VendorMapView
from .registration import (
    VendorRegistrationCompleteView, VendorRegistrationView
)
from .vendor import SupplierView

__all__ = [
    "LoginView",
    "SupplierView",
    "VendorRegistrationView",
    "VendorRegistrationCompleteView",
    "VendorMapView"
]
