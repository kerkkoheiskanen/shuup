# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.views.generic.detail import DetailView
from shuup.core.models import Product, Supplier
from shuup.front.utils.sorts_and_filters import (
    get_product_queryset, get_query_filters, post_filter_products,
    sort_products
)
from shuup.front.utils.views import cache_product_things


class SupplierView(DetailView):
    template_name = "shuup_multivendor/supplier/detail.jinja"

    def get_context_data(self, **kwargs):
        context = super(SupplierView, self).get_context_data(**kwargs)
        context["supplier"] = self.object

        data = self.request.GET
        from shuup.front.utils.sorts_and_filters import ProductListForm
        context["form"] = form = ProductListForm(
            request=self.request, shop=self.request.shop, category=None, data=data)
        form.full_clean()
        data = form.cleaned_data
        if "sort" in form.fields and not data.get("sort"):
            # Use first choice by default
            data["sort"] = form.fields["sort"].widget.choices[0][0]

        products = Product.objects.listed(
            customer=self.request.customer,
            shop=self.request.shop,
        ).filter(
            shop_products__shop=self.request.shop,
            variation_parent__isnull=True
        ).filter(get_query_filters(self.request, None, data=data))

        products = get_product_queryset(products, self.request, None, data).filter(
            shop_products__suppliers=self.object
        ).distinct()
        products = post_filter_products(self.request, None, products, data)
        products = cache_product_things(self.request, products)
        products = sort_products(self.request, None, products, data)
        context["products"] = products
        return context

    def get_queryset(self):
        return Supplier.objects.enabled().filter(shops=self.request.shop)
