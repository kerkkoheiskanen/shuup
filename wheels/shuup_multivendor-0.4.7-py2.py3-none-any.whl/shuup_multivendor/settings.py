# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

#: The default supplier module identifier used for vendors
#: Default: shuup.simple_supplier.module.SimpleSupplierModule.identifier
#:
SHUUP_MULTIVENDOR_SUPPLIER_MODULE_IDENTIFIER = "simple_supplier"

#: Indicates whether vendors can create their own products
#:
SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS = False

#: Whether vendor can share product with other vendors
#: This allows vendor to see all shop products in the system
#:
VENDOR_CAN_SHARE_PRODUCTS = False

#: List of countries that are allowed to register as a vendor
#:
SHUUP_MULTIVENDOR_REGISTRATION_COUNTRIES = []

#: Whether vendor has been approved before option to login
#:
SHUUP_MULTIVENDOR_VENDOR_REQUIRES_APPROVAL = False

#: Indicates whether the geolocation coordinates of the vendor
#: and contacts should be ensured using Google Maps.
#:
#: When this settings is `True` and a vendor or contact address is saved,
#: the app will check whether the address contains a valid geolocation (latitude, longitude).
#: If it is not valid or blank, Google Maps will be used to try geocoding the address
#: and filling that information. Google Maps API Key information is required.
#:
SHUUP_MULTIVENDOR_ENSURE_ADDRESS_GEOPOSITION = False

#: Google Maps API Key used to geocode the address when
#: `SHUUP_MULTIVENDOR_ENSURE_ADDRESS_GEOPOSITION` is enabled
#:
SHUUP_MULTIVENDOR_GOOGLE_MAPS_KEY = None

#: Indicates whether the vendor distance from contacts should be calculated automatically.
#:
SHUUP_MULTIVENDOR_CALCULATE_VENDOR_DISTANCE = False

#: Indicates the unit of distance that should be used to store distances.
#: Valid options are: "km" (default) and "mi"
#:
SHUUP_MULTIVENDOR_VENDOR_DISTANCE_UNIT = "km"

#: Indicates which Contact address should be used to calculate distance
#:
SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS = "shipping_address"

#: Spec that indicates which address model form should be used for vendor
#:
SHUUP_MULTIVENDOR_ADDRESS_FORM = "shuup.core.utils.forms.MutableAddressForm"

#: List of default permissions for staff user group
#:
STAFF_USER_GROUP_PERMISSIONS = [
    'Attributes',
    'Categories',
    'Contacts',
    'Customers Dashboard',
    'Media',
    'Notifications',
    'Orders',
    'Products',
    'Product Types',
    'Reports',
    'Sales Dashboard',
    'Shuup Support',
    'Vendors Management',
    'attribute.new',
    'attribute.edit',
    'attribute.list',
    'attribute.list_settings',
    'category.copy_visibility',
    'category.delete',
    'category.edit',
    'category.list',
    'category.list_settings',
    'category.new',
    'contact.detail',
    'contact.edit',
    'contact.list',
    'contact.list_settings',
    'contact.mass_edit',
    'contact.mass_edit_group',
    'contact.new',
    'contact.reset_password',
    'coupon.edit',
    'coupon.list',
    'coupon.list_settings',
    'coupon.new',
    'customer_tax_group.edit',
    'customer_tax_group.list',
    'customer_tax_group.list_settings',
    'customer_tax_group.new',
    'media.browse',
    'media.upload',
    'multivendor_vendors_summary_report',
    'notify.script.new',
    'notify.script.edit-content',
    'notify.script.edit',
    'notify.script.list',
    'notify.script-template',
    'notify.script-template-edit',
    'notify.mark-read',
    'notify.script-item-editor',
    'notify.script-template-config',
    'order.create-full-refund',
    'order.create-payment',
    'order.create-refund',
    'order.create-shipment',
    'order.delete-payment',
    'order.delete-shipment',
    'order.detail',
    'order.edit',
    'order.edit-addresses',
    'order.list',
    'order.new-log-entry',
    'order.set-paid',
    'order.set-status',
    'order.update-admin-comment',
    'printouts.confirmation_pdf',
    'product_type.list_settings',
    'product_type.edit',
    'product_type.new',
    'product_type.list',
    'reports.list',
    'shop_product.add_media',
    'shop_product.delete',
    'shop_product.edit',
    'shop_product.edit_cross_sell',
    'shop_product.edit_media',
    'shop_product.edit_package',
    'shop_product.edit_variation',
    'shop_product.list',
    'shop_product.mass_edit',
    'shop_product.new',
    'shuup_multivendor.dashboard.supplier',
    'shuup_multivendor.vendor.edit',
    'shuup_multivendor.vendor.list',
    'shuup_multivendor.vendor.new',
    'shuup_multivendor.vendor.login-as',
    'shuup_product_reviews.add_productreview',
    'shuup_product_reviews.change_productreview',
    'shuup_product_reviews.delete_productreview'
]

#: List of default permissions for vendor user group
#:
VENDOR_USER_GROUP_PERMISSIONS = [
    'Reports',
    'Vendor Orders',
    'Vendor Products',
    'Vendor Sales Dashboard',
    'Vendor Settings',
    'Vendor Discounts',
    'media.upload',
    'multivendor_full_sales_report',
    'multivendor-product-report',
    'multivendor_sales_report',
    'reports.list',
    'shuup_multivendor.create_shipment',
    'shuup_multivendor.set_line_status',
    'shuup_multivendor.dashboard.supplier',
    'shuup_multivendor.order_line_list',
    'shuup_multivendor.order_list',
    'shuup_multivendor.products_list',
    'shuup_multivendor.products_new',
    "shuup_multivendor.products_edit",
    "shuup_multivendor.products_delete",
    'shuup_multivendor.products_set_price',
    'shuup_multivendor.products_toggles_sale',
    'shuup_multivendor.reports.list',
    'shuup_multivendor.vendor.settings',
    'simple_supplier.alert_limits',
    'simple_supplier.stocks',
    'simple_supplier.stock_managed',
    'vendor_discounts.archive',
    'vendor_discounts.delete',
    'vendor_discounts.edit',
    'vendor_discounts.list',
    'vendor_discounts.new',
    'vendor_discounts.list_settings'
]
