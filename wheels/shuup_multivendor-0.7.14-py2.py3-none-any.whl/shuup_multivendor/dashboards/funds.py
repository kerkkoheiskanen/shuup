# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.dashboard import DashboardMoneyBlock

from shuup_multivendor.models import VendorFunds


def get_vendor_funds_block(vendor, currency):
    return DashboardMoneyBlock(
        id="vendor_funds_block",
        color="green",
        title=_("Vendor funds"),
        value=VendorFunds.get_funds(vendor, currency).value,
        currency=currency
    )
