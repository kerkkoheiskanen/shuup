# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from datetime import timedelta

from django.views.generic.base import TemplateView
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import Order
from shuup.utils import dates

from shuup_multivendor.dashboards.blocks import (
    get_avg_purchase_size_block, get_favorite_categories_block,
    get_favorite_products_block, get_lifetime_sales_block,
    get_new_customers_block, get_returning_customers_block,
    get_vendor_order_chart_dashboard_block
)
from shuup_multivendor.dashboards.funds import get_vendor_funds_block
from shuup_multivendor.utils.funds import is_vendor_funds_enabled


class SupplierDashboardView(TemplateView):
    template_name = "shuup_multivendor/admin/dashboard/dashboard.jinja"

    def get_context_data(self, **kwargs):
        context = super(SupplierDashboardView, self).get_context_data(**kwargs)
        request = self.request
        shop = get_shop(request)

        # For daily sales blocks let's use 4am as a cutoff time
        # 1. Before 4am we show sales from 4am yesterday
        # 2. After 4am we show sales from 4am today
        local_now = dates.local_now()
        four_am_today = local_now.replace(hour=4, minute=0, second=0)
        blocks = [
            ("block_30d", timedelta(days=30)),
            ("block_7d", timedelta(days=7)),
            ("block_daily", (four_am_today if local_now > four_am_today else four_am_today - timedelta(days=1)))
        ]

        supplier = get_supplier(request)
        if supplier:
            if is_vendor_funds_enabled(shop):
                context["blocks"] = [
                    get_vendor_funds_block(supplier, shop.currency)
                ]

            for block_id, delta in blocks:
                cutoff_date = (local_now - delta) if isinstance(delta, timedelta) else delta

                completed_order_ids = Order.objects.valid().filter(
                    shop_id=shop.id, order_date__gte=cutoff_date, lines__supplier=supplier).values_list("id", flat=True)

                if len(completed_order_ids) == 0:
                    continue

                context[block_id] = [
                    get_new_customers_block(shop.id, completed_order_ids, supplier, cutoff_date),
                    get_returning_customers_block(shop.id, completed_order_ids, supplier, cutoff_date),
                    get_lifetime_sales_block(completed_order_ids, supplier, shop.currency),
                    get_avg_purchase_size_block(completed_order_ids, supplier, shop.currency),
                    get_favorite_categories_block(request, shop.id, supplier, completed_order_ids),
                    get_favorite_products_block(request, shop.id, supplier, completed_order_ids)
                ]

                if block_id == "block_30d":
                    context[block_id] += [
                        get_vendor_order_chart_dashboard_block(request, shop.currency)
                    ]

        return context
