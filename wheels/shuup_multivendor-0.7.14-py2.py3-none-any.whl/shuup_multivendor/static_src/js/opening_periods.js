var moment = require('moment-timezone');

$(function() {
    const timezoneGuess = moment.tz.guess();
    window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE = timezoneGuess;

    function renderSchedule() {
        const headRow = $('<tr />').append($('<td />'));

        const timezoneSelect = (window.SUPPLIER_OPENING_PERIODS_TIMEZONES.length > 0);
        const selectID = "supplier-opening-hours-timezone-select";
        if (timezoneSelect) {
            const select = $('<select />')
                .addClass("pull-right selectpicker")
                .attr("id", selectID);
            let selectedOption = $('<option />')
                .attr("value", window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE)
                .attr("selected", "selected")
                .text(window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE.replace("_", " "));
            select.append(selectedOption)

            if (!window.SUPPLIER_OPENING_PERIODS_TIMEZONES.includes(timezoneGuess)) {
                window.SUPPLIER_OPENING_PERIODS_TIMEZONES.push(timezoneGuess);
            }

            window.SUPPLIER_OPENING_PERIODS_TIMEZONES.sort();
            $.each(window.SUPPLIER_OPENING_PERIODS_TIMEZONES, (idx, value) => {
                if (window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE != value) {
                    let option = $('<option />')
                        .attr("value", value)
                        .text(value.replace("_", " "));  // for America/New_York for example
                    select.append(option);
                }
            });

            headRow.append($(`<td></td>`).append(select));
        } else {
            headRow
                .append($(`<td><small>${window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE}</small></td>`)
                .addClass("pull-right text-small"));
        }

        const thead = $('<thead />').append(headRow);

        const tbody = $('<tbody />');
        $.each(window.SUPPLIER_OPENING_PERIODS, (day, values) => {
            let item = $('<tr />');
            item.append($(`<td>${gettext(day)}</td>`));
            let openingHours = [];
            $.each(values, (idx, value) => {
                parts = value.split("-");
                if (parts.length == 2) {
                    let start = moment(`${parts[0]} ${window.SUPPLIER_OPENING_PERIODS_TIMEZONE_OFFSET}`, "HH:mm Z")
                        .tz(window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE)
                    let end = moment(`${parts[1]} ${window.SUPPLIER_OPENING_PERIODS_TIMEZONE_OFFSET}`, "HH:mm Z")
                        .tz(window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE)
                    openingHours.push(`${start.format("LT")} - ${end.format("LT")}`);
                }
            });
            item.append($(`<td>${openingHours.join(", ")}</td>`));
            tbody.append(item);
        });

        const table = $('<table />').addClass('table table-striped');
        table.append(thead)
        table.append(tbody);
        $("#supplier-opening-hours-container").html(table);

        if (timezoneSelect) {
            $(".selectpicker").selectpicker();
            $(`#${selectID}`).on("change", (e) => {
                window.SUPPLIER_OPENING_PERIODS_SELECTED_TIMEZONE = e.target.value;
                renderSchedule();
            });
        }
    }

    if (window.SUPPLIER_OPENING_PERIODS) {
        renderSchedule();
    }
});
