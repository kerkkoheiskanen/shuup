# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.contrib.auth.models import Group
from django.core.management import BaseCommand
from django.utils.translation import activate
from shuup.core.models import Shop

from shuup_multivendor.models import SupplierUser
from shuup_multivendor.utils.permissions import (
    ensure_staff_permission_group_permissions,
    ensure_vendor_permission_group_permissions,
    set_staff_permission_group_for_shop, set_vendor_permission_group_for_shop
)


class Command(BaseCommand):
    def handle(self, *args, **options):
        activate(settings.PARLER_DEFAULT_LANGUAGE_CODE)

        for shop in Shop.objects.all():
            staff_group, _ = Group.objects.get_or_create(name="Shop-%s-Staff" % shop.pk)
            ensure_staff_permission_group_permissions(staff_group)
            set_staff_permission_group_for_shop(shop, staff_group)
            for user in shop.staff_members.all():
                user.groups.add(staff_group)

            vendor_group, _ = Group.objects.get_or_create(name="Shop-%s-Vendor-Users" % (shop.pk))
            ensure_vendor_permission_group_permissions(vendor_group)
            set_vendor_permission_group_for_shop(shop, vendor_group)
            for user in SupplierUser.objects.filter(shop=shop):
                user.groups.add(vendor_group)
