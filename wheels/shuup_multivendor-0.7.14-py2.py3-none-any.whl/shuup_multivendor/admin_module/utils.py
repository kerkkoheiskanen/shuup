# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import OrderStatus

from shuup_multivendor.utils.order import is_order_completed, is_order_initial


def get_order_status_for_supplier(request, order):
    supplier = get_supplier(request)

    if is_order_initial(order, supplier):
        return OrderStatus.objects.get_default_initial()

    if is_order_completed(order, supplier):
        return OrderStatus.objects.get_default_complete()

    return OrderStatus.objects.get_default_processing()
