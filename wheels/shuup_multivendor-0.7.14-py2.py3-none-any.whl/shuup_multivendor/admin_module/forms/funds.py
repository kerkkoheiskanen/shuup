# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from decimal import Decimal

from django import forms
from django.utils.translation import ugettext_lazy as _

from shuup_multivendor.models import VendorFunds
from shuup_multivendor.utils.funds import (
    get_minimum_withdraw_amount, get_withdraw_help_text
)


class FundsBaseForm(forms.Form):
    amount = forms.DecimalField(label="Amount to withdraw")

    def __init__(self, *args, **kwargs):
        self.shop = kwargs.pop("shop")
        self.vendor = kwargs.pop("vendor")
        super(FundsBaseForm, self).__init__(*args, **kwargs)

    def get_withdraw_help_text(self):
        return get_withdraw_help_text(self.shop)

    def get_funds_availalbe_for_withdraw(self):
        return VendorFunds.get_funds_formatted(self.vendor, self.shop.currency)

    def clean(self):
        data = super(FundsBaseForm, self).clean()
        amount = data.get("amount")
        minimum_amount = get_minimum_withdraw_amount(self.shop)
        if amount and minimum_amount and amount < Decimal(minimum_amount):
            self.add_error(
                "amount",
                _("Withdrawal minimum is %(withdrawal_minimum)s") % {"withdrawal_minimum": minimum_amount}
            )

        if amount and amount > VendorFunds.get_funds(self.vendor, self.shop.currency).value:
            self.add_error("amount", _("Amount exceeds funds available for withdrawal"))

        return data


class WireForm(FundsBaseForm):
    routing_number = forms.CharField(label=_("ABA/Routing number of the receiving bank"))
    receiving_bank_name = forms.CharField(label=_("Name of the receiving bank"))
    receiving_bank_address = forms.CharField(label=_("Address of the receiving bank"))
    receiving_bank_phone = forms.CharField(label=_("Phone number of the receiving bank"))
    recipients_bank_account_number = forms.CharField(label=_("Recipient's bank account number"))


class WireFormEU(FundsBaseForm):
    iban = forms.CharField(label="IBAN")
    swift = forms.CharField(label="SWIFT")
    bank_name = forms.CharField(label=_("Bank name"))
    receiving_bank_phone = forms.CharField(label=_("Recipient name"))


class PaypalForm(FundsBaseForm):
    paypal_email = forms.CharField(label=_("PayPal email"))
