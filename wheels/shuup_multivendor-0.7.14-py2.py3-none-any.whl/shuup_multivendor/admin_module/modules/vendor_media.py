# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule
from shuup.admin.utils.urls import admin_url


class MultivendorMediaAdminModule(AdminModule):
    name = _("Vendor Media")

    def get_urls(self):
        return [
            admin_url(
                "^vendor/(?P<pk>\d+)/media/add/$",
                "shuup_multivendor.admin_module.views.vendor_media.VendorMediaBulkAdderView",
                name="shuup_multivendor.attach_media"
            ),
            admin_url(
                "^vendor/media/upload/$",
                "shuup_multivendor.admin_module.views.vendor_media.media_upload",
                name="shuup_multivendor.upload_media"
            )
        ]
