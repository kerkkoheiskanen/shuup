# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import CONTENT_MENU_CATEGORY
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.urls import admin_url, get_edit_and_list_urls


class MultivendorSimpleCMSAdminModule(AdminModule):
    name = _("Vendor Content Pages")
    breadcrumbs_menu_entry = MenuEntry(name, "shuup_admin:multivendor_simple_cms.page.list")

    def get_required_permissions(self):
        return ("Vendor Content Pages", )

    def get_urls(self):
        url_prefix = "^cms/multivendor/page"
        view_template = "shuup_multivendor.admin_module.views.MVPage%sView"
        name_template = "multivendor_simple_cms.page.%s"
        return get_edit_and_list_urls(
            url_prefix=url_prefix,
            view_template=view_template,
            name_template=name_template,
        ) + [admin_url(
            r"%s/delete/(?P<pk>\d+)/" % url_prefix,
            view_template % "Delete",
            name=name_template % "delete",
            permissions=(name_template % "delete",)
        ), ]

    def get_menu_entries(self, request):
        if not get_supplier(request):
            return []

        return [
            MenuEntry(
                text=_("Pages"),
                icon="fa fa-file-text",
                url="shuup_admin:multivendor_simple_cms.page.list",
                category=CONTENT_MENU_CATEGORY,
                subcategory="elements",
                ordering=3,
                aliases=[_("Show pages")]
            )
        ]
