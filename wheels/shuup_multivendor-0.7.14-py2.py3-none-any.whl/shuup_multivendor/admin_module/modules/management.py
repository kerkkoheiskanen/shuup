# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import SETTINGS_MENU_CATEGORY
from shuup.admin.utils.urls import admin_url, get_edit_and_list_urls


class MultivendorVendorAdminModule(AdminModule):
    name = _("Vendors Management")
    breadcrumbs_menu_entry = MenuEntry(text=name, url="shuup_admin:shuup_multivendor.vendor.list")

    def get_urls(self):
        return get_edit_and_list_urls(
            url_prefix="^vendor",
            view_template="shuup_multivendor.admin_module.views.Vendor%sView",
            name_template="shuup_multivendor.vendor.%s",
        ) + [
            admin_url(
                r"^vendor/(?P<pk>\d+)/login-as/$",
                "shuup_multivendor.admin_module.views.LoginAsVendorView",
                name="shuup_multivendor.vendor.login-as",
            ),
            admin_url(
                r"^vendor/delete/(?P<pk>\d+)/$",
                "shuup_multivendor.admin_module.views.VendorDeleteView",
                name="shuup_multivendor.vendor.delete",
            )
        ]

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=self.name,
                icon="fa fa-list",
                url="shuup_admin:shuup_multivendor.vendor.list",
                category=SETTINGS_MENU_CATEGORY,
                subcategory="other_settings"
            )
        ]
