# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

import six
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.admin.shop_provider import get_shop
from shuup.core.models import get_person_contact

from shuup_multivendor.admin_module.forms.funds import (
    PaypalForm, WireForm, WireFormEU
)
from shuup_multivendor.models import VendorFunds
from shuup_multivendor.utils.funds import (
    is_paypal_withdraw_enabled, is_vendor_funds_enabled,
    is_wire_transfer_eu_withdraw_enabled, is_wire_transfer_withdraw_enabled
)


class BaseVendorFundsFormPart(FormPart):
    priority = 90
    name = ""
    form_class = None
    data_key = ""
    template_name = ""

    def get_form_defs(self):
        shop = get_shop(self.request)
        if not self.should_show(shop, self.object):
            return

        yield TemplatedFormDef(
            self.name,
            form_class=self.form_class,
            template_name=self.template_name,
            required=False,
            kwargs={
                "initial": self.get_initial(),
                "vendor": self.object,
                "shop": shop
            }
        )

    def should_show(self, shop, vendor):
        pass

    def get_initial(self):
        vendor = self.object
        if not vendor.options:
            return {}
        return vendor.options.get(self.data_key, "")

    def save_initial_data(self, data):
        vendor = self.object
        options = vendor.options or {}
        options.update({self.data_key: data})
        vendor.options = options
        vendor.save(update_fields=("options",))

    def form_valid(self, form):
        if self.name not in form.forms:
            return

        withdraw_form = form[self.name]
        if withdraw_form.changed_data:
            data = withdraw_form.cleaned_data
            amount = data.pop("amount")
            customer = get_person_contact(self.request.user)
            shop = get_shop(self.request)
            vendor = self.object
            self.save_initial_data(data)
            info = ""
            for key, value in six.iteritems(data):
                info += "%s: %s\n" % (key.capitalize(), value)

            VendorFunds.create_withdrawal(shop, vendor, customer, amount, shop.currency, info)
            messages.success(self.request, _("Withdrawal created successfully."))


class VendorFundsWireFormPart(BaseVendorFundsFormPart):
    priority = 91
    name = "funds_wire_transfer"
    form_class = WireForm
    data_key = "shuup_multivendor_funds_wire_transfer_data"
    template_name = "shuup_multivendor/admin/vendor/withdraw_template_wire_transfer.jinja"

    def should_show(self, shop, vendor):
        if not is_vendor_funds_enabled(shop):
            return False
        if not is_wire_transfer_withdraw_enabled(shop):
            return False
        return True


class VendorFundsWireEUFormPart(BaseVendorFundsFormPart):
    priority = 92
    name = "funds_wire_transfer_eu"
    form_class = WireFormEU
    data_key = "shuup_multivendor_funds_wire_eu_transfer_data"
    template_name = "shuup_multivendor/admin/vendor/withdraw_template_eu_wire_transfer.jinja"

    def should_show(self, shop, vendor):
        if not is_vendor_funds_enabled(shop):
            return False
        if not is_wire_transfer_eu_withdraw_enabled(shop):
            return False
        return True


class VendorFundsPaypalFormPart(BaseVendorFundsFormPart):
    priority = 93
    name = "funds_paypal"
    form_class = PaypalForm
    data_key = "shuup_multivendor_funds_paypal_data"
    template_name = "shuup_multivendor/admin/vendor/withdraw_template_paypal.jinja"

    def should_show(self, shop, vendor):
        if not is_vendor_funds_enabled(shop):
            return False
        if not is_paypal_withdraw_enabled(shop):
            return False
        return True
