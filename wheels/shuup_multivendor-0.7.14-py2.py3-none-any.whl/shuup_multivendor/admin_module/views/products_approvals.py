# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

from django.contrib import messages
from django.core.urlresolvers import reverse
from django.db.models import Q
from django.http.response import HttpResponseRedirect
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _
from django.views.generic import DetailView
from shuup.admin.modules.products.views.list import ProductListView
from shuup.admin.shop_provider import get_shop
from shuup.admin.toolbar import DropdownItem
from shuup.admin.utils.forms import flatatt_filter
from shuup.admin.utils.permissions import get_missing_permissions
from shuup.admin.utils.picotable import PicotableMassAction
from shuup.core.models import Product, ShopProduct
from shuup.core.utils import context_cache
from six import string_types

from shuup_multivendor.utils.product import (
    filter_product_waiting_approval, is_shop_product_approved,
    revoke_shop_product_approval, set_shop_product_approved)


class ApproveMassAction(PicotableMassAction):
    label = _("Set approved")
    identifier = "mass_action_product_approved"

    @staticmethod
    def process(request, ids):
        shop = get_shop(request)

        if isinstance(ids, string_types) and ids == "all":
            query = Q(shop=shop)
        else:
            query = Q(product__pk__in=ids, shop=shop)

        for shop_product in ShopProduct.objects.filter(query).iterator():
            set_shop_product_approved(shop_product, request.user)
            context_cache.bump_cache_for_shop_product(shop_product)


class ProductsApprovals(ProductListView):
    mass_actions = ["shuup_multivendor.admin_module.views.products_approvals:ApproveMassAction"]
    toolbar_buttons_provider_key = ""
    mass_actions_provider_key = ""

    def __init__(self):
        super(ProductsApprovals, self).__init__()

    def get_queryset(self):
        return filter_product_waiting_approval(super(ProductsApprovals, self).get_queryset())

    def get_toolbar(self):
        return None


class ApprovalsBaseView(DetailView):
    model = Product
    context_object_name = "product"

    def get_queryset(self):
        return super(ApprovalsBaseView, self).get_queryset().filter(shop_products__shop=get_shop(self.request))

    def do_action(self, request):
        pass

    def get(self, request, *args, **kwargs):
        return self.do_action(request)


class ApproveProductView(ApprovalsBaseView):
    def do_action(self, request):
        shop_product = self.get_object().get_shop_instance(get_shop(request))
        set_shop_product_approved(shop_product, request.user)
        context_cache.bump_cache_for_shop_product(shop_product)
        messages.success(request, _("%s has been approved successfully.") % shop_product.product)
        return HttpResponseRedirect(reverse("shuup_admin:shop_product.edit", kwargs=dict(pk=shop_product.pk)))


class RevokeProductApprovalView(ApprovalsBaseView):
    def do_action(self, request):
        shop_product = self.get_object().get_shop_instance(get_shop(request))
        revoke_shop_product_approval(shop_product, request.user)
        context_cache.bump_cache_for_shop_product(shop_product)
        messages.success(request, _("Approval for %s has been revoked successfully.") % shop_product.product)
        return HttpResponseRedirect(reverse("shuup_admin:shop_product.edit", kwargs=dict(pk=shop_product.pk)))


class ApproveProductAction(DropdownItem):
    def __init__(self, object, **kwargs):
        self.product = object
        kwargs["url"] = reverse("shuup_admin:shuup_multivendor.products_approvals_approve", kwargs={"pk": object.pk})
        kwargs["icon"] = "fa fa-check"
        kwargs["text"] = _("Approve product")
        kwargs["required_permissions"] = ("shuup_multivendor.products_approvals_approve",)
        super(ApproveProductAction, self).__init__(**kwargs)

    def render(self, request):
        shop_product = self.product.get_shop_instance(get_shop(request))
        if (
            not get_missing_permissions(request.user, self.required_permissions) and
            not is_shop_product_approved(shop_product)
        ):
            attrs = {
                "class": "dropdown-item",
                "title": self.tooltip,
                "href": self.url,
                "onclick": (mark_safe(self.onclick) if self.onclick else None)
            }
            yield '<a %s>' % flatatt_filter(attrs)
            yield self.render_label()
            yield '</a>'


class RevokeProductApprovalAction(DropdownItem):
    def __init__(self, object, **kwargs):
        self.product = object
        kwargs["url"] = reverse("shuup_admin:shuup_multivendor.products_approvals_revoke", kwargs={"pk": object.pk})
        kwargs["icon"] = "fa fa-remove"
        kwargs["text"] = _("Revoke product approval")
        kwargs["required_permissions"] = ("shuup_multivendor.products_approvals_revoke",)
        super(RevokeProductApprovalAction, self).__init__(**kwargs)

    def render(self, request):
        shop_product = self.product.get_shop_instance(get_shop(request))
        if (
            not get_missing_permissions(request.user, self.required_permissions) and
            is_shop_product_approved(shop_product)
        ):
            attrs = {
                "class": "dropdown-item",
                "title": self.tooltip,
                "href": self.url,
                "onclick": (mark_safe(self.onclick) if self.onclick else None)
            }
            yield '<a %s>' % flatatt_filter(attrs)
            yield self.render_label()
            yield '</a>'
