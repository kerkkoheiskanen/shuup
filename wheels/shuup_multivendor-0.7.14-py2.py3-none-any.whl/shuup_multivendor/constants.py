# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum


class DayOfTheWeek(Enum):
    Monday = "monday"
    Tuesday = "tuesday"
    Wednesday = "wednesday"
    Thursday = "thursday"
    Friday = "friday"
    Saturday = "saturday"
    Sunday = "sunday"

    class Labels:
        Monday = _("Monday")
        Tuesday = _("Tuesday")
        Wednesday = _("Wednesday")
        Thursday = _("Thursday")
        Friday = _("Friday")
        Saturday = _("Saturday")
        Sunday = _("Sunday")
