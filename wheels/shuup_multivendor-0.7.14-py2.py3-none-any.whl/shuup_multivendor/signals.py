# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.dispatch import Signal

vendor_registered = Signal(providing_args=["shop", "vendor", "user", "person_contact"], use_caching=True)
vendor_approved = Signal(providing_args=["shop", "vendor", "request"], use_caching=True)
order_line_status_changed = Signal(
    providing_args=["order", "order_line", "vendor", "vendor_user", "previous_status", "new_status"],
    use_caching=True
)
all_order_lines_completed = Signal(providing_args=["order"], use_caching=True)
vendor_order_completed = Signal(providing_args=["vendor", "order", "lines"], use_caching=True)
vendor_withdrawal_requested = Signal(
    providing_args=["order", "vendor", "amount_value", "currency", "info"],
    use_caching=True
)
vendor_pre_save = Signal(providing_args=["request", "shop", "supplier", "instance"])
vendor_product_pre_save = Signal(providing_args=["request", "shop", "supplier", "instance"])
vendor_shop_product_saved = Signal(providing_args=["shop_product", "request"])
vendor_shop_product_approved = Signal(providing_args=["shop_product", "is_auto_approved", "user"])
vendor_shop_product_approval_revoked = Signal(providing_args=["shop_product", "user"])
