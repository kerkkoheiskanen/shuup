# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.conf import settings
from django.contrib.auth.forms import UserCreationForm
from django.db.transaction import atomic
from django.utils.translation import ugettext_lazy as _
from shuup.apps.provides import get_provide_objects
from shuup.core.models import PersonContact, Supplier
from shuup.utils.form_group import FormGroup
from shuup.utils.importing import cached_load

from shuup_multivendor.models import SupplierUser
from shuup_multivendor.signals import vendor_registered


class VendorRegistrationUserForm(UserCreationForm):
    def __init__(self, *args, **kwargs):
        super(VendorRegistrationUserForm, self).__init__(*args, **kwargs)
        self.fields["username"].widget.attrs.pop("autofocus", None)


class VendorRegistrationCustomFieldsForm(forms.Form):
    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request", None)
        super(VendorRegistrationCustomFieldsForm, self).__init__(*args, **kwargs)

        provide_objects = (
            list(get_provide_objects("multivendor_registration_field_provider")) +
            list(get_provide_objects("front_registration_field_provider"))
        )

        for provider_cls in provide_objects:
            provider = provider_cls()
            for definition in provider.get_fields(request=self.request):
                self.fields[definition.name] = definition.field


class VendorRegistrationPersonForm(forms.ModelForm):
    class Meta:
        model = PersonContact
        fields = ["first_name", "last_name", "email", "phone"]

    def __init__(self, **kwargs):
        super(VendorRegistrationPersonForm, self).__init__(**kwargs)
        for (field_name, formfield) in self.fields.items():
            if field_name in ["first_name", "last_name", "email"]:
                formfield.required = True
                formfield.help_text = None


class VendorRegistrationBaseForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = ["name"]

    def __init__(self, **kwargs):
        super(VendorRegistrationBaseForm, self).__init__(**kwargs)
        if "name" in self.fields:
            self.fields["name"].label = _("Vendor name")
            self.fields["name"].help_text = None

    def save(self, commit=True):
        self.instance.stock_managed = True
        self.instance.module_identifier = settings.SHUUP_MULTIVENDOR_SUPPLIER_MODULE_IDENTIFIER
        self.instance.is_approved = False
        return super(VendorRegistrationBaseForm, self).save(commit)


class VendorRegistrationForm(FormGroup):
    def __init__(self, *args, **kwargs):
        vendor_address_form = cached_load("SHUUP_MULTIVENDOR_ADDRESS_FORM")
        self.request = kwargs.pop("request")
        super(VendorRegistrationForm, self).__init__(*args, **kwargs)
        self.add_form_def("vendor_user", form_class=VendorRegistrationUserForm)
        self.add_form_def("vendor_person", form_class=VendorRegistrationPersonForm)
        self.add_form_def("vendor_base", form_class=VendorRegistrationBaseForm)
        self.add_form_def("vendor_address", form_class=vendor_address_form)
        self.add_form_def(
            "vendor_custom",
            form_class=VendorRegistrationCustomFieldsForm,
            kwargs=dict(request=self.request)
        )

    def instantiate_forms(self):
        super(VendorRegistrationForm, self).instantiate_forms()
        vendor_address_form = self.forms["vendor_address"]

        if "name" in vendor_address_form.fields:
            vendor_address_form.fields["name"].required = False  # added from vendor name

        for field in list(vendor_address_form.fields):
            vendor_address_form.fields[field].help_text = None

        if settings.SHUUP_MULTIVENDOR_REGISTRATION_COUNTRIES:
            new_choices = [
                (code, name)
                for (code, name) in vendor_address_form.fields["country"].choices
                if code in settings.SHUUP_MULTIVENDOR_REGISTRATION_COUNTRIES
            ]
            vendor_address_form.fields["country"].choices = new_choices
            if len(new_choices) == 1:
                vendor_address_form.fields["country"].initial = new_choices[0][0]

    def save(self, commit=True):
        with atomic():
            vendor_user = self.forms["vendor_user"].save(commit=False)
            vendor_person = self.forms["vendor_person"].save(commit=False)
            vendor = self.forms["vendor_base"].save(commit=False)
            vendor_address = self.forms["vendor_address"].save(commit=False)

            vendor_user.first_name = vendor_person.first_name
            vendor_user.last_name = vendor_person.last_name
            vendor_user.email = vendor_person.email
            vendor_user.is_staff = not settings.SHUUP_MULTIVENDOR_VENDOR_REQUIRES_APPROVAL
            vendor_user.is_active = not settings.SHUUP_MULTIVENDOR_VENDOR_REQUIRES_APPROVAL
            vendor_user.save()

            vendor_address.name = vendor.name
            if not vendor_address.email and vendor_person.email:
                vendor_address.email = vendor_person.email
            vendor_address.save()

            vendor_person.user = vendor_user
            vendor_person.save()
            vendor_person.shops.add(self.request.shop)

            vendor.contact_address = vendor_address
            vendor.is_approved = not settings.SHUUP_MULTIVENDOR_VENDOR_REQUIRES_APPROVAL
            vendor.save()
            vendor.shops.add(self.request.shop)

            SupplierUser.objects.create(
                shop=self.request.shop,
                supplier=vendor,
                user=vendor_user,
                is_owner=True
            )
            vendor_registered.send(
                sender=type(self),
                shop=self.request.shop,
                vendor=vendor,
                user=vendor_user,
                person_contact=vendor_person
            )

            return vendor_user
