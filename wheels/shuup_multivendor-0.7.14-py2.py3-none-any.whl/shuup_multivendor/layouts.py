# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.xtheme.layout import Layout


def get_supplier_from_context(context):
    return (context.get("supplier") or context.get("object"))


class SupplierLayout(Layout):
    identifier = "supplier-layout"

    def get_help_text(self, context):
        from shuup.core.models import Supplier
        supplier = get_supplier_from_context(context)
        if not isinstance(supplier, Supplier):
            return None

        if not supplier:
            return ""

        return _("Content in this placeholder is shown for '%(supplier_name)s' vendor only." % {
            "supplier_name": supplier.name
        })

    def is_valid_context(self, context):
        from shuup.core.models import Supplier
        supplier = get_supplier_from_context(context)
        return isinstance(supplier, Supplier)

    def get_layout_data_suffix(self, context):
        supplier = get_supplier_from_context(context)
        return "%s-%s" % (self.identifier, supplier.pk)


class SupplierProductLayout(Layout):
    identifier = "supplier-product-layout"

    def get_help_text(self, context):
        product = context.get("product")
        from shuup.core.models import Supplier
        supplier = get_supplier_from_context(context)
        if not isinstance(supplier, Supplier):
            return None

        if not (supplier and product):
            return ""

        help_text = _(
            "Content in this placeholder is shown for '%(supplier_name)s' vendor and '%(product_name)s' product only.")
        return help_text % {
            "supplier_name": supplier.name,
            "product_name": product.name,
        }

    def is_valid_context(self, context):
        from shuup.core.models import Supplier
        supplier = get_supplier_from_context(context)
        return bool(isinstance(supplier, Supplier) and context.get("product"))

    def get_layout_data_suffix(self, context):
        product = context.get("product")
        supplier = get_supplier_from_context(context)
        return "%s-%s-%s" % (self.identifier, supplier.pk, product.pk)
