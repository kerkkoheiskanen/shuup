# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import datetime
import json

import requests
from django.conf import settings
from django.core.mail import send_mail
from django.core.management import BaseCommand
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import activate
from enumfields import Enum
from shuup.core.models import Shop, ShopStatus, Supplier
from shuup.core.models._shops import ShopLogEntry
from shuup.utils.dates import local_now
from shuup_subscriptions.models import Subscription

from shuup_vendor_plans.utils import get_shop_for_subscription


class LogIdentifier(Enum):
    ZERO = 0
    ONE = 1
    TWO = 2
    THREE = 3
    DEACTIVATE = 999


INTERNAL_EMAIL_TITLE = _("Store %(shop_name)s closing soon (%(days)s days left)")
INTERNAL_EMAIL = _("Store %(shop_name)s has %(days)s day(s) left to activate account")

BUSINESS_LOGIC = {
    "no_subscription": {
        0: {
            "internal_mail_title": INTERNAL_EMAIL_TITLE,
            "internal_mail": INTERNAL_EMAIL,
            "external_mail_title": _("Activate your Shuup POS Today!"),
            "external_mail": _("If the account is not being activated today, it will be closed."),
            "identifier": LogIdentifier.ZERO
        },
        1: {
            "internal_mail_title": INTERNAL_EMAIL_TITLE,
            "internal_mail": INTERNAL_EMAIL,
            "external_mail_title": _("One day left to activate your Shuup POS account"),
            "external_mail": _("One day left to activate account."),
            "identifier": LogIdentifier.ONE
        },
        2: {
            "internal_mail_title": INTERNAL_EMAIL_TITLE,
            "internal_mail": INTERNAL_EMAIL,
            "external_mail_title": _("Two days left to activate your Shuup POS account"),
            "external_mail": _("Two days left to activate account."),
            "identifier": LogIdentifier.TWO
        },
        3: {
            "internal_mail_title": INTERNAL_EMAIL_TITLE,
            "internal_mail": INTERNAL_EMAIL,
            "external_mail_title": _("Three days left to activate your Shuup POS account"),
            "external_mail": _("Three days left to activate account."),
            "identifier": LogIdentifier.THREE
        },
    },
    "subscription": {
        1: {

        }
    }
}


class Command(BaseCommand):
    dry_run = False

    def add_arguments(self, parser):
        parser.add_argument('--dry-run', action='store_true', default=False)

    def deactivate(self, shop):
        if ShopLogEntry.objects.filter(identifier=LogIdentifier.DEACTIVATE, target_id=shop.pk).exists():
            return
        shop.maintenance_mode = True
        shop.status = ShopStatus.DISABLED
        shop.save()
        shop.add_log_entry("deactivate due no subscriptions", identifier=LogIdentifier.DEACTIVATE)

    def _send_internal_mail(self, shop, days, key="no_subscription"):
        data = BUSINESS_LOGIC[key][days]
        try:
            send_mail(
                subject=data["internal_email_title"] % {"shop_name": shop.name, "days": days},
                message=data["internal_email"] % {"shop_name": shop.name, "days": days},
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=settings.SUPPORT_EMAILS)
        except Exception:
            from raven.contrib.django.raven_compat.models import client
            client.captureException()

    def _send_external_mail(self, shop, days, key="no_subscription"):
        data = BUSINESS_LOGIC[key][days]
        try:
            send_mail(
                subject=data["external_email_title"],
                message=data["external_email"],
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[shop.owner.email])
        except Exception:
            from raven.contrib.django.raven_compat.models import client
            client.captureException()

    def send_notifications(self, shop, days, notify_customer=False, key="no_subscription"):
        data = BUSINESS_LOGIC[key][days]
        identifier = data["identifier"]
        if ShopLogEntry.objects.filter(identifier=identifier, target_id=shop.pk).exists():
            return

        shop.add_log_entry(data["internal_mail"] % {"shop_name": shop.name, "days": days}, identifier=identifier)
        self._send_internal_mail(shop, days, key)
        if notify_customer:
            self._send_external_mail(shop, days, key)

    def handle(self, *args, **options):
        activate("en")
        self.dry_run = options["dry_run"]
        accounting_shop = get_shop_for_subscription()

        today_min = datetime.datetime.combine(local_now(), datetime.time.min)
        today_max = datetime.datetime.combine(local_now(), datetime.time.max)
        for sub in Subscription.objects.filter(end_date__range=(today_min, today_max)):
            supplier = Supplier.objects.filter(vendor_users__user=sub.customer.user).first()

            if not supplier:
                print("No supplier found for Subscription:", sub)
                continue

            print("Deactivating", sub)
            if self.dry_run:
                continue

            # deactivate supplier
            supplier.is_approved = False
            supplier.enabled = False
            supplier.save()

            # deactivate user
            sub.customer.user.is_active = False
            sub.customer.user.save()

            # Deactivate customer
            sub.customer.is_active = False
            sub.customer.save()
            # print("*"*80)
            # print(sub)
            # print("*" * 80)

            # TODO: Smail
            # TODO: Slack

        return

        for shop in Shop.objects.filter(
                status=ShopStatus.ENABLED
        ).exclude(
            pk=accounting_shop.pk
        ):
            if self.dry_run:
                print("Deactivating %s" % shop.name)
            else:
                self.deactivate(shop)
                if settings.ACCOUNTING_SLACK_URL:
                    requests.post(
                        settings.ACCOUNTING_SLACK_URL,
                        data=json.dumps({"text": "Shop disabled: https://%s.myshuup.com/" % shop.domain}))
