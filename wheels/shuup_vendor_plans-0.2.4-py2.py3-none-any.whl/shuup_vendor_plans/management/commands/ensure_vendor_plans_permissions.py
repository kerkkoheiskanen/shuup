# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.contrib.auth.models import Group, Permission
from django.core.management import BaseCommand

PERMISSIONS = [
    ("shuup_vendor_plans", "cancellationinfo", "add_cancellationinfo"),
]


class Command(BaseCommand):
    def add_arguments(self, parser):
        super(Command, self).add_arguments(parser)
        parser.add_argument('--vendor-group-name', type=str, required=True, help="Vendor User Group Name")

    def handle(self, *args, **options):
        print("Vendor Plans: Ensure Permissions: Starting...")
        try:
            group = Group.objects.get(name=options["vendor_group_name"])
        except Group.DoesNotExist:
            print("Group name %s Does not exist" % options["vendor_group_name"])
            return

        for app_label, model, perm_str in PERMISSIONS:
            perm = Permission.objects.get(
                content_type__app_label=app_label,
                content_type__model=model,
                codename=perm_str
            )
            group.permissions.add(perm)

        print("Vendor Plans: Ensure Permissions: Done.")
