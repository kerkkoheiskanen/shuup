# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import Supplier
from shuup.reports.forms import ShuupReportForm


def can_control_supplier(shop, user):
    return bool(
        getattr(user, "is_superuser", False) or
        shop.staff_members.filter(id=user.pk).exists()
    )


def _get_supplier_field(shop):
    return forms.ChoiceField(
        label=_("Vendor"), help_text=_("Filter results by vendor"), required=False,
        choices=[(None, "---")] + [
            (s.pk, s.name) for s in Supplier.objects.enabled().filter(shops=shop)
        ]
    )


class SubscriptionsReportForm(ShuupReportForm):
    def __init__(self, *args, **kwargs):
        super(SubscriptionsReportForm, self).__init__(*args, **kwargs)

        shop = get_shop(self.request)
        if can_control_supplier(shop, self.request.user):
            self.fields["supplier"] = _get_supplier_field(shop)
