# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from shuup.admin.supplier_provider import get_supplier

from shuup_vendor_plans.models import CancellationInfo
from shuup_vendor_plans.utils import (
    get_shop_for_subscription, get_subscription
)


class CancelForm(forms.ModelForm):
    class Meta:
        model = CancellationInfo
        fields = ["reason", "text", "shop", "subscription", "supplier", "canceled_by"]

    def __init__(self, **kwargs):
        self.request = kwargs.pop("request")

        super(CancelForm, self).__init__(**kwargs)
        self.fields["reason"].label = _("Please, select your reason for cancelling your plan")
        self.fields["text"].label = _("Please, elaborate on your selection")

        self.fields["shop"].widget = forms.HiddenInput()
        self.fields["shop"].initial = get_shop_for_subscription()

        self.fields["subscription"].widget = forms.HiddenInput()
        self.fields["subscription"].initial = get_subscription(self.request)

        self.fields["supplier"].widget = forms.HiddenInput()
        self.fields["supplier"].initial = get_supplier(self.request)

        self.fields["canceled_by"].widget = forms.HiddenInput()
        self.fields["canceled_by"].initial = self.request.user

    def clean_shop(self):
        # enforce.
        return get_shop_for_subscription(self.request)

    def clean_subscription(self):
        return get_subscription(self.request)

    def clean_supplier(self):
        return get_supplier(self.request)

    def clean_canceled_by(self):
        return self.request.user


class VerifyLoginForm(forms.Form):
    password = forms.CharField(
        label=_("Please enter your password to cancel your plan"),
        widget=forms.PasswordInput,
        required=True
    )

    def __init__(self, **kwargs):
        self.request = kwargs.pop("request")
        super(VerifyLoginForm, self).__init__(**kwargs)

    def clean_password(self):
        password = self.cleaned_data.get("password")
        if not self.request.user.check_password(password):
            raise ValidationError('Invalid password')
        return password
