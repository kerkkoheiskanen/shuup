# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.core.urlresolvers import reverse
from django.templatetags.static import static
from shuup.admin.supplier_provider import get_supplier
from shuup.utils.djangoenv import has_installed
from shuup.utils.excs import Problem
from shuup.xtheme.resources import add_resource

from shuup_vendor_plans.plan_limiter import PlanLimiter


def add_admin_resources(context, content):
    request = context.get("request")
    if not request:
        return

    match = request.resolver_match
    if not match:
        return

    if match.app_name != "shuup_admin":
        return

    supplier = get_supplier(request)

    urlmap = {
        "products": [
            reverse("shuup_admin:shop_product.list"),
            reverse("shuup_admin:shop_product.new"),
            reverse("shuup_admin:shuup_multivendor.products_list")
        ],
        "users": [
            reverse("shuup_admin:user.list"),
            reverse("shuup_admin:multivendor_user.list"),
            reverse("shuup_admin:user.new"),
            reverse("shuup_admin:multivendor_user.new")
        ]
    }

    if settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
        urlmap["products"].append(reverse("shuup_admin:shuup_multivendor.products_new"))

    if has_installed("shuup_courses"):
        urlmap["courses"] = [
            reverse("shuup_admin:shuup_courses.courses_list"),
            reverse("shuup_admin:shuup_courses.courses_new")
        ]

    if request.path in urlmap["courses"]:
        func = "can_create_course"
    elif request.path in urlmap["products"]:
        func = "can_create_product"
    elif request.path in urlmap["users"]:
        func = "can_create_user"
    else:
        return  # nothing to do

    try:
        limiter = PlanLimiter(supplier)
    except Problem as e:
        # no plan or subscription
        add_resource(context, "body_end", "%s?v=0.2.4.js" % static("shuup_vendor_plans/js/no_subscription.js"))
        return

    thing = getattr(limiter, func, None)
    if callable(thing) and not thing():
        add_resource(context, "body_end", "%s?v=0.2.4.js" % static("shuup_vendor_plans/js/disable_toolbar.js"))
