# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import logging
from collections import defaultdict

from django.conf import settings
from django.db.models import Q
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ugettext
from shuup import configuration
from shuup.core import cache
from shuup.core.models import (
    Order, OrderLine, OrderLineType, OrderStatusRole, PaymentStatus,
    PersonContact
)
from shuup.utils.analog import LogEntryKind
from six.moves.urllib.parse import urljoin

from packages.models import MetrcLog

LOGGER = logging.getLogger(__name__)
METRC_USER_API_KEY_KEY = "metrc_user_api_key"
METRC_ENABLED_KEY = "metrc_enabled"
METRC_FACILITY_NUMBER_KEY = "metrc_facility_number"
METRC_EXTRA_DATA_KEY = "metrc"


class MetrcError(Exception):
    def __init__(self, message):
        self.message = message


class MetrcSyncError(Exception):
    def __init__(self, order, message):
        self.order = order
        self.message = message


class MetrcCustomerType(object):
    Consumer = "Consumer"
    Patient = "Patient"
    Caregiver = "Caregiver"
    ExternalPatient = "ExternalPatient"


def get_response_errors(response):
    data = response.json()
    if isinstance(data, list):
        return data
    return [data]


def is_metrc_enabled(shop):
    return configuration.get(shop, METRC_ENABLED_KEY, False)


def set_metrc_enabled(shop, enabled):
    configuration.set(shop, METRC_ENABLED_KEY, enabled)


class Metrc(object):
    def __init__(self, shop):
        self.shop = shop
        self.api_url = settings.METRC_API_URL
        self.vendor_api_key = settings.METRC_VENDOR_API_KEY

    @property
    def enabled(self):
        return configuration.get(self.shop, METRC_ENABLED_KEY, False)

    def set_config(self, user_api_key, facility_number, enabled):
        configuration.set(self.shop, METRC_USER_API_KEY_KEY, user_api_key)
        configuration.set(self.shop, METRC_FACILITY_NUMBER_KEY, facility_number)
        set_metrc_enabled(self.shop, enabled)

    def get_config(self):
        """
        Returns a tuple of (user_api_key, facility_number, enabled) for the given shop
        """
        return (
            configuration.get(self.shop, METRC_USER_API_KEY_KEY),
            configuration.get(self.shop, METRC_FACILITY_NUMBER_KEY),
            is_metrc_enabled(self.shop)
        )

    def should_send_sales_receipt(self, order):
        """ Returns whether the order should be send to Metrc """
        if not (order.shop == self.shop and order.is_paid() and order.is_complete()):
            return False

        metrc_info = order.extra_data.get(METRC_EXTRA_DATA_KEY)
        if metrc_info and order.is_complete() and metrc_info.get("sent"):
            return False

        # there should be lines with measurements, and they should be from a batch that has a metrc tag
        return order.lines.filter(
            package_measurements__package__batch_transfer__batch__metrc_tag__isnull=False
        ).exists()

    def should_send_sales_receipt_for_refund(self, order, refund_lines):
        """ Check whether we should send sales receipt for the refunded lines """
        metrc_info = order.extra_data.get(METRC_EXTRA_DATA_KEY)

        # do not send if there is no metrc info or the status is canceled
        if not metrc_info:
            return False

        # we should refund when there is some refund line with measurement and that has a metrc tag
        return order.lines.filter(
            pk__in=[line.pk for line in refund_lines],
            package_measurements__package__batch_transfer__batch__metrc_tag__isnull=False
        ).exists()

    def get_not_sent_sales_receipt_orders(self):
        """
        Return all orders that should be synced to Metrc

        Orders must:
            - be from this shop
            - have lines with package measurements and packages are transferred from batches with a valid metrc tag
            - never synced before or the order status is different
            - are flagged to resync
        """
        return Order.objects.filter(
            Q(shop=self.shop, payment_status=PaymentStatus.FULLY_PAID, status__role=OrderStatusRole.COMPLETE),
            Q(lines__package_measurements__package__batch_transfer__batch__metrc_tag__isnull=False)
        ).exclude(
            Q(lines__package_measurements__package__batch_transfer__batch__metrc_tag="") |
            Q(extra_data__icontains=METRC_EXTRA_DATA_KEY)
        ).distinct()

    def send_sales_receipt(self, order):
        """ send sales receipt for the entire order, except refund lines """
        metrc_transactions = self._get_sales_receipt_transactions(order)
        return self._send_metrc_sales_receipt(order, metrc_transactions)

    def send_sales_receipt_for_refunds(self, order, refund_lines):
        """ Send sales receipt for refunded lines """
        metrc_transactions = self._get_sales_receipt_transactions_for_refunds(order, refund_lines)
        return self._send_metrc_sales_receipt(order, metrc_transactions)

    def get_units_of_measure(self):
        """
        Get sales units from Metrc and cache them
        """
        cache_key = "metrc_units_of_measure_{}".format(self.shop.pk)
        units_of_measure = cache.get(cache_key)
        if units_of_measure is not None:
            return units_of_measure

        user_api_key = self.get_config()[0]
        import requests
        from requests.exceptions import RequestException
        request_url = urljoin(self.api_url, "unitsofmeasure/v1/active")

        try:
            response = requests.get(url=request_url, auth=(self.vendor_api_key, user_api_key))
            if response.status_code == 200:
                units_of_measures = {}
                for unit in response.json():
                    units_of_measures[unit["Name"]] = unit
                cache.set(cache_key, units_of_measures)
                return units_of_measures

            msg = _("Failed to get units os measure from Metrc")
            MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
            raise MetrcError(msg)
        except RequestException:
            msg = _("Failed to get units os measure from Metrc")
            MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
            LOGGER.exception(msg)
            raise MetrcError(msg)

    def get_package(self, metrc_tag, allow_cache=True):
        """ Get the package info from a Metrc tag """
        cache_key = "metrc_package_{}".format(metrc_tag)

        if allow_cache:
            package_info = cache.get(cache_key)
            if package_info is not None:
                return package_info

        user_api_key = self.get_config()[0]
        import requests
        from requests.exceptions import RequestException
        request_url = urljoin(self.api_url, "packages/v1/%s" % metrc_tag)

        try:
            response = requests.get(url=request_url, auth=(self.vendor_api_key, user_api_key))
            if response.status_code == 200:
                package_info = response.json()
                cache.set(cache_key, package_info, timeout=60)   # 10 min of cache
                return package_info

            if response.status_code == 404:
                msg = _("Metrc Tag '%(metrc_tag)s' doesn't exist") % dict(metrc_tag=metrc_tag)
                MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
                raise MetrcError(msg)

            error = get_response_errors(response)[0]
            msg = _("Failed to get package %(metrc_tag)s from Metrc: %(error)s") % dict(
                metrc_tag=metrc_tag,
                error=error.get("message")
            )
            MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
            raise MetrcError(msg)
        except RequestException:
            msg = _("Failed to get package %(metrc_tag)s from Metrc") % dict(metrc_tag=metrc_tag)
            MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
            LOGGER.exception(msg)
            raise MetrcError(msg)

    def finish_package(self, metrc_tag):
        """ Finish a Metrc package """
        user_api_key, facility_number, enabled = self.get_config()
        if not enabled:
            return False

        import requests
        from requests.exceptions import RequestException
        request_url = urljoin(self.api_url, "/packages/v1/finish")

        try:
            response = requests.post(
                url=request_url,
                params={"licenseNumber": facility_number},
                auth=(self.vendor_api_key, user_api_key),
                json=[{
                    "Label": metrc_tag,
                    "ActualDate": now().date().isoformat()
                }]
            )
            # All OK!
            if response.status_code == 200:
                return True

            if response.status_code == 404:
                msg = _("Metrc Tag '%(metrc_tag)s' doesn't exist") % dict(metrc_tag=metrc_tag)
                MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
                raise MetrcError(msg)

            error = get_response_errors(response)[0]
            msg = _("Failed to finish package %(metrc_tag)s: %(error)s") % dict(
                metrc_tag=metrc_tag,
                error=error.get("message")
            )
            MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
            raise MetrcError(msg)
        except RequestException:
            msg = _("Failed to finish package %(metrc_tag)s") % dict(metrc_tag=metrc_tag)
            MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
            LOGGER.exception(msg)
            raise MetrcError(msg)

    def _get_sales_receipt_transactions(self, order):
        """ Get transaction lines payload from an order """
        packages = defaultdict(lambda: dict(quantity=0, amount=0))

        lines = OrderLine.objects.filter(
            order=order,
            type=OrderLineType.PRODUCT,
            package_measurements__package__batch_transfer__batch__metrc_tag__isnull=False
        ).exclude(
            package_measurements__package__batch_transfer__batch__metrc_tag=""
        ).distinct()

        for line in lines:
            # refunds are sent separetely
            if line.child_lines.refunds().exists():
                continue

            measurement = line.package_measurements.last()
            metrc_tag = measurement.package.batch_transfer.batch.metrc_tag
            package = packages[metrc_tag]

            package["quantity"] += measurement.package.batch_transfer.quantity
            package["amount"] += line.taxful_price.value

            if "in_grams" not in package:
                package["in_grams"] = measurement.package.batch_transfer.batch.is_in_grams()

        return dict(packages)

    def _get_sales_receipt_transactions_for_refunds(self, order, refund_lines):
        """ Get transaction lines payload from refund lines """
        packages = defaultdict(lambda: dict(quantity=0, amount=0))

        lines = OrderLine.objects.filter(
            order=order,
            package_measurements__package__batch_transfer__batch__metrc_tag__isnull=False,
            pk__in=[order_line.pk for order_line in refund_lines]
        ).exclude(
            package_measurements__package__batch_transfer__batch__metrc_tag=""
        ).distinct()

        for line in lines:
            measurement = line.package_measurements.last()
            metrc_tag = measurement.package.batch_transfer.batch.metrc_tag
            package = packages[metrc_tag]

            package["quantity"] -= measurement.package.batch_transfer.quantity
            package["amount"] = line.taxful_price.value

            if "in_grams" not in package:
                package["in_grams"] = measurement.package.batch_transfer.batch.is_in_grams()

        return dict(packages)

    def _send_metrc_sales_receipt(self, order, metrc_transactions):
        """ Send Salesreceipt to Metrc """
        user_api_key, facility_number, enabled = self.get_config()
        if not enabled:
            return False

        import requests
        from requests.exceptions import RequestException

        params = {"licenseNumber": facility_number}
        request_url = urljoin(self.api_url, "sales/v1/receipts/")
        payload = self._get_sales_receipt_payload(order, metrc_transactions)
        has_packages = (len(payload["Transactions"]) > 0)

        if has_packages:
            try:
                response = requests.post(
                    url=request_url,
                    json=[payload],
                    params=params,
                    auth=(self.vendor_api_key, user_api_key)
                )
                # create/update the MetrcOrder
                if response.status_code == 200:
                    metrc_info = {
                        "payload": payload,
                        "sent": True
                    }
                    order.extra_data[METRC_EXTRA_DATA_KEY] = metrc_info
                    order.save(update_fields=["extra_data"])
                    msg = ugettext("Order {} sent to Metrc").format(order.pk)
                    MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.AUDIT)
                    return True

                LOGGER.warning("Failed to send order %d to Metrc: %s", order.pk, response.content.decode("utf-8"))
                msg = ugettext("Failed to send order {} to Metrc").format(order.pk)
                MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
                raise MetrcSyncError(order, msg)

            except RequestException:
                LOGGER.exception("Failed to sync order %d with Metrc", order.pk)
                msg = ugettext("Failed to send order {} to Metrc").format(order.pk)
                MetrcLog.add_log_entry(self.shop, msg, kind=LogEntryKind.ERROR)
                raise MetrcSyncError(order, msg)
        return False

    def _get_metrc_customer_type(self, shop, customer):
        """
        Return the customer type according to the Metrc
        Options are:
            - Consumer
            - Patient
            - Caregiver
            - ExternalPatient
        """
        if customer:
            from shuup_pos.models import CustomerShopVerification
            csv = CustomerShopVerification.objects.filter(shop=shop, customer=customer).first()

            if csv and not csv.recreational and csv.is_verified():
                return MetrcCustomerType.Patient

        return MetrcCustomerType.Consumer

    def _get_patient_license_number(self, shop, customer):
        """ Get the license number for the given customer """
        from shuup_pos.models import CustomerShopVerification
        csv = CustomerShopVerification.objects.filter(shop=shop, customer=customer).first()
        if csv and not csv.recreational and csv.is_verified():
            return csv.rec_id

    def _get_sales_receipt_payload(self, order, metrc_transactions):
        """
        :param order shuup.core.models.Order
        :param metrc_transactions dict
        """
        customer = order.customer
        if customer and not isinstance(customer, PersonContact):
            customer = order.orderer

        order_payload = {
            "SalesDateTime": order.order_date.isoformat(),
            "SalesCustomerType": self._get_metrc_customer_type(order.shop, customer),
            "PatientLicenseNumber": self._get_patient_license_number(order.shop, customer),
            "CaregiverLicenseNumber": None,
            "IdentificationMethod": None,
            "Transactions": []
        }

        for metrc_tag, metrc_transaction in metrc_transactions.items():
            if metrc_transaction["quantity"]:
                quantity = metrc_transaction["quantity"]
                amount = metrc_transaction["amount"]
                order_payload["Transactions"].append({
                    "PackageLabel": metrc_tag,
                    "Quantity": quantity,
                    "UnitOfMeasure": "Grams" if metrc_transaction["in_grams"] else "Each",
                    "TotalAmount": amount
                })

        return order_payload
