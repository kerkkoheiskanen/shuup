# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from shuup.core.models import Order, ShopProduct
from shuup.core.signals import refund_created

from packages.metrc import Metrc, MetrcError
from packages.models import (
    Package, PackageLocation, PackageMeasurement, PackageType
)
from packages.package_logging import (
    create_barcode_changed_log, create_package_condition_changed_log,
    create_package_content_weight_changed_log, create_package_created_log,
    create_package_moved_log
)

from .signals import package_saved


@receiver(post_save, sender=Order)  # noqa: too complex
def handle_order_post_save(sender, instance, **kwargs):
    if instance.is_canceled():
        # Handle all lines having pre-packed packages linked to it
        #
        # 1. Re-measure package pack to it's last state before it was linked to order.
        # 2. Move it to cancel location.
        for line in instance.lines.filter(package_measurements__isnull=False).distinct():
            for measurement in line.package_measurements.filter(package__type=PackageType.PRE_PACKED):
                PackageMeasurement.objects.create(
                    package=measurement.package,
                    last_weight=measurement.total_weight,
                    total_weight=measurement.last_weight,
                    order=measurement.order,
                    order_line=line
                )

                cancel_location = PackageLocation.objects.filter(
                    supplier=line.supplier, name=settings.SHUUP_PACKAGES_CANCEL_LOCATION_NAME).first()
                if cancel_location:
                    measurement.package.location = cancel_location
                    measurement.package.save()

    metrc = Metrc(instance.shop)
    if metrc.enabled and metrc.should_send_sales_receipt(instance):
        try:
            metrc.send_sales_receipt(instance)
        except MetrcError:
            pass


@receiver(refund_created, sender=Order)
def handle_refund_created(sender, order, refund_lines, **kwargs):
    """
    Handle all lines having pre-packed packages linked to it

    1. Re-measure package pack to it's last state before it was linked to order.
    2. Move it to refund location.
    """
    for refund_line in refund_lines:
        order_line_package_measurements = PackageMeasurement.objects.filter(
            order_line=refund_line.parent_line,
            package__type=PackageType.PRE_PACKED
        ).order_by("-created_on")

        total_quantity = refund_line.quantity  # Make sure we don't restock too many packages
        for order_line_package_measurement in order_line_package_measurements:
            if total_quantity == 0:
                break

            # create the measurement to return to original weight
            PackageMeasurement.objects.create(
                package=order_line_package_measurement.package,
                last_weight=order_line_package_measurement.total_weight,
                total_weight=order_line_package_measurement.last_weight,
                order=order_line_package_measurement.order,
                order_line=refund_line
            )
            refund_location = PackageLocation.objects.filter(
                supplier=refund_line.parent_line.supplier, name=settings.SHUUP_PACKAGES_REFUND_LOCATION_NAME).first()
            if refund_location:
                order_line_package_measurement.package.location = refund_location
                order_line_package_measurement.package.save()

            total_quantity -= 1

    metrc = Metrc(order.shop)
    if metrc.enabled and metrc.should_send_sales_receipt_for_refund(order, refund_lines):
        try:
            metrc.send_sales_receipt_for_refunds(order, refund_lines)
        except MetrcError:
            pass


@receiver(post_save, sender=Package, dispatch_uid="handle_package_post_save")
def handle_package_post_save(sender, instance, **kwargs):
    instance.update_stocks()
    try:
        from trees.cache import bump_shop_product_cache
        for sp in ShopProduct.objects.filter(product=instance.product, suppliers=instance.supplier):
            bump_shop_product_cache(sp)
    except ImportError:
        pass


@receiver(package_saved, sender=Package, dispatch_uid="log_inventory")
def log_inventory(sender, instance, is_new, old_data, **kwargs):
    if is_new:
        create_package_created_log(instance)
    else:  # Old package lets log possible changes to key attributes
        old_barcode = old_data.get("old_barcode", None)
        if old_barcode and old_barcode != instance.barcode:
            create_barcode_changed_log(instance, old_barcode)

        old_location = old_data.get("old_location", "")
        if old_location and old_location != instance.location:
            create_package_moved_log(instance, old_location)

        old_condition = old_data.get("old_condition", "")
        if old_condition and old_condition != instance.condition:
            create_package_condition_changed_log(instance, old_condition)

        old_content_weight = old_data.get("old_content_weight", "")
        if old_content_weight and old_content_weight != instance.content_weight:
            create_package_content_weight_changed_log(instance, old_content_weight)
