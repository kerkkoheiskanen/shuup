# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

# Auto attach pre packs to order
#
# This is useful when the packages are not unique
# but the packages is used for purchase orders, batches
# and locations.
#
SHUUP_PACKAGES_AUTO_ATTACH_PRE_PACKS_TO_ORDER = False

# How supplier is selected for admin panel
#
# Class implementing get_supplier-method which get
# current shop and user as kwargs.
#
SHUUP_PACKAGES_SUPPLIER_STRATEGY = "packages.supplier_strategy:CloudSupplierStrategy"

# How supplier users are determined
#
# Class implementing get_users-method which gets supplier as kwargs.
#
SHUUP_PACKAGES_SUPPLIER_USERS_STRATEGY = "packages.supplier_strategy:CloudSupplierUserStrategy"

# Metrc API URL
# For sandbox use https://sandbox-api-ca.metrc.com
#
METRC_API_URL = None

# Metrc Vendor API
# The key you receive after passing through the Evaluation
#
METRC_VENDOR_API_KEY = None


# Location to move cancelled packages
# It is up to merchant whether the packages in cancelled location
# is available to sell or whether those require move before back
# to sale.
SHUUP_PACKAGES_CANCEL_LOCATION_NAME = "Cancelled"

# Location name for refunded packages
# When order is refunded we move the packages
# linked to the refunded order to this location
# for further handling.
SHUUP_PACKAGES_REFUND_LOCATION_NAME = "Refunded"

# Location to move the sold packages to
# This is done in packages save
SHUUP_PACKAGES_SOLD_LOCATION_NAME = "Sold"

# Location which the destroyed packages should be moved
SHUUP_PACKAGES_DESTROYED_LOCATION_NAME = "Destroyed"

# Location which lost packages should be moved to
SHUUP_PACKAGES_LOST_LOCATION_NAME = "Lost"

# Packages send back to distributor (in entcart this is government)
SHUUP_PACKAGES_RETURNED_TO_DISTRIBUTOR_LOCATION_NAME = "Returned to distributor"

# Not destroyed, lost or send to goverment but still disappeared somehow
SHUUP_PACKAGES_OTHER_REDUCTION_LOCATION_NAME = "Other reduction"

# Number of packages created or moved per transaction
SHUUP_PACKAGES_BARCODE_TRANSACTION_LIMIT = 1000
