# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import re

from django.conf import settings
from shuup import configuration
from shuup.admin.shop_provider import get_shop
from shuup.core.models import SalesUnit
from shuup.utils.importing import cached_load

PKG_BARCODE_RE = re.compile(r"^PKG([0-9]+)$", re.IGNORECASE)
BULK_ENABLED_CONFIG_KEY = "packages_bulk"
ALLOW_GENERATING_LABELS_KEY = "allow_generating_labels_key"


def get_package_supplier(shop):
    return get_supplier(shop, None)


def get_supplier_from_request(request):
    return get_supplier(get_shop(request), request.user)


def get_supplier(shop, user):
    supplier_strategy = cached_load("SHUUP_PACKAGES_SUPPLIER_STRATEGY")
    kwargs = {"shop": shop, "user": user}
    return supplier_strategy().get_supplier(**kwargs)


def get_users_for_supplier(supplier):
    supplier_users_strategy = cached_load("SHUUP_PACKAGES_SUPPLIER_USERS_STRATEGY")
    kwargs = {"supplier": supplier}
    return supplier_users_strategy().get_users(**kwargs)


def is_sales_unit_pieces(product):
    try:
        from trees_shop.utils.sales_units import DEFAULT_PIECES_IDENTIFIER
    except ImportError:
        DEFAULT_PIECES_IDENTIFIER = "pcs"  # noqa: N806
    return bool(product.sales_unit and product.sales_unit.identifier == DEFAULT_PIECES_IDENTIFIER)


def get_package_id_from_barcode(barcode):
    if not barcode:
        return
    match = PKG_BARCODE_RE.match(barcode)
    if match:
        return match.groups()[0]


def is_bulk_enabled(shop):
    return configuration.get(shop, BULK_ENABLED_CONFIG_KEY, False)


def set_bulk_enabled(shop, enabled):
    return configuration.set(shop, BULK_ENABLED_CONFIG_KEY, enabled)


def allow_generating_labels(shop):
    return configuration.get(shop, ALLOW_GENERATING_LABELS_KEY, False)


def set_allow_generating_labels(shop, enabled):
    return configuration.set(shop, ALLOW_GENERATING_LABELS_KEY, enabled)


def get_sales_unit_for_grams():
    try:
        from trees_shop.utils.sales_units import get_sales_unit_for_grams
        return get_sales_unit_for_grams()
    except ImportError:
        return SalesUnit.objects.filter(identifier="g").first()


def get_sales_unit_for_pieces():
    try:
        from trees_shop.utils.sales_units import get_sales_unit_for_pieces
        return get_sales_unit_for_pieces()
    except ImportError:
        return SalesUnit.objects.filter(identifier="pcs").first()


def ensure_default_package_conditions(supplier):
    from packages.models import PackageCondition
    default_conditions = [
        ("normal", "Normal", True),
        ("damaged", "Damaged (not sellable)", False)
    ]
    for identifier, name, is_sellable in default_conditions:
        defaults = {"name": name, "sellable": is_sellable}
        PackageCondition.objects.update_or_create(identifier=identifier, supplier=supplier, defaults=defaults)


def ensure_default_package_locations(supplier, members):
    from packages.models import PackageLocation
    static_locations = [
        settings.SHUUP_PACKAGES_CANCEL_LOCATION_NAME,
        settings.SHUUP_PACKAGES_DESTROYED_LOCATION_NAME,
        settings.SHUUP_PACKAGES_LOST_LOCATION_NAME,
        settings.SHUUP_PACKAGES_OTHER_REDUCTION_LOCATION_NAME,
        settings.SHUUP_PACKAGES_SOLD_LOCATION_NAME,
        settings.SHUUP_PACKAGES_REFUND_LOCATION_NAME,
        settings.SHUUP_PACKAGES_RETURNED_TO_DISTRIBUTOR_LOCATION_NAME
    ]
    for location_name in static_locations:
        new_location, _ = PackageLocation.objects.get_or_create(name=location_name, supplier=supplier, sellable=False)
        new_location.staff_members = members


class temp_disconnect_signal():  # noqa: N801
    """ Temporarily disconnect a model from a signal """
    def __init__(self, signal, receiver, sender, dispatch_uid=None):
        self.signal = signal
        self.receiver = receiver
        self.sender = sender
        self.dispatch_uid = dispatch_uid

    def __enter__(self):
        self.signal.disconnect(
            receiver=self.receiver,
            sender=self.sender,
            dispatch_uid=self.dispatch_uid,
            weak=False
        )

    def __exit__(self, type, value, traceback):
        self.signal.connect(
            receiver=self.receiver,
            sender=self.sender,
            dispatch_uid=self.dispatch_uid,
            weak=False
        )
