# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.core.management import BaseCommand
from django.db import transaction
from django.db.models.signals import post_save
from django.utils.timezone import now
from django.utils.translation import activate
from shuup.core.models import (
    Product, ProductMode, SalesUnit, Shop, ShopProduct, ShopStatus
)

from packages.models import (
    Batch, BatchProvider, BatchState, Package, PackageCondition,
    PackageLocation, PackageType, PurchaseOrder
)
from packages.signals import package_saved
from packages.utils import (
    ensure_default_package_locations, get_package_supplier
)


class Command(BaseCommand):
    def handle(self, *args, **options):
        """
        README!

        Before running this make sure right products has package supplier set.
        """
        activate("en")

        for shop in Shop.objects.filter(status=ShopStatus.ENABLED).exclude(id=settings.ACCOUNTING_STORE_ID):
            supplier = get_package_supplier(shop)
            create_distributors(supplier)  # Distributors deliveres the batches to store

            # Package locations is the places where packages are located
            create_package_locations(supplier, shop.staff_members.all())

            # Packages are handed to customers and can be from sales to batch and purchase order.
            create_packages(supplier, shop.staff_members.first())


def create_distributors(supplier):
    BatchProvider.objects.get_or_create(name="BC Government", supplier=supplier)


def create_package_locations(supplier, members):
    ensure_default_package_locations(supplier, members)

    safe1, _ = PackageLocation.objects.get_or_create(name="Safe 1", supplier=supplier, sellable=False)
    safe1.staff_members = members

    safe2, _ = PackageLocation.objects.get_or_create(name="Safe 2", supplier=supplier, sellable=False)
    safe2.staff_members = members

    room, _ = PackageLocation.objects.get_or_create(name="Backroom", supplier=supplier, sellable=True)
    room.staff_members = members

    counter1, _ = PackageLocation.objects.get_or_create(name="Counter 1", supplier=supplier, sellable=True)
    counter1.staff_members = members

    counter2, _ = PackageLocation.objects.get_or_create(name="Counter 2", supplier=supplier, sellable=True)
    counter2.staff_members = members


@transaction.atomic
def create_packages(supplier, created_by):
    if PurchaseOrder.objects.filter(supplier=supplier).exists():  # Do not create multiple orders willingly
        print("obs! Supplier %s already has purchase order lets skip..." % supplier.pk)
        return

    batch_provider = BatchProvider.objects.first()
    order = PurchaseOrder.objects.create(
        supplier=supplier, number="#1", date=now().date(), provider=batch_provider)

    sales_unit = SalesUnit.objects.filter(identifier="pcs").first()
    if not sales_unit:
        sales_unit = SalesUnit.objects.first()

    condition, _ = PackageCondition.objects.get_or_create(identifier="normal", supplier=supplier)
    data = [
        (PackageLocation.objects.get(supplier=supplier, name="Counter 1"), 5),
        (PackageLocation.objects.get(supplier=supplier, name="Counter 2"), 5),
        (PackageLocation.objects.get(supplier=supplier, name="Backroom"), 10),
        (PackageLocation.objects.get(supplier=supplier, name="Safe 1"), 40),
        (PackageLocation.objects.get(supplier=supplier, name="Safe 2"), 40)
    ]

    modes = [ProductMode.NORMAL, ProductMode.VARIATION_CHILD]
    query = ShopProduct.objects.filter(suppliers=supplier, product__mode__in=modes)

    message = """
        shop product count for supplier %s is %s we are
        creating about 36k packages in total for this shop
        slow eh
    """.strip()
    for line in (message % (supplier.pk, query.count())).splitlines():
        print(line.strip())

    post_save.disconnect(sender=Package, dispatch_uid="handle_package_post_save")
    package_saved.disconnect(sender=Package, dispatch_uid="log_inventory")

    batches = []
    products_data = query.values_list(
        "id", "default_price_value", "shop_id", "product_id", "product__translations__name", "product__net_weight"
    )

    for x, values in enumerate(products_data):
        if x % 10 == 0:
            print("   done %s products" % x)
        kwargs = {
            "shop_product_id": values[0],
            "default_price_value": values[1],
            "shop_id": values[2],
            "product_id": values[3],
            "product_name": values[4],
            "product_net_weight": values[5],
            "sales_unit": sales_unit,
            "supplier": supplier,
            "created_by": created_by,
            "condition": condition,
            "batch_provider": batch_provider
        }
        batch = create_batch_and_packages(data, **kwargs)
        batches.append(batch)

    order.batches = batches

    # Since we disabled those post_save and post_packages signals.
    # Warning! We skip "package created" log for this script
    product_ids = Product.objects.filter(shop_products__suppliers=supplier).values_list("pk", flat=True)
    supplier.update_stocks(product_ids)
    print("   commit...")


def create_batch_and_packages(data, **kwargs):
    expected_profit = 100 + kwargs["shop_product_id"]
    unit_purchase_price_value = ((kwargs["default_price_value"] * 100) / expected_profit)
    quantity = 100
    purchase_price_value = (quantity * unit_purchase_price_value)

    batch = Batch.objects.create(
        supplier_id=kwargs["supplier"].pk,
        name=kwargs["product_name"],
        provider=kwargs["batch_provider"],
        quantity=quantity,
        purchase_price_value=purchase_price_value,
        state=BatchState.Received,
        received_on=now(),
        sales_unit=kwargs["sales_unit"],
    )

    for location, count in data:
        for i in range(0, count):
            kwargs.update({
                "location": location
            })
            create_package_transfer(batch, **kwargs)

    return batch


def create_package_transfer(batch, **kwargs):
    barcode = get_barcode_for_product(kwargs["product_id"])
    batch.create_package_transfer(
        package_type=PackageType.PRE_PACKED,
        quantity=1,
        name=barcode[:64],
        barcode=barcode,
        product=kwargs["product_id"],
        transfer_group="by-script-for-%s" % kwargs["product_id"],
        condition=kwargs["condition"],
        packaging_weight=0,
        created_by=kwargs["created_by"],
        supplier=kwargs["supplier"],
        location=kwargs["location"],
        product_net_weight=kwargs["product_net_weight"] or 1
    )


def get_barcode_for_product(product_id):
    return "123456%s" % product_id
