# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.core.management import BaseCommand
from django.utils.translation import activate
from shuup import configuration
from shuup.api.permissions import PermissionLevel
from shuup.core.models import Supplier

from packages.utils import (
    ensure_default_package_conditions, ensure_default_package_locations,
    get_users_for_supplier
)

DEFAULT_API_PERMISSIONS = [
    ("api_permission_ShuupPackageViewSet", PermissionLevel.AUTHENTICATED_WRITE),
    ("api_permission_PackageSupplierViewSet", PermissionLevel.AUTHENTICATED_WRITE),
    ("api_permission_ShuupBatchViewSet", PermissionLevel.AUTHENTICATED_WRITE)
]


class Command(BaseCommand):
    def handle(self, *args, **options):
        activate("en")

        for supplier in Supplier.objects.all():
            ensure_default_package_conditions(supplier)
            # Members likely require some business logic so
            # set members separately for each location
            ensure_default_package_locations(supplier, members=get_users_for_supplier(supplier))

    for field, value in DEFAULT_API_PERMISSIONS:
        configuration.set(None, field, "%s" % value)
