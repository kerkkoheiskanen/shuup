<script> 
    $(function() {
        window.updateBarcodesAreaInfo = function() {
            var barcodeHelp = $("#barcode-help");
            var content = $("#id_barcodes").val();
            if (!content) {
                barcodeHelp.text("");
            } else {
                var lineCount = content.split(/\r*\n/).length;
                $("#barcode-help").text(lineCount + " barcodes read so far.");
            }
        }

        $("#id_barcodes").keyup(function() {
            window.updateBarcodesAreaInfo();
        });
        
        // Generate barcodes from batch identifier
        $("#generate-barcodes-from-batch-identifier").on("click", function() {
            var quantity = $("#barcodes-quantity").val();
            var barcode = $("#barcode-generate").val();
            if (quantity && barcode) {
                var barcodes = "";
                for (step = 0; (step < quantity) && (step < {{ max_barcodes - 1 }}); step++) {
                    barcodes += ((step === quantity - 1) ? barcode : (barcode + "\n"))
                }
                $("#id_barcodes").val(barcodes);
                window.updateBarcodesAreaInfo();
            }
        })

        // Generate barcodes from running number
        $("#generate-barcodes-from-running-number").on("click", function() {
            var quantity = $("#barcodes-running-numbers-quantity").val();
            var number = $("#barcodes-running-number").val();
            if (quantity && number) {
                var prefix = ($("#barcode-generate-prefix").val() || "");
                var suffix = ($("#barcode-generate-suffix").val() || "");
                var barcodes = "";
                for (step = 0; (step < quantity) && (step < {{ max_barcodes - 1 }}); step++) {
                    var barcode = (prefix + number.toString() + suffix);
                    barcodes += ((step === quantity - 1) ? barcode : (barcode + "\n"))
                    number++
                }
                $("#id_barcodes").val(barcodes);
                window.updateBarcodesAreaInfo();
            }
        })
    });
</script>
