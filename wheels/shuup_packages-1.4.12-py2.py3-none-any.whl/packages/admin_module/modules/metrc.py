# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.shop_provider import get_shop
from shuup.admin.utils.urls import admin_url
from shuup.admin.views.home import HelpBlockCategory, SimpleHelpBlock

from packages.metrc import is_metrc_enabled, Metrc


class MetrcModule(AdminModule):
    name = _("Metrc")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:metrc.settings")

    def get_menu_entries(self, request):
        return []

    def get_urls(self):
        return [
            admin_url(
                "package/metrc/settings/$",
                "packages.admin_module.views.metrc.MetrcSettingsView",
                name="metrc.settings",
            ),
            admin_url(
                "package/metrc/sync/$",
                "packages.admin_module.views.metrc.MetrcSyncView",
                name="metrc.sync",
            ),
            admin_url(
                "package/metrc/logs/$",
                "packages.admin_module.views.metrc.MetrcLogView",
                name="metrc.logs",
            )
        ]

    def get_help_blocks(self, request, kind):
        shop = get_shop(request)
        if not is_metrc_enabled(shop):
            return []

        actions = [
            {
                "text": _("Configure"),
                "url": reverse_lazy("shuup_admin:metrc.settings")
            },
            {
                "text": _("Synchronize"),
                "url": reverse_lazy("shuup_admin:metrc.sync")
            }
        ]
        metrc = Metrc(shop)
        is_done = (metrc.enabled and metrc.get_config()[0] and metrc.get_config()[1])
        yield SimpleHelpBlock(
            text=_("Metrc integration"),
            actions=actions,
            icon_url="packages/img/metrc.png",
            priority=2,
            category=HelpBlockCategory.GENERAL,
            done=is_done if kind == "setup" else False
        )
