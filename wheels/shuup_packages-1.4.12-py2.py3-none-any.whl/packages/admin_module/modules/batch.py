# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import PRODUCTS_MENU_CATEGORY
from shuup.admin.utils.urls import (
    admin_url, derive_model_url, get_edit_and_list_urls
)

from packages.models import Batch


class ShuupBatchModule(AdminModule):
    name = _("Inventory")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:batch.list")

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=_("Batches"),
                icon="fa fa-cube",
                url="shuup_admin:batch.list",
                category=PRODUCTS_MENU_CATEGORY,
                ordering=5
            )
        ]

    def get_urls(self):
        return get_edit_and_list_urls(
            url_prefix="^package/batch",
            view_template="packages.admin_module.views.Batch%sView",
            name_template="batch.%s",
        ) + [
            admin_url(
                r"package/batch/(?P<pk>\d+)/received/$",
                "packages.admin_module.views.BatchReceivedView",
                name="batch.received",
            ),
            admin_url(
                r"package/batch/(?P<pk>\d+)/delete/$",
                "packages.admin_module.views.BatchDeleteView",
                name="batch.delete",
            ),
            admin_url(
                r"package/batch/(?P<pk>\d+)/create_packages_from_barcodes/$",
                "packages.admin_module.views.edit.batch.BatchCreatePackagesFromBarcodesView",
                name="batch.create_packages_from_barcodes",
            ),
            admin_url(
                r"package/batch/(?P<pk>\d+)/packages/$",
                "packages.admin_module.views.BatchPackageListView",
                name="batch.packages",
            ),
            admin_url(
                r"package/batch/(?P<pk>\d+)/finish_metrc_package/$",
                "packages.admin_module.views.metrc.BatchFinishMetrcPackageView",
                name="batch.finish_metrc_package",
            )
        ]

    def get_model_url(self, object, kind, shop=None):
        return derive_model_url(Batch, "shuup_admin:batch", object, kind)
