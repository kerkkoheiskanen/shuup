# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import PRODUCTS_MENU_CATEGORY
from shuup.admin.utils.urls import (
    admin_url, derive_model_url, get_edit_and_list_urls
)

from packages.models import PackageLocation


class ShuupPackageLocationModule(AdminModule):
    name = _("Package Locations")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:package_location.list")

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=_("Package Locations"),
                icon="fa fa-cube",
                url="shuup_admin:package_location.list",
                category=PRODUCTS_MENU_CATEGORY,
                ordering=7
            )
        ]

    def get_urls(self):
        return [
            admin_url(
                "package/product/(?P<product_id>\d+)/location_summary$",
                "packages.admin_module.views.list.location.LocationSummaryView",
                name="package_location.product_summary",
            ),
            admin_url(
                "package/package_location/(?P<pk>\d+)/packages$",
                "packages.admin_module.views.list.package.LocationListView",
                name="package_location.detail",
            ),
            admin_url(
               "package/package_location/(?P<pk>\d+)/move",
               "packages.admin_module.views.edit.quick_move.PackagesQuickMoveView",
               name="package_location.quick_move",
            )
        ] + get_edit_and_list_urls(
            url_prefix="^package/package_location",
            view_template="packages.admin_module.views.PackageLocation%sView",
            name_template="package_location.%s",
        )

    def get_model_url(self, object, kind, shop=None):
        return derive_model_url(PackageLocation, "shuup_admin:package_location", object, kind)
