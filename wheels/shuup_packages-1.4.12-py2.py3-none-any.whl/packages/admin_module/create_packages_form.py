# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from uuid import uuid4

from django import forms
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import Product, ProductMode

from packages.models import PackageCondition, PackageLocation, PackageType
from packages.utils import (
    get_sales_unit_for_pieces, get_supplier_from_request, is_bulk_enabled
)

from .forms import QuickAddLocationSelect


class CreatePackagesFromBarcodesForm(forms.Form):

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        self.shop = get_shop(self.request)
        self.batch = kwargs.pop("batch")
        self.supplier = get_supplier_from_request(self.request)
        super(CreatePackagesFromBarcodesForm, self).__init__(*args, **kwargs)

        product_queryset = Product.objects.all_except_deleted().filter(
            shop_products__suppliers=self.supplier,
            mode__in=[ProductMode.NORMAL, ProductMode.VARIATION_CHILD]
        )
        if not is_bulk_enabled(self.shop):
            pieces_sales_unit = get_sales_unit_for_pieces()
            product_queryset = product_queryset.filter(sales_unit=pieces_sales_unit)

        self.fields["product"] = forms.ModelChoiceField(
            label=_("Product linked to package"),
            required=True,
            queryset=product_queryset
        )
        self.fields["package_location"] = forms.ModelChoiceField(
            label=_("Location to add packages to"),
            required=True,
            queryset=PackageLocation.objects.filter(supplier=self.supplier),
            widget=QuickAddLocationSelect()
        )

        self.fields["package_condition"] = forms.ModelChoiceField(
            label=_("Condition for packages"),
            required=True,
            queryset=PackageCondition.objects.filter(supplier=self.supplier),
            initial=PackageCondition.objects.filter(supplier=self.supplier, identifier="normal").first()
        )
        self.fields["barcodes"] = forms.CharField(
            label=_("Barcodes"),
            required=True,
            widget=forms.Textarea()
        )

    def clean_barcodes(self):
        barcodes = self.cleaned_data["barcodes"]
        available = self.batch.available_quantity
        barcodes_count = len(barcodes.splitlines())
        if barcodes_count > settings.SHUUP_PACKAGES_BARCODE_TRANSACTION_LIMIT:
            self.add_error(
                "barcodes",
                _("You can only set %(qty)s barcodes per transaction" % {
                    "qty": settings.SHUUP_PACKAGES_BARCODE_TRANSACTION_LIMIT
                })
            )

        if barcodes_count > available:
            self.add_error("barcodes", _("Batch has only %(qty)s available for transfer." % {"qty": available}))
        return barcodes

    def save(self):
        data = self.cleaned_data
        for barcode in data["barcodes"].splitlines():
            if not barcode:
                continue

            self.batch.create_package_transfer(
                barcode=barcode.strip(),  # Strip out line changes and possible whitespaces
                name=barcode.strip(),  # Strip out line changes and possible whitespaces
                package_type=PackageType.PRE_PACKED,
                quantity=1,
                product=data["product"],
                supplier=self.supplier,
                location=data["package_location"],
                condition=data["package_condition"],
                packaging_weight=0,
                created_by=self.request.user,
                transfer_group=uuid4().hex
            )
        if self.batch:
            if not self.batch.available_quantity:
                self.batch.set_completed()
