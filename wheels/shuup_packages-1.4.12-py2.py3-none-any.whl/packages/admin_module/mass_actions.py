# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db.transaction import atomic
from django.http.response import JsonResponse
from django.utils.translation import ugettext_lazy as _
from shuup.admin.utils.picotable import (
    PicotableFileMassAction, PicotableJavascriptMassAction,
    PicotableMassAction
)

from packages.api.labels import _get_labels_for_packages
from packages.models import Package
from packages.utils import get_supplier_from_request


def get_packages_queryset(request, ids, batch_id=None):
    supplier = get_supplier_from_request(request)
    if ids == "all":
        packages = Package.objects.filter(supplie=supplier)
        if batch_id:
            packages = packages.filter(batch_transfer__batch__id=batch_id)
        return packages

    return Package.objects.filter(id__in=ids, supplier=supplier)


class EnablePackagesMassAction(PicotableMassAction):
    label = _("Enable packages")
    identifier = "enable_packages"

    @atomic
    def process(self, request, ids):
        packages = get_packages_queryset(request, ids, batch_id=request.resolver_match.kwargs.get("pk"))
        for package in packages:
            package.active = True
            package.save()


class DisablePackagesMassAction(PicotableMassAction):
    label = _("Disable packages")
    identifier = "disable_packages"

    @atomic
    def process(self, request, ids):
        packages = get_packages_queryset(request, ids, batch_id=request.resolver_match.kwargs.get("pk"))
        for package in packages:
            package.active = False
            package.save()


class PrintPackageLabelMassAction(PicotableFileMassAction):
    label = _("Print labels")
    identifier = "print_package_labels"

    def process(self, request, ids):
        try:
            from trees.utils.barcode_label import get_barcode_label_pdf
            packages = get_packages_queryset(request, ids, batch_id=request.resolver_match.kwargs.get("pk"))
            response = get_barcode_label_pdf(_get_labels_for_packages(packages))
            response['Content-Disposition'] = 'attachment; filename="labels.pdf"'
            return response
        except ImportError:
            return JsonResponse({"error": "Couldn't print labels. Weasyprint not installed."}, status=400)


class ChangePackagesLocationMassAction(PicotableJavascriptMassAction):
    label = _("Set new location")
    identifier = "set_package_location"
    callback = "setPackagesLocations"


class ChangePackagesConditionMassAction(PicotableJavascriptMassAction):
    label = _("Set new condition")
    identifier = "set_package_condition"
    callback = "setPackagesConditions"
