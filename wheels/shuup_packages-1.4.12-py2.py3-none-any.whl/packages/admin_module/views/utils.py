# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.template.loader import render_to_string

from packages.models import PackageLocation, PackageType
from packages.utils import get_supplier_from_request


def get_package_location_div(request, package):
    supplier = get_supplier_from_request(request)
    # Deprecated!
    context = {
        "package": package,
        "locations": PackageLocation.objects.filter(supplier=supplier)
    }
    return render_to_string("packages/admin/package_location_change.jinja", context=context, request=request)


def get_stock_adjustment_div(request, package):
    # Deprecated!
    if package.type != PackageType.BULK:
        return None
    context = {"package": package}
    return render_to_string("packages/admin/package_stock_adjustment.jinja", context=context, request=request)
