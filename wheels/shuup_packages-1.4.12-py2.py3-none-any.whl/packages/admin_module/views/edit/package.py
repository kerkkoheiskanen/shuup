# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from shuup.admin.utils.views import CreateOrUpdateView

from packages.models import Package
from packages.utils import get_supplier_from_request


class PackageForm(forms.ModelForm):

    class Meta:
        model = Package
        fields = ("barcode", "location", "condition",)


class PackageEditView(CreateOrUpdateView):
    model = Package
    form_class = PackageForm
    template_name = "packages/admin/package_edit.jinja"
    context_object_name = "packages"

    def get_queryset(self):
        return Package.objects.filter(supplier=get_supplier_from_request(self.request))
