# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.core.urlresolvers import reverse_lazy
from django.db.models import Count
from django.utils.translation import ugettext_lazy as _
from shuup.admin.toolbar import Toolbar, URLActionButton
from shuup.admin.utils.forms import get_possible_name_fields_for_model
from shuup.admin.utils.picotable import (
    ChoicesFilter, Column, DateRangeFilter, TextFilter
)
from shuup.admin.utils.views import PicotableListView
from shuup.core.models import Product
from shuup.utils.i18n import format_number

from packages.models import (
    BatchPackageTransfer, Package, PackageLocation, PackageType
)
from packages.utils import get_supplier_from_request


class BasePackageListView(PicotableListView):
    model = Package
    title = "Packages"
    template_name = "packages/admin/package_list_picotable.jinja"

    default_columns = [
        Column(
            "package_type",
            _("Type"),
            display="get_type",
            filter_config=ChoicesFilter(PackageType.choices, filter_field="type")
        ),
        Column(
            "code",
            _("Barcode"),
            display="barcode",
            filter_config=TextFilter(filter_field="barcode", placeholder=_("Filter by name..."))
        ),
        Column(
            "product",
            _("Product"),
            display="get_product",
            filter_config=TextFilter(filter_field="product__translations__name")
        ),
        Column(
            "location",
            _("Location"),
            sortable=False, linked=False, raw=True,
            filter_config=TextFilter(filter_field="location__name")
        ),
        Column(
            "condition",
            _("Condition"),
            sortable=False, linked=False, raw=True,
            filter_config=TextFilter(filter_field="condition__name")
        ),
        Column("available_for_sale", _("Available for sale"), sortable=False, display="get_available_for_sale"),
    ]

    mass_actions = [
        "packages.admin_module.mass_actions:PrintPackageLabelMassAction",
        "packages.admin_module.mass_actions:ChangePackagesLocationMassAction",
        "packages.admin_module.mass_actions:ChangePackagesConditionMassAction",
    ]

    def get_object_abstract(self, instance, item):
        abstract = [
            {"title": "", "text": item.get("package_type")},
            {"title": "", "text": item.get("product")},
            {"title": "", "text": " ", "raw": item.get("location")},
        ]
        if instance.type == PackageType.BULK:
            abstract.append({"title": "", "text": " ", "raw": item.get("adjustment")})
        return abstract

    def get_packaging_weight(self, instance, *args, **kwargs):
        if instance.type == PackageType.PRE_PACKED:
            return " - "
        return "%s g" % format_number(instance.packaging_weight)

    def get_barcode(self, instance, *args, **kwargs):
        return instance.get_barcode()

    def get_type(self, instance, *args, **kwargs):
        return str(instance.type).capitalize()

    def get_product(self, instance, *args, **kwargs):
        return instance.product.safe_translation_getter("name")

    def get_available_for_sale(self, instance, *args, **kwargs):
        if instance.type == PackageType.PRE_PACKED:
            return "1 pcs"

        return "%s g" % format_number(instance.content_weight)

    def get_queryset(self):
        supplier = get_supplier_from_request(self.request)
        return Package.objects.filter(supplier=supplier).order_by("-modified_on").distinct()


class PackageListView(BasePackageListView):

    default_columns = [
        Column(
            "batch",
            _("Batch"),
            display="get_batch",
            filter_config=TextFilter(filter_field="batch_transfer__batch__name")
        ),
    ] + BasePackageListView.default_columns

    def get_queryset(self):
        supplier = get_supplier_from_request(self.request)
        qs = Package.objects.filter(supplier=supplier)
        if not getattr(self.request.user, 'is_superuser', False):
            location_ids = PackageLocation.objects.filter(
                supplier=supplier,
                staff_members=self.request.user
            ).values_list("pk", flat=True) or []
            return qs.filter(location_id__in=location_ids)
        return qs.order_by("-modified_on")

    def get_batch(self, instance, *args, **kwargs):
        transfer = BatchPackageTransfer.objects.filter(package=instance).first()
        return transfer.batch.name if transfer else "-"


class BatchPackageListView(BasePackageListView):
    def get_toolbar(self):
        toolbar = super().get_toolbar()
        toolbar.append(
            URLActionButton(
                url=reverse_lazy("shuup_admin:batch.edit", kwargs={"pk": self.kwargs["pk"]}),
                text=_("Back to batch"),
                icon="fa fa-chevron-left",
                extra_css_class="btn-default"
            )
        )
        return toolbar

    def get_queryset(self):
        return Package.objects.filter(
            batch_transfer__batch_id=self.kwargs["pk"],
            supplier=get_supplier_from_request(self.request)
        ).order_by("-modified_on").distinct()


class LocationListView(PackageListView):
    template_name = "packages/admin/package_list_location_picotable.jinja"

    default_columns = [
        Column(
            "name",
            _("Product"),
            display="get_product",
            filter_config=TextFilter(filter_field="product__translations__name")
        ),
        Column(
            "code",
            _("Barcode"),
            display="barcode", linked=False,
            filter_config=TextFilter(filter_field="barcode", placeholder=_("Filter by name..."))
        ),
        Column(
            "condition",
            _("Condition"),
            sortable=False, linked=False, raw=True,
            filter_config=TextFilter(filter_field="condition__name")
        ),
        Column(
            "modified_on", _("Modified on"), sortable=False, linked=False,
            filter_config=DateRangeFilter(filter_field="modified_on")
        )
    ]

    def __init__(self):
        super(PicotableListView, self).__init__()
        self.columns = [
            Column("select", "", display="", sortable=False, linked=False, class_name="text-center"),
        ] + self.default_columns

    def get_queryset(self):
        qs = Package.objects.filter(location_id=self.kwargs["pk"], supplier=get_supplier_from_request(self.request))
        if not getattr(self.request.user, 'is_superuser', False):
            return qs.filter(location__staff_members=self.request.user).order_by("-modified_on").distinct()
        return qs.order_by("-modified_on").distinct()

    def get_context_data(self, **kwargs):
        context = super(LocationListView, self).get_context_data(**kwargs)
        package_location = PackageLocation.objects.filter(id=self.kwargs["pk"]).first()
        context["location"] = package_location

        toolbar = Toolbar()
        save_button = URLActionButton(
            url=reverse_lazy("shuup_admin:package_location.quick_move", kwargs={"pk": package_location.id}),
            text=_("Quick move to location"),
            icon="fa fa-edit",
            extra_css_class="btn-primary"
        )
        toolbar.append(save_button)

        save_button = URLActionButton(
            url=reverse_lazy("shuup_admin:package_location.edit", kwargs={"pk": package_location.id}),
            text=_("Edit location"),
            icon="fa fa-edit",
            extra_css_class="btn-default"
        )
        toolbar.append(save_button)
        context["toolbar"] = toolbar

        product_summary = Product.objects.filter(packages__location=package_location).annotate(count=Count('packages'))
        context["product_summary"] = product_summary

        # For location quick add
        context["iframe_mode"] = bool(self.request.GET.get("mode", "") == "iframe")
        if context["iframe_mode"] and package_location and package_location.id is not None:
            name = None
            for field in get_possible_name_fields_for_model(package_location.__class__):
                name = getattr(package_location, field, None)
                if name:
                    break

            context["iframe_close"] = bool(self.request.GET.get("iframe_close"))
            context["quick_add_target"] = self.request.GET.get("quick_add_target", "")
            context["quick_add_callback"] = self.request.GET.get("quick_add_callback", "")
            context["quick_add_option_id"] = package_location.id
            context["quick_add_option_name"] = name if name else _("Unnamed")

        return context
