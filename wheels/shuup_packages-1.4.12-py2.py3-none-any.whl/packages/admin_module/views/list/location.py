# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.db.models import DecimalField, F, Sum
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.admin.utils.picotable import Column, TextFilter
from shuup.admin.utils.views import PicotableListView
from shuup.core.models import Product
from shuup.utils.i18n import format_money

from packages.models import Package, PackageLocation, PackageType
from packages.utils import get_supplier_from_request


class PackageLocationListView(PicotableListView):
    model = PackageLocation
    default_columns = [
        Column(
            "name",
            _("Name"),
            sort_field="name",
            display="name",
            filter_config=TextFilter(
                filter_field="name",
                placeholder=_("Filter by name...")
            )
        )
    ]

    def get_queryset(self):
        qs = PackageLocation.objects.filter(supplier=get_supplier_from_request(self.request))
        if not getattr(self.request.user, 'is_superuser', False):
            return qs.filter(staff_members=self.request.user)
        return qs


class LocationSummaryView(PicotableListView):
    model = PackageLocation
    default_columns = [
        Column("shop", _("Shop"), display="get_shop_name"),
        Column(
            "name", _("Location"), filter_config=TextFilter(filter_field="name")
        ),
        Column(
            "pre-pack-count", _("Prepack count / Purchase cost"), sortable=False, display="get_pre_pack_summary"
        ),
        Column(
            "grams-count", _("Bulk in grams / Purchase cost"), sortable=False, display="get_bulk_summary"
        )
    ]

    def __init__(self):
        super(PicotableListView, self).__init__()
        self.columns = self.default_columns

    def get_queryset(self):
        self.shop = get_shop(self.request)
        self.supplier = get_supplier_from_request(self.request)
        self.product_id = self.kwargs["product_id"]
        return PackageLocation.objects.filter(supplier=self.supplier)

    def get_shop_name(self, instance, *args, **kwargs):
        return self.shop.name

    def get_pre_pack_summary(self, instance, *args, **kwargs):
        query = Package.objects.filter(product_id=self.product_id, location=instance, type=PackageType.PRE_PACKED)
        pre_pack_count = query.count()
        pre_pack_value = query.aggregate(
            Sum("purchase_price_value"))["purchase_price_value__sum"] or 0
        return "%s / %s" % (pre_pack_count, format_money(self.shop.create_price(pre_pack_value)))

    def get_bulk_summary(self, instance, *args, **kwargs):
        query = Package.objects.filter(product_id=self.product_id, location=instance, type=PackageType.BULK)
        pre_pack_count = query.count()
        pre_pack_value = query.aggregate(
            total=Sum(F("purchase_price_value") * F("content_weight"), output_field=DecimalField()))["total"] or 0

        return "%s / %s" % (pre_pack_count, format_money(self.shop.create_price(pre_pack_value)))

    def get_context_data(self, **kwargs):
        context = super(LocationSummaryView, self).get_context_data(**kwargs)
        product_name = Product.objects.filter(id=self.product_id).first().name
        context["title"] = _("Location summary for %(product_name)s" % {"product_name": product_name})
        context["toolbar"] = None
        return context
