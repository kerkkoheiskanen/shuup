# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db import models
from django.db.models import Sum
from django.utils.translation import ugettext_lazy as _


class PurchaseOrder(models.Model):
    supplier = models.ForeignKey("shuup.Supplier", on_delete=models.CASCADE, verbose_name=_("supplier"))
    number = models.CharField(max_length=64, verbose_name=_("number"), help_text=_("Enter the purchase order number."))
    date = models.DateField(verbose_name=_("date"))
    batches = models.ManyToManyField("packages.Batch", blank=True, related_name="purchase_orders")
    provider = models.ForeignKey(
        "packages.BatchProvider",
        related_name="purchase_orders",
        on_delete=models.PROTECT,
        verbose_name=_("distributor")
    )

    class Meta:
        verbose_name = _("Purchase Order")
        verbose_name_plural = _("Purchase Orders")
        unique_together = ("supplier", "number")

    def __str__(self):
        return "Purchase Order #{}".format(self.number)

    @property
    def purchased_total_value(self):
        return self.batches.all().aggregate(total=Sum("purchase_price_value"))["total"] or 0
