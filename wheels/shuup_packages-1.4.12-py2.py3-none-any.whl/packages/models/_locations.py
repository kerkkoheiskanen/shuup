# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _


class PackageLocation(models.Model):
    name = models.CharField(max_length=64, verbose_name=_("location"), help_text=_("Enter the location name."))
    supplier = models.ForeignKey("shuup.Supplier", on_delete=models.CASCADE, verbose_name=_("supplier"))
    sellable = models.BooleanField(default=True, verbose_name=_("sellable"))
    staff_members = models.ManyToManyField(
        settings.AUTH_USER_MODEL, blank=True, related_name="+", verbose_name=_('staff members'))

    class Meta:
        verbose_name = _("Package location")
        verbose_name_plural = _("Package locations")

    def __str__(self):
        return self.name
