# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Sum
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum, EnumField
from shuup.core.fields import MoneyValueField, QuantityField

from packages.utils import get_sales_unit_for_grams

from ._packages import Package, PackageCondition, PackageType


class BatchState(Enum):
    Incoming = "incoming"
    Received = "received"
    Completed = "completed"

    class Labels:
        Incoming = _("Incoming")
        Received = _("Received")
        Completed = _("Completed")


class TransferOrigin(Enum):
    Batch = "batch"
    Package = "package"

    class Labels:
        Batch = _("Batch")
        Package = _("Package")


class BatchProvider(models.Model):
    name = models.CharField(max_length=64, verbose_name=_("name"), help_text=_("Enter the distributor name"))
    supplier = models.ForeignKey("shuup.Supplier", on_delete=models.CASCADE, verbose_name=_("supplier"), null=True)

    def __str__(self):
        return self.name


class Batch(models.Model):
    supplier = models.ForeignKey("shuup.Supplier", on_delete=models.CASCADE, verbose_name=_("supplier"))
    name = models.CharField(max_length=64, verbose_name=_("name"))
    identifier = models.CharField(max_length=128, blank=True, null=True, verbose_name=_("identifier"))
    notes = models.TextField(blank=True, null=True, verbose_name=_("notes"))
    provider = models.ForeignKey(
        BatchProvider, blank=True, null=True, related_name="batches", on_delete=models.PROTECT,
        verbose_name=_("distributor")
    )
    quantity = QuantityField(verbose_name=_("quantity"))
    sales_unit = models.ForeignKey("shuup.SalesUnit", verbose_name=_('sales unit'), blank=True, null=True)
    purchase_price_value = MoneyValueField(default=0)
    created_on = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name=_("created on"))
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, blank=True, null=True, editable=False, on_delete=models.PROTECT,
        verbose_name=_("created by")
    )
    received_on = models.DateTimeField(blank=True, null=True, db_index=True, verbose_name=_("received on"))
    completed_on = models.DateTimeField(blank=True, null=True, db_index=True, verbose_name=_("completed on"))
    state = EnumField(BatchState, default=BatchState.Incoming, verbose_name=_("State"))
    metrc_tag = models.CharField(max_length=24, verbose_name=_("Metrc tag"), blank=True, null=True, unique=True)

    def __str__(self):
        return self.name

    def set_received(self):
        self.received_on = now()
        self.state = BatchState.Received
        self.save()

    def set_completed(self):
        self.completed_on = now()
        self.state = BatchState.Completed
        self.save()

    @property
    def available_quantity(self):
        return (self.quantity - self.total_transferred)

    @property
    def total_transferred(self):
        return self.transfers.filter(
            transfer_origin=TransferOrigin.Batch
        ).aggregate(total=Sum("quantity"))["total"] or 0

    def is_in_grams(self):
        gram_sales_unit = get_sales_unit_for_grams()
        if not gram_sales_unit:
            return False
        return bool(self.sales_unit == gram_sales_unit)

    @property
    def price_per_sales_unit(self):
        return Decimal(self.purchase_price_value / self.quantity)

    def create_package_transfer(    # noqa (C901)
            self, package_type, quantity, name, product=None, supplier=None, condition=None, location=None,
            packaging_weight=0, created_by=None, origin_package=None, transfer_group=None, barcode=None,
            product_net_weight=None):

        if not origin_package and self.state != BatchState.Received:
            raise ValidationError(_("Invalid batch state for this origin."))

        if origin_package and quantity > origin_package.content_weight:
            raise ValidationError(_("Quantity should be lower or equals to the available quantity."))

        if not origin_package and quantity > self.available_quantity:
            raise ValidationError(_("Quantity should be lower or equals to the available quantity."))

        if not condition:
            condition = PackageCondition.objects.get(identifier="normal", supplier=self.supplier)

        if origin_package and not self.is_in_grams():
            raise ValidationError(_("It is not possible to create transfer when batch sales unit is not in grams."))

        package = None
        if product:
            if package_type == PackageType.PRE_PACKED:
                purchase_price_value = (quantity * self.price_per_sales_unit)

                # For prepacked product try to set content weight from product.
                # If product net weight is not available try quantity + packaging weight
                # and finally fallback to 1 which is totally fine with pre-packs.
                total_weight = product_net_weight or (quantity + packaging_weight) or 1
            else:
                purchase_price_value = self.price_per_sales_unit
                total_weight = (quantity + packaging_weight)

            package = Package.objects.create(
                product_id=(product.pk if hasattr(product, "pk") else product),
                supplier=self.supplier,
                type=package_type,
                location=location,
                name=name,
                condition=condition,
                total_weight=total_weight,
                packaging_weight=packaging_weight,
                purchase_price_value=purchase_price_value,
                barcode=barcode
            )

        package_transfer = BatchPackageTransfer(
            package=package,
            batch=self,
            quantity=quantity,
            created_by=created_by,
            transfer_group=transfer_group
        )

        if origin_package:
            package_transfer.transfer_origin = TransferOrigin.Package
            package_transfer.origin_package = origin_package

            from ._packages import PackageMeasurement
            PackageMeasurement.objects.create(
                package=origin_package,
                last_weight=origin_package.total_weight,
                total_weight=(origin_package.total_weight - quantity),
                created_by=created_by
            )
            origin_package.save()

        package_transfer.full_clean()
        package_transfer.save()
        return package_transfer


class BatchPackageTransfer(models.Model):
    batch = models.ForeignKey(Batch, related_name="transfers", verbose_name=_("batch"))
    package = models.OneToOneField(
        Package,
        related_name="batch_transfer",
        blank=True, null=True,
        verbose_name=_("package")
    )
    quantity = QuantityField(verbose_name=_("quantity"))
    created_on = models.DateTimeField(auto_now_add=True, db_index=True, verbose_name=_("created on"))
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        blank=True, null=True,
        editable=False,
        on_delete=models.PROTECT,
        verbose_name=_("created by")
    )
    transfer_origin = EnumField(
        TransferOrigin,
        default=TransferOrigin.Batch,
        db_index=True,
        verbose_name=_("transfer origin")
    )
    origin_package = models.ForeignKey(
        Package,
        related_name="transfers",
        blank=True, null=True,
        verbose_name=_("origin package")
    )
    transfer_group = models.CharField(
        verbose_name=_("transfer group"),
        db_index=True, max_length=32,
        blank=True, null=True,
        help_text=_("name to identify a transfer group")
    )

    class Meta:
        verbose_name = _("Batch package transfer")
        verbose_name_plural = _("Batch package transfers")
