# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db import models
from django.utils.text import slugify
from django.utils.translation import ugettext_lazy as _
from shuup.core.fields import InternalIdentifierField


class PackageCondition(models.Model):
    identifier = InternalIdentifierField(unique=False)
    name = models.CharField(max_length=64, verbose_name=_("name"), help_text=_("Enter the package condition name."))
    supplier = models.ForeignKey("shuup.Supplier", on_delete=models.CASCADE, verbose_name=_("supplier"))
    sellable = models.BooleanField(default=True, verbose_name=_("sellable"))

    class Meta:
        verbose_name = _("Package condition")
        verbose_name_plural = _("Package conditions")
        unique_together = ("identifier", "supplier")

    def save(self, *args, **kwargs):
        if not self.identifier:
            self.identifier = slugify(self.name)
        return super(PackageCondition, self).save(*args, **kwargs)

    def __str__(self):
        return self.name
