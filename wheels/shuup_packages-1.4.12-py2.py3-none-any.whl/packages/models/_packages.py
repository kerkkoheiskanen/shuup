# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.db import models
from django.db.models import F, Q
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum, EnumIntegerField
from shuup.core.fields import MeasurementField, MoneyValueField
from shuup.core.models import Product, ProductMode
from shuup.core.suppliers.enums import StockAdjustmentType
from shuup.utils.analog import define_log_model

from packages.package_logging import create_order_attached_to_package_log
from packages.signals import package_saved

from ._conditions import PackageCondition
from ._locations import PackageLocation


class PackageRestockDestination(Enum):
    NEW_PACKAGE = "new"
    ORIGINAL_PACKAGE = "original"

    class Labels:
        NEW_PACKAGE = _("New package")
        ORIGINAL_PACKAGE = _("Original package")


class PackageType(Enum):
    BULK = 0
    PRE_PACKED = 1

    class Labels:
        BULK = _("Bulk")
        PRE_PACKED = _("Pre-packed")


class PackageQuerySet(models.QuerySet):
    def is_in_sale(self):
        filter_query = Q(
            active=True, type__in=[PackageType.BULK, PackageType.PRE_PACKED],
            condition__sellable=True, location__sellable=True
        )

        # Check valid weights only for bulk
        exclude_query = Q(Q(type=PackageType.BULK), Q(content_weight=0) | Q(total_weight__lte=F("packaging_weight")))
        return self.filter(filter_query).exclude(exclude_query)


class Package(models.Model):
    supplier = models.ForeignKey("shuup.Supplier", on_delete=models.PROTECT, verbose_name=_("supplier"))

    created_on = models.DateTimeField(auto_now_add=True, editable=False, db_index=True, verbose_name=_("created on"))
    modified_on = models.DateTimeField(auto_now=True, editable=False, verbose_name=_('modified on'))
    type = EnumIntegerField(PackageType, default=PackageType.BULK, verbose_name=_('type'))
    name = models.CharField(
        max_length=64, verbose_name=_("name"), help_text=_("Enter a name for the package.")
    )
    barcode = models.CharField(
        max_length=512, blank=True, null=True,
        verbose_name=_("barcode"), help_text=_("Enter a barcode for the package.")
    )
    location = models.ForeignKey(
        PackageLocation, related_name="packages", verbose_name=_("location"), on_delete=models.PROTECT
    )
    condition = models.ForeignKey(
        PackageCondition, null=True, blank=True, verbose_name=_("condition"), related_name="packages"
    )
    active = models.BooleanField(default=True, db_index=True, verbose_name=_("active"))

    packaging_weight = MeasurementField(
        unit="g", verbose_name=_("packaging weight (g)"),
        help_text=_("Set the measured weight of the packaging without contents."))
    content_weight = MeasurementField(
        unit="g", verbose_name=_("content weight (g)"),
        help_text=_("Content amount in package. Calculated automatically on save."))
    total_weight = MeasurementField(
        unit="g", verbose_name=_("total weight (g)"),
        help_text=_("The measured total weight of the package including its contents. "
                    "This value should always be at least the packaging weight."))

    product = models.ForeignKey(
        "shuup.Product", related_name="packages", verbose_name=_("product"),
        help_text=_("Select the product that are sold from this package."))

    purchase_price_value = MoneyValueField(default=0, help_text="Purchase price value per sales unit.")

    has_orders = models.BooleanField(default=False, db_index=True, verbose_name=_("has orders"))

    objects = PackageQuerySet.as_manager()

    class Meta:
        verbose_name = _("Package")
        verbose_name_plural = _("Packages")

    def __str__(self):
        return "Package {}".format(self.name)

    def get_barcode(self):
        return (self.barcode if self.barcode else "PKG{}".format(self.id))

    def get_label(self):
        return "%0.1fg %s" % (self.content_weight, self.get_barcode())

    def cache_attrs(self):
        if self.id:
            latest_measurement = PackageMeasurement.objects.filter(package_id=self.id).order_by("-created_on").first()
            if latest_measurement:
                self.total_weight = latest_measurement.total_weight

        self.content_weight = (self.total_weight - self.packaging_weight)
        if self.content_weight and self.total_weight and not self.packaging_weight:
            self.packaging_weight = (self.total_weight - self.content_weight)

        if self.content_weight == 0:
            sold_location = PackageLocation.objects.filter(
                supplier=self.supplier, name=settings.SHUUP_PACKAGES_SOLD_LOCATION_NAME).first()
            if sold_location:
                self.location = sold_location

        self.has_orders = PackageMeasurement.objects.filter(package_id=self.id, order__isnull=False).exists()

    def save(self, *args, **kwargs):
        is_new = getattr(self, "pk", None) is None

        old_data = {}
        if not is_new:
            old_package = Package.objects.filter(pk=self.pk).first()
            old_data = {
                "old_barcode": old_package.barcode,
                "old_location": old_package.location,
                "old_condition": old_package.condition,
                "old_content_weight": old_package.content_weight
            }

        self.cache_attrs()
        super(Package, self).save(*args, **kwargs)

        if is_new:
            PackageMeasurement.objects.create(
                package=self,
                last_weight=self.total_weight,
                total_weight=self.total_weight
            )
        package_saved.send(sender=Package, instance=self, is_new=is_new, old_data=old_data)

    def get_products_available_for_pre_packing(self):
        if not self.id:
            return Product.objects.none()

        root = self.get_root()
        pre_pack_products = root.pre_pack_products.values_list("id", flat=True)
        return Product.objects.filter(
            Q(mode__in=[ProductMode.NORMAL, ProductMode.VARIATION_CHILD]) &
            Q(id__in=pre_pack_products) | Q(variation_parent__id__in=pre_pack_products)
        ).distinct()

    def get_all_sellable_products(self):
        if not self.id:
            return Product.objects.none()

        root = self.get_root()
        products_available_for_sale = set(
            list(root.products.values_list("id", flat=True)) + list(root.pre_pack_products.values_list("id", flat=True))
        )
        return Product.objects.filter(
            Q(mode__in=[ProductMode.NORMAL, ProductMode.VARIATION_CHILD]) &
            Q(id__in=products_available_for_sale) | Q(variation_parent__id__in=products_available_for_sale)
        ).distinct()

    @classmethod
    def get_packages_for_products(cls, supplier_ids, product_ids):
        return Package.objects.is_in_sale().filter(supplier__in=supplier_ids).filter(
            Q(product_id__in=product_ids) |
            Q(product__in=Product.objects.filter(id__in=product_ids).values_list("variation_parent", flat=True))
        ).distinct()

    @classmethod
    def get_packages_for_order(cls, order):
        from packages.modules import PackageSupplierModule
        lines = [line for line in order.lines.products() if (
            line.supplier and line.supplier.module_identifier == PackageSupplierModule.identifier
        )]
        if lines:
            supplier_ids = [line.supplier_id for line in lines]
            products_ids = [line.product_id for line in lines]
            return cls.get_packages_for_products(supplier_ids, products_ids)

        return cls.objects.none()

    def update_stocks(self):
        product_ids = [self.product.id] + list(self.product.variation_children.values_list("id", flat=True))
        self.supplier.update_stocks(product_ids)


class PackageMeasurement(models.Model):
    package = models.ForeignKey(
        Package,
        verbose_name=_("Package"),
        on_delete=models.CASCADE,
        related_name="measurements"
    )
    created_on = models.DateTimeField(auto_now_add=True, editable=False, db_index=True, verbose_name=_("created on"))
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, blank=True, null=True, on_delete=models.PROTECT, verbose_name=_("created by"))
    last_weight = MeasurementField(unit="g", verbose_name=_("last measured weight (g)"))
    total_weight = MeasurementField(unit="g", editable=False, verbose_name=_("total package measured weight (g)"))
    type = EnumIntegerField(
        StockAdjustmentType, db_index=True, default=StockAdjustmentType.INVENTORY, verbose_name=_("type"))
    order = models.ForeignKey(
        "shuup.Order", null=True, related_name="package_measurements", verbose_name=_("order"),
        help_text=_("The order which generated this measurement.")
    )
    order_line = models.ForeignKey(
        "shuup.OrderLine", null=True, related_name="package_measurements", verbose_name=_("order line"),
        help_text=_("The order line which generated this measurement.")
    )
    purchase_price_value = MoneyValueField(default=0, help_text="Purchase price value per measured quantity.")

    class Meta:
        verbose_name = _("Package weight measurement")
        verbose_name_plural = _("Package weight measurements")

    @property
    def quantity(self):
        return (self.last_weight - self.total_weight)

    def save(self, *args, **kwargs):
        is_new = getattr(self, "pk", None) is None
        if not is_new:  # We shouldn't update measurements too often so this should be ok
            old_measurement = PackageMeasurement.objects.filter(pk=self.pk).first()
            old_measurement_has_order_line = old_measurement.order_line

        if self.package.type == PackageType.BULK:
            self.purchase_price_value = (self.last_weight - self.total_weight) * self.package.purchase_price_value
        else:
            self.purchase_price_value = self.package.purchase_price_value

        super(PackageMeasurement, self).save(*args, **kwargs)
        self.package.save()

        if (is_new or not old_measurement_has_order_line) and self.order_line:
            create_order_attached_to_package_log(self.package, self.order_line.order.id, self.order_line.id)


PackageLogEntry = define_log_model(Package)
