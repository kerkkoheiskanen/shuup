# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db import models
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from shuup.utils.analog import BaseLogEntry, LogEntryKind


class MetrcLog(BaseLogEntry):
    shop = models.ForeignKey("shuup.Shop", verbose_name=_("Shop"), related_name="metrc_logs")

    class Meta:
        verbose_name = _("Metrc Log")
        verbose_name_plural = _("Metrc Logs")
        abstract = False

    @classmethod
    def add_log_entry(cls, shop, message, identifier=None, kind=LogEntryKind.OTHER, user=None, extra=None):
        return cls.objects.create(
            shop=shop,
            message=force_text(message),
            identifier=force_text(identifier or "", errors="ignore")[:64],
            user=user,
            kind=kind,
            extra=(extra or None)
        )
