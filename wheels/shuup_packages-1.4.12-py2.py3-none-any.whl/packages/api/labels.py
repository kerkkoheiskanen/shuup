# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.http.response import JsonResponse
from django.template.loader import render_to_string
from rest_framework import serializers, viewsets
from rest_framework.decorators import detail_route, list_route

from packages.models import Package
from packages.utils import get_supplier_from_request


class PrintLabelsSerializer(serializers.Serializer):
    packages = serializers.PrimaryKeyRelatedField(queryset=Package.objects.all(), required=False, many=True)


class PackageLabelMixin(viewsets.GenericViewSet):
    @detail_route(methods=["get"])
    def label(self, request, pk=None):
        try:
            from trees.utils.barcode_label import get_barcode_label_pdf
            return get_barcode_label_pdf(_get_labels_for_packages([self.get_object()]))
        except ImportError:
            return JsonResponse({"error": "Couldn't print labels. Weasyprint not installed."}, status=400)

    @list_route(methods=['post'])
    def print_labels(self, request):
        serializer = PrintLabelsSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        packages = serializer.validated_data["packages"]
        supplier = get_supplier_from_request(self.request)
        try:
            from trees.utils.barcode_label import get_barcode_label_pdf
            return get_barcode_label_pdf(
                _get_labels_for_packages([package for package in packages if package.supplier == supplier])
            )
        except ImportError:
            return JsonResponse({"error": "Couldn't print labels. Weasyprint not installed."}, status=400)


def _get_labels_for_packages(packages):
    return render_to_string("packages/label.jinja", context={"packages": packages})
