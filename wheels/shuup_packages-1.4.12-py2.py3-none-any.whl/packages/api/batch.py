# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from uuid import uuid4

from django.core.exceptions import ValidationError
from django.db.models import Q
from django.db.models.signals import post_save
from django.db.transaction import atomic
from django.utils.text import force_text
from django.utils.translation import ugettext_lazy as _
from rest_framework import exceptions, mixins, serializers, viewsets
from rest_framework.decorators import detail_route
from rest_framework.response import Response
from rest_framework.settings import api_settings
from shuup.api.fields import EnumField, FormattedDecimalField
from shuup.api.mixins import PermissionHelperMixin, SearchableMixin
from shuup.core.models import (
    AnonymousContact, Product, ProductMode, ShopProduct, StockBehavior
)

from packages.models import (
    Batch, BatchPackageTransfer, BatchState, Package, PackageCondition,
    PackageLocation, PackageType, TransferOrigin
)
from packages.signal_handlers import handle_package_post_save
from packages.utils import (
    get_package_id_from_barcode, get_sales_unit_for_pieces,
    get_supplier_from_request, temp_disconnect_signal
)

try:
    from shuup_pos.permissions import EmployeeUserPermission
except ImportError:  # For tests
    from rest_framework.permissions import BasePermission

    class EmployeeUserPermission(BasePermission):
        def has_permission(self, request, view):
            return True


class PackageConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = PackageCondition
        fields = ["id", "identifier", "name", "sellable"]


class PackageLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PackageLocation
        fields = ["id", "name"]


class PackageProductSerializier(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ["id", "name", "mode"]


class BaseBatchPackagesSerializer(serializers.ModelSerializer):
    location = PackageConditionSerializer()
    condition = PackageConditionSerializer()
    product = PackageProductSerializier()
    transferred = FormattedDecimalField(source="batch_transfer.quantity", read_only=True)
    available_for_sale = serializers.SerializerMethodField()
    barcode = serializers.ReadOnlyField(source="get_barcode")
    transfer_group = serializers.ReadOnlyField(source="batch_transfer.transfer_group")

    def get_available_for_sale(self, package):
        product = package.product
        if product:
            return package.supplier.get_stock_status(product.id).logical_count
        return 0

    class Meta:
        model = Package
        fields = [
            "id", "name", "condition", "type", "total_weight", "content_weight", "location",
            "product", "transferred", "created_on", "available_for_sale", "has_orders", "barcode",
            "transfer_group"
        ]


class BatchPackagesSerializer(BaseBatchPackagesSerializer):
    origin_package = BaseBatchPackagesSerializer(source="batch_transfer.origin_package", read_only=True)

    class Meta(BaseBatchPackagesSerializer.Meta):
        fields = BaseBatchPackagesSerializer.Meta.fields + ["origin_package"]


class BatchPackageTransferSerializer(serializers.ModelSerializer):
    transferred = FormattedDecimalField(source="quantity", read_only=True)
    transfer_group = serializers.ReadOnlyField()
    has_orders = serializers.ReadOnlyField(source="package.has_orders")
    location = PackageConditionSerializer(source="package.location")
    condition = PackageConditionSerializer(source="package.condition")
    product = PackageProductSerializier(source="package.product")
    barcode = serializers.ReadOnlyField(source="package.get_barcode")
    type = serializers.ReadOnlyField(source="package.type")
    total_weight = serializers.ReadOnlyField(source="package.total_weight")
    content_weight = serializers.ReadOnlyField(source="package.content_weight")
    name = serializers.ReadOnlyField(source="package.name")
    available_for_sale = serializers.SerializerMethodField()
    origin_package = BaseBatchPackagesSerializer()

    class Meta:
        model = BatchPackageTransfer
        fields = "__all__"

    def get_available_for_sale(self, batch_transfer):
        if not hasattr(batch_transfer, "package") or not hasattr(batch_transfer.package, "product"):
            return 0
        return batch_transfer.package.supplier.get_stock_status(batch_transfer.package.product.id).logical_count


class BatchProductSummary(serializers.Serializer):
    id = serializers.ReadOnlyField()
    name = serializers.ReadOnlyField()
    available_for_sale = serializers.SerializerMethodField()
    transferred = FormattedDecimalField()
    packages_count = serializers.IntegerField()

    def get_available_for_sale(self, data):
        return self.context["batch"].supplier.get_stock_status(data["product_id"]).logical_count


class BatchSerializer(serializers.ModelSerializer):
    sales_unit_identifier = serializers.ReadOnlyField(source="sales_unit.identifier")
    sales_unit_symbol = serializers.ReadOnlyField(source="sales_unit.symbol")
    available_quantity = FormattedDecimalField(read_only=True)
    total_transferred = FormattedDecimalField(read_only=True)

    class Meta:
        model = Batch
        exclude = []


class BatchPackageTransferCreateSerializer(serializers.Serializer):
    origin = EnumField(TransferOrigin)
    package_type = EnumField(PackageType)
    package = serializers.PrimaryKeyRelatedField(
        queryset=Package.objects.filter(active=True, content_weight__gt=0, type=PackageType.BULK),
        required=False
    )
    product = serializers.PrimaryKeyRelatedField(queryset=Product.objects.all_except_deleted(), required=False)
    condition = serializers.PrimaryKeyRelatedField(queryset=PackageCondition.objects.all())
    location = serializers.PrimaryKeyRelatedField(queryset=PackageLocation.objects.all())
    quantity = FormattedDecimalField()
    packaging_weight = FormattedDecimalField(required=False)

    def validate(self, attrs):  # noqa: C901
        attrs = super(BatchPackageTransferCreateSerializer, self).validate(attrs)
        batch = self.context["batch"]

        if attrs["origin"] == TransferOrigin.Batch and batch.state != BatchState.Received:
            raise exceptions.ValidationError(_("Invalid batch state for this origin."))

        supplier = get_supplier_from_request(self.context["request"])

        if attrs["location"].supplier != supplier:
            raise exceptions.ValidationError(_("Invalid location."))

        if attrs["condition"].supplier != supplier:
            raise exceptions.ValidationError(_("Invalid condition."))

        product = attrs.get("product")
        if product:
            if not ShopProduct.objects.filter(suppliers=supplier, product=product).exists():
                raise exceptions.ValidationError(_("Invalid product."))

        if attrs["quantity"] <= 0:
            raise exceptions.ValidationError(_("Invalid quantity."))

        required_quantity = attrs["quantity"]
        package_type = attrs["package_type"]

        if package_type == PackageType.PRE_PACKED:
            if not product:
                raise exceptions.ValidationError(_("The product is required for the package type."))

            if product.sales_unit != get_sales_unit_for_pieces():
                raise exceptions.ValidationError(_("Product sales unit needs to be pieces for pre packing."))

            if product.mode not in [ProductMode.NORMAL, ProductMode.VARIATION_CHILD]:
                raise exceptions.ValidationError(_("Invalid product for the package type."))

            if not float(required_quantity).is_integer():
                raise exceptions.ValidationError(_("The quantity should be an integer."))

            # For batches in grams we transfer need to multiple product net weight with
            # quantity to get the real transfer quantity
            if batch.is_in_grams() and product.net_weight:
                required_quantity = (product.net_weight * attrs["quantity"])

        elif package_type == PackageType.BULK:
            if product and not product.is_variation_parent() and product.sales_unit == get_sales_unit_for_pieces():
                raise exceptions.ValidationError(_("Product sales unit can not be pieces for bulk packages."))
            elif not batch.is_in_grams():
                raise exceptions.ValidationError(_("Invalid package type bulk for pieces based batch."))

        if attrs["origin"] == TransferOrigin.Batch and required_quantity > batch.available_quantity:
            raise exceptions.ValidationError(_("Insufficient quantity in batch."))

        elif attrs["origin"] == TransferOrigin.Package:
            if not batch.is_in_grams():
                msg = _("It is not possible to create transfer when batch sales unit is not grams.")
                raise exceptions.ValidationError(msg)

            package = attrs["package"]
            if package.supplier != supplier:
                raise exceptions.ValidationError(_("Invalid package."))

            if package.batch_transfer.batch != batch:
                raise exceptions.ValidationError(_("Invalid batch."))

            if required_quantity > package.content_weight:
                raise exceptions.ValidationError(_("Insufficient quantity in package."))

        return attrs

    @atomic  # noqa: C901
    def create(self, data):
        batch = self.context["batch"]
        supplier = batch.supplier
        origin = data.pop("origin")
        quantity = data.pop("quantity")
        condition = data.pop("condition")
        location = data.pop("location")
        package_type = data.pop("package_type")
        product = data.pop("product", None)
        packaging_weight = data.pop("packaging_weight", 0)
        packages = []
        original_name = product.safe_translation_getter("name") if product else "Package"

        extra_kwargs = {}
        if origin == TransferOrigin.Package:
            extra_kwargs["origin_package"] = data["package"]

        if not condition:
            condition = PackageCondition.objects.get(identifier="normal", supplier=batch.supplier)

        # Disconnect post save signal for bumping stocks
        #     In case a lot of prepackaged products are created
        #     here it is awfully slow to bump product stock after
        #     each package created. Those would not have effect
        #     anyways since this package transfer is from now on
        #     also atomic.
        with temp_disconnect_signal(post_save, handle_package_post_save, Package, "handle_package_post_save"):
            if package_type == PackageType.PRE_PACKED:
                quantity = int(quantity)
                transfer_group = uuid4().hex

                # TODO: Do thi sloop inside batch transfer and only create one transfer for whole quantity
                # Maybe shit turns out to be faster
                for i in range(1, quantity + 1):
                    name = ("%s-%s" % (original_name, i) if quantity > 1 else original_name)

                    # If the batch quantity sales unit is in grams we need to transfer the amount
                    # based on the product weight. For example creating 10 pre-packs when product
                    # net weight is 2 grams should transfer 20 grams when the batch is in grams.
                    # When the batch quantity is in pieces we want to transfer the exact amount
                    # the merchant filled out. For example if he transfers 20 t-shirts the transfer
                    # amount should be 20.
                    qty_to_transfer = (
                        product.net_weight if batch.is_in_grams() and (product and product.net_weight) else 1
                    )

                    batch_transfer = batch.create_package_transfer(
                        package_type=package_type,
                        quantity=qty_to_transfer,
                        name=name,
                        product=product,
                        supplier=supplier,
                        condition=condition,
                        location=location,
                        created_by=self.context["request"].user,
                        transfer_group=transfer_group,
                        product_net_weight=product.net_weight,
                        **extra_kwargs
                    )
                    packages.append(batch_transfer.package)
            else:
                batch_transfer = batch.create_package_transfer(
                    package_type=package_type,
                    quantity=quantity,
                    name=original_name,
                    product=product,
                    supplier=supplier,
                    condition=condition,
                    location=location,
                    packaging_weight=packaging_weight,
                    created_by=self.context["request"].user,
                    **extra_kwargs
                )
                packages.append(batch_transfer.package)

        # Since post save signal is disconnect update stock and bump cache.
        if product and supplier:
            product_ids = [product.id] + list(product.variation_children.values_list("id", flat=True))
            supplier.update_stocks(product_ids)
            try:
                from trees.cache import bump_shop_product_cache
                bump_shop_product_cache(product.get_shop_instance(batch.shop))  # Is batch.shop a good replacement?
            except (ImportError, ShopProduct.DoesNotExist):
                # In some situations it could be possible that
                # there isn't shop product for all product children
                # since the products might be splitted with multiple
                # shops which might have created somehow shop product
                # only for few variations.
                pass

            # When called through API which is the most common
            # way let's quickly make sure that product is in
            # right place.
            change_product = product
            if change_product.variation_parent:
                change_product = product.variation_parent

            for prod in [change_product] + list(change_product.variation_children.all()):
                prod.stock_behavior = StockBehavior.STOCKED
                prod.save(update_fields=["stock_behavior"])
                shop_product = prod.get_shop_instance(batch.shop)
                shop_product.suppliers.add(supplier)

                product_ids = [product.id] + list(product.variation_children.values_list("id", flat=True))
                supplier.update_stocks(product_ids)

                shop_product = ShopProduct.objects.filter(product=product, suppliers=supplier).first()
                if shop_product:
                    from trees.cache import bump_shop_product_cache
                    bump_shop_product_cache(shop_product)

        return packages


class ShuupBatchViewSet(
        PermissionHelperMixin, SearchableMixin, mixins.RetrieveModelMixin,
        mixins.ListModelMixin, viewsets.GenericViewSet):
    queryset = Batch.objects.all()
    serializer_class = BatchSerializer
    search_fields = SearchableMixin.search_fields + ("=name",)
    filter_backends = SearchableMixin.filter_backends
    permission_classes = list(api_settings.DEFAULT_PERMISSION_CLASSES) + [EmployeeUserPermission]

    def get_view_name(self):
        return _("Batch")

    @classmethod
    def get_help_text(cls):
        return _("Batch management")

    def get_queryset(self):
        return self.queryset.filter(supplier=get_supplier_from_request(self.request))

    def get_serializer_context(self):
        context = super(ShuupBatchViewSet, self).get_serializer_context()
        if self.action == "product_summary":
            context["batch"] = self.get_object()
        return context

    def get_serializer_class(self):
        if self.action == "packages":
            return BatchPackagesSerializer
        elif self.action == "product_summary":
            return BatchProductSummary
        elif self.action == "create_transfer":
            return BatchPackageTransferCreateSerializer
        elif self.action == "transfers":
            return BatchPackageTransferSerializer

        return super(ShuupBatchViewSet, self).get_serializer_class()

    @detail_route(methods=["post"])
    def create_transfer(self, request, pk=None):
        batch = self.get_object()
        context = self.get_serializer_context()
        context["batch"] = batch
        serializer_class = self.get_serializer_class()
        serializer = serializer_class(data=request.data, context=context)
        serializer.is_valid(raise_exception=True)

        try:
            with atomic():
                packages = serializer.save()
        except ValidationError as exc:
            raise exceptions.ValidationError({"error": force_text(exc.message)})

        # make batch completed
        batch.refresh_from_db()
        if not batch.available_quantity:
            batch.set_completed()

        return Response(BatchPackagesSerializer(packages, many=True).data)

    @detail_route(methods=["get"])
    def packages(self, request, pk=None):
        # do not use get_object() because `search` query param will change the
        # batch queryset instead of our custom queryset
        batch = self.get_queryset().filter(pk=pk)
        if not batch:
            raise exceptions.NotFound()

        packages = Package.objects.filter(batch_transfer__batch=batch)

        # search by name
        if request.query_params.get("search"):
            search = request.query_params["search"]
            filters = Q(name__icontains=search)

            # search by id
            if search.isdigit():
                filters = Q(id=search)

            # allow searching by barcode
            package_id = get_package_id_from_barcode(search)
            if package_id:
                filters |= Q(id=package_id)

            packages = packages.filter(filters)

        # only package that can be used in transfers
        if "available_for_transfer" in request.query_params:
            packages = packages.filter(content_weight__gt=0, active=True, type=PackageType.BULK)

        serializer_class = self.get_serializer_class()
        serializer = serializer_class(packages.distinct(), many=True, context=self.get_serializer_context())
        return Response(serializer.data)

    @detail_route(methods=["get"])
    def transfers(self, request, pk=None):
        batch = self.get_object()
        transfers = BatchPackageTransfer.objects.filter(batch=batch)
        serializer_class = self.get_serializer_class()
        serializer = serializer_class(transfers.distinct(), many=True, context=self.get_serializer_context())
        return Response(serializer.data)

    @detail_route(methods=["get"])
    def product_summary(self, request, pk=None):
        product_ids = (
            Package.objects
            .filter(batch_transfer__batch=self.get_object()).values_list("product_id", flat=True)
        )
        product_modes = [
            ProductMode.NORMAL,
            ProductMode.VARIATION_CHILD
        ]
        products = (
            Product.objects
            .filter(Q(id__in=product_ids) | Q(variation_parent_id__in=product_ids), mode__in=product_modes)
            .distinct()
            .values_list("id", "translations__name", "sales_unit__translations__name")
        )

        supplier = get_supplier_from_request(request)
        data = []
        for product_id, product_name, sales_unit_name in products:
            shop_product = ShopProduct.objects.get(suppliers=supplier, product_id=product_id)
            is_orderable = shop_product.is_orderable(supplier=supplier, customer=AnonymousContact(), quantity=1)
            stock_status = supplier.get_stock_status(product_id)
            data.append({
                "name": product_name,
                "sales_unit_name": sales_unit_name,
                "physical_count": stock_status.physical_count,
                "logical_count": stock_status.logical_count,
                "is_orderable": is_orderable
            })

        return Response(data)
