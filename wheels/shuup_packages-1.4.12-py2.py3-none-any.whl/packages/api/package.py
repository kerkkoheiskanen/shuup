# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db.models import Q
from django.db.transaction import atomic
from django.utils.translation import ugettext_lazy as _
from rest_framework import exceptions, serializers, status, viewsets
from rest_framework.decorators import detail_route, list_route
from rest_framework.fields import empty
from rest_framework.response import Response
from shuup.api.fields import EnumField, FormattedDecimalField
from shuup.api.mixins import PermissionHelperMixin, SearchableMixin
from shuup.core.models import ShopProduct

from packages.models import (
    Package, PackageCondition, PackageLocation, PackageMeasurement,
    PackageType
)
from packages.utils import (
    get_package_id_from_barcode, get_supplier, get_supplier_from_request
)

from .labels import PackageLabelMixin


class PackageLocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PackageLocation
        fields = "__all__"


class PackageConditionSerializer(serializers.ModelSerializer):
    class Meta:
        model = PackageCondition
        fields = "__all__"


class PackageSerializer(serializers.ModelSerializer):
    type = EnumField(enum=PackageType)
    packaging_weight = FormattedDecimalField()
    total_weight = FormattedDecimalField()
    content_weight = FormattedDecimalField()
    location = serializers.ReadOnlyField(source="location.name")
    condition = serializers.ReadOnlyField(source="condition.identifier")
    barcode = serializers.ReadOnlyField(source="get_barcode")

    class Meta:
        model = Package
        fields = "__all__"

    def __init__(self, instance=None, data=empty, **kwargs):
        super(PackageSerializer, self).__init__(instance, data, **kwargs)

        if instance and getattr(instance, "shop", None):
            self.fields["new_location"] = serializers.PrimaryKeyRelatedField(
                queryset=PackageLocation.objects.filter(supplier=instance.supplier),
                source="location",
                write_only=True,
                required=False
            )


class PackageSearchSerializer(PackageSerializer):
    shop_products = serializers.SerializerMethodField()
    shop_product = serializers.SerializerMethodField()

    def get_shop_products(self, package):
        return ShopProduct.objects.filter(
            Q(suppliers=package.supplier),
            Q(Q(product=package.product) | Q(product__in=package.product.variation_children.all()))
        ).distinct().values_list("id", flat=True)

    def get_shop_product(self, package):
        shop_product = ShopProduct.objects.filter(suppliers=package.supplier, product=package.product).first()
        return shop_product.id if shop_product else None


class PackageReWeighSerializer(serializers.Serializer):
    delta = FormattedDecimalField()


class PackageSupplierViewSet(PermissionHelperMixin, SearchableMixin, viewsets.ModelViewSet, PackageLabelMixin):
    queryset = Package.objects.all()
    serializer_class = PackageSerializer
    search_fields = SearchableMixin.search_fields + ("=name",)
    filter_backends = list(SearchableMixin.filter_backends)

    def get_view_name(self):
        return _("Package")

    @classmethod
    def get_help_text(cls):
        return _("Package management")

    def check_permissions(self, request):
        super(PackageSupplierViewSet, self).check_permissions(request)
        if not request.user.is_staff:
            raise exceptions.PermissionDenied()

    def get_queryset(self):
        supplier = get_supplier_from_request(self.request)
        if self.action == "locations":
            return PackageLocation.objects.filter(supplier=supplier)
        elif self.action == "conditions":
            return PackageCondition.objects.filter(supplier=supplier)

        try:
            from trees_shop.utils.pos import is_pos_request
            if is_pos_request(self.request):
                return self.queryset.filter(active=True, supplier=supplier)
        except ImportError:
            pass

        return self.queryset.filter(active=True, supplier=supplier)

    def get_serializer_context(self):
        context = super(PackageSupplierViewSet, self).get_serializer_context()
        if self.action in ["product_config"]:
            context["package"] = self.get_object()
        return context

    def get_serializer_class(self):
        if self.action == "product_config":
            from packages.api.serializers import ProductPackageConfigsSerializer
            return ProductPackageConfigsSerializer

        elif self.action == "locations":
            return PackageLocationSerializer
        elif self.action == "conditions":
            return PackageConditionSerializer
        elif self.action == "reweigh":
            return PackageReWeighSerializer
        elif self.action == "search_product":
            return PackageSearchSerializer

        return super(PackageSupplierViewSet, self).get_serializer_class()

    @detail_route(methods=["post"])
    def product_config(self, request, pk=None):
        with atomic():
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            serializer.save()
            return Response(status=status.HTTP_200_OK)

    @list_route(methods=["get"])
    def locations(self, request):
        return Response(self.get_serializer(self.get_queryset(), many=True).data)

    @list_route(methods=["get"])
    def conditions(self, request):
        return Response(self.get_serializer(self.get_queryset(), many=True).data)

    @detail_route(methods=["post"])
    def reweigh(self, request, pk=None):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(True)
        package = self.get_object()

        if package.type == PackageType.PRE_PACKED:
            raise exceptions.ValidationError(_("Pre-packs can not be re-weighted."))

        with atomic():
            PackageMeasurement.objects.create(
                package=package,
                last_weight=package.total_weight,
                total_weight=(serializer.validated_data["delta"] + package.packaging_weight),
                created_by=request.user
            )
            package.save()

        return Response(PackageSerializer(package).data)

    @list_route(methods=["post"])
    def set_packages_location(self, request):
        packages = request.data.get("packages")
        location_id = request.data.get("location")
        supplier = get_supplier_from_request(self.request)

        if not packages:
            raise exceptions.ValidationError(_("Invalid packages."))
        if not location_id:
            raise exceptions.ValidationError(_("Invalid location."))

        location = PackageLocation.objects.filter(pk=location_id, supplier=supplier).first()
        if not location:
            raise exceptions.ValidationError(_("Invalid location."))

        with atomic():
            move_packages = None
            if isinstance(packages, list):
                move_packages = Package.objects.filter(id__in=packages, supplier=supplier)
            elif packages == "all":
                move_packages = Package.objects.filter(supplier=supplier)

            if move_packages:
                for package in move_packages:
                    package.location = location
                    package.save()

                return Response({})

        # no packages to move
        raise exceptions.ValidationError(_("Invalid packages."))

    @list_route(methods=["post"])
    def set_packages_condition(self, request):
        packages = request.data.get("packages")
        condition_id = request.data.get("condition")
        supplier = get_supplier_from_request(self.request)

        if not packages:
            raise exceptions.ValidationError(_("Invalid packages."))
        if not condition_id:
            raise exceptions.ValidationError(_("Invalid condition."))

        condition = PackageCondition.objects.filter(pk=condition_id, supplier=supplier).first()
        if not condition:
            raise exceptions.ValidationError(_("Invalid condition."))

        with atomic():
            update_packages = None
            if isinstance(packages, list):
                update_packages = Package.objects.filter(id__in=packages, supplier=supplier)
            elif packages == "all":
                update_packages = Package.objects.filter(supplier=supplier)

            if update_packages:
                for package in update_packages:
                    package.condition = condition
                    package.save()

                return Response({})

        # no packages to move
        raise exceptions.ValidationError(_("Invalid packages."))

    @list_route(methods=["get"])
    def search_product(self, request):
        query = request.query_params.get("query")
        packages_query = request.query_params.get("packages") or ""
        packages = [p.strip() for p in packages_query.split(";") if p]
        supplier = get_supplier(request.shop, request.user)

        # Here taking first match with barcode let's us use batch
        # identifier as barcode and be happy to just track packages
        # per batch and not worry about individual sale. This would
        # still allow "callback" some batch of products. As well as
        # seed to sale.
        queryset = Package.objects.is_in_sale().filter(supplier=supplier, barcode=query)
        if packages:
            queryset = queryset.exclude(id__in=packages)
        package = queryset.first()

        if not package:
            package_id = get_package_id_from_barcode(query)
            if package_id:
                package = Package.objects.is_in_sale().filter(
                    id=package_id, supplier=supplier).exclude(id__in=packages).first()
                if package:
                    return Response(self.get_serializer(package).data)

        return Response(self.get_serializer(package).data)
