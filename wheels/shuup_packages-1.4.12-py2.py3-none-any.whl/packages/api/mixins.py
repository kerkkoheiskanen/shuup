# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db.transaction import atomic
from rest_framework import exceptions, serializers, status, viewsets
from rest_framework.decorators import detail_route
from rest_framework.response import Response
from shuup.core.models import ShopProduct

from packages.models import Package
from packages.utils import get_supplier


class PackageOrderSerializerMixin(serializers.Serializer):
    needs_package_adjustment = serializers.SerializerMethodField()

    def get_needs_package_adjustment(self, order):
        if order.package_measurements.exists():
            return False
        return Package.get_packages_for_order(order).exists()


class PackageOrderAPIMixin(viewsets.GenericViewSet):
    @detail_route(methods=['get'])
    def packages(self, request, pk=None):
        return Response(self.get_serializer(self.get_object()).data, status=status.HTTP_200_OK)

    @detail_route(methods=['post'])
    def adjust_package_stocks(self, request, pk=None):
        serializer = self.get_serializer(self.get_object(), data=request.data)
        serializer.is_valid(True)
        with atomic():
            serializer.save()
        return Response()


class PackageShopProductAPIMixin(serializers.Serializer):
    @detail_route(methods=['get'])
    def packages(self, request, pk=None):
        from packages.api.package import PackageSearchSerializer

        supplier = get_supplier(request.shop, request.user)

        # do not use get_object here, so variation children won't be returned
        shop_product = ShopProduct.objects.filter(pk=pk, suppliers=supplier).first()
        if not shop_product:
            raise exceptions.NotFound()

        product = shop_product.product
        products = [product.id] + list(product.variation_children.values_list("id", flat=True))
        if product.variation_parent:
            products += [product.variation_parent.id]

        packages = Package.objects.is_in_sale().filter(
            supplier=supplier,
            content_weight__gt=0,
            product__id__in=products
        ).order_by("id").distinct()

        serializer = PackageSearchSerializer(packages, many=True)
        return Response(serializer.data)
