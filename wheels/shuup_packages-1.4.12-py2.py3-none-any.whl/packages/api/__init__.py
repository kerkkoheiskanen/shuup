# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from .batch import ShuupBatchViewSet
from .package import PackageSupplierViewSet


def populate_api(router):
    # For batch transfers, batch packages and product summary
    router.register("packages/batch", ShuupBatchViewSet)

    # For printing labels
    router.register("packages/package_supplier", PackageSupplierViewSet)
