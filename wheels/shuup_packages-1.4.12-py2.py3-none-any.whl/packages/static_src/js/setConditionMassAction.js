import m from "mithril";
import prop from "mithril/stream";

import { xhrConfig } from "./utils";
import SelectField from "./selectField";


const SetConditionMassAction = {
    oninit(vnode) {
        vnode.state.condition = prop();
        vnode.state.conditionOptions = prop([]);
        vnode.state.moving = prop(false);
        vnode.state.unmount = () => {
            m.mount(document.getElementById("location-set-overlay"), null);
        };
        // load locations
        m.request({
            url: "/api/packages/package_supplier/conditions/",
            config: xhrConfig
        }).then((conditions) => {
            vnode.state.conditionOptions(conditions.sort((a, b) => {
                if (a.name > b.name) return 1;
                if (a.name < b.name) return -1;
                return 0;
            }));
            if (vnode.state.conditionOptions().length) {
                vnode.state.condition(vnode.state.conditionOptions()[0].id);
            }
        });
    },
    view(vnode) {
        return m(".location-mass-action-overlay", {
            onclick(e) {
                if (e.target === vnode.dom) {
                    vnode.state.unmount();
                }
            }
        },
            m(".location-mass-action",
                m("h3", gettext("Update package condition")),
                m(".search-box-close", m("a.link", {
                    onclick() {
                        vnode.state.unmount();
                    }
                }, m("i.fa.fa-close"))),
                m("p.text-info",
                    interpolate(gettext("You selected %s packages."), [
                        (vnode.attrs.packages === "all") ? gettext("all") : vnode.attrs.packages.length
                    ])
                ),
                m(SelectField, {
                    id: "id_condition",
                    labelText: gettext("The new condition"),
                    value: vnode.state.condition,
                    onchange: m.withAttr("value", vnode.state.condition),
                    required: true,
                    options: vnode.state.conditionOptions(),
                    helpText: gettext("All selected packages will be updated to this new condition.")
                }),
                m("button.btn.btn-block.btn-primary", {
                    type: "button",
                    disabled: vnode.state.moving() ? "disabled" : "",
                    onclick() {
                        vnode.state.moving(true);
                        m.request({
                            method: "post",
                            url: "/api/packages/package_supplier/set_packages_condition/",
                            config: xhrConfig,
                            data: {
                                packages: vnode.attrs.packages,
                                condition: vnode.state.condition()
                            }
                        }).then(() => {
                            vnode.state.unmount();
                            window.alertify.success(gettext("Success!."));
                            window.picotable.ctrl.refresh();
                        }, () => {
                            window.alertify.error(gettext("Error! Couldn't update package condition."));
                            vnode.state.moving(false);
                        });
                    }
                }, vnode.state.moving() ? gettext("Updating packages...") : gettext("Update packages"))
            )
        );
    }
};

export default SetConditionMassAction;
