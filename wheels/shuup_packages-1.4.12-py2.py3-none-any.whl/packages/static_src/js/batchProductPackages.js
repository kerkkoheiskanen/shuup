import m from "mithril";
import prop from "mithril/stream";
import moment from "moment";
import { groupBy } from "lodash";


const BatchPackageGroupRow = {
    view(vnode) {
        const { batch, pkg, collapsable } = vnode.attrs;
        return (
            m(`tr.${collapsable ? "group" : ""}`,
                m("td.text-center", pkg.barcode),
                m("td.text-center", pkg.origin_package ? pkg.origin_package.name : gettext("Batch")),
                m("td.text-center", moment(pkg.created_on).format("L LTS")),
                m("td.text-center", pkg.product.name),
                m("td.text-center", `${parseFloat(pkg.transferred)} ${batch.sales_unit_symbol}`),
                m("td.text-center", (pkg.has_orders ? gettext("Yes") : gettext("No"))),
                m("td.text-center", pkg.location.name)
            )
        );
    }
};

const BatchPackageGroup = {
    oninit(vnode) {
        vnode.state.collapsed = prop(true);
    },
    view(vnode) {
        const { batch, packages, group } = vnode.attrs;
        if (!packages.length) return null;
        const titlePkg = packages[0];
        return [
            m("tr.active", { key: `title-${group}` },
                m("td.text-center",
                    m("a.link.p2", {
                        onclick() {
                            vnode.state.collapsed(!vnode.state.collapsed());
                        }
                    }, vnode.state.collapsed() ? m("i.fa.fa-plus") : m("i.fa.fa-minus"))
                ),
                m("td.text-center", titlePkg.origin_package ? titlePkg.origin_package.name : gettext("Batch")),
                m("td.text-center", moment(titlePkg.created_on).format("L LTS")),
                m("td.text-center", titlePkg.product.name),
                m("td.text-center", interpolate(gettext("%s packages"), [packages.length])),
                m("td.text-center"),
                m("td.text-center")
            ),
            vnode.state.collapsed() ? null : (
                packages.map(pkg => (
                    m(BatchPackageGroupRow, {
                        collapsable: true,
                        pkg,
                        batch
                    })
                ))
            )
        ];
    }
};

const BatchProductPackages = {
    view(vnode) {
        const packages = vnode.attrs.packages;
        const batch = vnode.attrs.batch;
        const packageGroups = groupBy(packages, "transfer_group");
        const sortedPackages = [];

        Object.keys(packageGroups).forEach((key) => {
            if (key === "null" || packageGroups[key].length === 1) {
                sortedPackages.push(...packageGroups[key]);
            } else if (packageGroups[key].length) {
                sortedPackages.push({
                    group: key,
                    packages: packageGroups[key],
                    created_on: packageGroups[key][0].created_on
                });
            }
        });
        sortedPackages.sort((a, b) => (moment(a.created_on) - moment(b.created_on)));

        return m(".batch-no-product-packages",
            m("h2.text-center", gettext("Transferred to")),
            m("table.table.table-hover.table-bordered",
                m("thead",
                    m("tr",
                        m("th.text-center", gettext("Barcode")),
                        m("th.text-center", gettext("Origin")),
                        m("th.text-center", gettext("When")),
                        m("th.text-center", gettext("Product")),
                        m("th.text-center", gettext("Quantity transferred")),
                        m("th.text-center", gettext("Is Sold")),
                        m("th.text-center", gettext("Location"))
                    )
                ),
                m("tbody",
                    sortedPackages.map(pkg => (
                        pkg.group ? (
                            m(BatchPackageGroup, {
                                key: pkg.group,
                                batch,
                                group: pkg.group,
                                packages: pkg.packages
                            })
                        ) : m(BatchPackageGroupRow, {
                            key: pkg.id,
                            collapsable: false,
                            pkg,
                            batch
                        })
                    ))
                )
            )
        );
    }
};

export default BatchProductPackages;
