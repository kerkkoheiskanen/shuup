export const TransferOrigin = {
    Batch: "batch",
    Package: "package"
};
