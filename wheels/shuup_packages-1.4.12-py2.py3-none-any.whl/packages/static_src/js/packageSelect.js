import m from "mithril";

import Select from "./selectField";


const PackageOptionRow = {
    view(vnode) {
        if (!vnode.attrs.data.id) {
            return m("span", vnode.attrs.data.text);
        }
        const pkg = vnode.attrs.data.package;
        if (vnode.attrs.selected) {
            return m("span", interpolate("%s - %s", [pkg.barcode, pkg.name]));
        }
        return m(".package-option-row", { "data-id": pkg.id },
            m(".package-name", pkg.name),
            m(".package-detail",
                m("small", interpolate(
                    gettext("Barcode: %s | Location: %s | Content: %s g"),
                    [pkg.barcode, pkg.location.name, parseFloat(pkg.content_weight).toFixed(2)]
                ))
            )
        );
    }
};

const renderOption = params => ((data) => {
    const el = document.createElement("div");
    m.render(el, m(PackageOptionRow, { ...params, data }));
    return el;
});

const BatchPackageSelect = {
    oncreate(vnode) {
        $(vnode.dom).find("select").select2({
            minimumInputLength: 3,
            templateSelection: renderOption({ selected: true }),
            templateResult: renderOption(),
            ajax: {
                url: `/api/packages/batch/${vnode.attrs.batch}/packages/`,
                dataType: "json",
                delay: 250,
                data(params) {
                    const query = {
                        search: params.term
                    };
                    if (vnode.attrs.filters) {
                        Object.assign(query, vnode.attrs.filters);
                    }
                    return query;
                },
                processResults(data) {
                    return {
                        results: data.map(result => ({
                            id: result.id,
                            text: result.name,
                            package: result
                        }))
                    };
                }
            }
        });
    },
    view(vnode) {
        return m(Select, {
            labelText: gettext("Package"),
            onchange: vnode.attrs.onchange,
            required: vnode.attrs.required,
            helpText: vnode.attrs.helpText
        });
    }
};

export default BatchPackageSelect;
