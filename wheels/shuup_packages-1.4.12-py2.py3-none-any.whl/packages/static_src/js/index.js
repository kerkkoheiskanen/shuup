import m from "mithril";
import alertify from "alertifyjs";

import BatchView from "./batchView";
import "./packageList";

window.alertify = alertify;

if (document.getElementById("batch-edit-root")) {
    const batchId = parseInt($("#batch-edit-root").data("id"), 10);
    m.mount(document.getElementById("batch-edit-root"), {
        view() {
            return m(BatchView, { batch: batchId });
        }
    });
}
