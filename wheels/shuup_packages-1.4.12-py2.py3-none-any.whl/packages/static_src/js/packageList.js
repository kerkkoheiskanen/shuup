import m from "mithril";
import { xhrConfig } from "./utils";
import SetConditionMassAction from "./setConditionMassAction";
import SetLocationMassAction from "./setLocationMassAction";


window.setPackageLocation = (packageId, fieldId) => {
    m.request({
        method: "patch",
        url: `/api/packages/package_supplier/${packageId}/`,
        config: xhrConfig,
        data: {
            new_location: document.getElementById(fieldId).value
        }
    }).then(() => {
        window.alertify.success(gettext("Location changed!"));
    }, (error) => {
        console.warn(error);
        window.alertify.error(gettext("Failed to change package location."));
    });
};

window.adjustPackageStock = (packageId, fieldId) => {
    const field = document.getElementById(fieldId);
    const delta = parseFloat(field.value);

    if (!packageId) return;

    m.request({
        method: "post",
        url: `/api/packages/package_supplier/${packageId}/reweigh/`,
        config: xhrConfig,
        data: {
            delta
        }
    }).then(() => {
        window.alertify.success(gettext("Stock adjusted!"));
    }, (error) => {
        console.warn(error);
        window.alertify.error(gettext("Failed to adjust the package stock."));
    });
};

window.setPackagesLocations = (packageIds) => {
    m.mount(document.getElementById("location-set-overlay"), {
        view() {
            return m(SetLocationMassAction, { packages: packageIds });
        }
    });
};

window.setPackagesConditions = (packageIds) => {
    m.mount(document.getElementById("location-set-overlay"), {
        view() {
            return m(SetConditionMassAction, { packages: packageIds });
        }
    });
};
