const SALES_UNITS_GRAMS_IDENTIFIER = "g";

export function isBatchInGrams(salesUnitIdentifier) {
    return (salesUnitIdentifier === SALES_UNITS_GRAMS_IDENTIFIER);
}

export function getErrorListFromResponse(responseError) {
    let error = responseError;

    if (responseError instanceof Error) {
        try {
            error = JSON.parse(error.message);
        } catch (e) {
            error = error.message;
        }
    }

    if (typeof (error) === "string") {
        return [error];
    } else if (Array.isArray(error)) {
        return error;
    }

    let errorList = [];
    Object.keys(error).forEach((key) => {
        if (key === "non_field_errors") {
            errorList = errorList.concat(error[key]);
        } else if (["error", "detail"].includes(key)) {
            errorList.push(error[key]);
        } else {
            errorList.push(`${key}: ${error[key]}`);
        }
    });
    return errorList;
}

export function extractResponseWithBlob(xhr) {
    const type = xhr.getResponseHeader('Content-Type');
    if (xhr.status === 200 && type === "application/pdf") {
        const file = new Blob([xhr.response], { type });
        const fileURL = URL.createObjectURL(file);
        const link = document.createElement("a");
        if (typeof link.download === "undefined") {  // safari doesn't support this yet
            window.location = fileURL;
        } else {
            link.href = fileURL;
            link.download = "labels.pdf";
            document.body.appendChild(link);
            link.click();
        }
    }
    return null;
}

export function xhrConfigWithBlob(xhr) {
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("X-CSRFToken", window.ShuupAdminConfig.csrf);
    xhr.responseType = "blob";
}

export function xhrConfig(xhr) {
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.setRequestHeader("X-CSRFToken", window.ShuupAdminConfig.csrf);
}

export function getTranslation(object, attr, translationsAttr = "translations") {
    const language = window.ShuupAdminConfig.language;
    const fallbackLanguage = window.ShuupAdminConfig.fallbackLanguage;

    if (object[translationsAttr]) {
        if (object[translationsAttr][language] && object[translationsAttr][language][attr]) {
            return object[translationsAttr][language][attr];
        } else if (object[translationsAttr][fallbackLanguage] && object[translationsAttr][fallbackLanguage][attr]) {
            return object[translationsAttr][fallbackLanguage][attr];
        }
    }
    return gettext("Could not find translation.");
}
