import m from "mithril";

const Panel = {
    view(vnode) {
        const { title, onRemoveText, onRemovePress, onActionText, onActionPress, fields } = vnode.attrs;
        return m(".package-split-form",
            m(".panel.panel-default",
                m(".panel-heading", title),
                m(".panel-body",
                    m("form.form", fields),
                    m(".",
                        m("a.btn.btn-primary", {
                            href: "#",
                            onclick(e) {
                                e.preventDefault();
                                onRemovePress();
                            }
                        }, onRemoveText),
                        m("a.btn.btn-primary.pull-right", {
                            href: "#",
                            onclick(e) {
                                e.preventDefault();
                                onActionPress();
                            }
                        }, onActionText)
                    )
                )
            )
        );
    }
};

export default Panel;
