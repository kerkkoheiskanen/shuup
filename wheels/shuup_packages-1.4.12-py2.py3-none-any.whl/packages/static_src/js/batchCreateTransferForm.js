import m from "mithril";
import prop from "mithril/stream";

import InputField from "./inputField";
import SelectField from "./selectField";
import { PackageType, PackageTypeLabel } from "./packageType";
import ProductSelect from "./productSelect";
import PackageSelect from "./packageSelect";
import {
    isBatchInGrams,
    getErrorListFromResponse,
    extractResponseWithBlob,
    xhrConfigWithBlob,
    xhrConfig
} from "./utils";
import { TransferOrigin } from "./consts";

const printPackagesLabels = (packageIds) => {
    m.request({
        url: "/api/packages/package_supplier/print_labels/",
        method: "POST",
        extract: extractResponseWithBlob,
        config: xhrConfigWithBlob,
        data: {
            packages: packageIds
        }
    }).then(() => {
        window.alertify.success(gettext("Success! Open PDF to print out labels."));
    }, () => {
        window.alertify.error(gettext("Error! Couldn't get labels."));
    });
};


const ErrorMessage = {
    oncreate(vnode) {
        $("html, body").animate({
            scrollTop: $(vnode.dom).offset().top - 180
        }, 500);
    },
    view(vnode) {
        return m(".alert.alert-danger#error-msg", vnode.attrs.message);
    }
};

const BatchCreateTransferForm = {
    oninit(vnode) {
        vnode.state.origin = prop(TransferOrigin.Batch);
        vnode.state.package = prop();
        vnode.state.quantity = prop(0);
        vnode.state.packagingWeight = prop(0);
        vnode.state.product = prop();
        vnode.state.type = prop(PackageType.PrePacked);
        vnode.state.location = prop();
        vnode.state.condition = prop();
        vnode.state.error = prop();
        vnode.state.creating = prop(false);
        vnode.state.printLabels = prop(false);
        vnode.state.locationOptions = prop([]);
        vnode.state.conditionOptions = prop([]);

        vnode.state.isFormValid = () => {
            vnode.state.error(null);

            if (vnode.state.origin() === TransferOrigin.Batch) {
                if (!vnode.state.product() && parseInt(vnode.state.type(), 10) === PackageType.PrePacked) {
                    vnode.state.error(gettext("Invalid product."));
                    return false;
                }
            } else if (vnode.state.origin() === TransferOrigin.Package && !vnode.state.product()) {
                vnode.state.error(gettext("Invalid product."));
                return false;
            }

            if (vnode.state.quantity() <= 0) {
                vnode.state.error(gettext("Invalid quantity."));
                return false;
            } else if (!vnode.state.location()) {
                vnode.state.error(gettext("Invalid location."));
                return false;
            } else if (!vnode.state.condition()) {
                vnode.state.error(gettext("Invalid condition."));
                return false;
            }
            return true;
        };

        vnode.state.onCreateTransferPress = () => {
            vnode.state.creating(true);

            const data = {
                origin: vnode.state.origin(),
                package_type: vnode.state.type(),
                quantity: vnode.state.quantity(),
                product: vnode.state.product(),
                location: vnode.state.location(),
                condition: vnode.state.condition()
            };

            if (vnode.state.origin() === TransferOrigin.Package) {
                data.package = vnode.state.package();
            }
            if (parseInt(vnode.state.type(), 10) === PackageType.Bulk && vnode.state.packagingWeight()) {
                data.packaging_weight = vnode.state.packagingWeight();
            }

            const doTransfer = () => {
                m.request({
                    method: "POST",
                    url: `/api/packages/batch/${vnode.attrs.batch.id}/create_transfer/`,
                    data,
                    config: xhrConfig
                }).then((packages) => {
                    vnode.state.creating(false);
                    vnode.attrs.onCreateTransfer();

                    if (vnode.state.printLabels()) {
                        printPackagesLabels(packages.map(p => p.id));
                    }

                    window.alertify.success(gettext("Transfer created successfully!"));
                }, (response) => {
                    const error = getErrorListFromResponse(response).shift();
                    if (error) {
                        vnode.state.error(error);
                    }
                    vnode.state.creating(false);
                });
            };

            if (!data.product) {
                window.alertify.confirm(
                    gettext("No product selected"),
                    gettext("Are you sure you want to create transfer without product?"),
                    () => {
                        doTransfer();
                    },
                    () => {
                        vnode.state.creating(false);
                        m.redraw();
                    }
                );
            } else {
                doTransfer();
            }
        };

        vnode.state.loadSelectOptions = () => {
            // load conditions
            m.request({
                url: "/api/packages/package_supplier/conditions/",
                config: xhrConfig
            }).then((conditions) => {
                vnode.state.conditionOptions(conditions.sort((a, b) => {
                    if (a.name > b.name) return 1;
                    if (a.name < b.name) return -1;
                    return 0;
                }).map((condition) => {
                    if (condition.identifier === "normal") {
                        condition.selected = true;
                        vnode.state.condition(condition.id);
                    }
                    return condition;
                }));
            });

            // load locations
            m.request({
                url: "/api/packages/package_supplier/locations/",
                config: xhrConfig
            }).then((locations) => {
                vnode.state.locationOptions(locations.sort((a, b) => {
                    if (a.name > b.name) return 1;
                    if (a.name < b.name) return -1;
                    return 0;
                }));
            });
        };

        vnode.state.loadSelectOptions();
    },
    oncreate(vnode) {
        $("html, body").animate({
            scrollTop: $(vnode.dom).offset().top - 180
        }, 500);
    },
    view(vnode) {
        const packageOptions = [
            {
                id: PackageType.PrePacked,
                name: PackageTypeLabel[PackageType.PrePacked],
                selected: (PackageType.PrePacked === vnode.state.type())
            }
        ];
        if (isBatchInGrams(vnode.attrs.batch.sales_unit_identifier)) {
            packageOptions.push({
                id: PackageType.Bulk,
                name: PackageTypeLabel[PackageType.Bulk],
                selected: (PackageType.Bulk === vnode.state.type())
            });
        }

        const isBulkSelected = (parseInt(vnode.state.type(), 10) === PackageType.Bulk);
        const isPrePackSelected = (parseInt(vnode.state.type(), 10) === PackageType.PrePacked);

        const productHelpText = (isBulkSelected ?
            (
                gettext(
                    "Select the product to be used in this package. " +
                    "Select a parent product to include all variations. " +
                    "By leaving this field empty the transferred quantity will be unavailable for sale."
                )
            ) : gettext("Select the product to be used in the package.")
        );

        const packagingHelpText = gettext(
            "Use packaging weight to help with the re-weight process. " +
            "Most of the time package is re-weight using total weight of the container/package."
        );

        return m(".batch-create-transfer-form.content-block",
            m("h2.text-center", gettext("New package transfer")),
            vnode.state.error() ? m(ErrorMessage, { message: vnode.state.error() }) : null,
            m("form",
                isBatchInGrams(vnode.attrs.batch.sales_unit_identifier) ? (
                    m(SelectField, {
                        id: "id_origin",
                        labelText: gettext("Origin"),
                        value: vnode.state.origin,
                        onchange: m.withAttr("value", vnode.state.origin),
                        required: true,
                        options: [
                            { id: TransferOrigin.Batch, name: gettext("This batch") },
                            { id: TransferOrigin.Package, name: gettext("Package") }
                        ],
                        helpText: gettext(
                            "You can transfer quantities from this batch and also from a package. " +
                            "Select 'This batch' if you want to transfer from this batch. " +
                            "Select 'Package' if you want to transfer from some package of this batch."
                        )
                    })
                ) : null,
                (vnode.state.origin() === TransferOrigin.Package) ? (
                    m(PackageSelect, {
                        batch: vnode.attrs.batch.id,
                        value: vnode.state.package,
                        onchange: m.withAttr("value", vnode.state.package),
                        required: true,
                        filters: {
                            available_for_transfer: true
                        },
                        helpText: gettext(
                            "Select the package which should be used to move quantity from. " +
                            "Only Bulk packages transferred in this batch can be used as transfer origin."
                        )
                    })
                ) : null,
                (window.bulkEnabled) ? (
                    m(SelectField, {
                        id: "id_type",
                        labelText: gettext("Package type"),
                        value: vnode.state.type,
                        onchange: m.withAttr("value", vnode.state.type),
                        required: true,
                        options: packageOptions,
                        helpText: gettext("The package type that should be created in the transfer.")
                    })
                ) : null,
                (isBulkSelected ? (
                    m(InputField, {
                        id: "id_pkg_weight",
                        labelText: gettext("Packaging weight"),
                        type: "number",
                        value: vnode.state.packagingWeight,
                        oninput: m.withAttr("value", vnode.state.packagingWeight),
                        helpText: packagingHelpText,
                        extraFieldAttrs: {
                            min: 0,
                            step: 0.01
                        }
                    })
                ) : null),
                m(ProductSelect, {
                    value: vnode.state.product,
                    onchange: m.withAttr("value", vnode.state.product),
                    required: isPrePackSelected,
                    searchMode: (isPrePackSelected ? "sellable_mode_only" : "main"),
                    salesUnits: (isPrePackSelected ? "pcs" : null),
                    helpText: productHelpText
                }),
                m(InputField, {
                    id: "id_quantity",
                    labelText: gettext("Quantity"),
                    type: "number",
                    value: vnode.state.quantity,
                    oninput: m.withAttr("value", vnode.state.quantity),
                    required: true,
                    helpText: gettext("Enter the quantity that should be transferred."),
                    extraFieldAttrs: {
                        min: 0,
                        step: 0.01
                    }
                }),
                m(SelectField, {
                    id: "id_location",
                    labelText: gettext("Location"),
                    value: vnode.state.location,
                    emptyOptionText: " ",
                    onchange(e) {
                        vnode.state.location(e.target.value);
                    },
                    required: true,
                    options: vnode.state.locationOptions(),
                    helpText: gettext("Select the package location."),
                    quickAddUrl: window.ShuupAdminConfig.browserUrls.packageLocation,
                    fieldName: "pkg-location"
                }),
                m(SelectField, {
                    id: "id_condition",
                    labelText: gettext("Condition"),
                    value: vnode.state.condition,
                    emptyOptionText: " ",
                    onchange: m.withAttr("value", vnode.state.condition),
                    required: true,
                    options: vnode.state.conditionOptions(),
                    helpText: gettext("Select the package condition.")
                }),
                m(".form-group.form-content",
                    m(".checkbox",
                        m("label",
                            m("input", {
                                id: "id_printLabels",
                                type: "checkbox",
                                value: vnode.state.printLabels,
                                onchange: m.withAttr("checked", vnode.state.printLabels)
                            }),
                            gettext("Print labels")
                        )
                    ),
                    m(".", m("small.text-muted", gettext("Check this to download labels after packages have been created.")))
                ),
                m(".text-center",
                    m("button.btn.btn-primary.btn-lg", {
                        type: "button",
                        disabled: vnode.state.creating(),
                        onclick(e) {
                            e.preventDefault();
                            if (vnode.state.isFormValid()) {
                                vnode.state.onCreateTransferPress();
                            }
                        }
                    }, vnode.state.creating() ? (
                        m("span",
                            m("i.fa.fa-spin.fa-spinner"),
                            gettext(" Creating transfer...")
                        )
                    ) : (
                        m("span",
                            m("i.fa.fa-check"),
                            gettext(" Create transfer")
                        )
                    )),
                    m("button.btn.btn-default.btn-lg.ml2", {
                        type: "button",
                        onclick: vnode.attrs.onCancelPress
                    }, gettext("Cancel"))
                )
            )
        );
    }
};

export default BatchCreateTransferForm;
