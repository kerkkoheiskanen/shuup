import m from "mithril";


const BatchSummary = {
    view(vnode) {
        const yes = m("span.text-success", gettext("Yes"));
        const no = m("span.text-danger", gettext("No"));
        return m(".batch-packages-list",
            m("h2.text-center", gettext("Batch summary")),
            m("table.table.table-hover.table-bordered",
                m("caption.text-center", gettext("Summary for each product and transfer done from this batch")),
                m("thead",
                    m("tr",
                        m("th", gettext("Product")),
                        m("th.text-center", gettext("Sales Unit")),
                        m("th.text-center", gettext("Physical Count (qty)")),
                        m("th.text-center", gettext("Logical Count (qty)")),
                        m("th.text-center", gettext("Is orderable"))
                    )
                ),
                m("tbody",
                    vnode.attrs.products.map(product => (
                        m("tr",
                            m("td", product.name),
                            m("td.text-center.align-middle", product.sales_unit_name),
                            m("td.text-center.align-middle", parseInt(product.physical_count, 10)),
                            m("td.text-center.align-middle", parseInt(product.logical_count, 10)),
                            m("td.text-center.align-middle", product.is_orderable ? yes : no)
                        )
                    ))
                )
            )
        );
    }
};

export default BatchSummary;
