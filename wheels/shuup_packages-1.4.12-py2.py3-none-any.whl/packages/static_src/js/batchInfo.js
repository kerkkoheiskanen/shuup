import m from "mithril";

const BatchStateLabel = {
    incoming: gettext("Incoming"),
    received: gettext("Received"),
    completed: gettext("Completed")
};

const BatchInfo = {
    view(vnode) {
        const batch = vnode.attrs.batch;

        return m(".batch-info",
            m("dl.dl-horizontal",
                m("dt", gettext("State")),
                m("dd.text-info", BatchStateLabel[batch.state]),
                m("dt", gettext("Available quantity")),
                m("dd.text-info", `${parseFloat(batch.available_quantity)} ${batch.sales_unit_symbol || ""}`),
                m("dt", gettext("Total transferred")),
                m("dd.text-info", `${parseFloat(batch.total_transferred)} ${batch.sales_unit_symbol || ""}`)
            )
        );
    }
};

export default BatchInfo;
