# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db.models import Q
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import Product, ProductMode, ShopProduct, StockBehavior
from shuup.reports.report import ShuupReportBase

from packages.utils import get_supplier_from_request

from .forms import ProductReportForm


class ProductStockReport(ShuupReportBase):
    identifier = "package-inventory-product-stock-report"
    title = _("Package Inventory - Product Stock")
    description = _("This report shows current physical and logical stocks for all stocked products.")
    filename_template = "product-stock-report-%(time)s"
    form_class = ProductReportForm

    schema = [
        {"key": "name", "title": _("Name")},
        {"key": "physical_stock", "title": _("Physical stock")},
        {"key": "logical_stock", "title": _("Logical stock")}
    ]

    def get_objects(self):
        self.supplier = get_supplier_from_request(self.request)
        queryset = ShopProduct.objects.filter(
            suppliers=self.supplier,
            product__mode__in=[ProductMode.VARIATION_CHILD, ProductMode.NORMAL],
            product__stock_behavior=StockBehavior.STOCKED
        )

        if self.options.get("product"):
            queryset = queryset.filter(product_id=self.options["product"])

        if self.options.get("category"):
            category = self.options["category"]
            queryset = queryset.filter(
                Q(categories=category) |
                Q(product__variation_parent__shop_products__categories=category)
            )

        return queryset

    def get_data(self):
        data = []
        product_ids = self.get_objects().values_list("product_id", flat=True)
        stock_statuses = self.supplier.get_stock_statuses(product_ids)
        products_query = Product.objects.filter(
            id__in=product_ids).values_list("id", "variation_parent_id", "translations__name")
        for prod_id, parent_id, product_name in products_query:
            stock_status = stock_statuses[prod_id]
            data.append({
                "name": product_name,
                "physical_stock": "%.3f" % stock_status.physical_count,
                "logical_stock": "%.3f" % stock_status.logical_count,
                "parent_order": ("{}_child".format(parent_id) if parent_id else str(prod_id))
            })

        data.sort(key=lambda x: (x["name"], x["parent_order"]))
        return self.get_return_data(data, has_totals=False)
