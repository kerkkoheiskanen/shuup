# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

from babel.dates import format_date
from django.db.models import Q
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import OrderLine, OrderStatusRole, Product
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import format_money, format_number, format_percent

from packages.models import Batch
from packages.utils import get_supplier_from_request

from .forms import BatchPerformanceForm


class BatchPerformanceReport(ShuupReportBase):
    identifier = "package-inventory-batch-performance-report"
    title = _("Package Inventory - Batch Performance")
    description = _(
        "This report shows the performance for batches. " +
        "Use date range to filter batches based on received date. " +
        "Only batches with completed sales will be listed."
    )
    filename_template = "batch-performance-report-%(time)s"
    form_class = BatchPerformanceForm

    schema = [
        {"key": "name", "title": _("Name")},
        {"key": "received_date", "title": _("Received Date")},
        {"key": "batch_cost", "title": _("Batch Cost")},
        {"key": "batch_qty", "title": _("Batch Qty")},
        {"key": "unit_cost", "title": _("Unit Cost")},
        {"key": "qty_sold", "title": _("Qty Sold")},
        {"key": "unit_price", "title": _("Unit Price")},
        {"key": "batch_sale", "title": _("Batch Sale")},
        {"key": "performance", "title": _("Performance")}
    ]

    @classmethod
    def is_available_for(cls, request, shop):  # For cloud
        return True

    def get_objects(self):
        self.supplier = get_supplier_from_request(self.request)
        queryset = Batch.objects.filter(
            supplier=self.supplier,
            transfers__package__measurements__order__status__role=OrderStatusRole.COMPLETE
        )
        if self.start_date:
            queryset = queryset.filter(received_on__gte=self.start_date)

        if self.end_date:
            queryset = queryset.filter(received_on__lte=self.end_date)

        product = self.options.get("product")
        if product:
            product_ids = Product.objects.filter(
                Q(id=product) | Q(variation_parent_id=product)).values_list("pk", flat=True)
            queryset = queryset.filter(transfers__package__product_id__in=product_ids)

        purchase_order = self.options.get("purchase_order")
        if purchase_order:
            queryset = queryset.filter(purchase_orders=purchase_order)

        return queryset.distinct()

    def get_data(self):
        data = []
        batches = self.get_objects()
        shop = get_shop(self.request)
        for batch in batches:
            # only use transfers that have order line attached
            transfers = batch.transfers.filter(
                package__measurements__order_line__isnull=False,
                package__measurements__order__status__role=OrderStatusRole.COMPLETE
            ).distinct()

            batch_order_line_ids = list(
                set(list(transfers.values_list("package__measurements__order_line__id", flat=True)))
            )
            batch_order_lines = OrderLine.objects.filter(id__in=batch_order_line_ids)
            batch_sale = 0
            batch_qty_sold = 0
            for batch_order_line in batch_order_lines:
                batch_sale += batch_order_line.base_unit_price_value * batch_order_line.quantity
                batch_qty_sold += batch_order_line.quantity

            unit_price = (
                shop.create_price((batch_sale / batch_qty_sold) if batch_qty_sold else Decimal("0"))
            )
            unit_cost = shop.create_price(
                (batch.purchase_price_value / batch.quantity) if batch.quantity else Decimal()
            )
            batch_sales_unit = (batch.sales_unit.symbol if batch.sales_unit else "")

            performance = None
            if batch.purchase_price_value:
                performance = (batch_sale / batch.purchase_price_value)

            data.append({
                "name": batch.name,
                "received_date": format_date(batch.received_on or batch.created_on, "short"),
                "batch_cost": format_money(shop.create_price(batch.purchase_price_value)),
                "batch_qty": "{} {}".format(format_number(batch.quantity), batch_sales_unit),
                "unit_cost": format_money(unit_cost),
                "qty_sold": format_number(batch_qty_sold),
                "unit_price": format_money(unit_price),
                "batch_sale": format_money(shop.create_price(batch_sale)),
                "performance": (format_percent(performance, 2) if performance else "-")
            })

        return self.get_return_data(data, has_totals=False)
