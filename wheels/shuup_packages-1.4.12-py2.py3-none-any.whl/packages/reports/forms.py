# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from babel.dates import format_date
from django import forms
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import Category, Product, ProductMode
from shuup.reports.forms import ShuupReportForm
from shuup.utils.i18n import get_current_babel_locale

from packages.models import Batch, PurchaseOrder
from packages.utils import get_supplier_from_request


class InventoryBaseForm(ShuupReportForm):
    def __init__(self, *args, **kwargs):
        super(InventoryBaseForm, self).__init__(*args, **kwargs)
        self.shop = get_shop(self.request)
        self.supplier = get_supplier_from_request(self.request)


class ProductReportForm(InventoryBaseForm):
    category = forms.ChoiceField(
        required=False, label=_("Category"), help_text=_("Filter results by category"))
    product = forms.ChoiceField(
        required=False, label=_("Product"), help_text=_("Filter results by product"))

    def __init__(self, *args, **kwargs):
        super(ProductReportForm, self).__init__(*args, **kwargs)

        categories = Category.objects.filter(shops=self.shop).distinct()
        self.fields["category"].choices = [(None, "---")] + [
            (category.pk, category.safe_translation_getter("name")) for category in categories
        ]

        products = Product.objects.filter(
            mode__in=[ProductMode.VARIATION_CHILD, ProductMode.NORMAL],
            shop_products__suppliers=self.supplier
        ).distinct()
        self.fields["product"].choices = [(None, "---")] + [
            (product.pk, product.safe_translation_getter("name")) for product in products
        ]


class BatchPerformanceForm(ProductReportForm):
    purchase_order = forms.ChoiceField(
        required=False, label=_("Purchase order"), help_text=_("Filter results by purchase order"))
    start_date = forms.DateTimeField(label=_("Start Date"), required=False, help_text=_("For a custom date range."))
    end_date = forms.DateTimeField(label=_("End Date"), required=False, help_text=_("For a custom date range."))

    def __init__(self, *args, **kwargs):
        super(BatchPerformanceForm, self).__init__(*args, **kwargs)
        purchase_orders = PurchaseOrder.objects.filter(supplier=self.supplier)
        self.fields["purchase_order"].choices = [(None, "---")] + [
            (purchase_order.pk, purchase_order.number) for purchase_order in purchase_orders
        ]


class ProductPerformanceForm(BatchPerformanceForm):  # There is just too many batches to allow report for all shops
    combine_all_locations = forms.BooleanField(required=False, label=_("Combine results from all linked locations."))


class BatchOrdersForm(InventoryBaseForm):
    batch = forms.ChoiceField(
        label=_("Batch"), help_text=_("Select batch to get orders for."))

    def __init__(self, *args, **kwargs):
        super(BatchOrdersForm, self).__init__(*args, **kwargs)
        batches = Batch.objects.filter(supplier=self.supplier)
        self.fields["batch"].choices = [(None, "---")] + [(
            batch.pk,
            ("%s - %s" % (
                format_date(batch.created_on, locale=get_current_babel_locale()),
                batch.name
            ))
        ) for batch in batches]


class PackageMeasurementsReportForm(InventoryBaseForm):
    sort_by = forms.ChoiceField(
        label=_("Sort by"),
        required=False,
        initial="package",
        choices=(
            ("package", _("Package")),
            ("date", _("Date"))
        )
    )

    def __init__(self, *args, **kwargs):
        super(PackageMeasurementsReportForm, self).__init__(*args, **kwargs)
        self.fields["batch"] = forms.ModelChoiceField(
            label=_("Batch"),
            required=False,
            queryset=Batch.objects.filter(supplier=self.supplier)
        )
        self.fields["purchase_order"] = forms.ModelChoiceField(
            label=_("Purchase order"),
            required=False,
            queryset=PurchaseOrder.objects.filter(supplier=self.supplier)
        )
