# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.db.models import Q, Sum
from shuup.core.models import OrderLine, OrderStatusRole, Product

from packages.models import Package, PackageType
from packages.utils import is_sales_unit_pieces

try:
    from trees_shop.utils.sales_units import DEFAULT_PIECES_IDENTIFIER
except ImportError:
    DEFAULT_PIECES_IDENTIFIER = "pcs"


def get_current_stock_value(supplier_id, product_id):
    product = Product.objects.filter(id=product_id).first()
    if is_sales_unit_pieces(product):
        pre_packs = Package.objects.filter(
            type=PackageType.PRE_PACKED,
            supplier_id=supplier_id,
            product_id=product_id,
        ).is_in_sale().count()
        stocks = {
            "logical_count": pre_packs,
            "physical_count": pre_packs
        }
        return stocks

    bulk_grams = Package.objects.filter(
        type=PackageType.BULK,
        supplier_id=supplier_id,
        product_id=(product.variation_parent_id if product.variation_parent_id else product_id)
    ).is_in_sale().aggregate(Sum("content_weight"))["content_weight__sum"] or 0

    bulk_available_in_packages = (bulk_grams / product.net_weight if product.net_weight else 0)

    pending_grams_in_orders = 0
    sibling_ids_and_weights = product.get_variation_siblings().values_list("id", "net_weight")
    for prod_id, net_weight in [(product.id, product.net_weight)] + list(sibling_ids_and_weights):
        pending_orders_qty = (
            OrderLine.objects
            .filter(
                Q(supplier_id=supplier_id),
                Q(order__package_measurements__isnull=True),
                Q(product_id=prod_id),
                ~Q(product__sales_unit__identifier=DEFAULT_PIECES_IDENTIFIER))
            .filter(order__status__role__in=[OrderStatusRole.INITIAL, OrderStatusRole.PROCESSING])
            .aggregate(total=Sum("quantity"))["total"] or 0
        )

        pending_grams_in_orders += (pending_orders_qty * net_weight if net_weight else 0)

    pending_sales = (pending_grams_in_orders / product.net_weight if product.net_weight else 0)
    return {
        "logical_count": bulk_available_in_packages - pending_sales,
        "physical_count": bulk_available_in_packages
    }
