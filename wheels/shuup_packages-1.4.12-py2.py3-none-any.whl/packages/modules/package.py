# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from shuup.core.models import Product, StockBehavior
from shuup.core.utils import context_cache
from shuup.simple_supplier.models import StockCount
from shuup.simple_supplier.module import SimpleSupplierModule

from .utils import get_current_stock_value


class PackageSupplierModule(SimpleSupplierModule):
    identifier = "package_supplier"
    name = "Package Supplier"

    def update_stock(self, product_id):
        """
        Update product stock count based on bulk

        Also override simple supplier logic for counting
        stock value.
        """
        supplier_id = self.supplier.pk
        values = get_current_stock_value(supplier_id, product_id)

        stock_count, _ = StockCount.objects.get_or_create(supplier_id=supplier_id, product_id=product_id)
        stock_count.logical_count = values["logical_count"]
        stock_count.physical_count = values["physical_count"]

        if "shuup.notify" in settings.INSTALLED_APPS:
            if stock_count.alert_limit and stock_count.physical_count < stock_count.alert_limit:
                product = Product.objects.filter(id=product_id).first()
                if product and product.stock_behavior == StockBehavior.STOCKED:
                    from shuup.simple_supplier.notify_events import AlertLimitReached
                    for shop in self.supplier.shops.all():
                        AlertLimitReached(supplier=self.supplier, product=product).run(shop=shop)

        stock_count.save(update_fields=("logical_count", "physical_count"))
        context_cache.bump_cache_for_product(Product.objects.get(id=product_id))

    def ship_products(self, shipment, product_quantities):
        """
        Products created to packages may or may not be in shipping
        mode. The module itself does not require product shipments.

        Since re-weighting the packages happens separately in the
        order process we can just create shipment products here
        without checking actual stocks.
        """
        for product, quantity in product_quantities.items():
            if quantity > 0:
                sp = shipment.products.create(product=product, quantity=quantity)
                sp.cache_values()
                sp.save()

        shipment.cache_values()
        shipment.save()
