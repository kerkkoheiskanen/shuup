from shuup.front.themes.views._product_price import ProductPriceView
from shuup.front.views.product import ProductDetailView


class ProductListPriceView(ProductPriceView):
    template_name = "shuup_sunrise_theme/product/detail_order_section_list.jinja"


def product_list_price(request):
    return ProductListPriceView.as_view()(request, pk=request.GET["id"])


def product_price(request):
    return ProductPriceView.as_view()(request, pk=request.GET["id"])


class ProductActionsView(ProductDetailView):
    template_name = "shuup_sunrise_theme/product/product_actions.jinja"


def product_actions(request):
    return ProductActionsView.as_view()(request, pk=request.GET["id"])
