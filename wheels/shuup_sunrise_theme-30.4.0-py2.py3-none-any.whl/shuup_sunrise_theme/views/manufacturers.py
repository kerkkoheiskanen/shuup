# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import with_statement

from django.views.generic import DetailView

from shuup.core.models import Manufacturer


class ManufacturerView(DetailView):
    template_name = "shuup_sunrise_theme/manufacturer.jinja"
    model = Manufacturer
    template_object_name = "manufacturer"
