from shuup.front.themes.views import basket_partial, product_preview
from shuup.utils import update_module_attributes

from .product_price import product_actions, product_list_price, product_price

__all__ = [
    "basket_partial",
    "product_actions",
    "product_list_price",
    "product_preview",
    "product_price"
]

update_module_attributes(__all__, __name__)
