# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import six
from django.db.models import QuerySet
from django.utils.translation import ugettext_lazy as _
from filer.models import Image

from shuup.admin.forms.widgets import TextEditorWidget
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.forms import GenericPluginForm, TranslatableField
from shuup.xtheme.plugins.image import ImageIDField


class CategoryPromoConfigForm(GenericPluginForm):

    def populate(self):
        fields = [
            ("content", TranslatableField(required=False, label=_("Mid content"), widget=TextEditorWidget)),
            ("left_image", ImageIDField(required=False, label=_("Left side image"))),
            ("right_image", ImageIDField(required=False, label=_("Right side image"))),
            ("mobile_image", ImageIDField(required=False, label=_("Mobile image")))
        ]

        for field in fields:
            if isinstance(field, tuple):
                name, value = field
                value.initial = self.plugin.config.get(name, value.initial)
                self.fields[name] = value

    def clean(self):
        cleaned_data = super(CategoryPromoConfigForm, self).clean()

        for key, values in six.iteritems(cleaned_data):
            if issubclass((values.__class__ if hasattr(values, "__class__") else None), QuerySet):
                cleaned_data[key] = [value.pk for value in values if hasattr(value, "pk")]
            elif hasattr(values, "pk"):
                cleaned_data[key] = values.pk

        return cleaned_data


class CategoryPromoPlugin(TemplatedPlugin):
    identifier = "shuup_sunrise_theme.category_promo"
    name = _("Sunrise Category Promo")
    template_name = "shuup_sunrise_theme/plugins/category_promo.jinja"
    editor_form_class = CategoryPromoConfigForm
    fields = [("title")]

    def get_context_data(self, context):
        context = super(CategoryPromoPlugin, self).get_context_data(context)
        context.update(self.config)

        translated_fields = [
            "content"
        ]

        for field in translated_fields:
            if field not in context:
                continue
            context[field] = self.get_translated_value(field, default="")

        for field in ["left_image", "right_image", "mobile_image"]:
            if not context.get(field):
                continue
            context[field] = Image.objects.filter(pk=context[field]).first()

        return context
