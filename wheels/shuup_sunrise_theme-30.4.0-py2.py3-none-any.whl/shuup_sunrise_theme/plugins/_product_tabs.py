# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.

from django import forms
from django.utils.translation import ugettext_lazy as _

from shuup.admin.forms.widgets import TextEditorWidget
from shuup.core.shop_provider import get_shop
from shuup.utils.djangoenv import has_installed
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.forms import TranslatableField


class ProductTabsPlugin(TemplatedPlugin):
    identifier = "shuup_sunrise_theme.product_tabs"
    name = _("Sunrise Product Tabs")
    template_name = "shuup_sunrise_theme/plugins/product_tabs.jinja"
    inherited_variables = ("product", )

    @property
    def fields(self):
        fields = [
            (
                "show_product_description",
                forms.BooleanField(required=False, initial=True, label=_("Show product description"))
            ),
            (
                "description_tab_text",
                TranslatableField(required=False, initial=_("Description"), label=_("Description tab text"))
            ),
            (
                "description_video", forms.CharField(required=False, label=_("Video URL for description"))
            ),
            (
                "show_attributes",
                forms.BooleanField(
                    required=False,
                    initial=True,
                    label=_("Show product attributes on description tab")
                )
            ),
            (
                "second_tab_text", TranslatableField(required=False, label=_("Second tab text"))
            ),
            (
                "second_tab_content",
                TranslatableField(
                    required=False, label=_("Second tab left content"), widget=TextEditorWidget
                )
            ),
            (
                "second_tab_content_right",
                TranslatableField(
                    required=False, label=_("Second tab right content"), widget=TextEditorWidget
                )
            ),
            (
                "third_tab_text", TranslatableField(required=False, label=_("Third tab text"))
            ),
            (
                "third_tab_content",
                TranslatableField(
                    required=False, label=_("Third tab content"), widget=TextEditorWidget
                )
            ),
            (
                "third_tab_content_right",
                TranslatableField(
                    required=False, label=_("Third tab right content"), widget=TextEditorWidget
                )
            )
        ]
        if has_installed("shuup_product_reviews"):
            fields.extend([
                (
                    "render_reviews_tab",
                    forms.BooleanField(required=False, initial=False, label=_("Show product reviews tab"))
                ),
                (
                    "reviews_tab_title", TranslatableField(required=False, label=_("Product reviews tab title"))
                )
            ])
        return fields

    def get_context_data(self, context):
        context = super(ProductTabsPlugin, self).get_context_data(context)
        context.update(self.config)

        translated_fields = [
            "description_tab_text",
            "second_tab_text",
            "third_tab_text",
            "second_tab_content",
            "third_tab_content",
            "second_tab_content_right",
            "third_tab_content_right"
        ]

        for field in translated_fields:
            if field not in context:
                continue
            context[field] = self.get_translated_value(field, default="")

        video_url = self.config.get("description_video")
        if video_url:
            # get video id
            pieces = video_url.split("/")
            video_id = pieces[-1]
            context["video_id"] = video_id

        shop = get_shop(context["request"])
        context["shop_product"] = context["product"].get_shop_instance(shop=shop)

        if has_installed("shuup_product_reviews") and self.config.get("render_reviews_tab"):
            context["render_reviews_tab"] = True
            context["reviews_tab_title"] = self.get_translated_value("reviews_tab_title", "")

        return context
