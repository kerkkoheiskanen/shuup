# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import six
from django import forms
from django.db.models import QuerySet
from django.utils.translation import ugettext_lazy as _

from shuup.admin.forms.widgets import TextEditorWidget
from shuup.core import cache
from shuup.core.shop_provider import get_shop
from shuup.simple_cms.models import Page
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.forms import GenericPluginForm, TranslatableField

PLUGIN_CACHE_KEY_FMT = "{shop_id}_shuup_sunrise_theme.site_footer.context"


class FooterConfigForm(GenericPluginForm):
    def full_clean(self):
        """ Bump the cache """
        cache_key = PLUGIN_CACHE_KEY_FMT.format(shop_id=self.request.shop.pk)
        cache.bump_version(cache_key)
        return super(FooterConfigForm, self).full_clean()

    def populate(self):
        shop = get_shop(self.request)
        page_queryset = Page.objects.for_shop(shop)

        # TODO: Figure out how we get right ordering for the fields!
        fields = []

        # Top row
        fields += [
            (
                "top_row",
                TranslatableField(required=False, label=_("Top row"), widget=TextEditorWidget)
            )
        ]

        # Mid row
        for x in range(1, 7):
            fields += [
                (
                    "middle_row_page_%d" % x,
                    forms.ModelChoiceField(
                        queryset=page_queryset, required=False, initial=None, label=_("Middle row CMS page #%d" % x))
                )
            ]

        fields += [
            (
                "middle_row_facebook_link",
                forms.CharField(required=False, label=_("Middle row facebook link"))
            ),
            (
                "middle_row_youtube_link",
                forms.CharField(required=False, label=_("Middle row youtube link"))
            ),
            (
                "middle_row_instagram_link",
                forms.CharField(required=False, label=_("Middle row instagram link"))
            ),
            (
                "middle_row_twitter_link",
                forms.CharField(required=False, label=_("Middle row twitter link"))
            ),
            (
                "middle_row_free_text",
                TranslatableField(
                    required=False, label=_("Middle row free text"), widget=TextEditorWidget
                )
            )
        ]

        # Bottom row
        fields += [
            (
                "bottom_row_copyright_text",
                TranslatableField(
                    required=False, initial=_("Copyright © 2018 Your Company, Inc."),
                    label=_("Bottom row copyright text"))
            )
        ]
        for x in range(1, 4):
            fields += [
                (
                    "bottom_row_page_%d" % x,
                    forms.ModelChoiceField(
                        queryset=page_queryset, required=False, initial=None, label=_("Bottom row CMS page #%d" % x))
                )
            ]

        fields += [
            (
                "bottom_row_free_text",
                TranslatableField(
                    required=False, label=_("Bottom row free text"), widget=TextEditorWidget
                )
            )
        ]

        # Mobile extras
        fields += [
            (
                "mobile_extra_content",
                TranslatableField(
                    required=False, initial=_("We're here 24/7"), label=_("Mobile extra content"),
                    widget=TextEditorWidget)
            )
        ]

        for field in fields:
            if isinstance(field, tuple):
                name, value = field
                value.initial = self.plugin.config.get(name, value.initial)
                self.fields[name] = value

    def clean(self):
        cleaned_data = super(FooterConfigForm, self).clean()

        for key, values in six.iteritems(cleaned_data):
            if issubclass((values.__class__ if hasattr(values, "__class__") else None), QuerySet):
                cleaned_data[key] = [value.pk for value in values if hasattr(value, "pk")]
            elif hasattr(values, "pk"):
                cleaned_data[key] = values.pk

        return cleaned_data


class SiteFooterPlugin(TemplatedPlugin):
    identifier = "shuup_sunrise_theme.site_footer"
    name = _("Sunrise Site Footer")
    template_name = "shuup_sunrise_theme/plugins/footer.jinja"
    editor_form_class = FooterConfigForm
    fields = [("top_row_title")]

    def get_context_data(self, context):
        context = super(SiteFooterPlugin, self).get_context_data(context)
        context.update(self.config)
        cache_key = PLUGIN_CACHE_KEY_FMT.format(shop_id=context["request"].shop.pk)
        context_data = cache.get(cache_key)

        if context_data is None or not isinstance(context_data, dict):
            context_data = self.config
            # All translatable fields needs to be extracted based
            # on the current language.
            translated_fields = [
                "top_row",
                "middle_row_free_text",
                "middle_row_free_text",
                "bottom_row_copyright_text",
                "bottom_row_free_text",
                "mobile_extra_content"
            ]

            for field in translated_fields:
                if field not in context_data:
                    continue
                context_data[field] = self.get_translated_value(field, default="")

            # Now we have all necessary values in the context but
            # all model fields has only pk referencing to the object
            # and in the template we need the actual object instead of pk.
            page_fields = []
            for x in range(1, 7):
                page_fields.append("middle_row_page_%d" % x)

            for x in range(1, 4):
                page_fields.append("bottom_row_page_%d" % x)

            for field in page_fields:
                context_data[field] = (
                    Page.objects.filter(pk=context_data[field]).first() if field in context_data else None
                )

            middle_row_cms_pages = []
            for x in range(1, 7):
                key = "middle_row_page_%d" % x
                if context_data.get(key, None) is None:
                    continue
                middle_row_cms_pages.append(context_data[key])

            context_data["middle_row_cms_pages"] = middle_row_cms_pages

            bottom_row_cms_pages = []
            for x in range(1, 4):
                key = "bottom_row_page_%d" % x
                if context_data.get(key, None) is None:
                    continue
                bottom_row_cms_pages.append(context_data[key])

            context_data["bottom_row_cms_pages"] = bottom_row_cms_pages

            cache.set(cache_key, context_data)

        context.update(context_data)
        return context
