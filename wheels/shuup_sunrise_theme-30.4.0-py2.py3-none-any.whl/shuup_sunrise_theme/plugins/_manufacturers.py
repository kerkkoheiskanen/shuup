# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import six
from django import forms
from django.db.models import QuerySet
from django.utils.translation import ugettext_lazy as _

from shuup.core.models import Manufacturer
from shuup.core.shop_provider import get_shop
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.forms import GenericPluginForm, TranslatableField


class ManufacturersConfigForm(GenericPluginForm):

    def populate(self):
        shop = get_shop(self.request)
        manufacturer_queryset = Manufacturer.objects.filter(shops=shop)
        fields = []

        fields += [
            ("title", TranslatableField(required=False, label=_("Title"))),
            ("show_all_title", TranslatableField(required=False, label=_("Show all title"))),
            ("show_all_link", forms.CharField(required=False, label=_("Show all link"))),
            (
                "manufacturers",
                forms.ModelMultipleChoiceField(
                    queryset=manufacturer_queryset, required=False, initial=None,
                    label=_("Manufacturers"))
            )
        ]

        for field in fields:
            if isinstance(field, tuple):
                name, value = field
                value.initial = self.plugin.config.get(name, value.initial)
                self.fields[name] = value

    def clean(self):
        cleaned_data = super(ManufacturersConfigForm, self).clean()

        for key, values in six.iteritems(cleaned_data):
            if issubclass((values.__class__ if hasattr(values, "__class__") else None), QuerySet):
                cleaned_data[key] = [value.pk for value in values if hasattr(value, "pk")]
            elif hasattr(values, "pk"):
                cleaned_data[key] = values.pk

        return cleaned_data


class ManufacturerPlugin(TemplatedPlugin):
    identifier = "shuup_sunrise_theme.manufacturers"
    name = _("Sunrise Brand Promo")
    template_name = "shuup_sunrise_theme/plugins/manufacturers.jinja"
    editor_form_class = ManufacturersConfigForm
    fields = [("title")]

    def get_context_data(self, context):
        context = super(ManufacturerPlugin, self).get_context_data(context)
        context.update(self.config)

        # All translatable fields needs to be extracted based
        # on the current language.
        translated_fields = [
            "title",
            "show_all_title"
        ]

        for field in translated_fields:
            if field not in context:
                continue
            context[field] = self.get_translated_value(field, default="")

        for field in ["manufacturers"]:
            if not context.get(field):
                continue
            context[field] = Manufacturer.objects.filter(pk__in=context[field])

        return context
