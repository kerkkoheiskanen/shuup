# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import string
from collections import OrderedDict

import six
from django import forms
from django.db.models import QuerySet
from django.utils.translation import ugettext_lazy as _
from filer.models import Image

from shuup.admin.forms.widgets import TextEditorWidget
from shuup.core import cache
from shuup.core.models import Category, Manufacturer
from shuup.core.shop_provider import get_shop
from shuup.simple_cms.models import Page
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.forms import GenericPluginForm, TranslatableField
from shuup.xtheme.plugins.image import ImageIDField

PLUGIN_CACHE_KEY_FMT = "{shop_id}_shuup_sunrise_theme.site_navigation.context"



class NavigationConfigForm(GenericPluginForm):
    def full_clean(self):
        """ Bump the cache """
        cache_key = PLUGIN_CACHE_KEY_FMT.format(shop_id=self.request.shop.pk)
        cache.bump_version(cache_key)
        return super(NavigationConfigForm, self).full_clean()

    def populate(self):
        shop = get_shop(self.request)
        category_queryset = Category.objects.all_visible(None, shop=shop)
        page_queryset = Page.objects.visible(shop)
        manufacturer_queryset = Manufacturer.objects.filter(shops=shop)

        # TODO: Figure out how we get right ordering for the fields!
        fields = [
            (
                "menu_lowercase",
                forms.BooleanField(required=False, initial=True, label=_("Show Main menu links in lowercase"))
            )
        ]

        # Help dropdown
        fields += [
            (
                "show_help_dropdown",
                forms.BooleanField(required=False, initial=True, label=_("Show help dropdown"))
            ),
            (
                "help_dropdown_menu_title",
                TranslatableField(required=False, initial=_("24/7 help"), label=_("Help dropdown menu title"))
            ),
            (
                "help_dropdown_menu_title_mobile",
                TranslatableField(required=False, initial=_("help"), label=_("Mobile help dropdown menu title"))
            ),
            (
                "help_dropdown_title",
                TranslatableField(
                    required=False, initial=_("Get help from our experts 24/7"),
                    label=_("Help dropdown title"), widget=TextEditorWidget
                )
            ),
            (
                "help_dropdown_chat_link",
                forms.CharField(required=False, label=_("Help dropdown chat link"))
            ),
            (
                "help_dropdown_contact_us_link",
                forms.CharField(required=False, label=_("Help dropdown contact us link"))
            ),
            (
                "help_dropdown_show_track_order_link",
                forms.BooleanField(required=False, initial=True, label=_("Help dropdown show track order link"))
            ),
            (
                "help_dropdown_cms_page_1",
                forms.ModelChoiceField(
                    queryset=page_queryset, required=False, initial=None, label=_("Help dropdown CMS page 1")
                )
            ),
            (
                "help_dropdown_cms_page_2",
                forms.ModelChoiceField(
                    queryset=page_queryset, required=False, initial=None, label=_("Help dropdown CMS page 2")
                )
            )
        ]

        # Shop by category
        fields.append(
            (
                "shop_by_category_menu_title",
                TranslatableField(required=False, initial=_("Shop By Category"), label=_("Shop by category menu title"))
            )
        )

        for x in range(1, 11):
            fields += [
                (
                    "shop_by_category_%d_category" % x,
                    forms.ModelChoiceField(
                        queryset=category_queryset, required=False, label=_("Shop by category #%d category" % x))
                ),
                (
                    "shop_by_category_%d_desktop_banner" % x,
                    ImageIDField(required=False, label=_("Shop by category #%d desktop banner" % x))
                ),
                (
                    "shop_by_category_%d_mobile_banner" % x,
                    ImageIDField(required=False, label=_("Shop by category #%d mobile banner" % x))
                ),
                (
                    "shop_by_category_%d_manufacturers" % x,
                    forms.ModelMultipleChoiceField(
                        queryset=manufacturer_queryset, required=False, initial=None,
                        label=_("Shop by category #%d manufacturers" % x)
                    )
                )
            ]

        # Shop by manufacturer
        fields += [
            (
                "shop_by_manufacturer_menu_title",
                TranslatableField(
                    required=False, initial=_("Shop By Manufacturer"), label=_("Shop by manufacturer menu title"))
            ),
            (
                "shop_by_manufacturer_menu_link",
                forms.CharField(required=False, label=_("Shop by manufacturer menu link"))
            ),
            (
                "shop_by_manufacturer_manufacturers",
                forms.ModelMultipleChoiceField(
                    queryset=manufacturer_queryset, required=False, initial=None,
                    label=_("Shop by manufacturer populars")
                )
            )
        ]

        # Category dropdown
        fields += [
            (
                "category_dropdown_menu_title",
                TranslatableField(
                    required=False, initial=_("Categories"), label=_("Category dropdown menu title"))
            ),
            (
                "category_dropdown_categories",
                forms.ModelMultipleChoiceField(
                    queryset=category_queryset, required=False, initial=None,
                    label=_("Category dropdown categories")
                )
            )
        ]

        # Extra menu item
        fields += [
            (
                "show_deals_menu_title",
                forms.BooleanField(required=False, initial=True, label=_("Show deals menu title"))
            ),
            (
                "deals_menu_title",
                TranslatableField(required=False, initial=_("Today's deals"), label=_("Deals menu title"))
            ),
            (
                "deals_menu_link",
                forms.CharField(required=False, label=_("Deals menu link"))
            )
        ]

        # Marketing text
        fields += [
            (
                "marketing_text",
                TranslatableField(required=False, initial=True, label=_("Marketing text area"), widget=TextEditorWidget)
            )
        ]

        for field in fields:
            if isinstance(field, tuple):
                name, value = field
                value.initial = self.plugin.config.get(name, value.initial)
                self.fields[name] = value

    def clean(self):
        cleaned_data = super(NavigationConfigForm, self).clean()

        for key, values in six.iteritems(cleaned_data):
            if issubclass((values.__class__ if hasattr(values, "__class__") else None), QuerySet):
                cleaned_data[key] = [value.pk for value in values if hasattr(value, "pk")]
            elif hasattr(values, "pk"):
                cleaned_data[key] = values.pk

        return cleaned_data


class SiteNavigationPlugin(TemplatedPlugin):
    identifier = "shuup_sunrise_theme.site_navigation"
    name = _("Sunrise Site Navigation")
    template_name = "shuup_sunrise_theme/plugins/navigation/classic.jinja"
    editor_form_class = NavigationConfigForm
    fields = [("show_help_dropdown")]

    def get_context_data(self, context):
        context = super(SiteNavigationPlugin, self).get_context_data(context)
        request = context["request"]
        shop = get_shop(request)

        cache_key = PLUGIN_CACHE_KEY_FMT.format(shop_id=context["request"].shop.pk)
        data_context = cache.get(cache_key)

        if data_context is None or not isinstance(data_context, dict):
            data_context = {}
            # For shop by manufacturers we need alphabets for the quick search
            mfs = OrderedDict()
            alphabets = list(string.ascii_lowercase)
            for m in Manufacturer.objects.filter(shops=shop).order_by("name"):
                name = m.name
                letter = name[0].lower()
                if letter not in alphabets:
                    letter = "_"
                if letter not in mfs:
                    mfs[letter] = []
                mfs[letter].append(m)

            data_context.update({
                "manufacturers_by_alphabet": mfs,
                "alphabets": alphabets
            })
            data_context.update(self.config)

            # All translatable fields needs to be extracted based
            # on the current language.
            translated_fields = [
                "help_dropdown_menu_title",
                "help_dropdown_menu_title_mobile",
                "help_dropdown_title",
                "shop_by_category_menu_title",
                "shop_by_manufacturer_menu_title",
                "category_dropdown_menu_title",
                "deals_menu_title",
                "shop_by_manufacturer_menu_title",
                "marketing_text"
            ]

            for field in translated_fields:
                if field not in data_context:
                    continue
                data_context[field] = self.get_translated_value(field, default="")

            # Now we have all necessary values in the context but
            # all model fields has only pk referencing to the object
            # and in the template we need the actual object instead of pk.
            categories_fields = [
                "category_dropdown_categories"
            ]

            for field in categories_fields:
                if field not in data_context:
                    continue
                data_context[field] = Category.objects.filter(pk__in=data_context[field])

            category_fields = []
            for x in range(1, 11):
                category_fields.append("shop_by_category_%d_category" % x)

            for field in category_fields:
                if field not in data_context:
                    continue
                data_context[field] = Category.objects.filter(pk=data_context[field]).first()

            manufacturers_fields = [
                "shop_by_manufacturer_manufacturers"
            ]
            for x in range(1, 11):
                manufacturers_fields.append("shop_by_category_%d_manufacturers" % x)

            for field in manufacturers_fields:
                if field not in data_context:
                    continue
                data_context[field] = Manufacturer.objects.filter(pk__in=data_context[field])

            page_fields = [
                "help_dropdown_cms_page_1",
                "help_dropdown_cms_page_2"
            ]

            for field in page_fields:
                if field not in data_context:
                    continue
                data_context[field] = Page.objects.filter(pk=data_context[field]).first()

            image_fields = []
            for x in range(1, 11):
                image_fields.append("shop_by_category_%d_desktop_banner" % x)
                image_fields.append("shop_by_category_%d_mobile_banner" % x)

            for field in image_fields:
                if field not in data_context:
                    continue
                data_context[field] = Image.objects.filter(pk=data_context[field]).first()

            # Then we have these shop by categories objects which we need
            # to re-organize a little so we don't need to do much while
            # rendering.
            shop_by_category_items = []
            for x in range(1, 11):
                category_key = "shop_by_category_%d_category" % x
                desktop_banner_key = "shop_by_category_%d_desktop_banner" % x
                mobile_banner_key = "shop_by_category_%d_mobile_banner" % x
                manufacturers_key = "shop_by_category_%d_manufacturers" % x

                if category_key not in data_context:
                    continue

                shop_by_category_items.append({
                    "category": data_context[category_key],
                    "desktop_banner": data_context[desktop_banner_key],
                    "mobile_banner": data_context[mobile_banner_key],
                    "manufacturers": data_context[manufacturers_key]
                })

            data_context["shop_by_category_items"] = shop_by_category_items[:8]
            cache.set(cache_key, data_context)

        context.update(data_context)
        return context
