# This file is part of Shuup Sunrise Theme.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import re

import tinycss
from django.contrib.staticfiles import finders
from django.core.management.base import BaseCommand

TEXT_COLOR_MAP = {
    "ORANGE": "#D1B97E",    # to gold
    "#128CED": "#D1B97E",   # to gold
    "#F8D81C": "#D1B97E"    # yellow to gold
}
BG_COLOR_MAP = {
    "#EF6C00": "#D1B97E",    # orange to gold
    "#D76101": "#D1BA7E",   # orange to gold
    "ORANGE": "#D1B97E",    # orange to gold
    "#128CED": "#29292A",   # blue to light gold
    "#0D7ED4": "#29292A"    # blue to light gold
}
BORDER_COLOR_MAP = {
    "#EF6C00": "#D1B97E",   # orange to gold
    "#D76101": "#D1BA7E",   # orange to gold
    "ORANGE": "#D1B97E",    # to gold
    "#128CED": "#29292A",   # blue to light gold
    "#0D7ED4": "#29292A"    # blue to light gold
}


class Command(BaseCommand):
    def handle(self, *args, **options):
        style_css = finders.find("shuup_sunrise_theme/css/style.css")
        stylesheet = tinycss.make_parser().parse_stylesheet(open(style_css).read())
        rules = []

        for rule in stylesheet.rules:
            if not hasattr(rule, "declarations"):
                continue

            for declaration in rule.declarations:
                name = declaration.name
                if not (name in ("color", "background", "background-color") or "border" in name):
                    continue

                declaration_css = declaration.value.as_css()
                replaced = False

                if name == "color":
                    for from_color, to_color in TEXT_COLOR_MAP.items():
                        regex = re.compile(from_color.upper(), re.IGNORECASE)
                        if regex.findall(declaration_css):
                            replaced = True
                            declaration_css = regex.sub(to_color, declaration_css)

                elif name in ("background", "background-color"):
                    for from_color, to_color in BG_COLOR_MAP.items():
                        regex = re.compile(from_color.upper(), re.IGNORECASE)
                        if regex.findall(declaration_css):
                            replaced = True
                            declaration_css = regex.sub(to_color, declaration_css)

                else:
                    for from_color, to_color in BORDER_COLOR_MAP.items():
                        regex = re.compile(from_color.upper(), re.IGNORECASE)
                        if regex.findall(declaration_css):
                            replaced = True
                            declaration_css = regex.sub(to_color, declaration_css)

                if replaced:
                    rules.append("%(selector)s { %(name)s: %(value)s !important; }" % dict(
                        selector=rule.selector.as_css(),
                        name=name,
                        value=declaration_css
                    ))

        print("\n".join(rules))
