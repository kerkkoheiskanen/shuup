# -*- coding: utf-8 -*-
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_sunrise_theme"
    label = "shuup_sunrise_theme"
    provides = {
        "xtheme": "shuup_sunrise_theme.theme:ShuupSunriseTheme",
        "front_urls_post": ["shuup_sunrise_theme.urls:urlpatterns"],
    }

    def ready(self):
        from django.db.models.signals import post_save
        from shuup.xtheme.models import ThemeSettings
        from .signal_handler import handle_settings_save
        post_save.connect(handle_settings_save, sender=ThemeSettings)
