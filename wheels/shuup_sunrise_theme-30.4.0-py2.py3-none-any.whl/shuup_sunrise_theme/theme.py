# -*- coding: utf-8 -*-
import datetime

import pytz
from django import forms
from django.conf import settings
from django.utils.encoding import force_text
from django.utils.safestring import mark_safe
from django.utils.translation import get_language
from django.utils.translation import ugettext_lazy as _

from shuup.admin.forms.widgets import HexColorWidget
from shuup.core import cache
from shuup.core.models import ProductMode
from shuup.core.utils import context_cache
from shuup.front.utils.views import cache_product_things
from shuup.utils.djangoenv import has_installed
from shuup.utils.numbers import get_string_sort_order
from shuup.xtheme import Theme

WISHLIST_BUTTON_TEMPLATE = """
<btn href="#" class="btn btn-default add-to-wishlist" data-shop-product-id="%d" data-url-override="%s">
<i class="fa fa-fw fa-heart"></i> <span class="text">Add to wishlist</span></btn>
"""

COMPARISON_BUTTON_TEMPLATE = """
<btn href="#" class="btn btn-default shuup-product-compare-add" data-product-id="%d">
<i class="fa fa-fw fa-bar-chart"></i> <span class="text">Add to compare</span></btn>
"""

CUSTOM_COLORS_STYLE_THEME = """<style type="text/css">%s</style>"""

BODY_FONT_CUSTOM_RULES = [
    ".category-sidebar .sidebar-block .title",
    ".category-sidebar .sidebar-block .sidebar-block-title",
    ".category-sidebar .sidebar-block h2",
    ".category-sidebar .sidebar-subtitle",
    ".site-nav .language-nav .dropdown > a",
    ".site-nav .secondary-nav .cart > a",
    ".site-nav .user-nav li a",
    ".nav-toggler",
    ".main-menu ul li a",
    ".btn .btn-primary",
    ".product-preview-modal .labels .sale-badge",
    ".product-card .labels .label-sale",
    ".product-card .labels .label-new",
    ".product-image .labels .label-sale",
    ".product-image .labels .label-new",
    ".xt-snippet-injection"
]


class ColorField(forms.CharField):
    widget = HexColorWidget


class ShuupSunriseTheme(Theme):
    identifier = "shuup_sunrise_theme"
    name = _("Shuup Sunrise Theme")
    author = "Shuup Team"
    template_dir = "shuup_sunrise_theme/"

    plugins = [
        "shuup_sunrise_theme.plugins:ManufacturerPlugin",
        "shuup_sunrise_theme.plugins:ProductTabsPlugin",
        "shuup_sunrise_theme.plugins:SunriseProductHighlightPlugin",
        "shuup_sunrise_theme.plugins:SiteNavigationPlugin",
        "shuup_sunrise_theme.plugins:SiteFooterPlugin",
        "shuup_sunrise_theme.plugins:CategoryPromoPlugin",
        "shuup_sunrise_theme.plugins:VideoPlugin"
    ]

    stylesheets = [
        {
            "identifier": "classic",
            "stylesheet": "shuup_sunrise_theme/css/style.css",
            "name": _("Classic"),
            "images": []
        }
    ]

    @property
    def fields(self):
        fields = [
            (
                "show_supplier_info",
                forms.BooleanField(
                    required=False, initial=False, label=_("Show supplier info"),
                    help_text=_("Show supplier name in product-box, product-detail, basket- and order-lines"))
            ),
            ("show_carousel_actions", forms.BooleanField(
                required=False, initial=False, label=_("Allow Buying from Carousels"))),
            ("show_carousel_user_actions", forms.BooleanField(
                required=False, initial=False, label=_("Show user actions in Carousels"))),
            ("allow_company_linkage", forms.BooleanField(
                required=False, initial=False, label=_("Allow Linking Accounts to Company"))),
            ("product_new_days", forms.IntegerField(
                required=False, initial=14, label=_("Consider product new for days"))),
            ("show_product_detail_section", forms.BooleanField(
                required=False, initial=False, label=_("Show Product Details"),
                help_text=_("If you check this, extra information will be shown on product page in frontend."))),
            ("show_sales_units", forms.BooleanField(
                required=False, initial=True, label=_("Show sales units in product boxes"),
                help_text=_("If you check this the sales units are going to "
                            "be shown next to the quantity in product boxes."))),
            ("render_category_page_menu", forms.BooleanField(
                required=False, initial=True, label=_("Render categories on category page"),
                help_text=_("If you check this the categories are going to be "
                            "shown next to products on category page."))),
            ("hide_prices", forms.BooleanField(required=False, initial=False, label=_("Hide prices"))),
            ("catalog_mode", forms.BooleanField(required=False, initial=False, label=_("Set shop in catalog mode"))),

            ("text_color_1", ColorField(
                required=False,
                initial="",
                label=_("Text Color #1"),
                help_text=_(
                    "This color is used for navigation and footer links and icons."
                )
            )),
            ("button_bg_color_1", ColorField(
                required=False,
                initial="",
                label=_("Button Background Color #1"),
                help_text=_("This color is used for buttons backgrounds.")
            )),
            ("button_bg_color_2", ColorField(
                required=False,
                initial="",
                label=_("Button Background Color #2"),
                help_text=_("This color is also used for buttons backgrounds when gradient is used.")
            )),
            ("nav_footer_background_color", ColorField(
                required=False,
                initial="",
                label=_("Navigation/Footer Background Color"),
                help_text=_("This color is for navigation and footer backgrounds.")
            )),

            ("user_icon_selected_paths", forms.CharField(
                required=False,
                initial="",
                label=_("Customize paths for user icon selection"),
                help_text=_("Paths should be separated with semicolon. "
                            "User icon is selected when current path startswith any of the paths in this setting.")
            )),
            ("checkout_icon_selected_paths", forms.CharField(
                required=False,
                initial="",
                label=_("Customize paths for checkout icon selection"),
                help_text=_("Paths should be separated with semicolon. "
                            "Checkout icon is selected when current path startswith any of the paths in this setting.")
            )),
        ]
        if has_installed("shuup_product_reviews"):
            fields.extend([
                ("show_product_review", forms.BooleanField(
                    required=False, initial=True,
                    label=_("Show product reviews rating in product card")
                ))
            ])

        if has_installed("shuup_typography"):
            from shuup_typography.theme_utils import get_custom_font_fields
            fields.extend(get_custom_font_fields(self, self._shop))
        return fields

    def render_custom_font_style(self):
        if not has_installed("shuup_typography"):
            return ""
        from shuup_typography.theme_utils import get_render_custom_font_styles
        return get_render_custom_font_styles(self, BODY_FONT_CUSTOM_RULES)

    def get_view(self, view_name):
        import shuup_sunrise_theme.views as views
        return getattr(views, view_name, None)

    def _format_cms_links(self, shop, **query_kwargs):
        if "shuup.simple_cms" not in settings.INSTALLED_APPS:
            return
        from shuup.simple_cms.models import Page
        for page in Page.objects.visible(shop).filter(**query_kwargs):
            yield {"url": "/%s" % page.url, "text": force_text(page)}

    def get_wishlist_button(self, product, url_override):
        if "shuup_wishlist" not in settings.INSTALLED_APPS:
            return ""
        return mark_safe(WISHLIST_BUTTON_TEMPLATE % (product.pk, url_override))

    def get_comparison_button(self, product):
        if "shuup_product_comparison" not in settings.INSTALLED_APPS:
            return ""
        return mark_safe(COMPARISON_BUTTON_TEMPLATE % product.pk)

    def has_top_menu(self):
        left_menu_identifiers = [
            "love_and_light",
            "luxury_matress",
            "my_fluffy_friend",
            "patio_and_garden",
            "fragnance_heaven",
            "greatronics",
            "organic_juicery",
        ]
        sheet = self.settings_obj.data.get("settings", {}).get("stylesheet", None)
        for style in self.stylesheets:
            if style.get("stylesheet") == sheet and style.get("identifier") in left_menu_identifiers:
                return False
        return True

    def get_cms_navigation_links(self, request):
        return self._format_cms_links(request.shop, visible_in_menu=True)

    def get_variation_information(self, request, product):
        language = get_language()

        key, val = context_cache.get_cached_value(
            identifier="shop_product", item=product, context=request,
            language=language, theme="sunrise_theme")
        if val is not None:
            return val

        info = {}
        info["variation_children"] = []
        if product.mode == ProductMode.SIMPLE_VARIATION_PARENT:
            info["variation_children"] = cache_product_things(
                request,
                sorted(
                    product.variation_children.language(language).all(),
                    key=lambda p: get_string_sort_order(p.variation_name or p.name)
                )
            )
            info["orderable_variation_children"] = [
                p for p in info["variation_children"]
                if p.get_shop_instance(request.shop).is_orderable(
                    supplier=None,
                    customer=request.customer,
                    quantity=1
                )
                ]
        elif product.mode == ProductMode.VARIABLE_VARIATION_PARENT:
            from shuup.front.utils.product import get_orderable_variation_children
            variation_variables = product.variation_variables.all().prefetch_related("values")
            orderable_children, is_orderable = get_orderable_variation_children(product, request, variation_variables)
            info["orderable_variation_children"] = orderable_children
            info["variation_orderable"] = is_orderable
            info["variation_variables"] = variation_variables
        context_cache.set_cached_value(key, info)
        return info

    def product_is_new(self, request, product):
        past = datetime.datetime.now(tz=pytz.UTC) - datetime.timedelta(days=self.get_setting("product_new_days", 14))
        return (product.created_on >= past)

    def show_carousel_actions(self):
        return self.get_setting("show_carousel_actions", False)

    def show_carousel_user_actions(self):
        return self.get_setting("show_carousel_user_actions", False)

    def allow_company_linkage(self):
        return self.get_setting("allow_company_linkage", False)

    def show_product_detail_section(self):
        return self.get_setting("show_product_detail_section", False)

    def should_render_left_menu(self, request):
        if request:
            match = request.resolver_match
            if match and match.app_name == "shuup_admin":
                return
        return request.resolver_match.url_name in ["index", "product", "category"]

    def should_select_user_icon(self, request):
        default = [
            "/login/",
            "/register/",
            "/dashboard/",
            "/customer/",
            "/address-book/",
            "/order-history/",
            "/saved-carts/",
            "/address-book/",
            "/subscriptions/",
            "/product_reviews/",
            "/wishlists/"
        ]
        paths = (self.get_setting("user_icon_selected_paths", "").split(";") or default)
        return any([path for path in paths if request.path.startswith(path)])

    def should_select_checkout_icon(self, request):
        default = [
            "/basket/",
            "/checkout/",
        ]
        paths = (self.get_setting("checkout_icon_selected_paths", "").split(";") or default)
        return any([path for path in paths if request.path.startswith(path)])

    def show_sales_units(self):
        return self.get_setting("show_sales_units", True)

    def render_category_page_menu(self):
        return self.get_setting("render_category_page_menu", False)

    def get_product_filter_fields(self, form, exclude):
        return [field for field in form if field.name not in exclude]

    def shop_by_category(self):
        return self.get_setting("shop_by_category", False)

    def shop_by_manufacturer(self):
        return self.get_setting("shop_by_manufacturer", False)

    def shop_by_category_text(self):
        return self.get_setting("shop_by_category_text", _("Shop by Category"))

    def shop_by_manufacturer_text(self):
        return self.get_setting("shop_by_manufacturer_text", _("Shop by Manufacturer"))

    def render_custom_color_stylesheet(self):
        from django.template import loader as template_loader
        context = {
            "text_color_1": self.get_setting("text_color_1", False),
            "button_bg_color_1": self.get_setting("button_bg_color_1", False),
            "button_bg_color_2": self.get_setting("button_bg_color_2", False),
            "nav_footer_background_color": self.get_setting("nav_footer_background_color", False),
        }
        if not any(context.values()):
            return ""

        custom_style = template_loader.render_to_string("shuup_sunrise_theme/custom_colors.jinja", context)
        return mark_safe(CUSTOM_COLORS_STYLE_THEME % custom_style)

    def render_product_review_rating(self, product):
        if not has_installed("shuup_product_reviews"):
            return ""

        cache_key = "_product_review_rendered_rating_%d" % product.pk
        cached_rating = cache.get(cache_key)

        if cached_rating:
            return cached_rating

        from shuup_product_reviews.utils import render_product_review_ratings
        rendered = render_product_review_ratings(product)

        if rendered:
            cache.set(cache_key, rendered)
            return rendered

        return ""
