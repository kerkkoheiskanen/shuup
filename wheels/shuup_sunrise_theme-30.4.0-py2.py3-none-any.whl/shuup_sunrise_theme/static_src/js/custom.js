function scrollmanufacturers() {
    var letters = $(".drop-manufacturer-letters li");
    var manufacturerList = $(".manufacturer-list");

    letters.not(".disabled").first().addClass("is-selected");

    letters.on("click", "a", function (c) {
        c.preventDefault();
        if (!$(this).parent().hasClass("disabled")) {
            var d = $(this).attr("href")
                , e = $(d)[0]
                , f = e.offsetTop;
            letters.removeClass("is-selected");
            $(this).parent().addClass("is-selected");
            manufacturerList.addClass("clicked");

            manufacturerList.stop(!0).animate({
                scrollTop: f
            }, 100, function () {
                setTimeout(function () {
                    manufacturerList.removeClass("clicked");
                }, 101);
            });
        }
    });

    manufacturerList.on("scroll", function () {
        manufacturerList.find(".manufacturer-list-item").each(function () {
            var a = $(this);
            if (a.position().top < manufacturerList.height() - manufacturerList.height() + 20) {
                var c = a.attr("id");
                var d = c.substring(0);
                a.find("span").addClass("is-fixed");
                $(".drop-manufacturer-letters li").removeClass("is-selected");
                $("." + d).addClass("is-selected");
            } else {
                a.find("span").removeClass("is-fixed");
            }
        });
    });
}

function closeMenus() {
    $(".primary-support > li").removeClass("is-active");
    $(".primary-support > li > div").hide();
}

var transitioning = false;

var menuTool = {
    isOpen: function () {
        return $("#main-nav-state").is(":checked");
    },
    open: function () {
        var elem = $("#main-nav-state");
        elem.prop("checked", true);
        window.scrollTo(0, 0);
        this.toggleLock(elem, $(window).scrollTop());
        $("body").addClass("mobile-nav-open");
    },
    close: function () {
        var elem = $("#main-nav-state");
        elem.prop("checked", false);
        this.reset();
        this.toggleLock(elem, $(window).scrollTop());
        $("body").removeClass("mobile-nav-open");
    },
    reset: function () {
        $(".js-main-nav").find(".is-selected, .is-visited").removeClass("is-selected").removeClass("is-visited");
        $("#main-nav__first").addClass("is-selected");
    },
    getCurrentPanel: function () {
        return $(".main-nav .nav-panel.is-selected");
    },
    transition: function (e) {
        if (!transitioning) {
            transitioning = true;
            var panel = this.getCurrentPanel();
            if (panel.data("navigation-level") > e.data("navigation-level")) {
                e.removeClass("is-visited").addClass("is-selected");
                panel.removeClass("is-selected");
            } else {
                panel.addClass("is-visited").removeClass("is-selected");
                e.addClass("is-selected");
            }
            $(".js-main-nav").scrollTop(0);
            setTimeout(function () {
                transitioning = false;
            }, 500);
        }
    },
    toggleLock: function (e, t) {
        if (e.is(":checked")) {
            this.toggleLock.windowscroll = t;
            $("html").addClass("global-nav-open");
            $("body").css({
                top: -1 * this.toggleLock.windowscroll
            });
        } else {
            $("html").removeClass("global-nav-open");
            $("body").removeAttr("style");
            $(window).scrollTop(this.toggleLock.windowscroll);
        }
    }
};

jQuery.expr.filters.offscreen = function (el) {
    var rect = el.getBoundingClientRect();
    return ($("body").width() < rect.right);
};

$(document).ready(function () {

    var isMobile = false;
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        isMobile = true;
    }

    if (isMobile) {
        // Show Mobile Versions of header and footer
        $(".footer-main").hide();
        $(".site-nav").hide();
        $(".mobile-menu").show();
        $(".main-footer-mobile").show();
        $(document.body).addClass("mobile");
    }

    $(".js-main-nav").appendTo("body");

    scrollmanufacturers();

    $(".selectpicker select").selectpicker();

    $(".primary-support >li").on("mouseenter", function () {
        closeMenus();
        $(this).addClass("is-active");
        var $dropdown = $(this).find(".menu-dropdown");
        $dropdown.show();
        $dropdown.removeClass("offscreen");
        if ($dropdown.is(":offscreen")) {
            $dropdown.addClass("offscreen");
        }
    });
    $(".primary-support >li").on("mouseleave", function () {
        closeMenus();
    });

    $(".category-link").on("mouseenter", function () {
        $(this).addClass("is-active");
        $(this).find(".sunrise-megamenu").show();
    });
    $(".category-link").on("mouseleave", function () {
        $(this).removeClass("is-active");
        $(this).find(".sunrise-megamenu").hide();
        $("body").removeClass("nav-open");
    });

    // TODO: Figure out if we need this 'throttling'
    // var lastOpen;

    $(".nav-icon").on("mouseenter", function () {
        $("body").addClass("nav-open");
        $(".shop-by-category").find(".sunrise-megamenu").show();
        // lastOpen = (new Date()).getTime();
    });

    $(".nav-icon").on("click", function () {
        $("body").toggleClass("nav-open");
        $(".shop-by-category").find(".sunrise-megamenu").toggle();
        // var shouldClose = (((new Date()).getTime() - lastOpen) >= 300);
        // var shouldToggle = true;
        // if ($("body").hasClass("nav-open")) {
        //     if (shouldClose) {
        //         $("body").removeClass("nav-open");
        //     } else {
        //         shouldToggle = false;
        //     }
        // } else {
        //     $("body").addClass("nav-open");
        // }
        // if (shouldToggle) {
        //     $(".shop-by-category").find(".sunrise-megamenu").toggle();
        // }
    });


    $(".top-menu-wrap").on("mouseenter", function () {
        $("body").removeClass("nav-open");
    });

    $(".main-nav-trigger").on("click", function () {
        $("body").toggleClass("mobile-nav-open");
        $("#main-nav-first").addClass("is-selected");
    });
    $(".search-trigger").on("click", function () {
        $("body").removeClass("mobile-nav-open");
        $("#main-nav-first").removeClass("is-selected");
        $("#main-nav-state").prop("checked", false);
    });

    $(".js-main-nav").on("click", ".js-nav-drilldown, .js-nav-back", function (e) {
        e.preventDefault();
        var target = $($(this).data("target"));
        var a = $(target);
        menuTool.transition(a);
    });

    $(".category-selector").first().addClass("is-selected");
    $(".category-selector").on("mouseenter", function () {
        if ($(this).hasClass("has-children")) {
            var target = $(this).find("a").first().data("target");
            $(".sunrise-drop-category").hide();
            $(this).addClass("is-selected");
            $("." + target).show();
        }
    });
    $(".category-selector").on("mouseleave", function () {
        $(this).removeClass("is-selected");
    });

    $(".to-top").on("click", function (e) {
        e.preventDefault();
        const body = $("html, body");
        body.stop().animate({ scrollTop: 0 }, 500, "swing");
    });

    $(window).on("scroll", function () {
        if ($(".site-nav").height() === 150) {
            var scroll = $(window).scrollTop();
            if (scroll >= 150) {
                $(".site-nav").addClass("fixed-nav");
                // $(".checkout-basket-right").addClass("fixed");
            } else {
                $(".site-nav").removeClass("fixed-nav");
                // $(".checkout-basket-right").removeClass("fixed");
            }
        }
    });
    //
    $(".category-menu >ul >li.is-parent").on("mouseenter", function () {
        $(this).addClass("is-active");
    });
    $(".category-menu >ul >li.is-parent").on("mouseleave", function () {
        $(this).removeClass("is-active");
    });

    $(".btn-filters").on("click", function (e) {
        e.preventDefault();
        $(".category-sidebar").toggleClass("is-open");
        $(document.body).addClass("no-scroll");
    });

    $(".filters-close-btn").on("click", function (e) {
        e.preventDefault();
        $(".category-sidebar").toggleClass("is-open");
        $(document.body).removeClass("no-scroll");
    });

    $(".filter-section >h5").on("click", function (e) {
        e.preventDefault();
        $(this).parent().toggleClass("filter-opened");
    });

    $(".btn-variation").on("click", function (e) {
        e.preventDefault();
        var level = $(this).data("level");
        $(".btn-variation").each(function (i, elem) {
            if ($(elem).data("level") === level) {
                $(elem).removeClass("btn-active");
            }
        });
        $(this).addClass("btn-active");
        var productId = $(this).data("target-product");
        var variationId = $(this).data("product-id");
        var parentProduct = $(this).data("primary-product");
        if ($("#var_" + productId).length) {
            $("#var_" + productId).val(variationId);
        } else {
            $("#product-variations-" + productId).val(variationId);
        }
        var id = (parentProduct) ? parentProduct : productId;
        window.updatePrice(id);
    });

    $(document).on("click", "label", function () {
        var $parent = $(this).parents(".input-group, .form-group").first();
        $parent.addClass("field-focus");
        $parent.find("select").trigger("click");
    });

    $(document.body).on("DOMNodeInserted", function (e) {
        $("select.form-control").closest(".form-group").addClass("field-focus");
    });

    $(document).on("focusout", ".field-focus >.form-control", function () {
        const value = $(this).val();
        if (!value || !value.length) {
            $(this).parents(".field-focus").first().removeClass("field-focus");
        }
    });
    $(document).on("focusin", ".form-group >.form-control", function () {
        $(this).parents(".form-group").first().addClass("field-focus");
    });

    $(document).on("change", ".form-control", function () {
        const value = $(this).val();
        if (value && value.length) {
            var $parent = $(this).parents(".input-group, .form-group").first();
            if (!$parent.hasClass("field-focus")) {
                $parent.addClass("field-focus");
            }
        }
    });

    $(window).on("resize", function () {
        if ($(this).width() >= 750) {
            menuTool.close();
        }
    });

    window.setTimeout(function() {
        ensureFieldLabels();
    }, 100);
});

function ensureFieldLabels() {
    // Using -webkit-autofill for Chrome and .val().length > 0 for other browsers
    try {
        $(".form-control:-webkit-autofill").each(function (i, e) {
            var $parent = $(this).parents(".form-group").first();
            $parent.addClass("field-focus");
        });
    }
    catch(e) {
        // This means that the browser is not Chrome. Not an error.
    }
    $(".form-control").each(function (i, e) {
        const value = $(this).val();
        if (value && value.length) {
            var $parent = $(this).parents(".form-group").first();
            if (!$parent.hasClass("field-focus")) {
                $parent.addClass("field-focus");
            }
        }
    });
    $("#id_billing-region_code").prev("label").hide();
    $("#id_billing-region_code >option").first().text("Select region");
    $("#id_shipping-region_code").prev("label").hide();
    $("#id_shipping-region_code >option").first().text("Select region");
    $("#id_billing-country >option").first().text("Select country");
    $("#id_shipping-country >option").first().text("Select country");
    $("#id_contact-language >option").first().text($("#id_contact-language").prev("label").text());

}

function showErrorMessage(msg) {
    if (typeof window.flashMessage !== "undefined") {
        window.flashMessage("alert-danger", "", msg);
    } else {
        alert(msg);
    }
}
