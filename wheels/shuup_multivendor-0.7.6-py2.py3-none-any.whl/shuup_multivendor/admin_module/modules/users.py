# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import SETTINGS_MENU_CATEGORY
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.urls import admin_url


class MultivendorUserModule(AdminModule):
    name = _("Vendor Users")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:multivendor_user.list")

    def get_urls(self):
        return [
            admin_url(
                r"^vendor_users/(?P<pk>\d+)/reset-password/$",
                "shuup_multivendor.admin_module.views.users.MultivendorUserResetPasswordView",
                name="multivendor_user.reset-password"
            ),
            admin_url(
                r"^vendor_users/(?P<pk>\d+)/$",
                "shuup_multivendor.admin_module.views.users.MultivendorUserDetailView",
                name="multivendor_user.detail"
            ),
            admin_url(
                "^vendor_users/new/$",
                "shuup_multivendor.admin_module.views.users.MultivendorUserDetailView",
                kwargs={"pk": None},
                name="multivendor_user.new"
            ),
            admin_url(
                "^vendor_users/$",
                "shuup_multivendor.admin_module.views.users.MultivendorUserListView",
                name="multivendor_user.list"
            )
        ]

    def get_menu_entries(self, request):
        if not get_supplier(request):
            return []

        return [
            MenuEntry(
                text=_("Staff"),
                icon="fa fa-users",
                url="shuup_admin:multivendor_user.list",
                category=SETTINGS_MENU_CATEGORY,
                subcategory="other_settings",
                ordering=1
            )
        ]
