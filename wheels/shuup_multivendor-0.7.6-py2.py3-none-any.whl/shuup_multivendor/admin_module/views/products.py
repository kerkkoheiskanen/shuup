# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import decimal

from django.conf import settings
from django.contrib import messages
from django.contrib.staticfiles.templatetags.staticfiles import static
from django.core.exceptions import ObjectDoesNotExist
from django.core.urlresolvers import reverse
from django.db.models import Q
from django.db.transaction import atomic
from django.http import JsonResponse
from django.http.response import Http404, HttpResponseRedirect
from django.template.loader import render_to_string
from django.utils.translation import ugettext_lazy as _
from django.views.generic import DetailView, View
from shuup.admin.modules.products.views import \
    ProductEditView as BaseProductEditView
from shuup.admin.modules.products.views.edit import ProductAttributeFormPart
from shuup.admin.modules.products.views.toolbars import EditProductToolbar
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.toolbar import (
    get_default_edit_toolbar, PostActionButton, Toolbar, URLActionButton
)
from shuup.admin.utils.picotable import (
    ChoicesFilter, Column, Picotable, RangeFilter, TextFilter
)
from shuup.admin.utils.views import PicotableListView
from shuup.core.models import ProductMode, ShopProduct, Supplier
from shuup.core.utils import context_cache
from shuup.core.utils.price_cache import bump_prices_for_shop_product
from shuup.simple_supplier.models import StockCount
from shuup.simple_supplier.utils import (
    get_stock_adjustment_div, get_stock_information_html
)
from shuup.utils.excs import Problem

from shuup_multivendor.admin_module.form_parts.product import (
    VendorProductBaseFormPart, VendorProductImageMediaFormPart,
    VendorProductMediaFormPart, VendorShopProductFormPart
)
from shuup_multivendor.models import SupplierPrice
from shuup_multivendor.utils.cache import (
    bump_cheapest_supplier, bump_storefront_caches
)


class MultivendorProductPicotable(Picotable):
    def process_item(self, object):
        out = super(MultivendorProductPicotable, self).process_item(object)
        popup = self.request.GET.get("popup")
        kind = self.request.GET.get("kind", "")
        if popup and kind == "multivendor_product":  # Enable option to pick products
            out.update({"_id": object.product.id})
        return out


def get_stock_status_div(supplier, product):
    """
    Get the product stock status div for picotable column
    """
    stock_count = StockCount.objects.filter(product=product, supplier=supplier).first()
    context = {
        "product": product,
        "supplier": supplier,
        "stock_count": stock_count
    }
    return render_to_string("shuup_multivendor/admin/products/stock_status.jinja", context=context)


class InSaleFilter(ChoicesFilter):
    CHOICES = [
        (False, _("no")),
        (True, _("yes"))
    ]
    type = "choices"

    def __init__(self, filter_field=None, default=None):
        super(InSaleFilter, self).__init__(self.CHOICES)
        self.choices = self.CHOICES
        self.default = "_all"

    def filter_queryset(self, queryset, column, value, context):
        if value == "_all":
            return queryset

        if value:
            return queryset.filter(suppliers=get_supplier(context.request))

        return queryset.exclude(suppliers=get_supplier(context.request))


class ProductDeleteView(DetailView):
    model = ShopProduct
    context_object_name = "product"

    def get_queryset(self):
        return super(ProductDeleteView, self).get_queryset().filter(
            suppliers=get_supplier(self.request)
        )

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        return HttpResponseRedirect(
            reverse("shuup_admin:shuup_multivendor.products_edit", kwargs=dict(pk=self.object.pk)))

    def post(self, request, *args, **kwargs):
        product = self.get_object().product
        product.soft_delete(user=request.user)
        messages.success(request, _("%s has been marked deleted.") % product)
        return HttpResponseRedirect(reverse("shuup_admin:shuup_multivendor.products_list"))


class ProductListView(PicotableListView):
    template_name = "shuup_multivendor/admin/products/list.jinja"
    model = ShopProduct
    picotable_class = MultivendorProductPicotable
    default_columns = [
        Column(
            "primary_image",
            _("Primary Image"),
            display="get_primary_image",
            class_name="text-center",
            raw=True,
            ordering=1,
            sortable=False),
        Column(
            "name",
            _("Name"),
            sort_field="product__translations__name",
            display="product__name",
            filter_config=TextFilter(
                filter_field="product__translations__name",
                placeholder=_("Filter by name...")
            ),
            ordering=2),
        Column(
            "sku",
            _("SKU"),
            display="product__sku",
            filter_config=RangeFilter(filter_field="product__sku"),
            ordering=3),
        Column(
            "barcode",
            _("Barcode"),
            display="product__barcode",
            filter_config=TextFilter(placeholder=_("Filter by barcode...")),
            ordering=4),
        Column(
            "mode",
            _("Mode"),
            display="product__mode",
            filter_config=ChoicesFilter(ProductMode.choices),
            ordering=5),
        Column(
            "primary_category",
            _("Primary Category"),
            display=(lambda instance: instance.primary_category.name if instance.primary_category else None),
            filter_config=TextFilter(
                filter_field="primary_category__translations__name",
                placeholder=_("Filter by category name...")
            ),
            ordering=6),
        Column(
            "categories",
            _("Categories"),
            display="format_categories",
            filter_config=TextFilter(
                filter_field="categories__translations__name",
                placeholder=_("Filter by category name...")
            ),
            ordering=7
        ),
        Column("stock", _("Stock status"), display="format_stock", ordering=8, sortable=False)
    ]
    mass_actions = []

    related_objects = [
        ("product", "shuup.core.models:Product"),
    ]

    def __init__(self):
        super(ProductListView, self).__init__()
        if not settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
            self.columns = [
                Column(
                    "name",
                    _("Name"),
                    display="product__name",
                    class_name="d-none",
                    filter_config=TextFilter(
                        filter_field="product__translations__name",
                        placeholder=_("Filter by name...")
                    )
                ),
                Column(
                    "selling", _("Actions"), display="get_selling_button_and_price_display",
                    sortable=False, linked=True, raw=True
                ),
                Column(
                    "stock_information", _("Stock information"), display="get_stock_information",
                    linked=False, sortable=False, raw=True
                ),
                Column(
                    "adjust_stock", _("Adjust stock"), display="get_stock_adjustment_form",
                    sortable=False, linked=False, raw=True
                )
            ]
        if settings.VENDOR_CAN_SHARE_PRODUCTS and settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
            self.columns += [
                Column(
                    "in_sale",
                    _("In Sale"),
                    sortable=False,
                    display="get_in_sale_status",
                    filter_config=InSaleFilter()
                )
            ]

    def get_primary_image(self, instance):
        if instance.product.primary_image:
            thumbnail = instance.product.primary_image.get_thumbnail()
            if thumbnail:
                return "<img src='/media/{}'>".format(thumbnail)
        return "<img src='%s'>" % static("shuup_admin/img/no_image_thumbnail.png")

    def format_stock(self, instance):
        supplier = get_supplier(self.request)
        return get_stock_status_div(supplier, instance.product)

    def process_picotable(self, query_json):
        supplier = get_supplier(self.request)
        if supplier.module_identifier != "simple_supplier":
            self.columns = [column for column in self.columns if column.id != "adjust_stock"]

        if supplier.module_identifier != "":
            self.columns = [column for column in self.columns if column.id != "stock_information"]

        return super(ProductListView, self).process_picotable(query_json)

    def get_context_data(self, **kwargs):
        context = super(ProductListView, self).get_context_data(**kwargs)
        context["title"] = _("Vendor products")
        return context

    def get_toolbar(self):
        toolbar = Toolbar.for_view(self)
        if settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
            toolbar.append(
                URLActionButton(
                    url=reverse("shuup_admin:shuup_multivendor.products_new"),
                    text=_("New product"),
                    tooltip=_("Create new product."),
                    icon="fa fa-user-plus",
                    extra_css_class="btn-primary",
                    required_permissions=("shuup_multivendor.products_new",)
                )
            )
        return toolbar

    def get_object_abstract(self, instance, item):
        if not settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
            item.update({"_linked_in_mobile": False, "_url": ""})

        return [
            {"text": item.get("name"), "class": "header"},
        ]

    def _get_context(self, instance):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        in_sale = instance.suppliers.filter(id=supplier.pk).exists()
        if not in_sale:
            text = _("Start selling this product")
        else:
            text = _("Stop selling this product")

        price = SupplierPrice.objects.filter(shop=shop, supplier=supplier, product=instance.product).first()
        return {
            "text": text,
            "in_sale": in_sale,
            "instance": instance,
            "supplier": supplier,
            "price": price.amount_value if price else None,
            "custom_products_enabled": settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS,
            "vendors_can_share_products": settings.VENDOR_CAN_SHARE_PRODUCTS
        }

    def get_in_sale_status(self, instance):
        supplier = get_supplier(self.request)
        in_sale = instance.suppliers.filter(id=supplier.pk).exists()
        return _("Yes") if in_sale else _("No")

    def get_selling_button_and_price_display(self, instance):
        context = self._get_context(instance)
        return render_to_string("shuup_multivendor/admin/products/product.jinja", context=context, request=self.request)

    def get_stock_information(self, instance):
        supplier = get_supplier(self.request)
        return get_stock_information_html(supplier, instance.product)

    def get_stock_adjustment_form(self, instance):
        supplier = get_supplier(self.request)
        return get_stock_adjustment_div(self.request, supplier, instance.product)

    def get_queryset(self):
        filter = self.get_filter()
        shop = get_shop(self.request)
        qs = ShopProduct.objects.filter(product__deleted=False, shop=shop)
        q = Q()
        for mode in filter.get("modes", []):
            q |= Q(product__mode=mode)

        manufacturer_ids = filter.get("manufacturers")
        if manufacturer_ids:
            q |= Q(product__manufacturer_id__in=manufacturer_ids)

        qs = qs.filter(q).filter(product__mode__in=[ProductMode.NORMAL, ProductMode.VARIATION_CHILD])

        if not settings.VENDOR_CAN_SHARE_PRODUCTS:
            qs = qs.filter(suppliers=get_supplier(self.request))

        return qs

    def dispatch(self, request, *args, **kwargs):
        if not get_supplier(request):
            raise Problem(_("Supplier not detected. Are you a vendor?"))
        return super(ProductListView, self).dispatch(request, *args, **kwargs)

    def get_object_url(self, instance):
        if settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
            return reverse("shuup_admin:shuup_multivendor.products_edit", kwargs=dict(pk=instance.pk))


class ToggleSaleView(View):
    def post(self, request, *args, **kwargs):
        supplier = get_supplier(request)
        if not supplier and request.user.is_superuser:
            supplier = Supplier.objects.get(pk=int(request.POST.get("supplierId")))

        if not supplier:
            raise Http404()

        shop_product = ShopProduct.objects.get(pk=int(request.POST.get("productId")))

        is_in_sale = False
        if shop_product.suppliers.filter(pk=supplier.id).exists():
            shop_product.suppliers.remove(supplier)
        else:
            is_in_sale = True
            shop_product.suppliers.add(supplier)

        supplier.update_stock(shop_product.product.id)
        bump_cheapest_supplier(get_shop(request).pk, shop_product.product.pk)
        bump_storefront_caches(shop_product.shop)
        bump_prices_for_shop_product(shop_product)

        if shop_product.product.variation_parent:
            parent = shop_product.product.variation_parent
            parent_shop_product = parent.get_shop_instance(shop_product.shop)

            if parent_shop_product.suppliers.filter(pk=supplier.id).exists():
                parent_shop_product.suppliers.remove(supplier)
            else:
                parent_shop_product.suppliers.add(supplier)

        if request.is_ajax():
            return JsonResponse({"ok": True, "isInSale": is_in_sale})

        return HttpResponseRedirect(
            reverse("shuup_admin:shuup_multivendor.products_edit", kwargs=dict(pk=shop_product.pk)))


class SetPriceView(View):
    def post(self, request, *args, **kwargs):
        if request.user.is_superuser:
            supplier = Supplier.objects.get(pk=int(request.POST.get("supplierId")))
        else:
            supplier = get_supplier(request)

        shop_product = ShopProduct.objects.get(pk=int(request.POST.get("productId")))

        shop_product.suppliers.add(supplier)
        if shop_product.product.variation_parent:
            shop_product.product.variation_parent.get_shop_instance(shop_product.shop).suppliers.add(supplier)

        SupplierPrice.objects.update_or_create(
            shop=shop_product.shop, product=shop_product.product, supplier=supplier,
            defaults={"amount_value": decimal.Decimal(request.POST.get("price"))}
        )
        bump_cheapest_supplier(get_shop(request).pk, shop_product.product_id)
        context_cache.bump_cache_for_shop_product(shop_product)
        bump_storefront_caches(shop_product.shop)
        bump_prices_for_shop_product(shop_product)

        return JsonResponse({"ok": True})


class ProductEditView(BaseProductEditView):
    form_part_class_provide_key = "admin_vendor_product_form_part"
    base_form_part_classes = [
        VendorProductBaseFormPart,
        VendorShopProductFormPart,
        ProductAttributeFormPart,
        VendorProductImageMediaFormPart,
        VendorProductMediaFormPart
    ]

    def get_queryset(self):
        queryset = super(ProductEditView, self).get_queryset()
        if not settings.VENDOR_CAN_SHARE_PRODUCTS:
            queryset = queryset.filter(suppliers=get_supplier(self.request))
        return queryset

    def get_context_data(self, **kwargs):
        context = super(ProductEditView, self).get_context_data(**kwargs)
        orderability_errors = []
        shop_product = self.object

        if shop_product.pk:
            try:
                # override base orderability errors an pass the supplier too
                orderability_errors_iter = shop_product.get_orderability_errors(
                    supplier=get_supplier(self.request),
                    quantity=shop_product.minimum_purchase_quantity,
                    customer=None
                )
                orderability_errors.extend([msg.message for msg in orderability_errors_iter])
            except ObjectDoesNotExist:
                orderability_errors.append(_("Product is not available."))

        context["orderability_errors"] = orderability_errors
        return context

    def get_toolbar(self):
        if self.object.pk and not settings.VENDOR_CAN_SHARE_PRODUCTS:
            delete_url = reverse("shuup_admin:shuup_multivendor.products_delete", kwargs=dict(pk=self.object.pk))
        else:
            delete_url = None

        if self.object.pk and settings.VENDOR_CAN_SHARE_PRODUCTS:
            # TODO: requires permission to shop_product.list which can be only granted when products are shared
            toolbar = EditProductToolbar(view=self)
            in_sale = self.object.suppliers.filter(id=get_supplier(self.request).pk).exists()
            toolbar.append(
                PostActionButton(
                    post_url=reverse("shuup_admin:shuup_multivendor.products_toggles_sale"),
                    name="productId",
                    value=self.object.pk,
                    text=_("Stop selling this product") if in_sale else _("Start selling this product"),
                    extra_css_class="btn-danger" if in_sale else "btn-success",
                    required_permissions=("shuup_multivendor.products_toggles_sale",)
                )
            )
        else:
            toolbar = get_default_edit_toolbar(self, self.get_save_form_id(), delete_url=delete_url)

        return toolbar

    @atomic
    def form_valid(self, form):
        from shuup_multivendor.signals import vendor_product_pre_save
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        vendor_product_pre_save.send(
            sender=type(ShopProduct), request=self.request, shop=shop, supplier=supplier, instance=self.object)
        return super(ProductEditView, self).form_valid(form)

    def dispatch(self, request, *args, **kwargs):
        if not get_supplier(request):
            raise Problem(_("Supplier not detected. Are you a vendor?"))
        return super(ProductEditView, self).dispatch(request, *args, **kwargs)

    def get_success_url(self):
        next_url = self.request.POST.get("__next")
        if next_url == "return":
            return reverse("shuup_admin:shuup_multivendor.products_list")
        elif next_url == "new":
            return reverse("shuup_admin:shuup_multivendor.products_new")

        shop_product = self.object.get_shop_instance(get_shop(self.request), True)
        return reverse("shuup_admin:shuup_multivendor.products_edit", kwargs=dict(pk=shop_product.pk))
