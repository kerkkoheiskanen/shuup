# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from collections import defaultdict
from datetime import datetime

import pytz
from django import forms
from django.conf import settings
from django.templatetags.static import static
from django.utils.translation import ugettext_lazy as _
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.forms import TranslatableField
from shuup.xtheme.resources import add_resource


class SupplierOpeningPeriodsPlugin(TemplatedPlugin):
    identifier = "shuup_multivendor_opening_periods"
    name = _("Vendor Opening Periods To Product Detail")
    template_name = "shuup_multivendor/plugins/opening_periods.jinja"
    required_context_variables = ["supplier"]

    fields = [
        ("title", TranslatableField(
            label=_("Title"),
            required=False,
            initial=_("Opening periods:")
        )),
        ("timezones", forms.CharField(
            label=_("Timezones"),
            help_text=_("Extra timezone selections for the plugin. Separate timezones with semicolon."),
            required=False,
            initial=""
        ))
    ]

    def get_context_data(self, context):
        context = dict(context)
        supplier = context["supplier"]
        opening_periods = defaultdict(list)
        if not supplier.options:
            return {}

        if not supplier.options.get("opening_periods", []):
            return {}

        for period in supplier.options.get("opening_periods", []):
            opening_periods[period["day_of_week"].capitalize()].append("%s-%s" % (period["start"], period["end"]))

        timezones = self.config.get("timezones", None)
        return {
            "supplier_opening_periods_title": self.get_translated_value("title"),
            "supplier_opening_periods_timezones": (timezones.split(";") if timezones else []),
            "supplier_opening_periods_data": opening_periods,
            "supplier_opening_periods_data_offset": datetime.now(pytz.timezone(settings.TIME_ZONE)).strftime('%z')
        }

    def render(self, context):
        add_resource(context, "body_end", "%s?v=0.7.6.js" % static("shuup_multivendor/opening-periods.js"))
        return super(SupplierOpeningPeriodsPlugin, self).render(context)
