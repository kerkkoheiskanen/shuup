/* eslint no-underscore-dangle: "off" */
import m from "mithril";
import prop from "mithril/stream";
import Supercluster from "supercluster/dist/supercluster";

import MAP_STYLES from "./styles";
import MapInfoView from "./infoView";
import { getVendorDistance, getVendorCoords, updateCurrentLocationFilter, refreshFiltersInPlace } from "./utils";
import createVendorMarker from "./vendorMarket";


let MAP_INFO_WINDOW = null;
let CURRENT_USER_POSITION = null;


const Map = {
    _map: null,
    _markers: [],
    _cluster: null,
    _defaultMapZoom: 15,
    _renderSelectedVendor: null,
    _myLocationMarker: null,
    selectedVendor: null,
    _vendors: [],
    _center: {},
    _userLocation: { lat: 0, lng: 0 },

    init() {
        const {
            container,
            centerControl,
            renderSelectedVendor,
            mapStyle,
            currentLocationIcon,
            initialCenter,
            userLocation,
            vendors,
            oninit
        } = (arguments.length > 0 && arguments[0] !== undefined) ? arguments[0] : {};

        this._userLocation = userLocation;
        this._vendors = [];
        this._renderSelectedVendor = renderSelectedVendor;
        this._defaultMapZoom = window.VENDOR_MAP_SETTINGS.default_map_zoom;
        this._map = new window.google.maps.Map(container, {
            zoom: this._defaultMapZoom,
            minZoom: 5,
            maxZoom: 20,
            center: initialCenter,
            clickableIcons: false,
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: false,
            zoomControlOptions: {
                position: window.google.maps.ControlPosition.RIGHT_CENTER
            },
            mapTypeControlOptions: {
                mapTypeIds: ["roadmap", "satellite", "hybrid", "terrain", "styled_map"]
            }
        });

        // apply style
        if (mapStyle) {
            const styledMapType = new window.google.maps.StyledMapType(mapStyle, { name: "styled map" });
            this._map.mapTypes.set("styled_map", styledMapType);
            this._map.setMapTypeId("styled_map");
        }

        // add listeners to redraw
        // TODO: make this better to remove/add only changed vendors/markers
        this._map.addListener("dragend", this.renderVendors.bind(this));
        this._map.addListener("zoom_changed", this.renderVendors.bind(this));
        window.google.maps.event.addListenerOnce(this._map, "bounds_changed", this.renderVendors.bind(this));
        // on init
        window.google.maps.event.addListenerOnce(this._map, "tilesloaded", () => {
            if (oninit) {
                oninit();
            }
        });

        // create current position marker
        if (currentLocationIcon) {
            this._myLocationMarker = new window.google.maps.Marker({
                map: this._map,
                icon: currentLocationIcon,
                position: userLocation
            });
        }

        // add center control
        if (centerControl) {
            this._map.controls[window.google.maps.ControlPosition.RIGHT_CENTER].push(centerControl);
        }

        this.setCenter(initialCenter);
        this.setVendors(vendors);
        this.recalculateDistances();
    },

    getMap() {
        return this._map;
    },

    recalculateDistances() {
        let fromLocation = { lat: 0, lng: 0 };
        if (this._userLocation && this._userLocation.lat) {
            fromLocation = {
                latitude: this._userLocation.lat,
                longitude: this._userLocation.lng
            };
        }
        this._vendors.forEach((vendor) => {
            if (fromLocation.latitude) {
                vendor.distance = getVendorDistance(vendor, fromLocation);
            } else {
                vendor.distance = 0;
            }
        });

        this.renderSelectedVendor();
    },

    setVendors(vendors) {
        // filter only vendors with geoposition
        this._vendors = vendors.filter(vendor => (
            (vendor.contact_address && vendor.contact_address.latitude && vendor.contact_address.longitude)
        ))
        this._vendors.forEach((vendor) => {
            vendor.geometry = {
                type: "point",
                coordinates: [
                    parseFloat(vendor.contact_address.longitude),
                    parseFloat(vendor.contact_address.latitude)
                ]
            };
        });
        this.recalculateDistances();
    },

    clearMarkers() {
        // clear everything, for ever
        this._markers.forEach(marker => marker.setMap(null));
        this._markers = [];
    },

    renderVendors() {
        // remove all cluster markers from the map
        this._markers.filter(marker => marker.cluster).forEach(marker => marker.setMap(null));
        // remove all cluster markers from the list (destroy them)
        this._markers = this._markers.filter(marker => !marker.cluster);

        // deactivate all markers
        this._markers.forEach(marker => this.toggleMarkerActive(marker, false));
        this._cluster = this.getMarkerCluster();

        if (!this._cluster) {
            this.clearMarkers();
            return;
        }
        if (!this._map) {
            this.clearMarkers();
            return;
        }
        const bounds = this._map.getBounds();
        const vendors = this._cluster.getClusters([
            bounds.getSouthWest().lng(),
            bounds.getSouthWest().lat(),
            bounds.getNorthEast().lng(),
            bounds.getNorthEast().lat()
        ], this._map.getZoom());

        vendors.forEach((vendorData, idx) => {
            if (vendorData.properties && vendorData.properties.cluster) {
                this.renderMapMarkerForCluster(vendorData, idx);
            } else {
                this.renderMapMarkerForVendor(vendorData);
            }
        });

        this.renderSelectedVendor();
    },

    toggleMarkerActive(marker, active = true) {
        if (active && marker.getMap() !== this.getMap()) {
            marker.setMap(this.getMap());
        }
        marker.setOpacity(active ? 1 : 0);
    },

    getMarkerIcon() {
        if (!window.VENDOR_MAP_SETTINGS.custom_pin) return null;
        return {
            scaledSize: new window.google.maps.Size(40, 40),
            url: window.VENDOR_MAP_SETTINGS.custom_pin
        };
    },

    getMarkerCluster() {
        if (!this._vendors.length) {
            return null;
        }
        const cluster = new Supercluster({
            radius: 200,
            maxZoom: this._defaultMapZoom - 1
        });

        let vendors = this._vendors;
        // do not include the selected vendor on the cluester
        if (this.selectedVendor) {
            vendors = this._vendors.filter(vendor => vendor.id !== this.selectedVendor.id);
        }

        cluster.load(vendors);
        return cluster;
    },

    renderMapMarkerForCluster(cluster) {
        const marker = new window.google.maps.Marker({
            position: { lat: cluster.geometry.coordinates[1], lng: cluster.geometry.coordinates[0] },
            map: this._map,
            icon: {
                url: "/static/shuup_multivendor/img/clusterPin.png",
                scaledSize: new window.google.maps.Size(45, 45)
            },
            label: {
                text: cluster.properties.point_count_abbreviated + "",
                color: "#fff"
            }
        });
        marker.cluster = true;
        marker.setZIndex(-1);
        this._markers.push(marker);

        marker.addListener("click", () => {
            this._map.panTo({
                lat: cluster.geometry.coordinates[1],
                lng: cluster.geometry.coordinates[0]
            });
            this._map.setZoom(this._defaultMapZoom + 1);
            this.renderVendors();
        });
    },

    renderSelectedVendor() {
        if (this.selectedVendor) {
            // recheck if this vendor is still in the vendor list
            if (!this._vendors.find(vendor => vendor.id === this.selectedVendor.id)) {
                this.selectVendor(null);
                if (this._renderSelectedVendor) {
                    this._renderSelectedVendor(null);
                }
                return;
            }
        }

        const selectedVendorMarker = this.selectedVendor ? this.getVendorMarker(this.selectedVendor.id) : null;
        if (selectedVendorMarker) {
            this.toggleMarkerActive(selectedVendorMarker, true);
            this.selectVendor(this.selectedVendor);
        }

        if (this._renderSelectedVendor) {
            if (selectedVendorMarker && selectedVendorMarker.getOpacity() > 0) {
                this._renderSelectedVendor(this.selectedVendor, selectedVendorMarker);
                return;
            }

            this._renderSelectedVendor(null);
        }
    },

    getVendorMarker(vendorID) {
        return this._markers.find(marker => marker.vendor && marker.vendor.id === vendorID);
    },

    renderMapMarkerForVendor(vendor) {
        let marker = this.getVendorMarker(vendor.id);
        if (!marker) {
            marker = new createVendorMarker({
                vendor,
                position: {
                    lat: parseFloat(vendor.contact_address.latitude),
                    lng: parseFloat(vendor.contact_address.longitude)
                },
                icon: this.getMarkerIcon(),
                map: this._map,
                id: vendor.id
            });
            this._markers.push(marker);
            marker.vendor.id = vendor.id;

            marker.addListener("click", () => {
                this.selectVendor(vendor);

                if (this._renderSelectedVendor) {
                    this._renderSelectedVendor(this.selectedVendor, marker);
                }
            });
        }

        // show marker
        this.toggleMarkerActive(marker, true);
    },

    clearSelection() {
        this.selectVendor(null);
        this.renderVendors();
    },

    setCenter(centerPosition) {
        this._center = centerPosition;
    },

    setUserPosition(position) {
        this._userLocation = position;
        if (this._myLocationMarker) {
            this._myLocationMarker.setPosition(position);
        }
        this.recalculateDistances();
    },

    panToCenter() {
        this._map.panTo(this._center);
        this._map.setZoom(this._defaultMapZoom);
    },

    selectVendor(vendor) {
        if (this.selectedVendor && vendor && this.selectedVendor.id === vendor.id) {
            return;
        }

        const oldSelectedVendor = this.selectedVendor;
        this.selectedVendor = vendor;

        const oldSelectedMarker = oldSelectedVendor ? this.getVendorMarker(oldSelectedVendor.id) : null;
        if (oldSelectedMarker) {
            oldSelectedMarker.setZIndex(1);
        }

        if (this.selectedVendor) {
            const marker = this.getVendorMarker(vendor.id);
            if (marker) {
                marker.setZIndex(99999);

                this._map.panTo({
                    lat: parseFloat(vendor.contact_address.latitude),
                    lng: parseFloat(vendor.contact_address.longitude)
                });

                if (this._map.getZoom() < this._defaultMapZoom) {
                    this._map.setZoom(this._defaultMapZoom);
                }
                // make the pin be at the bottom of the map, so the info window can be displayed too
                // pan to bottom 20% of the actual div height
                this._map.panBy(0, -this._map.getDiv().getBoundingClientRect().height * 0.2);
            }
        }
    }
};
// expose to the world
window.VendorMap = Map;

const MapToggleButton = {
    view(vnode) {
        return (
            m(".form-group.browse-map-btn-content",
                m("label.control-label",
                    m("span.spacer", m.trust("&nbsp")),
                    m("span.map-label", gettext("Browse map"))
                ),
                m("button.btn.btn-primary.form-control", {
                    onclick(e) {
                        e.preventDefault();
                        vnode.attrs.onPress();
                    }
                }, m("i.fa.fa-map-marker"),
                    m("span.map-label", " ", vnode.attrs.toggled ? gettext("Show map") : gettext("Hide map")))
            )
        );
    }
};


function getCurrentPosition(vnode, forcePanToCenter = true) {
    navigator.geolocation.getCurrentPosition((position) => {
        CURRENT_USER_POSITION = [position.coords.latitude, position.coords.longitude];
        updateCurrentLocationFilter(position.coords.latitude, position.coords.longitude);
        const location = { lat: CURRENT_USER_POSITION[0], lng: CURRENT_USER_POSITION[1] };
        Map.setUserPosition(location);

        if (forcePanToCenter || !window.VENDOR_MAP_SETTINGS.current_vendor) {
            Map.setCenter(location);
            Map.panToCenter();
        }

        window.dispatchEvent(new CustomEvent("ShuupMultivendor.CurrentLocationUpdated", { detail: { location } }));
        vnode.state.renderPermissionDeniedWarning(false);
        m.redraw();

    }, (error) => {
        if (window.MULTIVENDOR_SETTINGS.customer_location) {
            const location = {
                lat: parseFloat(window.MULTIVENDOR_SETTINGS.customer_location.lat),
                lng: parseFloat(window.MULTIVENDOR_SETTINGS.customer_location.lng)
            };
            Map.setUserPosition(location);
            Map.setCenter(location);
            Map.panToCenter();
        }
        if (error.code === 1) {     // PERMISSION_DENIED
            vnode.state.renderPermissionDeniedWarning(true);
            m.redraw();
        }
    }, { maximumAge: (1000 * 60 * 5) });   // 5min
}

const MapView = {
    oninit(vnode) {
        vnode.state.collapsed = prop(window.VENDOR_MAP_SETTINGS.init_map_collapsed);
        vnode.state.renderPermissionDeniedWarning = prop(false);

        // refresh the filters to make sure the location is being used
        if (window.MULTIVENDOR_SETTINGS.customer_location && window.MULTIVENDOR_SETTINGS.customer_location.lat) {
            refreshFiltersInPlace();
        }
    },
    view(vnode) {
        let warningMessage = null;
        if (vnode.state.renderPermissionDeniedWarning()) {
            if (window.VENDOR_MAP_SETTINGS.user) {
                // user is logged in
                warningMessage = window.MULTIVENDOR_SETTINGS.customer_location ? window.VENDOR_MAP_SETTINGS.location_no_permission_msg : (
                    window.VENDOR_MAP_SETTINGS.location_no_permission_no_address_msg
                );
            } else {
                warningMessage = window.VENDOR_MAP_SETTINGS.location_no_permission_msg;
            }
        }
        return (
            m(".map-container",
                m("#map", {
                    style: {
                        width: "100%",
                        height: window.VENDOR_MAP_SETTINGS.map_height || "400px",
                        display: vnode.state.collapsed() ? "none" : "block"
                    }
                }),
                !!warningMessage && (
                    m(".alert.alert-warning.map-perm-warning", m.trust(warningMessage))
                )
            )
        );
    },

    renderSelectedVendor(vendor, marker) {
        if (!vendor || !marker) {
            $(".map-info-view-container").remove();
            if (MAP_INFO_WINDOW) {
                MAP_INFO_WINDOW.close();
            }
            return;
        }

        let infoView = $(".map-info-view-container")[0];
        if (!infoView) {
            infoView = document.createElement("div");
            infoView.className = "map-info-view-container";
        }

        m.render(infoView, m(MapInfoView, {
            vendor,
            showBrowseButton: true,
            onBrowsePress() {
                window.location = vendor.detail_url;
            }
        }));

        if (MAP_INFO_WINDOW) {
            MAP_INFO_WINDOW.setContent(infoView);
        } else {
            MAP_INFO_WINDOW = new window.google.maps.InfoWindow({
                content: infoView,
                maxWidth: 320,
                disableAutoPan: true
            });
        }
        MAP_INFO_WINDOW.vendorID = vendor.id;

        window.google.maps.event.addListenerOnce(MAP_INFO_WINDOW, "closeclick", () => {
            MAP_INFO_WINDOW = null;
            Map.clearSelection();
        });
        MAP_INFO_WINDOW.open(marker.getMap(), marker);
    },

    createCenterControl(vnode) {
        const centerControlDiv = document.createElement("div");
        const controlBtn = document.createElement("button");
        controlBtn.className = "btn btn-default map-center-control";
        controlBtn.style.width = "40px";
        controlBtn.style.height = "40px";
        controlBtn.style.marginRight = "10px";
        controlBtn.style.borderRadius = "2px";
        controlBtn.style.boxShadow = "0 1px 4px rgba(0,0,0,0.3)";
        controlBtn.style.cursor = "pointer";
        controlBtn.style.padding = "0px";
        controlBtn.addEventListener("click", () => {
            getCurrentPosition(vnode);
        });

        const controlIcon = document.createElement("i");
        controlIcon.className = "fa fa-location-arrow";
        controlIcon.style.fontSize = "1.2em";
        controlBtn.appendChild(controlIcon);

        centerControlDiv.appendChild(controlBtn);
        centerControlDiv.index = 3;
        return centerControlDiv;
    },

    oncreate(vnode) {
        const initialPosition = { lat: 0, lng: 0 };
        const userLocation = { lat: 0, lng: 0 };
        let selectedVendor = null;

        if (window.VENDOR_MAP_SETTINGS.search_address && window.VENDOR_MAP_SETTINGS.search_address.location) {
            const [lat, lng] = window.VENDOR_MAP_SETTINGS.search_address.location.split(",");
            userLocation.lat = parseFloat(lat);
            userLocation.lng = parseFloat(lng);

            if (!initialPosition.lat) {
                initialPosition.lat = userLocation.lat;
                initialPosition.lng = userLocation.lng;
            }
        }
        if (!initialPosition.lat && window.VENDOR_MAP_SETTINGS.current_vendor) {
            selectedVendor = vnode.attrs.vendors.find(v => v.id === window.VENDOR_MAP_SETTINGS.current_vendor);

            if (selectedVendor) {
                const coords = getVendorCoords(selectedVendor);
                initialPosition.lat = coords.latitude;
                initialPosition.lng = coords.longitude;
            }
        }
        if (!userLocation.lat && window.MULTIVENDOR_SETTINGS.customer_location) {
            userLocation.lat = parseFloat(window.MULTIVENDOR_SETTINGS.customer_location.lat);
            userLocation.lng = parseFloat(window.MULTIVENDOR_SETTINGS.customer_location.lng);

            if (!initialPosition.lat) {
                initialPosition.lat = userLocation.lat;
                initialPosition.lng = userLocation.lng;
            }
        }
        if (!initialPosition.lat && window.VENDOR_MAP_SETTINGS.initial_map_position) {
            const [lat, lng] = window.VENDOR_MAP_SETTINGS.initial_map_position.split(",");
            initialPosition.lat = parseFloat(lat.trim());
            initialPosition.lng = parseFloat(lng.trim());

            if (!userLocation.lat) {
                userLocation.lat = initialPosition.lat;
                userLocation.lng = initialPosition.lng;
            }
            window.dispatchEvent(
                new CustomEvent("ShuupMultivendor.CurrentLocationUpdated", { detail: { location: initialPosition } })
            );
            updateCurrentLocationFilter(initialPosition.lat, initialPosition.lng);
        }

        Map.init({
            container: $(vnode.dom).find("#map")[0],
            mapStyle: MAP_STYLES,
            centerControl: this.createCenterControl(vnode),
            renderSelectedVendor: this.renderSelectedVendor,
            vendors: vnode.attrs.vendors,
            userLocation,
            selectedVendor,
            initialCenter: initialPosition,
            currentLocationIcon: {
                path: window.google.maps.SymbolPath.CIRCLE,
                fillColor: "blue",
                fillOpacity: 1,
                scale: 5,
                strokeColor: "white",
                strokeWeight: 1
            },
            oninit() {
                if (selectedVendor) {
                    Map.selectVendor(selectedVendor);
                    Map.renderSelectedVendor();
                }
                if (!userLocation.lat || !initialPosition.lat) {
                    getCurrentPosition(vnode, false);
                }
                Map.renderVendors();
            }
        });

        this.setupCollapseToggle(vnode);
    },
    setupCollapseToggle(vnode) {
        // try to find a place to add a collapse toggle button to show/hide the map
        const $productListActions = $(".product-list-actions").first();
        if ($productListActions.length) {
            $productListActions.addClass("map-toggle-container");
            const mapToggleBtn = document.createElement("div");
            mapToggleBtn.className = "col-sm-3";
            $productListActions.children().removeClass("col-sm-4").addClass("col-sm-3");
            $productListActions.prepend(mapToggleBtn);
            m.mount(mapToggleBtn, {
                view() {
                    return m(MapToggleButton, {
                        toggled: vnode.state.collapsed(),
                        onPress() {
                            vnode.state.collapsed(!vnode.state.collapsed());
                        }
                    })
                }
            })
        }
    }
};

export default MapView;
