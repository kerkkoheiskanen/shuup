import m from "mithril";
import prop from "mithril/stream";

import "../../less/map.less";    // import styles
import MapView from "./view";

const rootElement = document.getElementById("vendor-map");

const VendorMap = {
    oninit(vnode) {
        vnode.state.vendors = prop([]);

        const vendorsUrl = rootElement.getAttribute("data-vendors-url");
        m.request({
            url: vendorsUrl,
            config: function(xhr) {
                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest")  // enables is_ajax in Django
              }
        }).then((response) => {
            vnode.state.vendors(response);
        }).catch((error) => console.error(error));
    },
    view(vnode) {
        if (!vnode.state.vendors().length) return null;

        return m(MapView, {
            vendors: vnode.state.vendors()
        });
    }
};

if (rootElement) {
    if (window.google && window.google.maps) {
        m.mount(rootElement, VendorMap);
    } else {
        window.addEventListener("ShuupMultivendor.GoogleMapsInited", () => {
            m.mount(rootElement, VendorMap);
        });
    }
}
