# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import six
from django.conf import settings
from django.db.transaction import atomic
from django.http.response import JsonResponse
from django.utils import translation

from shuup.core.models import Tax, TaxClass
from shuup.default_tax.models import TaxRule
from shuup_can_taxes.taxes import CANADA_TAX_MAPPING


class TaxImporter(object):
    def __init__(self):
        self.original_language = translation.get_language()
        self.country_code = "CA"
        identifier = settings.CAN_TAX_DEFAULT_TAX_IDENTIFIER
        self.tax_class, _ = TaxClass.objects.update_or_create(identifier=identifier, defaults={
            "name": "Product Sales Tax",
        })
        additional_ids = settings.CAN_TAX_ADDITIONAL_TAX_CLASS_IDENTIFIERS
        self.additional_tax_classes = list(TaxClass.objects.filter(identifier__in=additional_ids))

        translation.activate(settings.PARLER_DEFAULT_LANGUAGE_CODE)

    def ensure_tax(self, code, name, rate):
        tax = Tax.objects.filter(code=code).first()
        if not tax:
            tax = Tax.objects.create(code=code, rate=rate)
        tax.name = name
        tax.enabled = True
        tax.save()
        return tax

    @atomic
    def import_taxes(self):
        """
        Import Canadian taxes to Shuup

        :return: JSONResponse indicating the end result of this import
        """
        try:
            for title, data in six.iteritems(CANADA_TAX_MAPPING):
                for tax in data["taxes"]:
                    tax_label = tax["tax_label"]
                    code = "canada-%s-%s" % (data["id"], tax_label)
                    tax_obj = self.ensure_tax(code, tax_label, tax["rate"])

                    rule = TaxRule.objects.update_or_create(
                        country_codes_pattern=self.country_code,
                        region_codes_pattern=data["id"],
                        tax=tax_obj,
                        defaults={
                            "enabled": True
                        }
                    )[0]
                    rule.tax_classes.set(self.additional_tax_classes + [self.tax_class])
            return JsonResponse({"success": "OK!"})
        except Exception:
            from raven.contrib.django.raven_compat.models import client
            client.captureException()
            return JsonResponse({"success": False}, status=400)
        finally:
            translation.activate(self.original_language)
