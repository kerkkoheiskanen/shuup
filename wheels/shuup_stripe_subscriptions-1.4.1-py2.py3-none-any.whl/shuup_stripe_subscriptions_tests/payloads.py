# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

import stripe

CUSTOMER_CREATED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "cus_A2mkCFg5C2dJAG",
            "object": "customer",
            "account_balance": 0,
            "created": 1486028821,
            "currency": None,
            "default_source": "card_19ihB2GhH6U1U9uLoS59uxnb",
            "delinquent": False,
            "description": "Customer for card@example.com",
            "discount": None,
            "email": "admin@example.com",
            "livemode": False,
            "metadata": {},
            "shipping": None,
            "sources": {
                "object": "list",
                "data": [
                    {
                        "id": "card_19ihB2GhH6U1U9uLoS59uxnb",
                        "object": "card",
                        "address_city": None,
                        "address_country": None,
                        "address_line1": None,
                        "address_line1_check": None,
                        "address_line2": None,
                        "address_state": None,
                        "address_zip": None,
                        "address_zip_check": None,
                        "brand": "Visa",
                        "country": "US",
                        "customer": "cus_A2mkCFg5C2dJAG",
                        "cvc_check": "pass",
                        "dynamic_last4": None,
                        "exp_month": 12,
                        "exp_year": 2019,
                        "fingerprint": "NQWb1Qyl1923sEiH",
                        "funding": "credit",
                        "last4": "4242",
                        "metadata": {},
                        "name": "card@example.com",
                        "tokenization_method": None
                    }
                ],
                "has_more": False,
                "total_count": 1,
                "url": "/v1/customers/cus_A2mkCFg5C2dJAG/sources"
            },
            "subscriptions": {
                "object": "list",
                "data": [],
                "has_more": False,
                "total_count": 0,
                "url": "/v1/customers/cus_A2mkCFg5C2dJAG/subscriptions"
            }
        },
    },
    "id": "evt_asdf",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "customer.created"
}

CUSTOMER_SOURCE_CREATED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "card_19ihB2GhH6U1U9uLoS59uxnb",
            "object": "card",
            "address_city": None,
            "address_country": None,
            "address_line1": None,
            "address_line1_check": None,
            "address_line2": None,
            "address_state": None,
            "address_zip": None,
            "address_zip_check": None,
            "brand": "Visa",
            "country": "US",
            "customer": "cus_A2mkCFg5C2dJAG",
            "cvc_check": "pass",
            "dynamic_last4": None,
            "exp_month": 12,
            "exp_year": 2019,
            "fingerprint": "NQWb1Qyl1923sEiH",
            "funding": "credit",
            "last4": "4242",
            "metadata": {},
            "name": "card@example.com",
            "tokenization_method": None
        },
    },
    "id": "evt_asdf123",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "customer.source.created"
}

PLAN_CREATED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "5",
            "object": "plan",
            "amount": 499,
            "created": 1486028824,
            "currency": "eur",
            "interval": "month",
            "interval_count": 1,
            "livemode": False,
            "metadata": {},
            "name": "Partavuosikerta - 4,99 / month",
            "statement_descriptor": None,
            "trial_period_days": None
        },
    },
    "id": "evt_123123",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "plan.created"
}

CUSTOMER_UPDATED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "cus_A2mkCFg5C2dJAG",
            "object": "customer",
            "account_balance": 0,
            "created": 1486028821,
            "currency": "eur",
            "default_source": "card_19ihB2GhH6U1U9uLoS59uxnb",
            "delinquent": False,
            "description": "Customer for card@example.com",
            "discount": None,
            "email": "admin@example.com",
            "livemode": False,
            "metadata": {},
            "shipping": None,
            "sources": {
                "object": "list",
                "data": [
                    {
                        "id": "card_19ihB2GhH6U1U9uLoS59uxnb",
                        "object": "card",
                        "address_city": None,
                        "address_country": None,
                        "address_line1": None,
                        "address_line1_check": None,
                        "address_line2": None,
                        "address_state": None,
                        "address_zip": None,
                        "address_zip_check": None,
                        "brand": "Visa",
                        "country": "US",
                        "customer": "cus_A2mkCFg5C2dJAG",
                        "cvc_check": "pass",
                        "dynamic_last4": None,
                        "exp_month": 12,
                        "exp_year": 2019,
                        "fingerprint": "NQWb1Qyl1923sEiH",
                        "funding": "credit",
                        "last4": "4242",
                        "metadata": {},
                        "name": "card@example.com",
                        "tokenization_method": None
                    }
                ],
                "has_more": False,
                "total_count": 1,
                "url": "/v1/customers/cus_A2mkCFg5C2dJAG/sources"
            },
            "subscriptions": {
                "object": "list",
                "data": [
                    {
                        "id": "sub_A2mkMZHRppnRUS",
                        "object": "subscription",
                        "application_fee_percent": None,
                        "cancel_at_period_end": False,
                        "canceled_at": None,
                        "created": 1486028826,
                        "current_period_end": 1488448026,
                        "current_period_start": 1486028826,
                        "customer": "cus_A2mkCFg5C2dJAG",
                        "discount": None,
                        "ended_at": None,
                        "items": {
                            "object": "list",
                            "data": [
                                {
                                    "id": "si_19ihBGGhH6U1U9uLctJBJL9C",
                                    "object": "subscription_item",
                                    "created": 1486028827,
                                    "plan": {
                                        "id": "5",
                                        "object": "plan",
                                        "amount": 499,
                                        "created": 1486028824,
                                        "currency": "eur",
                                        "interval": "month",
                                        "interval_count": 1,
                                        "livemode": False,
                                        "metadata": {},
                                        "name": "Partavuosikerta - 4,99 / month",
                                        "statement_descriptor": None,
                                        "trial_period_days": None
                                    },
                                    "quantity": 1
                                }
                            ],
                            "has_more": False,
                            "total_count": 1,
                            "url": "/v1/subscription_items?subscription=sub_A2mkMZHRppnRUS"
                        },
                        "livemode": False,
                        "metadata": {},
                        "plan": {
                            "id": "5",
                            "object": "plan",
                            "amount": 499,
                            "created": 1486028824,
                            "currency": "eur",
                            "interval": "month",
                            "interval_count": 1,
                            "livemode": False,
                            "metadata": {},
                            "name": "Partavuosikerta - 4,99 / month",
                            "statement_descriptor": None,
                            "trial_period_days": None
                        },
                        "quantity": 1,
                        "start": 1486028826,
                        "status": "active",
                        "tax_percent": None,
                        "trial_end": None,
                        "trial_start": None
                    }
                ],
                "has_more": False,
                "total_count": 1,
                "url": "/v1/customers/cus_A2mkCFg5C2dJAG/subscriptions"
            }
        },
    },
    "previous_attributes": {
        "currency": None
    },
    "id": "evt_1999912",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "customer.updated"
}

CHARGE_SUCCEEDED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "ch_19ihBHGhH6U1U9uLAl7zX7gP",
            "object": "charge",
            "amount": 499,
            "amount_refunded": 0,
            "application": None,
            "application_fee": None,
            "balance_transaction": "txn_19ihBHGhH6U1U9uL5Cs5N3mj",
            "captured": True,
            "created": 1486028827,
            "currency": "eur",
            "customer": "cus_A2mkCFg5C2dJAG",
            "description": None,
            "destination": None,
            "dispute": None,
            "failure_code": None,
            "failure_message": None,
            "fraud_details": {},
            "invoice": "in_19ihBGGhH6U1U9uLF40iwj87",
            "livemode": False,
            "metadata": {},
            "order": None,
            "outcome": {
                "network_status": "approved_by_network",
                "reason": None,
                "risk_level": "normal",
                "seller_message": "Payment complete.",
                "type": "authorized"
            },
            "paid": True,
            "receipt_email": None,
            "receipt_number": None,
            "refunded": False,
            "refunds": {
                "object": "list",
                "data": [],
                "has_more": False,
                "total_count": 0,
                "url": "/v1/charges/ch_19ihBHGhH6U1U9uLAl7zX7gP/refunds"
            },
            "review": None,
            "shipping": None,
            "source": {
                "id": "card_19ihB2GhH6U1U9uLoS59uxnb",
                "object": "card",
                "address_city": None,
                "address_country": None,
                "address_line1": None,
                "address_line1_check": None,
                "address_line2": None,
                "address_state": None,
                "address_zip": None,
                "address_zip_check": None,
                "brand": "Visa",
                "country": "US",
                "customer": "cus_A2mkCFg5C2dJAG",
                "cvc_check": "pass",
                "dynamic_last4": None,
                "exp_month": 12,
                "exp_year": 2019,
                "fingerprint": "NQWb1Qyl1923sEiH",
                "funding": "credit",
                "last4": "4242",
                "metadata": {},
                "name": "card@example.com",
                "tokenization_method": None
            },
            "source_transfer": None,
            "statement_descriptor": None,
            "status": "succeeded",
            "transfer_group": None
        },
    },
    "id": "evt_11351",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "charge.succeeded"
}

INVOICE_CREATED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "in_19ihBGGhH6U1U9uLF40iwj87",
            "object": "invoice",
            "amount_due": 499,
            "application_fee": None,
            "attempt_count": 1,
            "attempted": True,
            "charge": "ch_19ihBHGhH6U1U9uLAl7zX7gP",
            "closed": True,
            "currency": "eur",
            "customer": "cus_A2mkCFg5C2dJAG",
            "date": 1486028826,
            "description": None,
            "discount": None,
            "ending_balance": 0,
            "forgiven": False,
            "lines": {
                "object": "list",
                "data": [
                    {
                        "id": "sub_A2mkMZHRppnRUS",
                        "object": "line_item",
                        "amount": 499,
                        "currency": "eur",
                        "description": None,
                        "discountable": True,
                        "livemode": False,
                        "metadata": {},
                        "period": {
                            "start": 1486028826,
                            "end": 1488448026
                        },
                        "plan": {
                            "id": "5",
                            "object": "plan",
                            "amount": 499,
                            "created": 1486028824,
                            "currency": "eur",
                            "interval": "month",
                            "interval_count": 1,
                            "livemode": False,
                            "metadata": {},
                            "name": "Partavuosikerta - 4,99 / month",
                            "statement_descriptor": None,
                            "trial_period_days": None
                        },
                        "proration": False,
                        "quantity": 1,
                        "subscription": None,
                        "subscription_item": "si_19ihBGGhH6U1U9uLctJBJL9C",
                        "type": "subscription"
                    }
                ],
                "has_more": False,
                "total_count": 1,
                "url": "/v1/invoices/in_19ihBGGhH6U1U9uLF40iwj87/lines"
            },
            "livemode": False,
            "metadata": {},
            "next_payment_attempt": None,
            "paid": True,
            "period_end": 1486028826,
            "period_start": 1486028826,
            "receipt_number": None,
            "starting_balance": 0,
            "statement_descriptor": None,
            "subscription": "sub_A2mkMZHRppnRUS",
            "subtotal": 499,
            "tax": None,
            "tax_percent": None,
            "total": 499,
            "webhooks_delivered_at": None
        },
    },
    "id": "evt_19kAEyDuYw8C",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "invoice.created"
}

INVOICE_PAYMENT_SUCCEEDED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "in_19ihBGGhH6U1U9uLF40iwj87",
            "object": "invoice",
            "amount_due": 499,
            "application_fee": None,
            "attempt_count": 1,
            "attempted": True,
            "charge": "ch_19ihBHGhH6U1U9uLAl7zX7gP",
            "closed": True,
            "currency": "eur",
            "customer": "cus_A2mkCFg5C2dJAG",
            "date": 1486028826,
            "description": None,
            "discount": None,
            "ending_balance": 0,
            "forgiven": False,
            "lines": {
                "object": "list",
                "data": [
                    {
                        "id": "sub_A2mkMZHRppnRUS",
                        "object": "line_item",
                        "amount": 499,
                        "currency": "eur",
                        "description": None,
                        "discountable": True,
                        "livemode": False,
                        "metadata": {},
                        "period": {
                            "start": 1486028826,
                            "end": 1488448026
                        },
                        "plan": {
                            "id": "5",
                            "object": "plan",
                            "amount": 499,
                            "created": 1486028824,
                            "currency": "eur",
                            "interval": "month",
                            "interval_count": 1,
                            "livemode": False,
                            "metadata": {},
                            "name": "Partavuosikerta - 4,99 / month",
                            "statement_descriptor": None,
                            "trial_period_days": None
                        },
                        "proration": False,
                        "quantity": 1,
                        "subscription": None,
                        "subscription_item": "si_19ihBGGhH6U1U9uLctJBJL9C",
                        "type": "subscription"
                    }
                ],
                "has_more": False,
                "total_count": 1,
                "url": "/v1/invoices/in_19ihBGGhH6U1U9uLF40iwj87/lines"
            },
            "livemode": False,
            "metadata": {},
            "next_payment_attempt": None,
            "paid": True,
            "period_end": 1486028826,
            "period_start": 1486028826,
            "receipt_number": None,
            "starting_balance": 0,
            "statement_descriptor": None,
            "subscription": "sub_A2mkMZHRppnRUS",
            "subtotal": 499,
            "tax": None,
            "tax_percent": None,
            "total": 499,
            "webhooks_delivered_at": None
        },
    },
    "id": "evt_sdfoaihp",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "invoice.payment.succeeded"
}

CUSTOMER_SUBSCRIPTION_CREATED = {
    "api_version": "2017-01-27",
    "created": 1486378812,
    "data": {
        "object": {
            "id": "sub_A2mkMZHRppnRUS",
            "object": "subscription",
            "application_fee_percent": None,
            "cancel_at_period_end": False,
            "canceled_at": None,
            "created": 1486028826,
            "current_period_end": 1488448026,
            "current_period_start": 1486028826,
            "customer": "cus_A2mkCFg5C2dJAG",
            "discount": None,
            "ended_at": None,
            "items": {
                "object": "list",
                "data": [
                    {
                        "id": "si_19ihBGGhH6U1U9uLctJBJL9C",
                        "object": "subscription_item",
                        "created": 1486028827,
                        "plan": {
                            "id": "5",
                            "object": "plan",
                            "amount": 499,
                            "created": 1486028824,
                            "currency": "eur",
                            "interval": "month",
                            "interval_count": 1,
                            "livemode": False,
                            "metadata": {},
                            "name": "Partavuosikerta - 4,99 / month",
                            "statement_descriptor": None,
                            "trial_period_days": None
                        },
                        "quantity": 1
                    }
                ],
                "has_more": False,
                "total_count": 1,
                "url": "/v1/subscription_items?subscription=sub_A2mkMZHRppnRUS"
            },
            "livemode": False,
            "metadata": {},
            "plan": {
                "id": "5",
                "object": "plan",
                "amount": 499,
                "created": 1486028824,
                "currency": "eur",
                "interval": "month",
                "interval_count": 1,
                "livemode": False,
                "metadata": {},
                "name": "Partavuosikerta - 4,99 / month",
                "statement_descriptor": None,
                "trial_period_days": None
            },
            "quantity": 1,
            "start": 1486028826,
            "status": "active",
            "tax_percent": None,
            "trial_end": None,
            "trial_start": None
        },
    },
    "id": "evt_1233332122",
    "livemode": False,
    "object": "event",
    "pending_webhooks": 0,
    "request": "req_A4Ip8Zd7JvEtO9",
    "type": "customer.subscription.created"
}

# todo: Use this
INVOICE_PAYMENT_SUCCEEDED_FREE_TRIAL = {
  "id": "evt_1C0xPWHegfX1daYdrolUwTa0",
  "object": "event",
  "api_version": "2018-02-06",
  "created": 1519933790,
  "data": {
    "object": {
      "id": "in_1C0xPVHegfX1daYdK2Zw8KRO",
      "object": "invoice",
      "amount_due": 0,
      "amount_paid": 0,
      "amount_remaining": 0,
      "application_fee": None,
      "attempt_count": 0,
      "attempted": True,
      "billing": "charge_automatically",
      "charge": None,
      "closed": True,
      "currency": "usd",
      "customer": "cus_CPmzMKUYsC8vh1",
      "date": 1519933789,
      "description": None,
      "discount": None,
      "due_date": None,
      "ending_balance": 0,
      "forgiven": False,
      "lines": {
        "object": "list",
        "data": [
          {
            "id": "sub_CPmzba3DTh3e5N",
            "object": "line_item",
            "amount": 0,
            "currency": "usd",
            "description": "Trial period for Plan-199Mo-Pet-Store-1 - $199/mo",
            "discountable": True,
            "livemode": False,
            "metadata": {
            },
            "period": {
              "start": 1519933789,
              "end": 1522612188
            },
            "plan": {
              "id": "199000000000-12",
              "object": "plan",
              "amount": 19900,
              "created": 1519933789,
              "currency": "usd",
              "interval": "month",
              "interval_count": 1,
              "livemode": False,
              "metadata": {
              },
              "nickname": None,
              "product": "87",
              "trial_period_days": None
            },
            "proration": False,
            "quantity": 1,
            "subscription": None,
            "subscription_item": "si_CPmztl0dDJ6Qu6",
            "type": "subscription"
          }
        ],
        "has_more": False,
        "total_count": 1,
        "url": "/v1/invoices/in_1C0xPVHegfX1daYdK2Zw8KRO/lines"
      },
      "livemode": False,
      "metadata": {
      },
      "next_payment_attempt": None,
      "number": "A9B5826-0001",
      "paid": True,
      "period_end": 1519933789,
      "period_start": 1519933789,
      "receipt_number": None,
      "starting_balance": 0,
      "statement_descriptor": None,
      "subscription": "sub_CPmzba3DTh3e5N",
      "subtotal": 0,
      "tax": None,
      "tax_percent": None,
      "total": 0,
      "webhooks_delivered_at": None
    }
  },
  "livemode": False,
  "pending_webhooks": 1,
  "request": {
    "id": "req_PdyvbPbCWZo473",
    "idempotency_key": None
  },
  "type": "invoice.payment_succeeded"
}


class SubscriptionFlow(object):
    def __init__(self, api_key=None):
        self.api_key = api_key

    def get_events(self):
        for data in self.event_data:
            event = stripe.Event.construct_from(data, self.api_key)
            yield event


class NewUserSubscriptionFlow(SubscriptionFlow):
    event_data = [
        CUSTOMER_CREATED,
        CUSTOMER_SOURCE_CREATED,
        PLAN_CREATED,
        CUSTOMER_UPDATED,
        CHARGE_SUCCEEDED,
        INVOICE_CREATED,
        INVOICE_PAYMENT_SUCCEEDED,
        CUSTOMER_SUBSCRIPTION_CREATED,
    ]
