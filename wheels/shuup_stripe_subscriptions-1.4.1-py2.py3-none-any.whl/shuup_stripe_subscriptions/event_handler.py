# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from datetime import datetime

import stripe
from django.utils import timezone
from shuup.core.pricing import TaxfulPrice

from .enums import EventHandlerResultCode, InvoiceLineType, InvoiceStatus
from .models import Invoice, InvoiceLine, StripeSubscription
from .utils import stripe_amount_to_money


"""
https://www.masteringmodernpayments.com/stripe-webhook-event-cheatsheet
8. Create a customer with a plan without a trial

Customer and subscriptions are where Stripe's webhook
system really starts to shine. All of these events
happen more or less simultaneously when you create a
customer object and include the ``plan_id`` and card attributes.

* customer.created (Customer)
* customer.source.created (Source)
* customer.subscription.created (Subscription)
----------------------------------------------
* invoice.created (Invoice)
* invoice.payment_succeeded (Invoice)
* charge.succeeded (Charge)
"""


def handle_event(event):
    """
    Handle a Stripe event.

    :type event: stripe.Event
    :rtype: EventHandlerResult
    """
    handler = EventHandler()
    return handler.handle_event(event)


class EventHandlerResult(object):
    def __init__(self, code, message):
        assert isinstance(code, EventHandlerResultCode)
        self.code = code
        self.message = message

    @classmethod
    def handled(cls, message):
        return cls(EventHandlerResultCode.handled, message)

    @classmethod
    def ignored(cls, message):
        return cls(EventHandlerResultCode.ignored, message)

    def __repr__(self):
        return '<{}: {}:{}>'.format(
            type(self).__name__, self.code.value, self.message)


class EventHandler(object):
    def handle_event(self, event):
        try:
            assert isinstance(event, stripe.Event)
            assert event.object == 'event'
            self.object = event.data.object
            if event.id == 'evt_00000000000000':
                return EventHandlerResult.ignored(
                    "Test event received successfully")
            event_handler = self._get_event_handler(event)
            if event_handler:
                return event_handler(event)
            return EventHandlerResult.ignored("Unhandled event type: {event_type}".format(event_type=event.type))
        except Exception as e:
            return EventHandlerResult.ignored("Unhandled exception %s" % str(e))

    def _get_event_handler(self, event):
        event_type = 'handle_{}'.format(event.type.replace('.', '_'))
        if hasattr(self, event_type):
            func = getattr(self, event_type)
            if func and callable(func):
                return func
        return None

    def _create_invoice(self, stripe_invoice):
        invoicing_date = convert_to_datetime(stripe_invoice.date)
        period_start = convert_to_datetime(stripe_invoice.period_start)
        period_end = convert_to_datetime(stripe_invoice.period_end)

        subs_ext_id = stripe_invoice.subscription
        if not subs_ext_id:
            return EventHandlerResult.ignored("Non-subscription invoice")
        stripe_subscription = StripeSubscription.get_for_stripe_id(subs_ext_id)
        if not stripe_subscription:
            return EventHandlerResult.ignored("Unknown subscription")

        invoice_data = {
            "subscription": stripe_subscription.subscription,
            "invoicing_date": invoicing_date,
            "start_date": period_start,
            "end_date": period_end,
            "currency": stripe_invoice.currency.upper(),
        }

        (invoice, created) = Invoice.objects.get_or_create(
            external_id=stripe_invoice.id, defaults=invoice_data)

        if not created:
            return EventHandlerResult.ignored("Invoice already exists")

        for stripe_line in stripe_invoice.lines:
            assert isinstance(stripe_line, stripe.StripeObject)
            InvoiceLine.objects.create(
                external_id=stripe_line.id,
                invoice=invoice,
                amount=TaxfulPrice(stripe_amount_to_money(stripe_line)),
                type=InvoiceLineType.NORMAL
            )
        return invoice

    def handle_invoice_payment_succeeded(self, event):
        return self.create_invoice_and_subscription_payment(event.data.object)

    def create_invoice_and_subscription_payment(self, stripe_invoice):
        """
        Create an invoice and a subscription payment.

        :type stripe_invoice: stripe.Invoice
        :rtype: EventHandlerResult
        """
        invoice_or_handler_result = self._create_invoice(stripe_invoice)
        if not isinstance(invoice_or_handler_result, Invoice):
            return invoice_or_handler_result

        # trial payments has null value on charge, and because `payment_identifier` unique, do this
        payment_key = 'Stripe-{}'.format(stripe_invoice.charge or stripe_invoice.id)
        payment = invoice_or_handler_result.subscription.payments.filter(
            payment_identifier=payment_key).first()
        if not payment:
            payment = invoice_or_handler_result.subscription.create_payment(
                stripe_amount_to_money(stripe_invoice, 'total'),
                payment_identifier=payment_key,
                description="Stripe Subscription Charge")
            extra_info = " with payment {}".format(payment.pk)
        else:
            extra_info = ''

        if stripe_invoice.amount_due <= 0:
            # Set charged as nothing is due
            invoice_or_handler_result.status = InvoiceStatus.CHARGED
            invoice_or_handler_result.save()

        return EventHandlerResult.handled(
            "Created invoice {invoice_id}{extra_info}".format(
                invoice_id=invoice_or_handler_result.pk, extra_info=extra_info))


def convert_to_datetime(timestamp):
    return datetime.fromtimestamp(timestamp, timezone.utc)
