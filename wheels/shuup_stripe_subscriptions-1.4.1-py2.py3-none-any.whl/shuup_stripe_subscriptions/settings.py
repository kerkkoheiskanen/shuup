# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import environ

env = environ.Env(DEBUG=(bool, False))

# Either 2015 or 2018
STRIPE_SUBSCRIPTIONS_API_VERSION = env('STRIPE_SUBSCRIPTIONS_API_VERSION', default='2015')
