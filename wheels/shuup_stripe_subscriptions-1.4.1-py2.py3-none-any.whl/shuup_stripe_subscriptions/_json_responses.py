# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.http import (
    HttpResponseBadRequest, HttpResponseNotFound, JsonResponse)


class JsonErrorResponse(JsonResponse):
    def __init__(self, error_message):
        super(JsonErrorResponse, self).__init__({'error': error_message})


class BadRequest(JsonErrorResponse, HttpResponseBadRequest):
    pass


class NotFound(JsonErrorResponse, HttpResponseNotFound):
    pass
