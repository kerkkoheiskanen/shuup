# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from __future__ import unicode_literals

from django.db import models
from shuup.core.models import Contact
from shuup_subscriptions.models import Plan, Subscription

from .base import StripedModel


class StripePlan(StripedModel):
    plan = models.ForeignKey(Plan, related_name="stripe_profiles")


class StripeCustomer(StripedModel):
    customer = models.ForeignKey(Contact, related_name="stripe_profiles", null=True, blank=True)


class StripeSubscription(StripedModel):
    subscription = models.ForeignKey(Subscription, related_name="stripe_profiles")


class StripeCustomerSubscription(models.Model):
    stripe_subscription = models.ForeignKey(StripeSubscription)
    stripe_customer = models.ForeignKey(StripeCustomer)
