"""
    The amount of tax calculated depends on many factors, including the destination
    of the shipment and the type of item purchased. All items shipped to
    destinations in Canada are subject to Canadian Goods and Services Tax ("GST") at 5%.
    In addition, the following Provincial Sales Tax ("PST") or Harmonized Sales Tax ("HST") might apply,
    depending on the item and the destination of the shipment:

    New Brunswick, Newfoundland, Nova Scotia and Prince Edward Island: HST at 15% (including GST portion)
    Ontario: HST at 13% (including GST portion)
    British Columbia: Provincial Sales Tax ("PST") at 7%
    Saskatchewan: Provincial Sales Tax ("PST") at 6%
    Quebec: Quebec Sales Tax ("QST") at 9.975%
    Manitoba: Retail Sales Tax ("RTS") at 8%
"""

CANADA_TAX_MAPPING = {
    "Alberta": {
        "id": "AB",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
        ]
    },
    "British Columbia": {
        "id": "BC",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
            {"tax_label": "PST", "rate": 0.07, "full_name": "Provincial Sales Tax"},
        ]
    },
    "Manitoba": {
        "id": "MB",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
            {"tax_label": "RTS", "rate": 0.08, "full_name": "Retail Sales Tax"},
        ]
    },
    "New Brunswick": {
        "id": "NB",
        "taxes": [
            {"tax_label": "HST", "rate": 0.15, "full_name": "Harmonized Sales Tax"},  # includes GST
        ]
    },
    "Newfoundland and Labrador": {
        "id": "NL",
        "taxes": [
            {"tax_label": "HST", "rate": 0.15, "full_name": "Harmonized Sales Tax"},  # includes GST
        ]
    },
    "Northwest Territories": {
        "id": "NT",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
            {"tax_label": "PST", "rate": 0.07, "full_name": "Provincial Sales Tax"},
        ]
    },
    "Nova Scotia": {
        "id": "NS",
        "taxes": [
            {"tax_label": "HST", "rate": 0.15, "full_name": "Harmonized Sales Tax"},  # includes GST
        ]
    },
    "Nunavut": {
        "id": "BC",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
            {"tax_label": "PST", "rate": 0.07, "full_name": "Provincial Sales Tax"},
        ]
    },
    "Ontario": {
        "id": "NU",
        "taxes": [
            {"tax_label": "HST", "rate": 0.13, "full_name": "Harmonized Sales Tax"},  # includes GST
        ]
    },
    "Prince Edward Island": {
        "id": "PE",
        "taxes": [
            {"tax_label": "HST", "rate": 0.15, "full_name": "Harmonized Sales Tax"},  # includes GST
        ]
    },
    "Quebec": {
        "id": "QC",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
            {"tax_label": "QST", "rate": 0.09975, "full_name": "Quebec Sales Tax"},
        ]
    },
    "Saskatchewan": {
        "id": "SK",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
            {"tax_label": "PST", "rate": 0.06, "full_name": "Provincial Sales Tax"},
        ]
    },
    "Yukon": {
        "id": "YT",
        "taxes": [
            {"tax_label": "GST", "rate": 0.05, "full_name": "Goods and Services Tax"},
        ]
    }
}
