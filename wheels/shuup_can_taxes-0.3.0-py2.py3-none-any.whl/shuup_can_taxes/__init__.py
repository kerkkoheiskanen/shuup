# -​*- coding: utf-8 -*​-
default_app_config = __name__ + ".apps.AppConfig"
