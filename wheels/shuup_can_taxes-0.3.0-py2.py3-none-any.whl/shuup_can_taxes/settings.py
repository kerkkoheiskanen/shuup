# -*- coding: utf-8 -*-

# The tax class identifier to be used by default default
CAN_TAX_DEFAULT_TAX_IDENTIFIER = 'default'

# Additional tax classes to be used in the tax rules
CAN_TAX_ADDITIONAL_TAX_CLASS_IDENTIFIERS = []
