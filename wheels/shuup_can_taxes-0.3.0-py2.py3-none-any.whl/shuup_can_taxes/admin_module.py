# -​*- coding: utf-8 -*​-
from __future__ import unicode_literals

from django import forms
from django.contrib import messages
from django.http.response import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic.edit import FormView

from shuup import configuration
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import SETTINGS_MENU_CATEGORY
from shuup.admin.toolbar import get_default_edit_toolbar
from shuup.admin.utils.permissions import get_default_model_permissions
from shuup.admin.utils.urls import admin_url
from shuup.core.models import Tax
from shuup_can_taxes.importer import TaxImporter

ENABLED_CONF_KEY = "shuup_can_taxes:is_enabled"


class ConfigurationForm(forms.Form):
    is_enabled = forms.BooleanField(label=_("Enabled"), required=False)


class ConfigurationView(FormView):
    template_name = "shuup_can_taxes/config.jinja"
    form_class = ConfigurationForm

    def get_initial(self):
        initial = super(ConfigurationView, self).get_initial()
        initial.update({"is_enabled": bool(configuration.get(None, ENABLED_CONF_KEY))})
        return initial

    def form_valid(self, form):
        configuration.set(None, ENABLED_CONF_KEY, form.cleaned_data["is_enabled"])
        messages.success(self.request, _("Configuration keys saved"))
        return HttpResponseRedirect(self.request.path)

    def get_context_data(self, **kwargs):
        context = super(ConfigurationView, self).get_context_data(**kwargs)
        context["toolbar"] = get_default_edit_toolbar(self, "can_taxes_config_form", with_split_save=False)
        return context


def import_taxes_view(request):
    importer = TaxImporter()
    return importer.import_taxes()


class CanadaTaxAdminModule(AdminModule):
    name = _("Canada Taxes")
    breadcrumbs_menu_entry = MenuEntry(text=name, url="shuup_admin:shuup_can_taxes.config")

    def get_urls(self):
        return [
            admin_url(
                "^can_taxes/$",
                "shuup_can_taxes.admin_module.ConfigurationView",
                name="shuup_can_taxes.config",
                permissions=get_default_model_permissions(Tax)
            ),
            admin_url(
                "^can_taxes/import_taxes/$",
                "shuup_can_taxes.admin_module.import_taxes_view",
                name="shuup_can_taxes.import_taxes",
                permissions=get_default_model_permissions(Tax)
            )
        ]

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=self.name, icon="fa fa-money",
                url="shuup_admin:shuup_can_taxes.config",
                category=SETTINGS_MENU_CATEGORY,
                subcategory="taxes"
            )
        ]

    def get_required_permissions(self):
        return (get_default_model_permissions(Tax))
