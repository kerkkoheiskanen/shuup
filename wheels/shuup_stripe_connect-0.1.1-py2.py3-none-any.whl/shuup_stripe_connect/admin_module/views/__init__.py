# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Connect.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from .connect import StripeConnectView
from .finalize import StripeFinalizeConnectView

__all__ = [
    "StripeConnectView",
    "StripeFinalizeConnectView"
]
