# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Connect.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import shuup.apps


class ShuupStripeConnectAppConfig(shuup.apps.AppConfig):
    name = "shuup_stripe_connect"
    label = "shuup_stripe_connect"
    verbose_name = "Shuup Stripe Connect integration"

    provides = {
        "front_urls_pre": [
            "shuup_stripe_connect.urls:urlpatterns"
        ],
        "admin_module": [
            "shuup_stripe_connect.admin_module:StripeConnectAdminModule"
        ],
        "stripe_charger": [
            "shuup_stripe_connect.module:StripeConnectCharger"
        ]
    }
