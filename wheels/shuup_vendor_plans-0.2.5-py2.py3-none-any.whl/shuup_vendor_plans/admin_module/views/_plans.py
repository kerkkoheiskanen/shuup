# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _
from shuup.admin.breadcrumbs import BreadcrumbedView
from shuup.admin.forms import ShuupAdminForm
from shuup.admin.forms.fields import Select2ModelMultipleField
from shuup.admin.shop_provider import get_shop
from shuup.admin.toolbar import (
    get_default_edit_toolbar, NewActionButton, SettingsActionButton, Toolbar
)
from shuup.admin.utils.picotable import (
    Column, TextFilter, true_or_false_filter
)
from shuup.admin.utils.views import CreateOrUpdateView, PicotableListView
from shuup.core.models import Supplier
from shuup_subscriptions.models import Plan

from shuup_vendor_plans.utils import configure_vendor_plan


class VendorPlanForm(ShuupAdminForm):
    class Meta:
        model = Plan
        exclude = ["products", "shop"]

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        super(VendorPlanForm, self).__init__(*args, **kwargs)

        initial_vendors = []

        if self.instance.pk and hasattr(self.instance, "vendor_visibility"):
            initial_vendors = self.instance.vendor_visibility.vendors.all()

        self.fields["vendors"] = Select2ModelMultipleField(
            initial=initial_vendors,
            model=Supplier,
            required=False,
            widget=forms.SelectMultiple(
                choices=((vendor.pk, vendor.name) for vendor in initial_vendors),
                attrs={
                    "data-model": "shuup.Supplier",
                    "data-search-mode": "enabled"
                }
            ),
        )

    def save(self, *args, **kwargs):
        self.instance.shop = get_shop(self.request)
        instance = super(VendorPlanForm, self).save(*args, **kwargs)
        configure_vendor_plan(instance, self.cleaned_data.get("vendors"))
        return instance


class VendorPlanEditView(BreadcrumbedView, CreateOrUpdateView):
    model = Plan
    template_name = "shuup_vendor_plans/admin/vendor_plan_edit.jinja"
    form_class = VendorPlanForm
    context_object_name = "plan"
    add_form_errors_as_messages = True
    parent_name = _("Vendor Plans")
    parent_url = "shuup_admin:shuup_vendor_plans.plan.list"

    def get_context_data(self, **kwargs):
        context = super(VendorPlanEditView, self).get_context_data(**kwargs)
        if self.object.pk:
            context["title"] = _("Edit Plan: {plan_name}").format(plan_name=self.object)
        else:
            context["title"] = _("New Vendor Plan")
        return context

    def get_success_url(self):
        return reverse("shuup_admin:shuup_vendor_plans.plan.edit", kwargs={"pk": self.object.pk})

    def get_toolbar(self):
        save_form_id = self.get_save_form_id()
        toolbar = get_default_edit_toolbar(self, save_form_id)
        return toolbar

    def get_form_kwargs(self):
        kwargs = super(VendorPlanEditView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs


class VendorPlanListView(PicotableListView):
    model = Plan
    url_identifier = "shuup_vendor_plans.plan"
    default_columns = [
        Column(
            "name", _("Name"), sort_field="translations__name",
            display=(lambda plan: plan.safe_translation_getter('name') or ""),
            filter_config=TextFilter(filter_field="translations__name", placeholder=_("Filter by name..."))
        ),
        Column("is_active", _("Enabled"), filter_config=true_or_false_filter),
        Column("amount", _("Amount"), sort_field="amount_value"),
        Column("interval", _("Interval")),
        Column("vendors", _("Visible for vendors"), display="get_visible_vendors", sortable=False),
    ]

    def get_context_data(self, **kwargs):
        context = super(VendorPlanListView, self).get_context_data(**kwargs)
        context["title"] = _("Vendor Plans")
        return context

    def get_object_url(self, instance):
        return reverse("shuup_admin:shuup_vendor_plans.plan.edit", kwargs={"pk": instance.pk})

    def get_visible_vendors(self, instance):
        if not hasattr(instance, "vendor_visibility") or not instance.vendor_visibility.vendors.exists():
            return _("All")
        return ", ".join(list(instance.vendor_visibility.vendors.values_list("name", flat=True)))

    def get_toolbar(self):
        return Toolbar([
            NewActionButton("shuup_admin:shuup_vendor_plans.plan.new"),
            SettingsActionButton.for_model(Plan, return_url="shuup_vendor_plans.plan")
        ])
