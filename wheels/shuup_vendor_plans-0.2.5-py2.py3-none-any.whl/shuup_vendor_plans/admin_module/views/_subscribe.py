# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json

import requests
from django.conf import settings
from django.core.urlresolvers import reverse
from django.db.transaction import atomic
from django.http import HttpResponseBadRequest, HttpResponseRedirect
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from django.views.generic import FormView, TemplateView
from shuup import configuration
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import (
    OrderStatus, PaymentMethod, ProductMode, ProductPackageLink
)
from shuup.front.checkout._storage import CheckoutPhaseStorage
from shuup.utils.excs import Problem
from shuup_multivendor.models import SupplierUser
from shuup_stripe.checkout_forms import StripeTokenForm
from shuup_stripe_subscriptions.models import \
    StripeSubscriptionPaymentProcessor
from shuup_stripe_subscriptions.utils import get_amount_info
from shuup_subscriptions.models import Plan

from shuup_vendor_plans.basket import VendorsSubscriptionBasket
from shuup_vendor_plans.order_creator import VendorsSubscriptionOrderCreator
from shuup_vendor_plans.utils import (
    get_plans, get_shop_for_subscription,
    get_subscription_contact_for_supplier
)


class StoragedViewMixin(object):
    @property
    def storage(self):
        if not hasattr(self, "_storage"):
            self._storage = CheckoutPhaseStorage(request=self.request, phase_identifier="admin_plan_order")
        return self._storage


class PlanPaymentView(StoragedViewMixin, FormView):
    service = None  # Injected by the method phase
    title = _("Pay the plan")
    template_name = "shuup_vendor_plans/admin/plan_payment.jinja"
    form_class = StripeTokenForm
    basket = None
    plan = None

    def get_payment_method(self):
        shop = get_shop_for_subscription(self.request)
        return PaymentMethod.objects.filter(
            payment_processor=self.provider,
            shop=shop
        ).first() if self.provider else None

    def dispatch(self, request, *args, **kwargs):
        if request.method != "POST":
            return HttpResponseRedirect(reverse("shuup_admin:shuup_vendor_plans.subscribe"))

        if not self.service:
            self.provider = StripeSubscriptionPaymentProcessor.objects.first()
            self.service = self.get_payment_method()

        if not self.basket:
            shop = get_shop_for_subscription(request)
            self.plan = Plan.objects.get(pk=request.POST.get("plan"), shop=shop)
            product = self.plan.products.first()

            if not product:
                return HttpResponseBadRequest(_("Invalid plan. Plan is not correctly configured."))

            if self.plan not in get_plans(get_shop(self.request), get_supplier(self.request)):
                return HttpResponseBadRequest(_("Invalid plan."))

            basket = VendorsSubscriptionBasket(request, shop=shop)
            shop_product = product.get_shop_instance(shop)
            basket.add_product(shop_product.suppliers.first(), shop, product, quantity=1)
            basket.set_plan(self.plan)
            request.basket = self.basket = basket

            if bool(
                getattr(settings, "ALLOW_SUBSCRIBING_FREE_PLAN_WITHOUT_STRIPE", False) and
                basket.total_price.value == 0
            ):
                self.storage["free-plan"] = True
                self.storage["stripe"] = {}
                self.storage["plan"] = self.plan.pk
                return HttpResponseRedirect(reverse("shuup_admin:shuup_vendor_plans.success"))

        return super(PlanPaymentView, self).dispatch(request, *args, **kwargs)

    def get_stripe_context(self):
        shop = get_shop_for_subscription(self.request)
        if not self.provider:
            raise Problem(_("Please configure Stripe Subscription."))
        if not self.service:
            raise Problem(_("Please configure Stripe Subscription Payment Methods."))

        payment_processor = self.service.payment_processor
        publishable_key = payment_processor.publishable_key
        secret_key = payment_processor.secret_key

        if not (publishable_key and secret_key):
            raise Problem(_("Please configure Stripe keys for payment processor %s.") % payment_processor)

        config = {
            "publishable_key": publishable_key,
            "name": force_text(shop),
            "description": force_text(_("Purchase")),  # TODO: plan name
        }

        config.update(get_amount_info(self.basket.plan.amount))
        return config

    def get_context_data(self, **kwargs):
        context = super(PlanPaymentView, self).get_context_data(**kwargs)
        context["stripe"] = self.get_stripe_context()
        context["plan"] = self.plan
        return context

    def is_valid(self):
        return (
            self.storage.get("plan") and
            ("token" in self.storage.get("stripe", {}) or self.storage.get("free-plan"))
        )

    def form_valid(self, form):
        self.storage["stripe"] = {
            "token": form.cleaned_data.get("stripeToken"),
            "token_type": form.cleaned_data.get("stripeTokenType"),
            "email": form.cleaned_data.get("stripeEmail"),
        }
        self.storage["plan"] = self.request.POST.get("plan")  # used for override later on
        self.storage["free-plan"] = False
        return super(PlanPaymentView, self).form_valid(form)

    def get_success_url(self):
        return reverse("shuup_admin:shuup_vendor_plans.success")


class PaymentSuccessView(StoragedViewMixin, TemplateView):
    template_name = None
    order = None

    def _get_vendor(self, request):
        supplier = get_supplier(request)
        vendor_contact = get_subscription_contact_for_supplier(supplier)
        if not vendor_contact:
            SupplierUser.objects.update_or_create(
                shop=self.shop,
                supplier=supplier,
                user=request.user,
                defaults=dict(is_owner=True)
            )
            vendor_contact = get_subscription_contact_for_supplier(supplier)
        return vendor_contact

    def dispatch(self, request, *args, **kwargs):
        # re-create basket due front middleware madness
        with atomic():
            shop = get_shop_for_subscription(request)
            plan = Plan.objects.get(pk=self.storage["plan"], shop=shop)
            product = plan.products.first()
            assert product.mode == ProductMode.SUBSCRIPTION

            self.product = product
            self.shop_product = product.get_shop_instance(shop)
            self.shop = get_shop(request)
            vendor_contact = self._get_vendor(request)
            request.basket = basket = VendorsSubscriptionBasket(request, shop=shop)
            basket.clear_all()
            assert not basket.plan
            basket.add_product(self.shop_product.suppliers.first(), shop, product, quantity=1)
            basket.set_plan(plan)
            basket.customer = vendor_contact
            basket.creator = request.user
            basket.orderer = vendor_contact
            basket.status = OrderStatus.objects.get_default_complete()
            # needed by `subscriber.py`
            basket.payment_data["stripe"] = self.storage["stripe"]

            assert ProductPackageLink.objects.filter(parent=product).exists()
            assert basket.get_subscription_product() == product

            # Create the order
            creator = VendorsSubscriptionOrderCreator()
            self.order = creator.create_order(basket)

            if bool(
                getattr(settings, "ALLOW_SUBSCRIBING_FREE_PLAN_WITHOUT_STRIPE", False) and
                self.order.taxful_total_price.value == 0
            ):
                self.order.update_payment_status()
            else:
                processor = StripeSubscriptionPaymentProcessor.objects.first()
                choice_identifier = processor.get_service_choices()[0]
                processor.process_payment_return_request(choice_identifier, self.order, None)

        try:
            slack_url = configuration.get(None, settings.SVP_SLACK_URL_KEY, None)
            if slack_url:
                requests.post(
                    slack_url,
                    data=json.dumps({
                        "text": "Subscription order received for %s (%s)." % (
                            shop.name, self.order.taxful_total_price)
                    })
                )
        except Exception:
            from raven.contrib.django.raven_compat.models import client
            client.captureException()

        return HttpResponseRedirect(reverse("shuup_admin:shuup_vendor_plans.subscribe"))
