# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.contrib.auth.models import User
from django.db import models
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum, EnumIntegerField
from shuup.core.models import Shop, ShuupModel, Supplier
from shuup_subscriptions.models import Subscription


class CancelReason(Enum):
    NOT_SUIT = 1
    MISSING_FEATURES = 2
    EXPENSIVE = 3
    ALTERNATIVE = 4
    TESTING = 5
    OTHER = 6

    class Labels:
        NOT_SUIT = _("The software did not suit my needs")
        MISSING_FEATURES = _("The software was missing features I needed")
        EXPENSIVE = _("It is too expensive")
        ALTERNATIVE = _("I am using alternative software")
        TESTING = _("I was just testing your service")
        OTHER = _("Other")


class CancellationInfo(ShuupModel):
    shop = models.ForeignKey(Shop)
    subscription = models.ForeignKey(Subscription)
    supplier = models.ForeignKey(Supplier)
    reason = EnumIntegerField(CancelReason, verbose_name=_("reason"), help_text=_("Choose a reason for cancellation"))
    text = models.TextField()
    canceled_by = models.ForeignKey(User)
    created_on = models.DateTimeField(auto_now_add=True, editable=False, verbose_name=_('created on'))
    modified_on = models.DateTimeField(auto_now=True, editable=False, db_index=True, verbose_name=_('modified on'))

    class Meta:
        unique_together = ("shop", "subscription")


class PlanVendorVisilibity(models.Model):
    plan = models.OneToOneField("shuup_subscriptions.Plan", related_name="vendor_visibility")
    vendors = models.ManyToManyField("shuup.Supplier", related_name="visible_plans")
