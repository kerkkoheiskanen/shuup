# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

from django.db.models import Q
from django.db.transaction import atomic
from django.utils.translation import ugettext_lazy as _
from shuup import configuration
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.excs import Problem
from shuup.core.models import (
    Category, CategoryStatus, CompanyContact, get_person_contact, Product,
    ProductPackageLink, ProductType, SalesUnit, ShippingMode, Shop,
    ShopProduct, ShopProductVisibility, Supplier, SupplierType, TaxClass
)
from shuup_multivendor.models import SupplierUser
from shuup_subscriptions.models import Plan, Subscription

from shuup_vendor_plans.models import PlanVendorVisilibity

from .consts import \
    PLAN_CATEGORY_DATA  # RESERVED_DOMAIN_SUBSTRINGS, RESERVED_DOMAINS


def get_plans(shop, supplier):
    """
    Returns the plans for shop and supplier
    """
    return Plan.objects.filter(
        Q(shop=shop, is_active=True),
        Q(
            Q(vendor_visibility__isnull=True) |
            Q(vendor_visibility__vendors__isnull=True) |
            Q(vendor_visibility__vendors=supplier)
        )
    ).order_by("amount_value").distinct()


def get_company_contact_identifier_for_shop(shop):  # Revise
    return "shop-contact-{shop_id}".format(shop_id=shop.id)


def get_company_contact_shop(request):
    return get_shop(request)


def ensure_company_contact(request):
    user = request.user
    shop = get_company_contact_shop(request)
    contact = get_person_contact(user)
    identifier = get_company_contact_identifier_for_shop(shop)
    company_contact = CompanyContact.objects.update_or_create(identifier=identifier, defaults=dict(name=shop.name))[0]
    company_contact.members.add(contact)
    company_contact.shops.add(shop)
    return (company_contact, contact)


def get_subscription_contact_for_supplier(supplier):
    return get_person_contact(SupplierUser.get_owner(supplier))


def get_subscriptions_for_supplier(supplier):
    return Subscription.objects.filter(
        customer=get_subscription_contact_for_supplier(supplier),
        end_date__isnull=True
    )


def get_subscription_for_supplier(supplier):
    return get_subscriptions_for_supplier(supplier).first()


def get_supplier_for_subscription(subscription):
    user = (getattr(subscription.customer, "user", None) if subscription.customer else None)
    supplier_user = SupplierUser.objects.filter(user=user, shop=subscription.plan.shop).first()
    if supplier_user:
        return supplier_user.supplier


def get_subscription(request, without_end_date=True):
    if not request.user or request.user and not request.user.is_staff:
        return None

    shop = get_shop(request)
    supplier = get_supplier(request)
    vendor_contact = get_subscription_contact_for_supplier(supplier)
    subscriptions = Subscription.objects.filter(plan__shop=shop, customer=vendor_contact)
    if without_end_date:
        subscriptions = subscriptions.filter(end_date__isnull=True)
    return subscriptions.first()


def get_shop_for_subscription(request=None):
    shop_id = configuration.get(None, "plan_shop")
    if not shop_id:
        return Shop.objects.first()  # TODO: Something wiser (.None())?
    return Shop.objects.get(pk=shop_id)


def get_plans_category(shop):
    # Update or create the plans category
    category = Category.objects.update_or_create(identifier="plans", defaults=dict(
        name=PLAN_CATEGORY_DATA["name"],
        slug=PLAN_CATEGORY_DATA["slug"],
        identifier=PLAN_CATEGORY_DATA["identifier"],
        visible_in_menu=PLAN_CATEGORY_DATA["visible_in_menu"],
        status=CategoryStatus.INVISIBLE
    ))[0]
    category.shops.set([shop])
    return category


def get_vendor_setting(key, default_value=None):
    return configuration.get(None, key, default=default_value)


def get_subscription_supplier(shop):
    supplier = Supplier.objects.update_or_create(
        identifier="subs_supplier_{}".format(shop.pk),
        defaults=dict(
            name=_("Subscription Supplier"),
            type=SupplierType.INTERNAL,
            stock_managed=False,
            module_identifier="",
            enabled=False,
            is_approved=False
        )
    )[0]
    supplier.shops.add(shop)
    return supplier


def get_subscription_plan_product(plan):
    shop = plan.shop
    with atomic():
        tax_class_id = configuration.get(None, "tax_class")
        tax_class = TaxClass.objects.filter(pk=tax_class_id).first()
        if not tax_class:
            raise Problem(_("Tax Class should be set in shop configuration"))

        product_type = ProductType.objects.get_or_create(identifier="plan", defaults=dict(name="Plan"))[0]

        # 1)_Create the subscription product
        subscription_product = Product.objects.get_or_create(
            sku="subs_plan_{}".format(plan.pk),
            defaults=dict(
                name=_("{plan_name} - Subscription").format(plan_name=plan.name),
                shipping_mode=ShippingMode.NOT_SHIPPED,
                tax_class=tax_class,
                sales_unit=SalesUnit.objects.first(),
                type=product_type
            )
        )[0]
        subscription_shop_product = ShopProduct.objects.get_or_create(
            shop=shop,
            product=subscription_product,
            defaults=dict(
                default_price_value=Decimal(),
                visibility=ShopProductVisibility.NOT_VISIBLE
            )
        )[0]
        subscription_shop_product.suppliers.set([get_subscription_supplier(shop)])
        subscription_shop_product.categories.set([get_plans_category(shop)])

        # 2) Create the subscription fee product (it's a subscription product package children)
        subscription_fee_product = Product.objects.get_or_create(
            sku="subs_fee_plan_{}".format(plan.pk),
            defaults=dict(
                name=_("{plan_name} - Subscription Fee").format(plan_name=plan.name),
                shipping_mode=ShippingMode.NOT_SHIPPED,
                tax_class=tax_class,
                sales_unit=SalesUnit.objects.first(),
                type=product_type
            )
        )[0]
        subscription_fee_shop_product = ShopProduct.objects.get_or_create(
            shop=shop,
            product=subscription_fee_product,
            defaults=dict(
                default_price_value=Decimal(),
                visibility=ShopProductVisibility.NOT_VISIBLE
            )
        )[0]
        # only vendors will see this product
        subscription_fee_shop_product.suppliers.set([get_subscription_supplier(shop)])
        subscription_fee_shop_product.categories.set([get_plans_category(shop)])

        # 3) Link the fee product into the subscription product
        ProductPackageLink.objects.get_or_create(
            parent=subscription_product,
            child=subscription_fee_product,
            defaults=dict(quantity=1)
        )

    return subscription_product


def configure_vendor_plan(plan, vendors=None):
    """
    Configure the vendor plan by ensuring it has a configured subscription product
    and the subscription has the fee product.
    """
    plan_product = get_subscription_plan_product(plan)
    plan.products.set([plan_product])
    plan_product.save()     # ensure product mode

    plan_shop_product = plan_product.get_shop_instance(plan.shop)
    plan_shop_product.default_price_value = plan.amount
    plan_shop_product.save()

    if vendors:
        plan_vendor_visibility = PlanVendorVisilibity.objects.get_or_create(plan=plan)[0]
        plan_vendor_visibility.vendors.set(vendors)
    else:
        PlanVendorVisilibity.objects.filter(plan=plan).delete()
