# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

# matches the arbitrary form field names
SVP_FROM_EMAIL_KEY = "email_from"
SVP_NOTIFY_EMAIL = "notify_email"
SVP_SLACK_URL_KEY = "slack_url"
SVP_CANCEL_FIRST_KEY = "cancel_first"
SVP_CANCEL_SECOND_KEY = "cancel_second"
SVP_CANCEL_THIRD_KEY = "cancel_third"
SVP_UPGRADE_KEY = "plan_upgrade_text"

ALLOW_SUBSCRIBING_FREE_PLAN_WITHOUT_STRIPE = True

"""
Example:
    PLAN_LIMITER_CONFIG = {
        "Free Business Plan": {
            "product_limit": 2,
            "course_limit": 3,
            "user_limit": 1
        },
        "Solo Business Plan": {
            "product_limit": 6,
            "course_limit": 6,
            "user_limit": 2
        },
    }

"""
PLAN_LIMITER_CONFIG = {}
