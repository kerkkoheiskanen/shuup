# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from shuup.core.models import ProductMode
from shuup.core.order_creator import OrderCreator


class VendorsSubscriptionOrderCreator(OrderCreator):
    def _check_orderability(self, order_line):
        # ignore subscription lines
        if order_line.product.mode == ProductMode.SUBSCRIPTION:
            return
        elif order_line.source_line and (
                order_line.source_line.get("is_subscription_line") or
                order_line.source_line.get("is_subscription_parent")):
            return

        super(VendorsSubscriptionOrderCreator, self)._check_orderability(order_line)
