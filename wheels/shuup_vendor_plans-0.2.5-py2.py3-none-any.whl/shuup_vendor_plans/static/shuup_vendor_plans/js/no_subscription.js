$(document).ready(function() {
    $(".shuup-toolbar").empty();  // remove old buttons
    $("<div class='pull-right'>"+gettext("Please subscribe to create more products")+"</div>").appendTo(".shuup-toolbar");
});
