$(document).ready(function() {
    $(".shuup-toolbar").empty();  // remove old buttons
    $("<div class='pull-right'>"+gettext("Please upgrade your subscription to create more products")+"</div>").appendTo(".shuup-toolbar");
});
