# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from shuup.core.models import ShopProduct
from shuup.utils.djangoenv import has_installed
from shuup.utils.excs import Problem

from shuup_vendor_plans.utils import (
    get_subscription_contact_for_supplier, get_subscription_for_supplier
)


class PlanLimiter(object):

    def __init__(self, supplier, **kwargs):
        if not hasattr(settings, "PLAN_LIMITER_CONFIG") or not settings.PLAN_LIMITER_CONFIG:
            self.supplier = None
        elif not supplier or not supplier.vendor_users.exists():
            self.supplier = None
        else:
            self._initialize(supplier, **kwargs)

    def _initialize(self, supplier, **kwargs):
        subscription = get_subscription_for_supplier(supplier)
        if not subscription:
            raise Problem("No subscription")

        self.plan = subscription.plan

        plan_config = settings.PLAN_LIMITER_CONFIG

        if self.plan.name not in plan_config:
            raise Problem("Unknown plan")

        self.config = plan_config[self.plan.name]
        self.supplier = supplier

    def is_vendor(self):
        return get_subscription_contact_for_supplier(self.supplier)

    def can_create_course(self, excluded_obj=None, filters=None, exclude=None, **kwargs):
        if not has_installed("shuup_courses"):
            return True

        if not self.is_vendor():
            return True

        if not filters:
            filters = {}

        if not exclude:
            exclude = {}

        from shuup_courses.utils import get_course_product_type
        filters["product__type"] = get_course_product_type()
        limiter = self.get_course_limit
        return self._can_create_product(limiter, excluded_obj, filters, exclude, **kwargs)

    def can_create_product(self, excluded_obj=None, filters=None, exclude=None, **kwargs):
        if not self.is_vendor():
            return True

        if not filters:
            filters = {}

        if not exclude:
            exclude = {}

        if has_installed("shuup_courses"):
            from shuup_courses.utils import get_course_product_type
            exclude["product__type"] = get_course_product_type()
        limiter = self.get_product_limit
        return self._can_create_product(limiter, excluded_obj, filters, exclude, **kwargs)

    def _can_create_product(self, limiter, excluded_obj=None, filters=None, exclude=None, **kwargs):
        if not self.is_vendor():
            return True

        queryset = ShopProduct.objects.filter(suppliers=self.supplier, product__deleted=False, shop=self.plan.shop)
        if excluded_obj and excluded_obj.pk:
            queryset = queryset.exclude(pk=excluded_obj.pk)

        if filters:
            queryset = queryset.filter(**filters)

        if exclude:
            queryset = queryset.exclude(**exclude)

        return queryset.count() < limiter()

    def can_create_user(self, excluded_obj=None, filters=None, **kwargs):
        if not self.is_vendor():
            return True

        queryset = self.supplier.vendor_users.all()

        if excluded_obj:
            queryset = queryset.exclude(pk=excluded_obj.pk)
        if filters:
            queryset = queryset.filter(**filters)
        return queryset.count() < self.get_user_limit()

    def get_course_limit(self):
        return self._get_config("course_limit")

    def get_product_limit(self):
        return self._get_config("product_limit")

    def get_user_limit(self):
        return self._get_config("user_limit")

    def _get_config(self, key):
        if key in self.config:
            return self.config[key]
