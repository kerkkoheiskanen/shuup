# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_vendor_plans"
    verbose_name = "Shuup Vendor Plans"
    label = "shuup_vendor_plans"
    provides = {
        "admin_shop_form_part": [
            "shuup_vendor_plans.admin_module.forms.VendorPlansSettingsFormPart",
        ],
        "admin_vendor_form_part": [
            "shuup_vendor_plans.admin_module.subscriptions.VendorSubscriptionsFormPart"
        ],
        "vendor_plan_provider": [
            "shuup_vendor_plans.plan_provider:VendorPlanProvider"
        ],
        "admin_module": [
            "shuup_vendor_plans.admin_module:VendorSubscriptionModule",
        ],
        "reports": [
            "shuup_vendor_plans.reports.subscriptions:PlanSubscriptionReport",
            "shuup_vendor_plans.reports.payments:PlanPaymentsReport",
        ],
        "xtheme_resource_injection": [
            "shuup_vendor_plans.admin_module.admin_resources:add_admin_resources"
        ],
    }

    def ready(self):
        import shuup_vendor_plans.signal_handlers  # noqa
