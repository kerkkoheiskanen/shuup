# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.dispatch import receiver
from shuup.utils.djangoenv import has_installed
from shuup.utils.excs import Problem
from shuup_multivendor.signals import vendor_pre_save, vendor_product_pre_save

from shuup_vendor_plans.plan_limiter import PlanLimiter


@receiver(vendor_product_pre_save)
def can_create_products(request, shop, supplier, instance, **kwargs):
    if instance.pk:
        return
    limiter = PlanLimiter(supplier)
    if not limiter.can_create_product():
        raise Problem("Limit reached, you cannot create more products.")


if has_installed("shuup_courses"):
    from shuup_courses.signals import course_pre_save

    @receiver(course_pre_save)
    def can_create_courses(request, shop, supplier, instance, **kwargs):
        if instance.pk:
            return
        limiter = PlanLimiter(supplier)
        if not limiter.can_create_course():
            raise Problem("Limit reached, you cannot create more courses.")


@receiver(vendor_pre_save)
def can_create_users(request, shop, supplier, instance, **kwargs):
    if instance.pk:
        return
    limiter = PlanLimiter(supplier)
    if not limiter.can_create_user():
        raise Problem("Limit reached, you cannot create more users.")
