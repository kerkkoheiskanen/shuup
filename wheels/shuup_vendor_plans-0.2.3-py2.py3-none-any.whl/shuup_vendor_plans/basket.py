# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from collections import Counter

import six
from shuup.core.basket.objects import BasketLine
from shuup.core.models import OrderLineType, ShopProduct
from shuup_subscriptions.checkout._basket import SubscriptionBasket


class VendorsSubscriptionBasket(SubscriptionBasket):
    def __init__(self, request, basket_name="vendors_subscription_basket", shop=None):
        super(VendorsSubscriptionBasket, self).__init__(request, basket_name, shop)

    def verify_orderability(self):
        """
        Just trust what developer is doing
        """
        pass

    def _cache_lines(self):     # noqa (C901)
        lines = [BasketLine.from_dict(self, line) for line in self._data_lines]
        lines_by_line_id = {}
        orderable_counter = Counter()
        orderable_lines = []

        for line in lines:
            lines_by_line_id[line.line_id] = line
            if line.type != OrderLineType.PRODUCT:
                orderable_lines.append(line)
            else:
                product = line.product
                quantity = line.quantity + orderable_counter[product.id]

                try:
                    shop_product = line.shop_product
                except ShopProduct.DoesNotExist:
                    continue

                # this is the only difference from the base SubscriptionBasket._cache_lines method
                # it will bypass the orderability check when the line is a subscription line/parent line
                is_orderable = (
                    line.get("is_subscription_line") or
                    line.get("is_subscription_parent") or
                    shop_product.is_orderable(line.supplier, self.customer, quantity, allow_cache=False)
                )
                if is_orderable:
                    if product.is_package_parent():
                        quantity_map = product.get_package_child_to_quantity_map()
                        orderable = True
                        for child_product, child_quantity in six.iteritems(quantity_map):
                            sp = child_product.get_shop_instance(shop=self.shop)
                            in_basket_child_qty = orderable_counter[child_product.id]
                            total_child_qty = ((quantity * child_quantity) + in_basket_child_qty)
                            if not sp.is_orderable(
                                    line.supplier, self.customer, total_child_qty, allow_cache=False):
                                orderable = False
                                break
                        if orderable:
                            orderable_lines.append(line)
                            orderable_counter[product.id] += quantity
                            for child_product, child_quantity in six.iteritems(quantity_map):
                                orderable_counter[child_product.id] += child_quantity * line.quantity
                    else:
                        orderable_lines.append(line)
                        orderable_counter[product.id] += line.quantity

        self._orderable_lines_cache = orderable_lines
        self._unorderable_lines_cache = [line for line in lines if line not in orderable_lines]
        self._lines_by_line_id_cache = lines_by_line_id
        self._lines_cached = True
