# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from babel.dates import format_datetime
from django.utils.translation import ugettext_lazy as _
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import Supplier
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import format_money, get_current_babel_locale
from shuup_subscriptions.models import SubscriptionPayment

from shuup_vendor_plans.utils import (
    get_subscriptions_for_supplier, get_supplier_for_subscription
)

from .utils import can_control_supplier, SubscriptionsReportForm


class PlanPaymentsReport(ShuupReportBase):
    identifier = "multivendor-vendor-plan-payments-report"
    title = _("Vendor Plan Payments Report")
    description = _("This report shows all vendor payments for given time period.")
    filename_template = "multivendor-vendor-plan-payments-report-%(time)s"
    form_class = SubscriptionsReportForm

    schema = [
        {"key": "date", "title": _("Date")},
        {"key": "plan", "title": _("Plan")},
        {"key": "vendor", "title": _("Vendor")},
        {"key": "customer_name", "title": _("Customer")},
        {"key": "total_paid", "title": _("Payment Amount")}
    ]

    def get_objects(self):
        supplier = get_supplier(self.request)
        if not supplier and can_control_supplier(self.shop, self.request.user):
            supplier_id = self.options.get("supplier")
            if supplier_id:
                supplier = Supplier.objects.filter(id=supplier_id).first()

        queryset = SubscriptionPayment.objects.all()
        if supplier:
            queryset = queryset.filter(
                subscription_id__in=get_subscriptions_for_supplier(supplier).values_list("id", flat=True)
            )

        return queryset

    def get_data(self):
        data = []

        for payment in self.get_objects():
            subscription = payment.subscription
            supplier = get_supplier_for_subscription(subscription)
            data.append({
                "date": format_datetime(payment.created_on, locale=get_current_babel_locale()),
                "plan": subscription.plan.name,
                "vendor": supplier.name,
                "customer_name": payment.subscription.customer.name,
                "total_paid": format_money(payment.amount)
            })

        return self.get_return_data(data)
