# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json

import requests
from django.conf import settings
from django.contrib import messages
from django.core.mail import send_mail
from django.core.urlresolvers import reverse, reverse_lazy
from django.db.transaction import atomic
from django.http import Http404, HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic import FormView, TemplateView
from shuup import configuration
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import Supplier
from shuup.utils.dates import local_now
from shuup_subscriptions.enums import SubscriptionCancellationMethod
from shuup_subscriptions.utils import add_plan_interval_to_date

from shuup_vendor_plans.forms import CancelForm, VerifyLoginForm
from shuup_vendor_plans.models import CancellationInfo
from shuup_vendor_plans.utils import (
    get_shop_for_subscription, get_subscription,
    get_subscriptions_for_supplier
)

MESSAGE_TEMPLATE = """
Hi Dear Admins,

Shop #{shop} has canceled their subscription.

Plan: {plan}

Reason: {reason}

Description for reason
{reason_text}
"""


CANCEL_TEMPLATES = {
    1: _("You are about to cancel your subscription. Are you sure?"),
    2: _("You are about to cancel your subscription. Are you sure?"),
    3: _("You are about to cancel your subscription. Are you sure?")
}


def get_cancel_text(key, default_value):
    cancel_text = configuration.get(None, key)
    if not cancel_text:
        cancel_text = CANCEL_TEMPLATES[default_value]
    return cancel_text


class FirstCancelView(TemplateView):
    template_name = "shuup_vendor_plans/admin/plan_cancel_first.jinja"

    def get_context_data(self, **kwargs):
        ctx = super(FirstCancelView, self).get_context_data(**kwargs)
        ctx["cancel_text"] = get_cancel_text("cancel_first", 1)
        return ctx


class SecondCancelView(FormView):
    template_name = "shuup_vendor_plans/admin/plan_cancel_second.jinja"
    form_class = CancelForm
    success_url = reverse_lazy("shuup_admin:shuup_vendor_plans.cancel_third")

    def get_form_kwargs(self):
        kwargs = super(SecondCancelView, self).get_form_kwargs()
        kwargs["request"] = self.request
        subscription = get_subscription(self.request)
        if subscription:
            cancellation_info = CancellationInfo.objects.filter(subscription=subscription).first()
            if cancellation_info:
                kwargs["instance"] = cancellation_info
        return kwargs

    def form_valid(self, form):
        form.save()
        return HttpResponseRedirect(self.get_success_url())

    def get_context_data(self, **kwargs):
        ctx = super(SecondCancelView, self).get_context_data(**kwargs)
        ctx["cancel_text"] = get_cancel_text("cancel_second", 2)
        return ctx


class ThirdCancelView(FormView):
    # ask user password to finalize cancel
    form_class = VerifyLoginForm
    template_name = "shuup_vendor_plans/admin/plan_cancel_third.jinja"
    success_url = reverse_lazy("shuup_admin:shuup_vendor_plans.cancel")

    def get_form_kwargs(self):
        kwargs = super(ThirdCancelView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs

    def get_context_data(self, **kwargs):
        ctx = super(ThirdCancelView, self).get_context_data(**kwargs)
        ctx["cancel_text"] = get_cancel_text("cancel_third", 3)
        return ctx


class CancelConfirmedView(TemplateView):
    template_name = ""

    def dispatch(self, request, *args, **kwargs):
        subscription = get_subscription(request)
        cancel_subscription(request, subscription)
        messages.success(request, _("Account cancelled successfully"))
        return HttpResponseRedirect(reverse("shuup_admin:dashboard"))


class CancelVendorSubscriptionView(TemplateView):
    template_name = "shuup_vendor_plans/admin/subscription_cancel.jinja"

    def dispatch(self, request, **kwargs):
        current_supplier = get_supplier(request)
        if current_supplier and str(current_supplier) != kwargs["vendor_pk"]:
            raise Http404(_("Invalid vendor"))

        self.subscription = get_subscriptions_for_supplier(Supplier.objects.get(pk=kwargs["vendor_pk"])).filter(
            pk=kwargs["subscription_pk"]
        ).first()

        if not self.subscription:
            raise Http404(_("Invalid subscription"))

        return super().dispatch(request, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["subscription"] = self.subscription
        return context

    def post(self, request, *args, **kwargs):
        cancel_subscription(request, self.subscription)
        messages.success(request, _("Subscription canceled"))
        return HttpResponseRedirect(
            reverse("shuup_admin:shuup_multivendor.vendor.edit", kwargs=dict(pk=kwargs["vendor_pk"]))
        )


def cancel_subscription(request, subscription):
    with atomic():
        shop = get_shop(request)
        cancel_method = configuration.get(None, "cancel_method", SubscriptionCancellationMethod.IMMEDIATELY.value)

        if cancel_method == SubscriptionCancellationMethod.IMMEDIATELY.value:
            end_date = local_now()
        else:
            if subscription.last_payment and subscription.next_payment_date:
                end_date = subscription.next_payment_date
            else:
                end_date = add_plan_interval_to_date(subscription.plan.interval, subscription.start_date)

        subscription.cancel(request.user, end_date)

        cancel_info = CancellationInfo.objects.filter(subscription=subscription).first()
        if cancel_info:
            parsed_message = MESSAGE_TEMPLATE.format(
                shop=shop.pk,
                plan=subscription.plan.name,
                reason=cancel_info.reason.label,
                reason_text=cancel_info.text
            )
            # notify with email to the admin
            main_shop = get_shop_for_subscription(request)
            default_email = main_shop.contact_address.email if main_shop.contact_address else None
            from_email = configuration.get(None, settings.SVP_FROM_EMAIL_KEY, default_email)
            notify_email = configuration.get(None, settings.SVP_NOTIFY_EMAIL, default_email)

            try:
                if notify_email and from_email:
                    send_mail(
                        subject=_("Subscription canceled"),
                        message=parsed_message,
                        from_email=from_email,
                        recipient_list=[notify_email]
                    )

                slack_url = configuration.get(None, settings.SVP_SLACK_URL_KEY, None)
                if slack_url:
                    requests.post(
                        slack_url,
                        data=json.dumps({
                            "text": "Subscription cancelled for %s." % shop.name
                        })
                    )
            except Exception:
                from raven.contrib.django.raven_compat.models import client
                client.captureException()
