# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils import timezone
from django.views.generic import TemplateView

from shuup_vendor_plans.utils import (
    get_shop_for_subscription, get_subscription
)


class ContextMixin(TemplateView):
    def get_context_data(self, **kwargs):
        ctx = super(ContextMixin, self).get_context_data(**kwargs)
        shop = get_shop_for_subscription(self.request)
        subscription = get_subscription(self.request)
        ctx["shop"] = shop
        ctx["subscription"] = subscription
        ctx["is_trial"] = subscription.is_in_trial_period(timezone.now()) if subscription else False
        return ctx


class ShopInfoView(ContextMixin, TemplateView):
    template_name = "shuup_vendor_plans/admin/shop_info.jinja"


class SubscriptionTableInfoView(ContextMixin, TemplateView):
    template_name = "shuup_vendor_plans/admin/sub_table.jinja"
