# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from django.views.generic import TemplateView
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier

from shuup_vendor_plans.utils import (
    ensure_company_contact, get_plans, get_subscription_for_supplier,
    get_vendor_setting
)


class PlanListView(TemplateView):
    template_name = "shuup_vendor_plans/admin/plan_selector.jinja"

    def get_context_data(self, **kwargs):
        ctx = super(PlanListView, self).get_context_data(**kwargs)
        ensure_company_contact(self.request)
        subscription = get_subscription_for_supplier(get_supplier(self.request))

        if subscription and not subscription.active:
            subscription = None

        ctx["plans"] = get_plans(get_shop(self.request), get_supplier(self.request))
        ctx["subscription"] = subscription
        ctx["is_expiring"] = bool(subscription.end_date) if subscription else False
        ctx["is_trial"] = subscription.is_in_trial_period(timezone.now()) if subscription else False
        ctx["title"] = _("Choose a plan") if not subscription else _("Subscription Info")
        ctx["plan_upgrade_text"] = get_vendor_setting(settings.SVP_UPGRADE_KEY)
        return ctx
