# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import PRODUCTS_MENU_CATEGORY, SETTINGS_MENU_CATEGORY
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.permissions import has_permission
from shuup.admin.utils.urls import admin_url, get_edit_and_list_urls


class VendorSubscriptionModule(AdminModule):
    name = _("Vendor Plans")

    def get_extra_permissions(self):
        return [
            "shuup_vendor_plans.vendor-subscriptions"
        ]

    def get_menu_entries(self, request):
        entries = []
        if has_permission(request.user, "shuup_vendor_plans.plan.list"):
            entries.append(
                MenuEntry(
                    text=_("Vendor Plans"),
                    icon="fa fa-file-text",
                    url="shuup_admin:shuup_vendor_plans.plan.list",
                    category=PRODUCTS_MENU_CATEGORY,
                    subcategory="subscriptions",
                    ordering=3,
                    aliases=[_("Vendor plans")]
                )
            )
        if has_permission(request.user, "shuup_vendor_plans.subscribe") and get_supplier(request):
            entries.append(
                MenuEntry(
                    text=_("Subscription"),
                    icon="fa fa-inbox",
                    url="shuup_admin:shuup_vendor_plans.subscribe",
                    category=SETTINGS_MENU_CATEGORY,
                    subcategory="other_settings",
                    ordering=1,
                    aliases=[_("Subscription Info")]
                )
            )
        return entries

    def get_urls(self):
        return [
            # XHR
            admin_url(
                "^plans/shop-info/$",
                "shuup_vendor_plans.admin_module.views.ShopInfoView",
                name="shuup_vendor_plans.shop_info"
            ),
            admin_url(
                "^plans/subscription-table/$",
                "shuup_vendor_plans.admin_module.views.SubscriptionTableInfoView",
                name="shuup_vendor_plans.sub_table"
            ),
            # Cancellation
            admin_url(
                "^plans/cancel-confirmed/$",
                "shuup_vendor_plans.admin_module.views.CancelConfirmedView",
                name="shuup_vendor_plans.cancel"
            ),
            admin_url(
                "^plans/cancel-finalize/$",
                "shuup_vendor_plans.admin_module.views.ThirdCancelView",
                name="shuup_vendor_plans.cancel_third"
            ),
            admin_url(
                "^plans/cancel-reason/$",
                "shuup_vendor_plans.admin_module.views.SecondCancelView",
                name="shuup_vendor_plans.cancel_second"
            ),
            admin_url(
                "^plans/cancel/$",
                "shuup_vendor_plans.admin_module.views.FirstCancelView",
                name="shuup_vendor_plans.cancel_first"
            ),
            # subscribing
            admin_url(
                "^plans/success/$",
                "shuup_vendor_plans.admin_module.views.PaymentSuccessView",
                name="shuup_vendor_plans.success"
            ),
            admin_url(
                "^plans/pay/$",
                "shuup_vendor_plans.admin_module.views.PlanPaymentView",
                name="shuup_vendor_plans.pay"
            ),
            admin_url(
                "^plans/$",
                "shuup_vendor_plans.admin_module.views.PlanListView",
                name="shuup_vendor_plans.subscribe"
            ),
            admin_url(
                r"^subscription/(?P<subscription_pk>\d+)/(?P<vendor_pk>\d+)/cancel/$",
                "shuup_vendor_plans.admin_module.views.CancelVendorSubscriptionView",
                name="shuup_vendor_plans.cancel_subscription"
            ),
        ] + get_edit_and_list_urls(
            url_prefix="^vendor_plan",
            view_template="shuup_vendor_plans.admin_module.views.VendorPlan%sView",
            name_template="shuup_vendor_plans.plan.%s"
        )
