# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.utils.translation import ugettext_lazy as _
from enumfields import EnumField
from shuup.admin.forms.widgets import QuickAddTaxClassSelect, TextEditorWidget
from shuup.admin.modules.settings.forms.system import (
    BaseSettingsForm, BaseSettingsFormPart
)
from shuup.core.models import Shop, TaxClass
from shuup_subscriptions.enums import SubscriptionCancellationMethod


class VendorPlanSettingsForm(BaseSettingsForm):
    title = _("Vendor Plan Settings")
    tax_class = forms.ChoiceField(
        label=_("Default Tax Class for plans"),
        widget=QuickAddTaxClassSelect(editable_model="shuup.TaxClass")
    )
    plan_shop = forms.ChoiceField(
        label=_("Plan Shop"),
    )
    cancel_method = EnumField(SubscriptionCancellationMethod).formfield(
        default=SubscriptionCancellationMethod.PERIOD_END
    )
    cancel_first = forms.CharField(
        max_length=1024,
        widget=TextEditorWidget,
        label=_("First cancellation page text"),
        help_text=_("Write text here to ensure your client doesn't cancel the subscription."),
        required=False
    )
    cancel_second = forms.CharField(
        max_length=1024,
        widget=TextEditorWidget,
        label=_("Second cancellation page text (Feedback page)"),
        help_text=_("Write text here to ensure your client gives you appropriate feedback."),
        required=False
    )
    cancel_third = forms.CharField(
        max_length=1024,
        widget=TextEditorWidget,
        label=_("Last cancellation page text (Cancellation Done)"),
        help_text=_("Write text here to ensure your client gets appropriate info after cancelling."),
        required=False
    )
    plan_upgrade_text = forms.CharField(
        max_length=1024,
        widget=TextEditorWidget,
        label=_("Plan upgrade information"),
        help_text=_("Write text here to ensure your client gets appropriate info on how to upgrade plan."),
        required=False
    )
    email_from = forms.EmailField(required=False)
    notify_email = forms.EmailField(required=False)
    slack_url = forms.CharField(
        max_length=128,
        label=_("Slack URL"),
        help_text=_("Fill this if you have slack in use and want to get notifications there"),
        required=False
    )

    def __init__(self, *args, **kwargs):
        super(VendorPlanSettingsForm, self).__init__(*args, **kwargs)
        self.fields["tax_class"].choices = [(tx.pk, tx.name) for tx in TaxClass.objects.all()]
        self.fields["plan_shop"].choices = [(shop.pk, shop.name) for shop in Shop.objects.all()]


class VendorPlansSettingsFormPart(BaseSettingsFormPart):
    form = VendorPlanSettingsForm
    name = "shuup_vendor_plans"
    priority = 13

    def form_valid(self, form):
        if self.name not in form.forms:
            return
        form = form.forms[self.name]
        super(VendorPlansSettingsFormPart, self).save(form)


class CancelSubscriptionForm(forms.Form):
    confirm = forms.BooleanField(label=_("Terminate subscription"))
