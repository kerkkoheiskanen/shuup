# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf.urls import url
from django.contrib.auth.decorators import login_required

from shuup_rewards_multivendor.views import CustomerRewardsDashboardView

urlpatterns = [
    url(
        r"^dashboard/rewards/$",
        login_required(CustomerRewardsDashboardView.as_view()),
        name="multivendor_rewards.customer_dashboard"
    ),
]
