# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum, EnumIntegerField

from shuup.core.models import (
    CompanyContact, Order, OrderLine, PaymentStatus, PolymorphicShuupModel
)
from shuup_rewards_multivendor.fields import DecimalValueField


class AdjustmentType(Enum):
    UNKNOWN = 0
    SPEND = 1
    SPEND_REFUND = 2
    EARN = 3
    EARN_REFUND = 4
    EARN_MANUAL = 5
    SPEND_MANUAL = 6

    class Labels:
        UNKNOWN = _("unknown")
        SPEND = _("spend")
        SPEND_REFUND = _("spend refund")
        EARN = _("earn")
        EARN_REFUND = _("earn refund")
        EARN_MANUAL = _("earn manual")
        SPEND_MANUAL = _("spend manual")


class RewardCount(models.Model):
    customer = models.ForeignKey(
        "shuup.PersonContact",
        related_name="multivendor_reward_count",
        verbose_name=_("customer")
    )
    shop = models.ForeignKey("shuup.Shop", verbose_name=_("shop"))
    supplier = models.ForeignKey(
        "shuup.Supplier",
        verbose_name=_("supplier")
    )
    created_on = models.DateTimeField(auto_now_add=True, editable=False, verbose_name=_("created on"))
    modified_on = models.DateTimeField(auto_now=True, editable=False, verbose_name=_("modified on"))
    net_count = models.IntegerField(default=0, verbose_name=_("net count"))
    gross_count = models.IntegerField(default=0, verbose_name=_("gross count"))

    class Meta:
        unique_together = [("shop", "customer", "supplier")]

    def __str__(self):
        return "RewardCount customer:%s in:%s sup:%s <p:%s l:%s>" % (
            self.customer.pk,
            self.shop.pk,
            self.supplier_id,
            self.gross_count,
            self.net_count
        )

    @classmethod
    def recalculate(cls, shop_id, customer_id):
        # total adjustments made in this shop
        total_adjustments = RewardAdjustment.objects.filter(
            shop_id=shop_id,
            customer_id=customer_id
        ).values("supplier").annotate(total=models.Sum("delta"))

        not_paid_orders = Order.objects.filter(
            shop_id=shop_id,
            customer_id=customer_id,
            payment_status__in=[PaymentStatus.NOT_PAID, PaymentStatus.PARTIALLY_PAID]
        ).distinct()

        from shuup_rewards_multivendor.utils import get_points_from_order_line, round_transaction_points
        for supplier_id, total_adjustment in total_adjustments.values_list("supplier", "total"):
            total_adjustment = total_adjustment or 0
            points_in_not_paid_orders = 0

            # get the amount of points in incompleted orders so we can determine net count
            not_paid_order_lines = OrderLine.objects.filter(
                order__in=not_paid_orders,
                supplier_id=supplier_id
            ).select_related("order").distinct()

            for line in not_paid_order_lines:
                points_in_not_paid_orders += get_points_from_order_line(line)

            cls.objects.update_or_create(
                shop_id=shop_id,
                customer_id=customer_id,
                supplier_id=supplier_id,
                defaults={
                    "gross_count": int(round_transaction_points(total_adjustment + points_in_not_paid_orders)),
                    "net_count": round_transaction_points(total_adjustment)
                }
            )

    @classmethod
    def grant_points(cls, shop, customer, supplier, points=1):
        if isinstance(customer, CompanyContact):
            return  # no points for companies

        RewardAdjustment.objects.create(
            supplier=supplier,
            customer=customer,
            shop=shop,
            delta=points,
            reason=_("Granted {points} reward point(s)").format(points=points),
            type=AdjustmentType.EARN_MANUAL,
        )


class RewardAdjustment(PolymorphicShuupModel):
    customer = models.ForeignKey(
        "shuup.PersonContact",
        related_name="multivendor_reward_adjustments",
        verbose_name=_("customer")
    )
    shop = models.ForeignKey(
        "shuup.Shop",
        related_name="multivendor_reward_adjustments",
        verbose_name=_("shop")
    )
    supplier = models.ForeignKey(
        "shuup.Supplier",
        related_name="multivendor_reward_adjustments",
        verbose_name=_("supplier")
    )
    created_on = models.DateTimeField(auto_now_add=True, editable=False, verbose_name=_("created on"))
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, blank=True, null=True, verbose_name=_("created by"))
    reason = models.CharField(max_length=128, blank=True, null=True, verbose_name=_("reason"))
    type = EnumIntegerField(AdjustmentType, default=AdjustmentType.UNKNOWN, verbose_name=_("adjustment type"))
    delta = DecimalValueField(default=0, verbose_name=_("delta"))
    price_per_point = DecimalValueField(
        default=0,
        verbose_name=_("price per point"),
        help_text=_("the price per point used to transform the amount into points")
    )

    def save(self, *args, **kwargs):
        super(RewardAdjustment, self).save(*args, **kwargs)
        RewardCount.recalculate(self.shop_id, self.customer_id)

    @classmethod
    def create_for_source(cls, source, **kwargs):
        if isinstance(source, OrderLine):
            kwargs["supplier"] = source.supplier
            return OrderLineRewardAdjustment.objects.create(order_line=source, **kwargs)


class OrderLineRewardAdjustment(RewardAdjustment):
    order_line = models.ForeignKey(
        "shuup.OrderLine",
        related_name="multivendor_reward_adjustments",
        verbose_name=_("order line")
    )


class RewardsProductConfiguration(models.Model):
    product = models.ForeignKey("shuup.Product", verbose_name=_("product"), related_name="rewards_configurations")
    supplier = models.ForeignKey("shuup.Supplier", verbose_name=_("supplier"), related_name="rewards_configurations")
    disabled = models.BooleanField(
        verbose_name=_("Disable rewards"),
        help_text=_("Indicates whether this product can be purchased using points."),
        default=False
    )
    required_purchase_points = DecimalValueField(
        default=0,
        verbose_name=_("Purchase required number of points"),
        help_text=_(
            "The number of points required to completely purchase this product with points. "
            "This will override the number of points calculated using the item price and the price per points."
        )
    )

    class Meta:
        unique_together = ("supplier", "product")
