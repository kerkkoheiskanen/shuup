# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _

from shuup.core.basket.command_dispatcher import BasketCommandDispatcher
from shuup.front.basket import commands
from shuup.utils.numbers import parse_decimal_string
from shuup_rewards_multivendor import utils


def handle_spend_points(request, basket, line_id, points, **kwargs):
    """
    Handle spend points in basket.

    :param line_id: the line ID to spend points on. It should be a line that has a valid price and a supplier.
    :param points: the number of points to spend on the line.
    """

    if not basket.customer:
        raise ValidationError(_("Invalid basket: Customer not found."), code="customer-not-found")

    parent_line = basket.get_basket_line(line_id)
    if not parent_line:
        raise ValidationError(
            _("Invalid basket line to spend points: Line ID not found."),
            code="basket-line-id-not-found"
        )

    elif not parent_line.supplier:
        raise ValidationError(
            _("Invalid basket line to spend points: Line doesn't contain a supplier."),
            code="basket-line-doesnt-contain-supplier"
        )

    supplier = parent_line.supplier
    net_points, gross_points = utils.get_current_points(basket.shop, basket.customer, supplier)
    points = abs(parse_decimal_string(points))

    if points > net_points:
        raise ValidationError(_("Not enough points."), code="not-enough-points")

    discount_amount = utils.spend_points_to_currency(supplier, points)
    line_total_amount = utils.get_purchase_order_line_amount(parent_line)

    # can't spend more points that the order line amount, so ajust the points to the order line price
    if discount_amount > line_total_amount:
        points = utils.currency_to_spend_points(supplier, line_total_amount)

    line = basket.add_line(
        **utils.get_spend_points_source_line_attrs(basket, supplier, parent_line, points)
    )

    return {
        "ok": basket.smart_product_count,
        "line_id": line.line_id,
        "spent": points
    }


commands.handle_spend_points = handle_spend_points


class RewardsBasketCommandDispatcher(BasketCommandDispatcher):
    commands_module = commands
