# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.utils.translation import ugettext_lazy as _

from shuup.admin.forms.fields import Select2ModelField
from shuup.admin.shop_provider import get_shop
from shuup.core.models import PersonContact
from shuup.utils.i18n import format_money


class VendorRewardsConfigurationForm(forms.Form):
    rewards_enabled = forms.BooleanField(
        required=False,
        label=_("Rewards system enabled"),
    )
    vendor_earn_points_price_per_point = forms.DecimalField(
        required=False,
        label=_("How much money 1 point worth when a user earns points?"),
        max_digits=15,
        decimal_places=8,
        min_value=0
    )
    vendor_spend_points_price_per_point = forms.DecimalField(
        required=False,
        label=_("How much money 1 point worth when a user spends points?"),
        max_digits=15,
        decimal_places=8,
        min_value=0
    )
    vendor_earn_total_percentage = forms.DecimalField(
        required=False,
        max_value=100, min_value=0,
        label=_("What is the percentage over the item total to use on points calculation?"),
        help_text=_("Using 60 means that 60% of the item total will be used to generate points.")
    )

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        super().__init__(*args, **kwargs)
        shop = get_shop(self.request)

        self.fields["vendor_earn_points_price_per_point"].help_text = _(
            "E.g. {sample} means 5 points will be generated for every {unit} spent"
        ).format(
            sample=format_money(shop.create_price(0.2)),
            unit=format_money(shop.create_price(1)),
        )
        self.fields["vendor_spend_points_price_per_point"].help_text = _(
            "E.g. {sample} means 20 points are required to generate a {unit} discount"
        ).format(
            sample=format_money(shop.create_price(0.05)),
            unit=format_money(shop.create_price(1)),
        )


class GrantUserPointsForm(forms.Form):
    contact = Select2ModelField(
        model=PersonContact,
        label=_("Customer"),
    )
    points = forms.DecimalField(
        label=_("How many points to grant to the customer?"),
        max_digits=15,
        decimal_places=2
    )

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        super().__init__(*args, **kwargs)

        if self.request.GET.get("contact"):
            contact = PersonContact.objects.filter(
                shops=get_shop(self.request),
                pk=self.request.GET["contact"]
            ).first()

            if contact:
                self.fields["contact"].initial = contact
                self.fields["contact"].widget.choices = [(contact.pk, contact.name)]


class ProductRewardsForm(forms.Form):
    rewards_disabled = forms.BooleanField(
        label=_("Disable Reward Points for this product"),
        required=False
    )
    purchase_required_points = forms.DecimalField(
        label=_("How many points are required to purchase each unit of this product?"),
        help_text=_(
            "Setting this configuration will override the global point price and each unit will only be purchasable "
            "when user owns enough points to purchase the entire item."
        ),
        max_digits=15,
        decimal_places=0,
        required=False
    )
