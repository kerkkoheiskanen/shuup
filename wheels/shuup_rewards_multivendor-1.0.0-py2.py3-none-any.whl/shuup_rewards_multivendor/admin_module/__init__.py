# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _

from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import CAMPAIGNS_MENU_CATEGORY
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.urls import admin_url


class MultivendorUserRewardsAdminModule(AdminModule):
    name = _("Multivendor User Rewards")

    def get_urls(self):
        return [
            admin_url(
                "^multivendor-rewards/users/$",
                "shuup_rewards_multivendor.admin_module.views.UsersPointsListView",
                name="multivendor_rewards.user_points.list",
            ),
            admin_url(
                r"^multivendor-rewards/users/(?P<pk>\d+)/$",
                "shuup_rewards_multivendor.admin_module.views.UserPointsDetailView",
                name="multivendor_rewards.user_points.detail",
            ),
            admin_url(
                r"^multivendor-rewards/grant-points/$",
                "shuup_rewards_multivendor.admin_module.views.GrantUserPointsView",
                name="multivendor_rewards.grant_points",
            ),
        ]

    def get_menu_entries(self, request):
        if not get_supplier(request):
            return []

        return [
            MenuEntry(
                text=_("User Points"),
                icon="fa fa-trophy",
                url="shuup_admin:multivendor_rewards.user_points.list",
                category=CAMPAIGNS_MENU_CATEGORY,
                ordering=10
            )
        ]
