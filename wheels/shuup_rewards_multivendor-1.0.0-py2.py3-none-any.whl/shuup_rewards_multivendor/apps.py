# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_rewards_multivendor"
    provides = {
        "admin_module": [
            "shuup_rewards_multivendor.admin_module.MultivendorUserRewardsAdminModule"
        ],
        "admin_vendor_form_part": [
            "shuup_rewards_multivendor.admin_module.form_parts.VendorRewardsConfigurationFormPart",
        ],
        "admin_product_form_part": [
            "shuup_rewards_multivendor.admin_module.form_parts.ProductRewardsFormPart",
        ],
        "order_source_validator": [
            "shuup_rewards_multivendor.order_source_validator.MultivendorRewardsSourceValidator",
        ],
        "customer_dashboard_items": [
            "shuup_rewards_multivendor.dashboard_items.CustomerRewardsDashboardItem",
        ],
        "front_urls_pre": [
            "shuup_rewards_multivendor.urls.urlpatterns",
        ]
    }

    def ready(self):
        # connect signals
        import shuup_rewards_multivendor.signal_handler     # noqa (C901)
