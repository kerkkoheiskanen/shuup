# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from collections import defaultdict
from decimal import Decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _

from shuup_rewards_multivendor import utils


class MultivendorRewardsSourceValidator(object):

    @classmethod
    def get_validation_errors(cls, order_source):
        total_spending_points_per_supplier = defaultdict(Decimal)

        if not order_source.customer:
            return []

        shop = order_source.shop
        customer = order_source.customer

        for line in order_source.get_final_lines():
            if line.accounting_identifier != settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
                continue
            elif not line.supplier:
                continue
            elif not line.parent_line:
                yield ValidationError(
                    _("The parent line is required when spending points"),
                    code="parent-line-required"
                )
                continue
            elif line.parent_line.supplier != line.supplier:
                yield ValidationError(
                    _("The parent line supplier is different from the spending points supplier"),
                    code="parent-line-supplier-not-equals"
                )
                continue

            spend_points = line.quantity

            if line.parent_line.product:
                if utils.is_product_rewards_disabled(line.parent_line.supplier, line.parent_line.product):
                    yield ValidationError(
                        _("The product {item} can't be paid with points").format(item=line.parent_line.text),
                        code="cant-be-paid-with-points"
                    )
                    continue

                required_purchase_points = utils.get_product_required_points(
                    line.parent_line.supplier,
                    line.parent_line.product
                )
                # there is a number of required points to purchase this product
                if required_purchase_points > Decimal():
                    net_points, gross_points = utils.get_current_points(shop, customer, line.supplier)

                    if required_purchase_points > net_points or spend_points < required_purchase_points:
                        yield ValidationError(
                            _("There is not enough points to purchase {item}").format(item=line.parent_line.text),
                            code="product-not-enough-required-points"
                        )
                        continue

            # spending points line
            total_spending_points_per_supplier[line.supplier] += spend_points

        for supplier, total_spending_points in total_spending_points_per_supplier.items():
            if total_spending_points > Decimal():
                net_points, gross_points = utils.get_current_points(shop, customer, supplier)
                if abs(total_spending_points) > net_points:
                    yield ValidationError(
                        _("Not enough points to use on {} vendor").format(supplier.name),
                        code="not-enough-points"
                    )
