# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal
from uuid import uuid4

import pytest
from django.conf import settings
from django.core.cache import cache
from django.db.models import Sum

from shuup.core.models import OrderLine, OrderLineType, ShippingMode, Supplier
from shuup.core.order_creator import OrderCreator
from shuup.testing import factories
from shuup.utils.numbers import bankers_round
from shuup_rewards_multivendor import utils
from shuup_rewards_multivendor.models import (
    AdjustmentType, OrderLineRewardAdjustment, RewardAdjustment, RewardCount
)

from .utils import seed_source


def rndpts(value):
    return bankers_round(value, 2)


def create_random_order(order_total, payment_method=None, customer=None, shop=None):
    shop = shop or factories.get_default_shop()
    user = factories.create_random_user()
    supplier = factories.get_default_supplier()
    product = factories.create_product(uuid4().hex, shop=shop, supplier=supplier, default_price=order_total)
    product.shipping_mode = ShippingMode.NOT_SHIPPED
    product.save()
    customer = customer or factories.create_random_person()
    customer.user = user
    customer.save()
    order = factories.create_order_with_product(
        product=product,
        supplier=supplier,
        quantity=1,
        taxless_base_unit_price=order_total,
        shop=shop
    )
    order.customer = customer

    if payment_method:
        order.payment_method = payment_method

    order.save()
    return order


@pytest.mark.django_db
@pytest.mark.parametrize("price_per_point, order_total", [
    (1, 100),
    (1, 155),
    (2, 23.5),
    (2, 95.3)
])
def test_order_line_points(price_per_point, order_total):
    supplier = factories.get_default_supplier()
    utils.set_vendor_price_per_point_on_earn(supplier, price_per_point)
    order = create_random_order(order_total)
    order_line = order.lines.products().first()

    # rewards disabled for vendor
    assert rndpts(utils.get_points_from_order_line(order_line)) == Decimal()

    utils.set_vendor_rewards_enabled(supplier, True)
    utils.adjust_order(order)
    expected_points = rndpts(Decimal(order_total / price_per_point))
    assert rndpts(utils.get_points_from_order_line(order_line)) == expected_points


@pytest.mark.django_db
@pytest.mark.parametrize("price_per_point, order_total, spent_points", [
    (0.01, 100, 5),
    (0.5, 155, 10),
    (2.5, 23.5, 2),
    (1.2, 95.3, 6)
])
def test_order_line_spent_points(price_per_point, order_total, spent_points):
    user = factories.create_random_user()
    order_source = seed_source(user)
    supplier = factories.get_default_supplier()
    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_earn(supplier, price_per_point)
    utils.set_vendor_price_per_point_on_spend(supplier, price_per_point)

    RewardCount.grant_points(order_source.shop, order_source.customer, supplier, order_total)

    product = factories.create_product(
        sku="the-product",
        shop=order_source.shop,
        supplier=supplier,
        default_price=order_total
    )
    product_line = order_source.add_line(
        line_id="product-line",
        type=OrderLineType.PRODUCT,
        product=product,
        supplier=supplier,
        quantity=1,
        base_unit_price=order_source.create_price(order_total),
    )
    order_source.add_line(
        **utils.get_spend_points_source_line_attrs(order_source, supplier, product_line, spent_points)
    )

    creator = OrderCreator()
    order = creator.create_order(order_source)
    discount_line = order.lines.discounts().first()
    product_line = order.lines.products().first()
    assert rndpts(utils.get_points_from_order_line(discount_line)) == -rndpts(Decimal(spent_points))
    granted_points = rndpts(Decimal(product_line.taxless_price.value / Decimal(price_per_point)) - spent_points)
    assert rndpts(utils.get_points_from_order_line(product_line)) == granted_points


@pytest.mark.django_db
@pytest.mark.parametrize("initial_pts, price_per_point, order_total, discount_points, payment_points, percentage", [
    (1000, 1, 100, 20, 10, 30),
    (2000, 0.5, 155, 20, 30, 3.5),
    (1523, 10, 23.5, 60, 5, 31),
    (325, 2, 95.3, 10, 2, 2)
])
def test_adjust_order(initial_pts, price_per_point, order_total, discount_points, payment_points, percentage):
    order = create_random_order(order_total)
    supplier = order.lines.products().first().supplier
    utils.set_vendor_rewards_enabled(supplier, True)

    utils.set_vendor_price_per_point_on_spend(supplier, Decimal(1 / price_per_point))
    utils.set_vendor_price_per_point_on_earn(supplier, price_per_point)
    utils.set_vendor_earn_total_percentage(supplier, percentage)
    order_line = order.lines.products().first()

    # give some points
    RewardCount.grant_points(order.shop, order.customer, supplier, initial_pts)
    utils.adjust_order(order)

    # nothing generated, just the initial points
    assert RewardAdjustment.objects.count() == 1

    # add discount line
    discount_line = OrderLine.objects.create(
        parent_line=order_line,
        supplier=supplier,
        order=order,
        type=OrderLineType.DISCOUNT,
        accounting_identifier=settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER,
        quantity=discount_points,
        base_unit_price_value=-(utils.spend_points_to_currency(supplier, discount_points) / discount_points)
    )
    utils.adjust_order(order)
    # no change, order is not paid yet
    assert RewardAdjustment.objects.count() == 1

    # pay the order
    order.create_payment(order.shop.create_price(order.get_total_unpaid_amount()))

    # user earned points and also spent some through the discount line
    adjustments = RewardAdjustment.objects.not_instance_of(OrderLineRewardAdjustment)
    order_line_adjustments = OrderLineRewardAdjustment.objects.all()
    assert adjustments.count() == 1
    assert order_line_adjustments.count() == 2

    assert adjustments[0].type == AdjustmentType.EARN_MANUAL   # when we gave user points at the start
    assert adjustments[0].delta == initial_pts

    assert order_line_adjustments[0].type == AdjustmentType.EARN   # earned points from the order
    assert order_line_adjustments[0].order_line == order_line
    assert order_line_adjustments[0].delta == utils.get_points_from_order_line(order_line)

    assert order_line_adjustments[1].type == AdjustmentType.SPEND    # using through discount line
    assert order_line_adjustments[1].order_line == discount_line
    assert order_line_adjustments[1].delta == -discount_points

    rewards_count = RewardCount.objects.get(customer=order.customer, shop=order.shop, supplier=supplier)
    assert rewards_count.net_count == int(
        adjustments[0].delta + order_line_adjustments[0].delta + order_line_adjustments[1].delta
    )
    assert rewards_count.gross_count == rewards_count.net_count

    # refund the order
    order.create_full_refund()

    # all the operations should be reverted
    adjustments = RewardAdjustment.objects.not_instance_of(OrderLineRewardAdjustment)
    order_line_adjustments = OrderLineRewardAdjustment.objects.all()
    assert adjustments.count() == 1
    assert order_line_adjustments.count() == 4

    assert adjustments[0].type == AdjustmentType.EARN_MANUAL   # when we gave user points at the start
    assert order_line_adjustments[0].order_line == order_line
    assert order_line_adjustments[0].type == AdjustmentType.EARN

    assert order_line_adjustments[1].order_line == discount_line
    assert order_line_adjustments[1].type == AdjustmentType.SPEND

    assert order_line_adjustments[2].order_line.parent_line == order_line
    assert order_line_adjustments[2].type == AdjustmentType.EARN_REFUND

    assert order_line_adjustments[3].order_line.parent_line == discount_line
    assert order_line_adjustments[3].type == AdjustmentType.SPEND_REFUND

    count = RewardCount.objects.get(customer=order.customer, shop=order.shop)
    total_points = RewardAdjustment.objects.aggregate(total_points=Sum("delta"))["total_points"]

    assert count.net_count == int(total_points) == initial_pts
    assert count.gross_count == int(total_points) == initial_pts


@pytest.mark.parametrize("price_per_point_1, price_per_point_2, order_total", [
    (10, 25, 150),
    (24, 12, 200),
    (0.1, 0.2, 200),
])
@pytest.mark.django_db
def test_adjust_payment_spend_refund(price_per_point_1, price_per_point_2, order_total):
    order = create_random_order(order_total)
    supplier = order.lines.products().first().supplier
    utils.set_vendor_rewards_enabled(supplier, True)
    order_line = order.lines.products().first()
    utils.adjust_order(order)

    assert RewardAdjustment.objects.count() == 0
    assert utils.get_current_points(order.shop, order.customer, supplier) == (0, 0)

    utils.set_vendor_price_per_point_on_earn(supplier, price_per_point_1)
    order.create_payment(order.taxful_total_price)
    order_line_pts = int(utils.get_points_from_order_line(order_line))
    assert utils.get_current_points(order.shop, order.customer, supplier) == (order_line_pts, order_line_pts)

    # refund the order
    order.create_full_refund()

    # points back to initial
    assert utils.get_current_points(order.shop, order.customer, supplier) == (0, 0)


@pytest.mark.parametrize("price_per_point_1, price_per_point_2, order_total, spent_points, initial_pts", [
    (10, 25, 350, 3, 5000),
    (2, 12, 400, 50, 3000),
    (0.1, 0.2, 800, 2, 4000),
])
@pytest.mark.django_db
def test_adjust_order_discount_spend_refund(price_per_point_1, price_per_point_2,
                                            order_total, spent_points, initial_pts):
    cache.clear()
    supplier = factories.get_default_supplier()
    shop = factories.get_default_shop()
    user = factories.create_random_user()
    customer = factories.create_random_person()
    customer.user = user
    customer.save()

    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_earn(supplier, price_per_point_1)
    utils.set_vendor_price_per_point_on_spend(supplier, price_per_point_1)

    RewardCount.grant_points(shop, customer, supplier, initial_pts)
    assert utils.get_current_points(shop, customer, supplier) == (initial_pts, initial_pts)

    order_source = seed_source(user)
    product = factories.create_product(
        sku="the-product",
        shop=order_source.shop,
        supplier=supplier,
        default_price=order_total
    )
    product_line = order_source.add_line(
        line_id="product-line",
        type=OrderLineType.PRODUCT,
        product=product,
        supplier=supplier,
        quantity=1,
        base_unit_price=order_source.create_price(order_total),
    )
    order_source.add_line(
        **utils.get_spend_points_source_line_attrs(order_source, supplier, product_line, spent_points)
    )
    creator = OrderCreator()
    order = creator.create_order(order_source)
    utils.adjust_order(order)

    order_line_pts = utils.get_points_from_order_line(order.lines.products().first())
    spent_pts = utils.get_points_from_order_line(order.lines.discounts().first())
    discount_price = order.lines.discounts().first().taxless_price.value
    assert rndpts(spent_pts) == rndpts(utils.currency_to_points(discount_price, Decimal(price_per_point_1)))

    expected_pts = (
        int(utils.round_transaction_points(initial_pts)),
        int(utils.round_transaction_points(initial_pts + order_line_pts + spent_pts))
    )
    assert utils.get_current_points(shop, customer, supplier) == expected_pts

    order.create_payment(order.taxful_total_price)

    order_line_pts2 = utils.get_points_from_order_line(order.lines.products().first())
    spent_pts2 = utils.get_points_from_order_line(order.lines.discounts().first())
    assert rndpts(order_line_pts) == rndpts(order_line_pts2)

    discount_price = order.lines.discounts().first().taxless_price.value
    assert rndpts(spent_pts) == rndpts(spent_pts2)
    assert rndpts(spent_pts) == -rndpts(-utils.currency_to_points(discount_price, Decimal(price_per_point_1)))

    expected_pts = (
        int(utils.round_transaction_points(initial_pts + order_line_pts + spent_pts)),
        int(utils.round_transaction_points(initial_pts + order_line_pts + spent_pts))
    )
    assert utils.get_current_points(shop, customer, supplier) == (int(expected_pts[0]), int(expected_pts[1]))

    order.create_full_refund()

    expected_pts = (initial_pts, initial_pts)
    assert utils.get_current_points(shop, customer, supplier) == (int(expected_pts[0]), int(expected_pts[1]))


@pytest.mark.parametrize("price_per_point_1, price_per_point_2, order_total", [
    (10, 25, 150),
    (24, 12, 200),
    (0.1, 0.2, 200),
])
@pytest.mark.django_db
def test_adjust_order_refund(price_per_point_1, price_per_point_2, order_total):
        supplier = factories.get_default_supplier()
        utils.set_vendor_rewards_enabled(supplier, True)
        utils.set_vendor_price_per_point_on_earn(supplier, price_per_point_1)
        shop = factories.get_default_shop()
        customer = factories.create_random_person()

        assert utils.get_current_points(shop, customer, supplier) == (0, 0)
        order = create_random_order(order_total, customer=customer, shop=shop)
        order.create_payment(shop.create_price(order_total))
        order_line = order.lines.products().first()
        assert order.is_paid()

        earned_points = utils.get_points_from_order_line(order_line)
        assert utils.get_current_points(shop, customer, supplier) == (int(earned_points), int(earned_points))

        order.create_full_refund()
        assert utils.get_current_points(shop, customer, supplier) == (0, 0)


@pytest.mark.django_db
def test_spend_earn_settings():
    supplier = factories.get_default_supplier()
    utils.set_vendor_rewards_enabled(supplier, True)

    earn_price_per_point = 0.1     # means 10 points for each $1
    spend_price_per_point = 0.01    # means $0.01 for each 1 point

    utils.set_vendor_price_per_point_on_earn(supplier, earn_price_per_point)
    utils.set_vendor_price_per_point_on_spend(supplier, spend_price_per_point)

    # convert 10 spent points into money, it should worth $0.1
    # (spend_price_per_point * points) => (0.01 * 10) = $0.1
    assert rndpts(utils.spend_points_to_currency(supplier, 10)) == Decimal("0.1")

    # convert 100 earned points into money, it should worth $10
    # ((1 / earn_price_per_point) * points) => ((1 / 10) * 100) = $10
    assert rndpts(utils.earn_points_to_currency(supplier, 100)) == Decimal("10")

    # convert $20 into spent points, as each spent point worths $0.01, it should worth 2000 points
    # ((1 / spend_price_per_point) * amount) => (0.01 * 10) = 2000
    assert rndpts(utils.currency_to_spend_points(supplier, 20)) == Decimal("2000")

    # convert $50 into earned points, as each $1 worths 10 earned points, it should worth 500 points
    # (earn_price_per_point * amount) => (10 * 50) = 500
    assert rndpts(utils.currency_to_earn_points(supplier, 50)) == Decimal("500")

    # nothing configured
    supplier2 = Supplier.objects.create(name="Supplier 2")
    assert utils.spend_points_to_currency(supplier2, 10) == Decimal()
    assert utils.earn_points_to_currency(supplier2, 10) == Decimal()
    assert utils.currency_to_spend_points(supplier2, 10) == Decimal()
    assert utils.currency_to_earn_points(supplier2, 10) == Decimal()


@pytest.mark.django_db
@pytest.mark.parametrize("initial_pts, price_per_point, order_total, discount_points, payment_points, percentage", [
    (1000, 1, 100, 20, 10, 30),
    (2000, 0.5, 155, 20, 30, 3.5),
    (1523, 10, 23.5, 60, 5, 31),
    (325, 2, 95.3, 10, 2, 2)
])
def test_adjust_order_with_configs(initial_pts, price_per_point, order_total,
                                   discount_points, payment_points, percentage):

    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_earn(supplier, price_per_point)
    utils.set_vendor_price_per_point_on_spend(supplier, price_per_point)
    utils.set_vendor_earn_total_percentage(supplier, percentage)

    order = create_random_order(order_total, shop=shop)
    RewardCount.grant_points(shop, order.customer, supplier, initial_pts)

    # nothing generated, just the initial points
    assert RewardAdjustment.objects.count() == 1

    utils.adjust_order(order)
    line_pts = utils.get_points_from_order_line(order.lines.products().first())
    assert utils.get_current_points(shop, order.customer, supplier) == (int(initial_pts), int(initial_pts + line_pts))

    OrderLine.objects.create(
        parent_line=order.lines.products().first(),
        order=order,
        supplier=supplier,
        type=OrderLineType.DISCOUNT,
        accounting_identifier=settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER,
        quantity=1,
        base_unit_price_value=-(discount_points / price_per_point)
    )

    utils.adjust_order(order)
    # no change, order is not paid yet
    assert RewardAdjustment.objects.count() == 1
    assert utils.get_current_points(shop, order.customer, supplier) == (int(initial_pts), int(initial_pts + line_pts))

    order.create_payment(order.shop.create_price(order.get_total_unpaid_amount()))

    # user earned points and also spent some through the discount line
    assert RewardAdjustment.objects.count() == 3
    assert OrderLineRewardAdjustment.objects.count() == 2


def test_conversion_utils():
    precision = Decimal("0.0001")

    # $100 = 100 points ($1 per point)
    assert utils.currency_to_points(100, 1).quantize(precision) == Decimal(100).quantize(precision)

    # $100 = 10 points ($10 per point)
    assert utils.currency_to_points(100, 10).quantize(precision) == Decimal(10).quantize(precision)

    # $1 = 100 points ($0.01 per point)
    assert utils.currency_to_points(1, 0.01).quantize(precision) == Decimal(100).quantize(precision)

    # $1 = 0.0001 points ($1000 per point)
    assert utils.currency_to_points(1, 1000).quantize(precision) == Decimal(0.001).quantize(precision)

    # 1000 points = $1000 ($1 per point)
    assert utils.points_to_currency(1000, 1).quantize(precision) == Decimal(1000).quantize(precision)

    # 100 points = $1 ($0.01 per point)
    assert utils.points_to_currency(100, 0.01).quantize(precision) == Decimal(1).quantize(precision)

    # 20000 points = $80 ($0.004 per point)
    assert utils.points_to_currency(20000, 0.004).quantize(precision) == Decimal(80).quantize(precision)

    # 1500000 points = $300 ($0.0002 per point)
    assert utils.points_to_currency(1500000, 0.0002).quantize(precision) == Decimal(300).quantize(precision)


@pytest.mark.django_db
def test_product_required_points():
    initial_points = 10000
    product_price = 500
    product_required_points = 500
    product_quantity = 2

    supplier = factories.get_default_supplier()
    shop = factories.get_default_shop()
    user = factories.create_random_user()
    customer = factories.create_random_person()
    customer.user = user
    customer.save()

    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_earn(supplier, 1)
    utils.set_vendor_price_per_point_on_spend(supplier, 1)

    RewardCount.grant_points(shop, customer, supplier, initial_points)
    assert utils.get_current_points(shop, customer, supplier) == (initial_points, initial_points)

    product1 = factories.create_product("product1", shop=shop, supplier=supplier, default_price=product_price)
    product2 = factories.create_product("product2", shop=shop, supplier=supplier, default_price=product_price)
    utils.set_product_purchase_required_points(supplier, product1, product_required_points)

    order_source = seed_source(user)
    product1_line = order_source.add_line(
        line_id="product1-line",
        type=OrderLineType.PRODUCT,
        product=product1,
        supplier=supplier,
        quantity=product_quantity,
        base_unit_price=order_source.create_price(product_price),
    )
    product2_line = order_source.add_line(
        line_id="product2-line",
        type=OrderLineType.PRODUCT,
        product=product2,
        supplier=supplier,
        quantity=product_quantity,
        base_unit_price=order_source.create_price(product_price),
    )

    assert utils.get_line_purchase_required_points(product1_line) == product_required_points * product_quantity
    assert utils.get_line_purchase_required_points(product1_line, True) == product_required_points
    assert utils.get_line_purchase_required_points(product2_line) == product_price * product_quantity
    assert utils.get_line_purchase_required_points(product2_line, True) == product_price

    product1_spend_line = order_source.add_line(**utils.get_spend_points_source_line_attrs(
        order_source=order_source,
        supplier=supplier,
        parent_line=product1_line,
        points=99999999999999       # try using ALL points of the world
    ))
    # it used the maximum number of required points
    assert product1_spend_line.quantity == product_required_points * product_quantity

    product2_spend_line = order_source.add_line(**utils.get_spend_points_source_line_attrs(
        order_source=order_source,
        supplier=supplier,
        parent_line=product2_line,
        points=99999999999999       # try using ALL points of the world
    ))
    # it used the maximum number of points to pay the entire line
    assert product2_spend_line.quantity == product_price * product_quantity
