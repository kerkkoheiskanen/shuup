# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

import pytest
from django.utils.encoding import force_text

from shuup.core.models import Order, OrderLineType
from shuup.core.order_creator import OrderCreator
from shuup.testing.factories import (
    create_order_with_product, create_product, create_random_person,
    create_random_user, get_default_shop, get_default_supplier
)
from shuup_rewards_multivendor import utils
from shuup_rewards_multivendor.models import RewardAdjustment, RewardCount

from .utils import seed_source

ADJUSTMENT_MATRIX = [
    (["100", "123", "23", "1000"],  2.0, Decimal("24.92"), 20),
    ([10, 10, 12, 24, 44, 44, 50],  2.5, Decimal("4.85"), 2),
    ([332, 230, 22, 36, 44],        1.0, Decimal("6.64"), 3),
    ([98, 99.4, 23, 22, 33],        1.5, Decimal("4.13"), 1),
    ([99.99, 20, 15.5],             3.0, Decimal("4.06"), 1),
    ([40.22, 23, 22, 2],            3.5, Decimal("3.05"), 1),
    ([23, 22, 76],                  2.3, Decimal("2.78"), 2),
    ([2.5, 4.67, 55.5, 300],        1.4, Decimal("5.08"), 1),
    ([33.33, 150],                  1.8, Decimal("3.30"), 1),
    ([99.99],                       5.2, Decimal("5.2"), 2)
]


def rndpts(value):
    return utils.round_transaction_points(value)


@pytest.mark.parametrize("order_total, percentage, expected_points", [
    ("100", 2, 2),
    ("150", 3, 4),
    ("50", 3.5, 1),
    ("50", 1.0, 0),
    ("550", 1.0, 5),
    ("360", 2.5, 9),
    ("133", 1.0, 1),
    ("10", 1.0, 0),
    ("23", 0, 0),
])
@pytest.mark.django_db
def test_simple_adjustments(order_total, percentage, expected_points):
    shop = get_default_shop()
    supplier = get_default_supplier()
    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_earn(supplier, 1)
    utils.set_vendor_earn_total_percentage(supplier, percentage)

    product = create_product("cat", shop=shop, supplier=supplier, default_price=10)
    random_customer = create_random_person()
    order = create_order_with_product(
        product=product,
        supplier=supplier,
        quantity=1,
        taxless_base_unit_price=order_total,
        shop=shop
    )
    order.customer = random_customer
    order.save()
    order.create_payment(order.taxful_total_price)

    assert RewardAdjustment.objects.exists()
    assert order.taxful_total_price.value == Decimal(order_total)

    count_obj = RewardCount.objects.filter(shop_id=shop.id, customer_id=random_customer.id).first()
    assert count_obj.net_count == expected_points
    assert count_obj.gross_count == expected_points


@pytest.mark.django_db
def test_earn_spend_adjustments():
    shop = get_default_shop()
    supplier = get_default_supplier()
    user = create_random_user()
    order_source = seed_source(user)
    random_customer = create_random_person()
    order_source.customer = random_customer

    spend_price_per_point = 0.2     # $0.2 for each point
    earn_price_per_point = 0.025     # 40 points for each $1 ($0.025 for each point)

    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_spend(supplier, spend_price_per_point)
    utils.set_vendor_price_per_point_on_earn(supplier, earn_price_per_point)

    # order total = 150
    order_total = 150
    # let use 10 points in the order
    points_spent = 10
    # give customer 40 points
    initial_pts = 40
    RewardCount.grant_points(shop, random_customer, supplier, initial_pts)

    assert utils.get_current_points(shop, random_customer, supplier) == (initial_pts, initial_pts)

    product = create_product(
        sku="the-product",
        shop=order_source.shop,
        supplier=supplier,
        default_price=order_total
    )
    product_line = order_source.add_line(
        line_id="product-line",
        type=OrderLineType.PRODUCT,
        product=product,
        supplier=supplier,
        quantity=1,
        base_unit_price=order_source.create_price(order_total),
    )
    spent_points_in_money = utils.spend_points_to_currency(supplier, points_spent)
    assert rndpts(spent_points_in_money) == Decimal(2)

    order_source.add_line(
        **utils.get_spend_points_source_line_attrs(order_source, supplier, product_line, points_spent)
    )

    creator = OrderCreator()
    order = creator.create_order(order_source)
    order.create_payment(order.taxful_total_price)

    net_pts, gross_count = utils.get_current_points(shop, random_customer, supplier)

    # total earned = ($150 - $2) / 0.025 = 5920
    assert net_pts == (initial_pts - points_spent + 5920)   # (initial_pts - points_spent + earned)
    assert net_pts == gross_count


@pytest.mark.parametrize("order_totals, percentage, points_gained, spent_points", ADJUSTMENT_MATRIX)
@pytest.mark.django_db
def test_real_life_management(order_totals, percentage, points_gained, spent_points):
    # this means that 20 dollars GIVES customer 1 reward point
    # if order total is 100, percentage is 2, user should gain 2 points
    shop = get_default_shop()
    supplier = get_default_supplier()
    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_earn(supplier, 1)
    utils.set_vendor_price_per_point_on_spend(supplier, 1)
    utils.set_vendor_earn_total_percentage(supplier, percentage)
    product = create_product("cat", shop=shop, supplier=supplier, default_price=10)
    random_customer = create_random_person()
    points_after_orders = Decimal("0")

    for order_total in order_totals:
        order = create_order_with_product(
            product=product, supplier=supplier, quantity=1, taxless_base_unit_price=order_total, shop=shop)
        order.customer = random_customer
        order.save()
        order.create_payment(order.taxful_total_price)
        points_after_orders += utils.get_points_from_order_line(order.lines.products().first())

    assert Decimal(points_after_orders).quantize(Decimal("0.01")) == Decimal(points_gained).quantize(Decimal("0.01"))

    RewardCount.recalculate(shop.id, random_customer.id)  # Make sure the signal run already

    assert Order.objects.paid().count() == len(order_totals)

    count_obj = RewardCount.objects.get(shop_id=shop.id, customer_id=random_customer.id)
    assert count_obj.net_count == count_obj.gross_count == int(points_after_orders)

    count_obj = RewardCount.objects.get(shop_id=shop.id, customer_id=random_customer.id)
    assert count_obj.net_count == int(points_after_orders)
    assert count_obj.gross_count == int(points_after_orders)
    assert force_text(count_obj)


@pytest.mark.django_db
def test_disabled_rewards_adjustments():
    shop = get_default_shop()
    supplier = get_default_supplier()
    utils.set_vendor_rewards_enabled(supplier, True)
    utils.set_vendor_price_per_point_on_earn(supplier, 1)

    product1 = create_product("p1", shop=shop, supplier=supplier, default_price=100)
    product2 = create_product("p2", shop=shop, supplier=supplier, default_price=250)

    # disable points from product 2
    utils.set_product_rewards_disabled(supplier, product2, True)
    user = create_random_user()
    order_source = seed_source(user)
    random_customer = create_random_person()
    order_source.customer = random_customer

    order_source.add_line(
        line_id="product1-line",
        type=OrderLineType.PRODUCT,
        product=product1,
        supplier=supplier,
        quantity=1,
        base_unit_price=order_source.create_price(100),
    )
    order_source.add_line(
        line_id="product2-line",
        type=OrderLineType.PRODUCT,
        product=product2,
        supplier=supplier,
        quantity=1,
        base_unit_price=order_source.create_price(250),
    )

    creator = OrderCreator()
    order = creator.create_order(order_source)
    order.create_payment(order.taxful_total_price)
    assert utils.get_current_points(shop, random_customer, supplier) == (100, 100)

    assert order.lines.products().first().multivendor_reward_adjustments.first().delta == Decimal(100)
    assert order.lines.products().last().multivendor_reward_adjustments.first().delta == Decimal()
