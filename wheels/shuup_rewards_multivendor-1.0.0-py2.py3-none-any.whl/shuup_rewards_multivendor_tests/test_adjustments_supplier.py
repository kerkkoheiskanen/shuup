# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from uuid import uuid4

import pytest

from shuup.core.models import Supplier
from shuup.testing.factories import (
    create_order_with_product, create_product, create_random_person,
    get_default_shop
)
from shuup_rewards_multivendor import utils


def _create_order_for_supplier(shop, supplier, customer, total):
    product = create_product(uuid4().hex, shop=shop, supplier=supplier, default_price=total)
    order = create_order_with_product(
        product=product,
        supplier=supplier,
        quantity=1,
        taxless_base_unit_price=total,
        shop=shop
    )
    order.customer = customer
    order.save()
    order.create_payment(order.taxful_total_price)
    return order


@pytest.mark.django_db
def test_adjustments_multiple_suppliers():
    shop = get_default_shop()
    random_customer = create_random_person()

    supplier1 = Supplier.objects.create(name="Supplier 1")
    supplier2 = Supplier.objects.create(name="Supplier 2")
    utils.set_vendor_rewards_enabled(supplier1, True)
    utils.set_vendor_rewards_enabled(supplier2, True)

    earn_price_per_point = 10
    utils.set_vendor_price_per_point_on_earn(supplier1, earn_price_per_point)
    utils.set_vendor_price_per_point_on_earn(supplier2, earn_price_per_point)

    order_supplier1 = _create_order_for_supplier(shop, supplier1, random_customer, 60)
    order_supplier2 = _create_order_for_supplier(shop, supplier2, random_customer, 150)

    net_count, gross_count = utils.get_current_points(shop, random_customer, supplier1)
    assert net_count == utils.currency_to_points(order_supplier1.taxful_total_price.value, earn_price_per_point)
    assert gross_count == utils.currency_to_points(order_supplier1.taxful_total_price.value, earn_price_per_point)

    net_count, gross_count = utils.get_current_points(shop, random_customer, supplier2)
    assert net_count == utils.currency_to_points(order_supplier2.taxful_total_price.value, earn_price_per_point)
    assert gross_count == utils.currency_to_points(order_supplier2.taxful_total_price.value, earn_price_per_point)
