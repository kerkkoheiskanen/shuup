# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from shuup.admin.forms.widgets import BasePopupChoiceWidget
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.toolbar import get_default_edit_toolbar
from shuup.core.models import Product, ShopProduct
from shuup.discounts.admin.views import (
    ArchivedDiscountListView, DiscountDeleteView, DiscountEditView,
    DiscountListView
)
from shuup.discounts.models import Discount


class MultivendorProductChoiceWidget(BasePopupChoiceWidget):
    browse_kind = "multivendor_product"
    browse_text = _("Select Product")

    def get_object(self, value):
        return Product.objects.get(pk=value)


class VendorDiscountListView(DiscountListView):
    mass_actions = [
        "shuup_multivendor.admin_module.discounts_mass_actions:ArchiveMassAction"
    ]

    def get_queryset(self):
        queryset = Discount.objects.active(get_shop(self.request))
        supplier = get_supplier(self.request)
        if supplier:
            queryset = queryset.filter(supplier=supplier)
        return queryset


class ArchivedVendorDiscountListView(ArchivedDiscountListView):
    mass_actions = [
        "shuup_multivendor.admin_module.discounts_mass_actions:UnarchiveMassAction",
        "shuup_multivendor.admin_module.discounts_mass_actions:DeleteMassAction"
    ]

    def get_queryset(self):
        queryset = Discount.objects.archived(get_shop(self.request))
        supplier = get_supplier(self.request)
        if supplier:
            queryset = queryset.filter(supplier=supplier)
        return queryset


class VendorDiscountForm(DiscountEditView.form_class):
    def __init__(self, *args, **kwargs):
        super(VendorDiscountForm, self).__init__(*args, **kwargs)
        del self.fields["supplier"]
        del self.fields["contact"]
        self.fields["product"].widget = MultivendorProductChoiceWidget(clearable=True)

    def clean(self):
        data = super(VendorDiscountForm, self).clean()

        if data.get("product"):
            if not ShopProduct.objects.filter(product=data["product"], suppliers=get_supplier(self.request)).exists():
                raise forms.ValidationError(_("Invalid product"))

        return data

    def save(self, commit=True):
        instance = super(VendorDiscountForm, self).save(commit)
        instance.supplier = get_supplier(self.request)
        instance.save()
        return instance


class VendorDiscountEditView(DiscountEditView):
    form_class = VendorDiscountForm

    def get(self, request, *args, **kwargs):
        supplier = get_supplier(self.request)
        if not supplier:
            self.object = self.get_object()
            from django.shortcuts import redirect
            if self.object.pk:
                return redirect(reverse_lazy("shuup_admin:discounts.edit", kwargs={"pk": self.object.pk}))
            else:
                return redirect(reverse_lazy("shuup_admin:discounts.new"))

        return super(VendorDiscountEditView, self).get(request, *args, **kwargs)

    def get_queryset(self):
        queryset = Discount.objects.filter(shops=get_shop(self.request))
        supplier = get_supplier(self.request)
        if supplier:
            queryset = queryset.filter(supplier=supplier)
        return queryset

    def get_toolbar(self):
        object = self.get_object()
        delete_url = (
            reverse_lazy("shuup_admin:vendor_discounts.delete", kwargs={"pk": object.pk})
            if object.pk else None)
        return get_default_edit_toolbar(self, self.get_save_form_id(), delete_url=delete_url)


class VendorDiscountDeleteView(DiscountDeleteView):
    def get_queryset(self):
        queryset = Discount.objects.filter(shops=get_shop(self.request))
        supplier = get_supplier(self.request)
        if supplier:
            queryset = queryset.filter(supplier=supplier)
        return queryset
