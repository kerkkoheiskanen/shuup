# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseBadRequest
from django.template.loader import render_to_string
from django.utils.html import escape
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.toolbar import DropdownActionButton, Toolbar
from shuup.admin.utils.permissions import get_missing_permissions
from shuup.admin.utils.picotable import (
    Column, DateRangeFilter, MultiFieldTextFilter, RangeFilter, TextFilter
)
from shuup.admin.utils.views import PicotableListView
from shuup.apps.provides import get_provide_objects
from shuup.core.models import Label, Order, OrderLine, OrderStatus, Shipment
from shuup.core.pricing import TaxfulPrice, TaxlessPrice
from shuup.utils.i18n import format_money, get_locally_formatted_datetime

from shuup_multivendor.admin_module.utils import get_order_status_for_supplier
from shuup_multivendor.signals import (
    all_order_lines_completed, order_line_status_changed,
    vendor_order_completed
)
from shuup_multivendor.utils.configuration import (
    get_completed_status_label_for_shop, get_order_line_labels_for_shop
)
from shuup_multivendor.utils.order import is_line_complete, is_order_completed


class OrderDetailToolbar(Toolbar):
    def __init__(self, order):
        self.order = order
        super(OrderDetailToolbar, self).__init__()
        self.build()

    def build(self):
        self._build_action_button()

    def _build_action_button(self):
        action_menu_items = []

        for button in get_provide_objects("admin_order_toolbar_action_item"):
            # TODO: Figure a proper way...
            if button.visible_for_object(self.order) and "EditAddresses" not in str(button):
                action_menu_items.append(button(object=self.order))

        if action_menu_items:
            self.append(
                DropdownActionButton(
                    action_menu_items,
                    icon="fa fa-star",
                    text=_("Actions"),
                    extra_css_class="btn-inverse",
                )
            )


class FormatterMixin(object):
    def format_taxful_total_price(self, instance, *args, **kwargs):
        supplier = get_supplier(self.request)
        if supplier:
            taxful_total = TaxfulPrice(0, instance.currency)
            for line in instance.lines.filter(supplier=supplier):
                taxful_total += line.taxful_price
            return escape(format_money(taxful_total))
        return escape(format_money(instance.taxful_total_price))

    def format_taxless_total_price(self, instance, *args, **kwargs):
        supplier = get_supplier(self.request)
        if supplier:
            taxless_total = TaxlessPrice(0, instance.currency)
            for line in instance.lines.filter(supplier=supplier):
                taxless_total += line.taxless_price
            return escape(format_money(taxless_total))
        return escape(format_money(instance.taxless_total_price))


class OrderListView(FormatterMixin, PicotableListView):
    model = Order
    default_columns = [
        Column(
            "id", _("Number"),
            filter_config=TextFilter(
                filter_field="id",
                placeholder=_("Filter by number...")
            )
        ),
        Column(
            "reference_number", _("Reference"),
            filter_config=TextFilter(
                filter_field="reference_number",
                placeholder=_("Filter by reference...")
            )
        ),
        Column(
            "customer", _("Customer"), display="format_customer_name",
            filter_config=MultiFieldTextFilter(
                filter_fields=(
                    "customer__email", "customer__name", "billing_address__name",
                    "shipping_address__name", "orderer__name"
                )
            )
        ),
        Column("order_date", _("Order Date"), display="format_order_date", filter_config=DateRangeFilter()),
        Column("status", _("Status"), display="format_order_status"),
        Column(
            "taxful_total_price_value", _("Total"), sort_field="taxful_total_price_value",
            display="format_taxful_total_price", class_name="text-right",
            filter_config=RangeFilter(field_type="number", filter_field="taxful_total_price_value")
        )
    ]

    def __init__(self, *args, **kwargs):
        super(OrderListView, self).__init__(*args, **kwargs)
        self.columns = self.default_columns

    def get_queryset(self):
        from django.db.models import Max
        qs = super(OrderListView, self).get_queryset().filter(
            lines__supplier=get_supplier(self.request)).annotate(Max("id")).order_by()
        return qs

    def get_object_url(self, instance):
        return reverse("shuup_admin:shuup_multivendor.order_line_list", kwargs={"pk": instance.pk})

    def get_toolbar(self):
        return []

    def format_customer_name(self, instance, *args, **kwargs):
        return instance.get_customer_name() or ""

    def format_order_date(self, instance, *args, **kwargs):
        return get_locally_formatted_datetime(instance.order_date)

    def format_order_status(self, instance, *args, **kwargs):
        return get_order_status_for_supplier(self.request, instance).name

    def label(self, instance, *args, **kwargs):
        # format label to make it human readable
        return instance.label.replace("_", " ").title()

    def get_object_abstract(self, instance, item):
        return [
            {"text": "%s" % instance, "class": "header"},
            {"title": _("Reference"), "text": item.get("reference_number")},
            {"title": _("Status"), "text": item.get("status")},
            {"title": _("Total"), "text": item.get("taxful_total_price_value")}
        ]


class OrderLineListView(PicotableListView):
    template_name = "shuup_multivendor/admin/orders/order_lines.jinja"
    model = OrderLine
    mass_actions_provider_key = "multivendor_order_line_list_mass_actions_provider"

    default_columns = [
        Column("id", _("#"), linked=False),
        Column("text", _("Text"), linked=False),
        Column("quantity", _("Quantity"), linked=False),
        Column("price", _("Price"), display="format_price", linked=False),
        Column(
            "labels",
            _("Status"),
            linked=False,
            raw=True,
            display="format_labels",
            sort_field="labels__translations__name",
            filter_config=TextFilter(
                filter_field="labels__translations__name",
                placeholder=_("Filter by status...")
            )
        )
    ]

    def __init__(self):
        super(OrderLineListView, self).__init__()
        self.columns = self.default_columns

    def get_object_abstract(self, instance, item):
        item.update({"_linked_in_mobile": False, "_url": ""})
        return [
            {"text": "%s" % instance, "class": "header"},
            {"title": "", "text": item.get("price")},
            {"title": "", "text": " ", "raw": item.get("labels")}
        ]

    def format_labels(self, instance, *args, **kwargs):
        labels = get_order_line_labels_for_shop(get_shop(self.request))
        if not labels:
            return _("Completed") if is_line_complete(instance) else _("Processing")

        return render_to_string("shuup_multivendor/admin/orders/order_line_status.jinja", {
            "order_line": instance,
            "available_order_lines_labels": labels
        })

    def format_price(self, instance, *args, **kwargs):
        return escape(format_money(instance.taxful_price))

    def get_queryset(self):
        supplier = get_supplier(self.request)
        shop = get_shop(self.request)

        lines = super(OrderLineListView, self).get_queryset().filter(
            order__shop=shop,
            order=self.order,
            product__isnull=False
        )
        if not self.request.user.is_superuser:
            lines = lines.filter(supplier=supplier)

        return lines

    def dispatch(self, request, *args, **kwargs):
        self.order = Order.objects.filter(pk=kwargs["pk"], shop=get_shop(self.request)).first()
        assert self.order, "Invalid Order Id"
        return super(OrderLineListView, self).dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(OrderLineListView, self).get_context_data(**kwargs)
        order = self.order
        context["order"] = order
        context["title"] = _("Order Information")

        context["shipment_section"] = ""
        supplier = get_supplier(self.request)
        if (order.has_products_requiring_shipment(supplier=supplier) or Shipment.objects.filter(order=order).exists()):
            from django.template import loader
            from shuup.admin.modules.orders.sections import ShipmentSection
            shipment_context = {
                "shipments_data": _get_shipments_data(order, self.request),
                "order": order
            }
            context["shipment_section"] = loader.render_to_string(
                template_name=ShipmentSection.template, context=shipment_context, request=self.request
            )

        return context


def set_order_line_status(request, pk=None):
    data = request.POST
    order_line_id = data.get("order_line")
    label_id = data.get("label")

    if not order_line_id:
        return HttpResponseBadRequest()

    supplier = get_supplier(request)
    order = Order.objects.get(pk=pk, shop=request.shop)
    order_line = OrderLine.objects.filter(order=order, supplier=supplier, pk=order_line_id).first()

    if not order_line:
        return HttpResponseBadRequest()

    is_order_completed_for_vendor = is_order_completed(order, supplier)
    lines_not_completed = []
    completed_status_label = get_completed_status_label_for_shop(request.shop)
    if completed_status_label:
        lines_not_completed = list(OrderLine.objects.products().filter(order=order).exclude(
            labels=completed_status_label
        ))

    current_label = order_line.labels.all().first()
    if label_id:
        new_label = Label.objects.get(pk=label_id)
    else:
        new_label = None

    if current_label != new_label:
        order_line.labels.set([new_label] if new_label else [])
        order_line_status_changed.send(
            sender=type(OrderLine),
            order=order,
            order_line=order_line,
            vendor=supplier,
            vendor_user=request.user,
            previous_status=current_label,
            new_status=new_label
        )

        # check whether all order lines of this order has the completed status
        # there must be label configured and some pending line to be completed
        if completed_status_label and lines_not_completed:
            new_lines_not_completed = list(OrderLine.objects.products().filter(order=order).exclude(
                labels=completed_status_label
            ))
            # no lines with status different from the completed one, so, order complete!
            if not new_lines_not_completed:
                all_order_lines_completed.send(sender=type(OrderLine), order=order)

                if order.can_set_complete():
                    order.status = OrderStatus.objects.get_default_complete()
                    order.save()

        # order is now completed for this vendor
        if is_order_completed(order, supplier) and not is_order_completed_for_vendor:
            vendor_order_completed.send(
                sender=type(OrderLine),
                vendor=supplier,
                order=order,
                lines=OrderLine.objects.products().filter(order=order, supplier=supplier)
            )

    return HttpResponse()


def _get_shipments_data(order, request):
    supplier = get_supplier(request)
    create_url_name = "shuup_multivendor.create-shipment"
    delete__url_name = "shuup_multivendor.delete-shipment"
    missing_permissions = get_missing_permissions(request.user, [create_url_name, delete__url_name])
    create_urls = {}
    if create_url_name not in missing_permissions:
        create_urls[supplier.pk] = reverse(
            "shuup_admin:shuup_multivendor.create-shipment", kwargs={"pk": order.pk, "supplier_pk": supplier.pk})

    delete_urls = {}
    if delete__url_name not in missing_permissions:
        for shipment_id in order.shipments.all_except_deleted().values_list("id", flat=True):
            delete_urls[shipment_id] = reverse(
                "shuup_admin:shuup_multivendor.delete-shipment", kwargs={"pk": shipment_id})
    return {
        "suppliers": [supplier],
        "create_urls": create_urls,
        "delete_urls": delete_urls
    }
