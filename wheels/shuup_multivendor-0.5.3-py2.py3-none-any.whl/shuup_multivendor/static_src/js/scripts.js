import haversine from "haversine";
import queryString from "query-string";
import loadGoogleMapsAPI from "load-google-maps-api";
import { geocodeLatLng, getBestGeocodeResult, updateCurrentLocationFilter, refreshFiltersInPlace, setMapLocation } from "./map/utils"


function getLocationParam(paramValue) {
    if (paramValue && paramValue.includes(",")) {
        const [lat, lng] = paramValue.split(",");
        return [parseFloat(lat), parseFloat(lng)];
    }
    return null;
}

function getDistanceParam(paramValue) {
    if (paramValue && paramValue.includes("-")) {
        let [min, max] = paramValue.split("-");
        min = parseFloat(min);
        max = parseFloat(max);
        return [min || 0, max || 0];
    }
    return null;
}


function sortVendorOptions() {
    const parsed = queryString.parse(location.search);
    const locationValue = $("#id_location").val();
    const locationFilter = getLocationParam(locationValue);

    if (locationFilter) {
        const unit = (window.MULTIVENDOR_SETTINGS.distance_unit === "mi" ? "mile" : "km");
        const [lat, lng] = locationFilter;
        const $vendorOptions = $(".vendor-filter-option");
        const $vendorOptionsParent = $vendorOptions.parent();
        const locationInfo = { latitude: lat, longitude: lng };
        const distanceMap = {};

        $vendorOptions.sort((a, b) => {
            const [latA, lngA] = [
                parseFloat(a.getAttribute("data-lat")), parseFloat(a.getAttribute("data-lng"))
            ];
            const [latB, lngB] = [
                parseFloat(b.getAttribute("data-lat")), parseFloat(b.getAttribute("data-lng"))
            ];

            const idA = $(a).find("input[name='vendor']")[0].id;
            const idB = $(b).find("input[name='vendor']")[0].id;

            let distanceA = distanceMap[idA];
            let distanceB = distanceMap[idB];

            if (!distanceA) {
                distanceA = haversine(locationInfo, { latitude: latA, longitude: lngA }, { unit });
                distanceMap[idA] = distanceA;
            }
            if (!distanceB) {
                distanceB = haversine(locationInfo, { latitude: latB, longitude: lngB }, { unit });
                distanceMap[idB] = distanceB;
            }

            if (distanceA > distanceB) return 1;
            if (distanceA < distanceB) return -1;
            return 0;
        });
        const distanceFilter = getDistanceParam(parsed.vendor_dist);
        let shouldRefresh = false;

        $(".vendor-filter-option").each((index, option) => {
            const $option = $(option);
            const id = $option.find("input[name='vendor']")[0].id;
            const distance = distanceMap[id];

            $($option).find(".distance-info").html(
                interpolate("%s%s", [
                    distance.toFixed(1),
                    window.MULTIVENDOR_SETTINGS.distance_unit
                ])
            );
            option.setAttribute("data-distance", distance);

            if (distanceFilter) {
                const [minDistance, maxDistance] = distanceFilter;
                let show = false;
                if (distance >= 0) {
                    if (minDistance && maxDistance) {
                        if (distance >= minDistance && distance <= maxDistance) {
                            show = true;
                        }
                    } else if (maxDistance) {
                        if (distance <= maxDistance) {
                            show = true;
                        }
                    } else if (minDistance) {
                        if (distance >= minDistance) {
                            show = true;
                        }
                    }
                }
                if (show) {
                    $option.show();
                } else {
                    $option.hide();

                    if ($option.find("input").prop("checked")) {
                        shouldRefresh = true;
                    }
                }
            }
        });

        $vendorOptions.detach().appendTo($vendorOptionsParent);

        if (shouldRefresh) {
            $vendorOptions.find("input").prop("checked", false);
            refreshFiltersInPlace();
        }
    }
}

function checkLocationParam() {
    // check whether the current location params from the hidden input is the same as the one in the URL
    const parsed = queryString.parse(location.search);
    const urlLocation = parsed.location;
    const locationValue = $("#id_location").val();

    if (urlLocation != locationValue) {
        $("#id_location").val(urlLocation);
        if (urlLocation && urlLocation.includes(",")) {
            const [lat, lng] = urlLocation.split(",");
            setMapLocation(parseFloat(lat), parseFloat(lng));
        }
    }
}

function geocodeCurrentLocation() {
    const newLocation = getLocationParam($("#id_location").val());
    const addressFields = document.getElementsByClassName("location-address-field");

    if (newLocation && addressFields.length) {
        const newLocationPos = { lat: newLocation[0], lng: newLocation[1] };

        geocodeLatLng(newLocationPos).then((results) => {
            const bestLocation = getBestGeocodeResult(results);
            if (bestLocation) {
                addressFields[0].setAttribute("value", bestLocation.formatted_address);
            } else {
                addressFields[0].setAttribute("value", newLocationPos.lat + ", " + newLocationPos.lng);
            }
        }).catch(() => {
            addressFields[0].setAttribute("value", newLocationPos.lat + ", " + newLocationPos.lng);
        });
    }
}

function createAutocomplete(input) {
    const autocomplete = new google.maps.places.Autocomplete(input);
    if (window.MULTIVENDOR_SETTINGS.gmaps_countries) {
        autocomplete.setComponentRestrictions({ 'country': window.MULTIVENDOR_SETTINGS.gmaps_countries });
    }
    autocomplete.setFields(['address_components', 'geometry', 'icon', 'name']);
    autocomplete.addListener('place_changed', () => {
        const place = autocomplete.getPlace();
        if (!place.geometry) {
            return;
        }

        // If the place has a geometry, then present it on a map.
        setMapLocation(place.geometry.location.lat(), place.geometry.location.lng());
        updateCurrentLocationFilter(place.geometry.location.lat(), place.geometry.location.lng());
    });

    window.addEventListener("ShuupMultivendor.CurrentLocationUpdated", (e) => {
        geocodeCurrentLocation();
    });
}

(() => {
    // Vendor Filter for Product List exists here, setup events to
    // sort vendors by distance when current location exists
    if (document.getElementsByClassName("vendor-filter-option").length) {
        window.addEventListener("Shuup.FiltersRefreshed", (e) => {
            sortVendorOptions();

            if ($("#id_location").val() && !$("#id_address").val()) {
                geocodeCurrentLocation();
            }
        });
        sortVendorOptions();
    }

    window.addEventListener("popstate", function (e) {
        checkLocationParam();
        geocodeCurrentLocation();
    });

    if (window.MULTIVENDOR_SETTINGS && window.MULTIVENDOR_SETTINGS.gmaps_api_key) {
        loadGoogleMapsAPI({
            key: window.MULTIVENDOR_SETTINGS.gmaps_api_key,
            libraries: ["places"]
        }).then(() => {
            window.dispatchEvent(new CustomEvent("ShuupMultivendor.GoogleMapsInited"));

            const addressFields = document.getElementsByClassName("location-address-field");
            if (addressFields.length) {
                createAutocomplete(addressFields[0]);
            }
        }).catch((err) => {
            console.error(err);
        });
    } else {
        console.warn("Settings not found. Google Maps was not initialized.")
    }
})();
