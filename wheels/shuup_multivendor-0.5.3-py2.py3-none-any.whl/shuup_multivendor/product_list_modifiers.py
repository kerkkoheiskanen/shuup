# -*- coding: utf-8 -*-
from decimal import Decimal, InvalidOperation
from itertools import chain

from django import forms
from django.conf import settings
from django.db.models import F, Q, Value
from django.db.models.fields import DecimalField
from django.template.loader import render_to_string
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import ShopProduct, ShopProductVisibility, Supplier
from shuup.front.forms.product_list_modifiers import SimpleProductListModifier
from shuup.front.utils.sorts_and_filters import (
    get_configuration, get_form_field_label
)
from shuup.utils.i18n import format_number

from shuup_multivendor.models import DistanceUnit

from .db_functions import ACos, Cos, Degrees, Radians, Round, Sin

EARTH_DISTANCE_PER_DEGREE = Decimal(111.045)   # 111.045km in a latitude degree


def get_distance_unit_label(distance_unit, plural):
    if distance_unit == DistanceUnit.km:
        return _("Kilometers") if plural else _("Kimometer")
    return _("Miles") if plural else _("Mile")


class VendorChoiceFilterWidget(forms.Select):
    def render(self, name, value, attrs=None, choices=()):
        if value is None:
            value = []
        choices_to_render = []

        for vendor_pk, vendor in chain(self.choices, choices):
            choices_to_render.append((vendor_pk, vendor))

        return mark_safe(
            render_to_string(
                "shuup_multivendor/supplier/vendor_choice.jinja", {
                    "name": name,
                    "values": value,
                    "choices": choices_to_render,
                    "one_choice": True
                }
            )
        )


def annotate_distance(queryset, lat, lng, address_field_prefix):
    return queryset.annotate(
        distance=Round(
            Degrees(
                ACos(
                    Cos(Radians(Value(lat))) *
                    Cos(Radians(F("{}__latitude".format(address_field_prefix)))) *
                    Cos(Radians(Value(lng) - F("{}__longitude".format(address_field_prefix)))) +
                    Sin(Radians(Value(lat))) *
                    Sin(Radians(F("{}__latitude".format(address_field_prefix))))
                )
            ) * Value(EARTH_DISTANCE_PER_DEGREE),
            3,
            output_field=DecimalField()
        )
    )


class VendorDistanceProductListFilter(SimpleProductListModifier):
    is_active_key = "filter_products_by_vendor_distance"
    is_active_label = _("Filter products by vendor distance")
    ordering_key = "filter_products_by_vendor_distance_ordering"
    ordering_label = _("Ordering for filter by vendor distance")
    choices_key = "filter_products_by_vendor_distance_choices_key"
    required_key = "filter_products_by_vendor_distance_required_key"

    def get_fields(self, request, category=None):
        configuration = get_configuration(request.shop, category)
        choices = configuration.get(self.choices_key)
        required = configuration.get(self.required_key)
        distance_unit = DistanceUnit(settings.SHUUP_MULTIVENDOR_DISTANCE_UNIT)

        if not choices:
            return

        field_choices = get_distance_ranges(choices.split(","), distance_unit)

        if not required:
            field_choices = [(None, "-------")] + field_choices

        return [
            ("vendor_dist", forms.ChoiceField(
                required=False,
                choices=field_choices,
                initial=(field_choices[0][0] if required else None),
                label=get_form_field_label("vendor_dist", _("Vendor distance"))
            ))
        ]

    def get_queryset(self, queryset, data):     # noqa (C901)
        request = data.get("request")
        vendor_dist = data.get("vendor_dist")
        category = data.get("category")

        if not request:
            return queryset

        if not vendor_dist:
            configuration = get_configuration(request.shop, category)
            required = configuration.get(self.required_key)

            # force and use the first option value
            if required:
                distance_unit = DistanceUnit(settings.SHUUP_MULTIVENDOR_DISTANCE_UNIT)
                choices = configuration.get(self.choices_key)
                field_choices = get_distance_ranges(choices.split(","), distance_unit)
                vendor_dist = field_choices[0][0]
            else:
                return queryset

        try:
            min_dist, max_dist = vendor_dist.split("-", 1)
            min_dist = Decimal(min_dist or 0)
            max_dist = Decimal(max_dist or 0)
        except InvalidOperation:
            return queryset

        location = data.get("location")
        if not location or "," not in location:
            return queryset

        lat, lng = location.split(",")[:2]
        try:
            lat = Decimal(lat)
            lng = Decimal(lng)

            # transform the distance in KM to use in the queryset
            if settings.SHUUP_MULTIVENDOR_DISTANCE_UNIT == "mi":
                min_dist *= Decimal(1.60934)
                max_dist *= Decimal(1.60934)

            if lat and lng:
                queryset = annotate_distance(
                    queryset, lat, lng, "shop_products__suppliers__contact_address"
                )
                if max_dist and min_dist:
                    queryset = queryset.filter(distance__gte=min_dist, distance__lte=max_dist)
                elif max_dist:
                    queryset = queryset.filter(distance__lte=max_dist)
                else:
                    queryset = queryset.filter(distance__gte=min_dist)

        except InvalidOperation:
            pass

        return queryset

    def get_admin_fields(self):
        default_fields = super(VendorDistanceProductListFilter, self).get_admin_fields()
        default_fields[0][1].help_text = _("Check this to allow products to be filtered by vendor distance.")
        default_fields[1][1].help_text = _(
            "Use a numeric value to set the order in which the vendor distance filter will appear on the "
            "product listing page."
        )
        choices = forms.CharField(
            label=_("Distances"),
            required=False,
            help_text=_("Enter a comma-separated list of distance ranges, e.g. 5,7.5,15.")
        )
        required = forms.BooleanField(
            label=_("Required"),
            required=False,
            help_text=_(
                "Whether this filter should be required and always used. If so, the first option will "
                "be selected by default."
            )
        )
        return default_fields + [
            (self.choices_key, choices),
            (self.required_key, required),
        ]


def get_distance_ranges(distance_ranges, distance_unit):
    ranges = []
    if not distance_ranges or len(distance_ranges) < 2:
        return ranges

    for index, distance in enumerate(distance_ranges):
        if not distance:
            continue

        if index == 0:
            ranges.append(
                ("-%s" % distance, _("Under {min_limit} {unit}").format(
                    min_limit=format_number(distance),
                    unit=get_distance_unit_label(distance_unit, distance != Decimal(1)).lower()
                ))
            )
        else:
            ranges.append(
                (
                    "%s-%s" % (distance_ranges[index-1], distance),
                    _("{min} {unit_min} to {max} {unit_max}").format(
                        min=format_number(distance_ranges[index-1]),
                        max=format_number(distance),
                        unit_min=get_distance_unit_label(distance_unit, distance_ranges[index-1] != Decimal(1)).lower(),
                        unit_max=get_distance_unit_label(distance_unit, distance != Decimal(1)).lower()
                    )
                )
            )
            # the latest
            if index == len(distance_ranges) - 1:
                ranges.append(
                    ("%s-" % distance, _("{max_limit} {unit} & Above").format(
                        max_limit=distance,
                        unit=get_distance_unit_label(distance_unit, distance != Decimal(1)).lower()
                    ))
                )

    return ranges


class AddressLocationFilter(SimpleProductListModifier):
    is_active_key = "filter_products_by_location"
    is_active_label = _("Filter products by location")
    ordering_key = "ordering_products_by_location"
    ordering_label = _("Ordering for filter by location")

    def get_fields(self, request, category=None):
        initial_address = ""
        initial_location = ""

        if request.customer:
            address_field = "default_{}".format(settings.SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS)
            address = getattr(request.customer, address_field, None)

            if address:
                if address.latitude and address.longitude:
                    initial_location = "{},{}".format(address.latitude, address.longitude)
                    initial_address = ", ".join([
                        field
                        for field in (address.street, address.street2, address.city, address.postal_code)
                        if field.strip()
                    ])

        return [
            ("address", forms.CharField(
                label=_("Location"),
                required=False,
                initial=initial_address,
                widget=forms.TextInput(attrs={
                    "class": "location-address-field",
                    "data-no-auto-update": 1,
                    "value": initial_address
                })
            )),
            ("location", forms.CharField(
                required=False,
                widget=forms.HiddenInput(attrs=dict(value=initial_location)),
                initial=initial_location
            ))
        ]

    def get_admin_fields(self):
        default_fields = super(AddressLocationFilter, self).get_admin_fields()
        default_fields[0][1].help_text = _(
            "Check this to allow filtering products by the current user address. This also enables "
            "the usage of Sort by Distance."
        )
        default_fields[1][1].help_text = _(
            "Use a numeric value to set the order in which this filter will appear on the product listing page."
        )
        return default_fields


class SortVendorsByDistance(SimpleProductListModifier):
    is_active_key = "sort_products_by_distance"
    is_active_label = _("Sort products by distance")
    ordering_key = "sort_products_by_distance_ordering"
    ordering_label = _("Ordering for sort by distance")

    def should_use(self, configuration):
        if not configuration:
            return

        # AddressLocationFilter should be enabled too
        return (
            bool(configuration.get(self.is_active_key)) and
            bool(configuration.get(AddressLocationFilter.is_active_key))
        )

    def get_fields(self, request, category=None):
        return [
            ("sort", forms.CharField(
                required=False, widget=forms.Select(), label=get_form_field_label("sort", _('Sort'))))
        ]

    def sort_products(self, request, products, data):
        sort = data.get("sort")
        if not products or sort not in ("distance_a", "distance_d"):
            return products

        # no distance property
        if not hasattr(products[0], "distance"):
            return products

        reverse = bool(sort.endswith('_d'))
        return sorted(products, key=lambda item: item.distance, reverse=reverse)

    def get_choices_for_fields(self):
        return [
            ("sort", [
                ("distance_a", _("Distance - Nearest first")),
                ("distance_d", _("Distance - Farther first")),
            ])
        ]

    def get_admin_fields(self):
        default_fields = super(SortVendorsByDistance, self).get_admin_fields()
        default_fields[0][1].help_text = _(
            "Check this to allow products to be sortable by distance."
        )
        default_fields[1][1].help_text = _(
            "Use a numeric value to set the order in which the the filter will appear on the "
            "product listing page."
        )
        return default_fields

    def get_queryset(self, queryset, data):
        request = data.get("request")
        if not request or not data.get("sort"):
            return queryset

        sort = data.get("sort")
        location = data.get("location")
        if sort not in ("distance_a", "distance_d") or not location or "," not in location:
            return queryset

        lat, lng = location.split(",")[:2]
        try:
            lat = Decimal(lat)
            lng = Decimal(lng)

            if lat and lng:
                queryset = annotate_distance(
                    queryset, lat, lng, "shop_products__suppliers__contact_address"
                ).order_by("distance" if sort == "distance_a" else "-distance")
        except InvalidOperation:
            pass

        return queryset


class VendorProductListFilter(SimpleProductListModifier):
    is_active_key = "filter_products_by_vendor"
    is_active_label = _("Filter products by vendor")
    ordering_key = "filter_products_by_vendor_ordering"
    ordering_label = _("Ordering for filter by vendor")

    def get_fields(self, request, category=None):
        shop_products_qs = ShopProduct.objects.filter(
            shop=request.shop
        ).exclude(visibility=ShopProductVisibility.NOT_VISIBLE)

        if category:
            shop_products_qs = shop_products_qs.filter(categories=category)

        queryset = Supplier.objects.enabled().filter(
            Q(shop_products__in=shop_products_qs),
            shops=request.shop
        ).distinct()

        if not queryset.exists():
            return

        return [
            (
                "vendor",
                forms.ChoiceField(
                    choices=([(vendor.pk, vendor) for vendor in queryset]),
                    required=False,
                    label=get_form_field_label("vendor", _("Vendors")),
                    widget=VendorChoiceFilterWidget()
                )
            )
        ]

    def get_filters(self, request, data):
        vendor = data.get("vendor")
        if vendor:
            return Q(shop_products__suppliers__id=vendor)

    def get_admin_fields(self):
        default_fields = super(VendorProductListFilter, self).get_admin_fields()
        default_fields[0][1].help_text = _(
            "Check this to allow products to be filterable by vendor."
        )
        default_fields[1][1].help_text = _(
            "Use a numeric value to set the order in which the vendor filters will appear."
        )
        return default_fields
