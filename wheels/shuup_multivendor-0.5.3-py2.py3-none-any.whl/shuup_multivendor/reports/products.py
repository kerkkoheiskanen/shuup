# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import six
from django.utils.translation import ugettext_lazy as _
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import Product, ProductMode
from shuup.core.pricing import get_price_info, PricingContext
from shuup.core.shop_provider import get_shop
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import format_money

from shuup_multivendor.reports.utils import ProductReportForm


class ProductReport(ShuupReportBase):
    identifier = "multivendor-product-report"
    title = _("Vendor Product Report")
    description = _("This report shows current price, physical and logical stocks for all stocked products.")
    filename_template = "multivendor-product-report-%(time)s"
    form_class = ProductReportForm

    schema = [
        {"key": "name", "title": _("Name")},
        {"key": "price", "title": _("Price")},
        {"key": "physical_stock", "title": _("Physical stock")},
        {"key": "logical_stock", "title": _("Logical stock")}
    ]

    def get_objects(self):
        supplier = get_supplier(self.request)
        queryset = (
            Product.objects
            .all_except_deleted(shop=self.shop)
            .filter(
                shop_products__suppliers=supplier,
                mode__in=[ProductMode.VARIATION_CHILD, ProductMode.NORMAL])
        )

        if self.options.get("product"):
            queryset = queryset.filter(id=self.options["product"])

        if self.options.get("category"):
            queryset = queryset.filter(shop_products__categories=self.options["category"])

        return queryset

    def get_data(self):
        data = []
        supplier = get_supplier(self.request)
        if supplier:
            shop = get_shop(self.request)
            price_context = PricingContext(shop=shop, customer=self.request.customer, supplier=supplier)

            product_ids = self.get_objects().values_list("id", flat=True)
            product_name_to_id_map = dict(
                Product.objects.filter(id__in=product_ids).values_list("id", "translations__name"))
            stock_statuses = supplier.get_stock_statuses(product_ids)
            for prod_id, stock_status in six.iteritems(stock_statuses):
                price_info = get_price_info(price_context, prod_id)

                data.append({
                    "name": product_name_to_id_map[prod_id],
                    "price": format_money(price_info.price),
                    "physical_stock": "%.3f" % stock_status.physical_count,
                    "logical_stock": "%.3f" % stock_status.logical_count
                })

            data.sort(key=lambda x: x["name"])

        return self.get_return_data(data, has_totals=False)
