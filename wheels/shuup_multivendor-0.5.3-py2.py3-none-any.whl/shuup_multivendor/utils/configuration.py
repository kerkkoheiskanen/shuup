# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from shuup import configuration
from shuup.core.models import Label


def get_order_line_labels_for_shop(shop):
    """
    Returns a queryset of Label that can be used for OrderLine status
    """
    multivendor_order_line_labels_ids = configuration.get(shop, "multivendor_order_line_labels")
    if multivendor_order_line_labels_ids:
        return Label.objects.filter(id__in=multivendor_order_line_labels_ids)
    return Label.objects.none()


def set_order_line_labels_for_shop(shop, labels):
    """
    Sets the labels that can be used for OrderLine status
    """
    labels = [label.pk for label in labels] if labels else None
    configuration.set(shop, "multivendor_order_line_labels", labels)


def set_completed_status_label_for_shop(shop, label):
    """
    Sets the labels that indicates a completed status
    """
    label = label.pk if label else None
    configuration.set(shop, "multivendor_completed_status_label", label)


def get_completed_status_label_for_shop(shop):
    completed_status_label_id = configuration.get(shop, "multivendor_completed_status_label")
    if completed_status_label_id:
        return Label.objects.filter(pk=completed_status_label_id).first()
