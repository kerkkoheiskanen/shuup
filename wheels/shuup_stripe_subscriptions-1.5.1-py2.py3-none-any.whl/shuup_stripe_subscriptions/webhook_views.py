# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

import json

import six
from django.core.exceptions import ValidationError
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

import stripe

from . import event_handler
from ._json_responses import BadRequest, NotFound
from .models import StripeSubscriptionPaymentProcessor, WebhookEventLogEntry


class Error(Exception):
    def __init__(self, error_response):
        self.error_response = error_response


@csrf_exempt
def webhook_view(request, slug):
    log_entry = WebhookEventLogEntry.log_request(request, commit=False)

    try:
        processor = _get_processor_by_slug(slug)
        log_entry.processor = processor

        signing_key = processor.webhook_signing_key
        payload = _get_verified_payload(request, signing_key)

        event = _get_event(payload, processor.secret_key)
        log_entry.event = event.serialize(None)

        result = event_handler.handle_event(event)
        log_entry.result_code = result.code.value
        log_entry.result_message = result.message

        return JsonResponse({'message': result.message})

    except ValidationError as error:
        # Re-raise ValidationError as another type exception so that
        # Shuup's ProblemMiddleware won't catch it, since then we
        # wouldn't get anything to Sentry.
        six.raise_from(
            Exception('Validation error: {}'.format(error)),
            error)

    except Error as error:
        return error.error_response

    finally:
        log_entry.save()
        WebhookEventLogEntry.objects.for_cleanup().delete()


def _get_processor_by_slug(slug):
    try:
        return StripeSubscriptionPaymentProcessor.objects.get(
            webhook_slug=slug)
    except StripeSubscriptionPaymentProcessor.DoesNotExist:
        raise Error(NotFound('No such payment processor'))


def _get_verified_payload(request, signing_key, max_age=300):
    signature_header = request.META.get('HTTP_STRIPE_SIGNATURE')
    payload = _get_decoded_payload(request)

    if not signature_header:
        raise Error(BadRequest('Stripe signature header is missing'))

    try:
        stripe.WebhookSignature.verify_header(
            payload, signature_header, signing_key, max_age)
    except stripe.error.SignatureVerificationError:
        raise Error(BadRequest('Invalid signature'))

    return payload


def _get_decoded_payload(request):
    try:
        return request.body.decode('utf-8')
    except UnicodeDecodeError:
        raise Error(BadRequest('Invalid encoding, expecting UTF-8'))


def _get_event(payload, api_key):
    try:
        data = json.loads(payload)
    except Exception:
        raise Error(BadRequest('Invalid JSON data'))

    if not isinstance(data, dict):
        raise Error(BadRequest('Expecting a dict'))

    for key in ['id', 'object', 'data']:
        if key not in data:
            raise Error(BadRequest('No "{}" in JSON data'.format(key)))

    return stripe.Event.construct_from(data, api_key)
