# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from enumfields import Enum


class InvoiceStatus(Enum):
    PENDING = 0  # Invoice is going to be charged
    CHARGING = 1  # invoice is sent to Stripe
    CHARGED = 2  # Invoice is accepted by Stripe
    CANCELLED = 3  # TODO: Review need.


class InvoiceType(Enum):
    NORMAL = 0
    FREE_TRIAL = 1


class InvoiceLineType(Enum):
    NORMAL = 0
    COMMISSION = 1
    FIXED_PRICE = 2
    DISCOUNT = 3


class EventHandlerResultCode(Enum):
    handled = 'H'
    ignored = 'I'
