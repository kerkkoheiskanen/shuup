# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from shuup_stripe_subscriptions.models import (
    StripeCustomer, StripePlan, StripeSubscription)


def get_or_create_customer(self, order):
    if order.customer:
        email = order.customer.email
    else:
        email = order.email

    customer_id = "cus_A2mkCFg5C2dJAG"

    internal_obj = StripeCustomer.objects.create(
        customer=order.customer,
        external_id=customer_id,
    )

    return internal_obj, {
        "id": customer_id,
        "object": "customer",
        "account_balance": 0,
        "created": 1486020712,
        "currency": "usd",
        "default_source": None,
        "delinquent": False,
        "description": None,
        "discount": None,
        "email": email,
        "livemode": False,
        "metadata": {
        },
        "shipping": None,
        "sources": {
            "object": "list",
            "data": [
            ],
            "has_more": False,
            "total_count": 0,
            "url": "/v1/customers/cus_A2mkCFg5C2dJAG/sources"
        },
        "subscriptions": {
            "object": "list",
            "data": [],
            "has_more": False,
            "total_count": 0,
            "url": "/v1/customers/cus_A2mkCFg5C2dJAG/subscriptions"
        }
    }


def get_or_create_plan(self, subscription, product):

    external_id = subscription.plan.unique_key
    internal_obj = StripePlan.objects.create(
        plan=subscription.plan,
        external_id=external_id,
    )

    return internal_obj, {
      "id": external_id,
      "object": "plan",
      "amount": int(subscription.plan.amount_value * 100),
      "created": 1486020703,
      "currency": subscription.plan.shop.currency.lower(),
      "interval": subscription.plan.interval,
      "interval_count": 1,
      "livemode": False,
      "metadata": {},
      "name": "%s - %s" % (product.name, subscription.plan.name),
      "statement_descriptor": None,
      "trial_period_days": None
    }


def get_or_create_subscription(
        self, subscription, stripe_customer, stripe_plan,
        subscription_id='sub_A2mkMZHRppnRUS'):
    internal_obj = StripeSubscription.objects.create(
        subscription=subscription,
        external_id=subscription_id,
    )
    return internal_obj, {
        "id": subscription_id,
        "object": "subscription",
        "application_fee_percent": None,
        "cancel_at_period_end": False,
        "canceled_at": None,
        "created": 1486020704,
        "current_period_end": 1488439904,
        "current_period_start": 1486020704,
        "customer": stripe_customer["id"],
        "discount": None,
        "ended_at": None,
        "items": {
            "object": "list",
            "data": [
                {
                    "id": "si_19if4G2eZvKYlo2Cwmk9iSNi",
                    "object": "subscription_item",
                    "created": 1486020704,
                    "plan": stripe_plan,
                    "quantity": 1
                }
            ],
            "has_more": False,
            "total_count": 1,
            "url": "/v1/subscription_items?subscription=sub_A2kZkjY8hRU2ku"
        },
        "livemode": False,
        "metadata": {},
        "plan": stripe_plan,
        "quantity": 1,
        "start": 1486020704,
        "status": "active",
        "tax_percent": None,
        "trial_end": None,
        "trial_start": None
    }


def get_or_create_subscription2(*args, **kwargs):
    return get_or_create_subscription(
        *args, subscription_id='sub_As9dc8ShJ86AFK', **kwargs)


#
#
# def handle_order(order):
#     # create customer to stripe
#     stripe_customer = get_or_create_customer(order.customer)
#     # create plan to stripe
#     for product_line in order.lines.products().filter(product__mode=ProductMode.SUBSCRIPTION):
#         subscription = product_line.subscription.first()
#         stripe_plan = get_or_create_plan(subscription, product_line.product)
#         stripe_subscription = get_or_create_subscription(stripe_customer, stripe_plan)
