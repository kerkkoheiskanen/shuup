import pytest
from mock import patch
from shuup.testing.factories import get_default_shop
from shuup.testing.utils import apply_request_middleware
from shuup_subscriptions.checkout import SubscriptionBasket
from shuup_subscriptions.models import Plan, Subscription, SubscriptionPayment

from shuup_stripe_subscriptions import event_handler
from shuup_stripe_subscriptions.models import (
    Invoice, InvoiceLine, StripeSubscription,
    StripeSubscriptionPaymentProcessor)
from shuup_stripe_subscriptions.modules.subscriber import StripeSubscriber

from .events import SubscriptionOrderingEventFlow
from .mocks import (
    get_or_create_customer, get_or_create_plan, get_or_create_subscription,
    get_or_create_subscription2)
from .payloads import NewUserSubscriptionFlow
from .utils import create_order_for_stripe

SUBSCRIPTION_ID = "sub_A2mkMZHRppnRUS"  # This is a subscription id in payloads.py


@pytest.mark.django_db
@pytest.mark.parametrize("flow_cls", [NewUserSubscriptionFlow])
@patch.object(StripeSubscriber, 'get_or_create_customer', get_or_create_customer)
@patch.object(StripeSubscriber, 'get_or_create_plan', get_or_create_plan)
@patch.object(StripeSubscriber, 'get_or_create_subscription', get_or_create_subscription)
def test_flow(rf, flow_cls):
    plan_price = 19.99
    shop = get_default_shop()
    plan_data = dict(
        shop=shop,
        is_active=True,
        amount_value=plan_price,
        name="test_plan",
    )
    plan = Plan.objects.create(**plan_data)

    user_email = "admin@example.com"
    payment_processor = StripeSubscriptionPaymentProcessor.objects.create(
        secret_key="x", publishable_key="x")
    order = create_order_for_stripe(payment_processor, plan=plan)
    order.payment_data = {"stripe": {
        "token": 'FAKE_TOKEN_ID',
        "email": user_email
    }}
    order.save()

    # create subscription with plan
    create_subscriptions_for_order(rf, order, plan)

    service = order.payment_method
    payment_processor.process_payment_return_request(service, order, rf.post("/"))

    assert Subscription.objects.count() == 1

    flow = flow_cls()
    for event in flow.get_events():
        event_handler.handle_event(event)

    assert Invoice.objects.count() == 1
    assert InvoiceLine.objects.count() == 1
    assert SubscriptionPayment.objects.count() == 1


@pytest.mark.django_db
@pytest.mark.parametrize("flow_cls", [SubscriptionOrderingEventFlow])
@patch.object(StripeSubscriber, 'get_or_create_customer', get_or_create_customer)
@patch.object(StripeSubscriber, 'get_or_create_plan', get_or_create_plan)
@patch.object(StripeSubscriber, 'get_or_create_subscription', get_or_create_subscription2)
def test_subscription_ordering(rf, flow_cls):
    plan_price = 19.99
    shop = get_default_shop()
    plan_data = dict(
        shop=shop,
        is_active=True,
        amount_value=plan_price,
        name="test_plan",
    )
    plan = Plan.objects.create(**plan_data)

    user_email = "admin@example.com"
    payment_processor = StripeSubscriptionPaymentProcessor.objects.create(
        secret_key="x", publishable_key="x")
    order = create_order_for_stripe(payment_processor, plan=plan)
    order.payment_data = {"stripe": {
        "token": 'FAKE_TOKEN_ID',
        "email": user_email
    }}
    order.save()
    # create subscription with plan
    create_subscriptions_for_order(rf, order, plan)

    service = order.payment_method
    payment_processor.process_payment_return_request(service, order, rf.post("/"))

    assert StripeSubscription.objects.get().external_id == 'sub_As9dc8ShJ86AFK'

    flow = flow_cls()
    results = []
    for event in flow.get_events():
        result = event_handler.handle_event(event)
        results.append((event.type, result.code.value, result.message))

    assert results == [
        ('plan.created', 'I', "Unhandled event type: plan.created"),
        ('customer.created', 'I', "Unhandled event type: customer.created"),
        ('invoice.created', 'I', "Unhandled event type: invoice.created"),
        ('customer.updated', 'I', "Unhandled event type: customer.updated"),
        ('customer.source.created', 'I', "Unhandled event type: customer.source.created"),
        ('invoice.payment_succeeded', 'H', "Created invoice 1 with payment 1"),
        ('customer.subscription.created', 'I', "Unhandled event type: customer.subscription.created"),
        ('charge.succeeded', 'I', "Unhandled event type: charge.succeeded"),
    ]
    assert Invoice.objects.get().external_id == 'in_1AWPJlI4n88fqZHqvDHA0oJ0'
    assert InvoiceLine.objects.get().external_id == 'sub_As9dc8ShJ86AFK'
    assert SubscriptionPayment.objects.get().payment_identifier == (
        'Stripe-ch_1AWPJlI4n88fqZHq13XwHP52')


def create_subscriptions_for_order(rf, order, plan):
    request = apply_request_middleware(rf.get("/"))
    basket = SubscriptionBasket(request)
    basket.prices_include_tax = order.prices_include_tax
    basket.currency = order.currency
    if order.extra_data is None:
        order.extra_data = {}
    if order.shipping_data is None:
        order.shipping_data = {}
    order.save()
    basket.update_from_order(order)
    prod_line = order.lines.products().first()
    basket.add_product(
        supplier=prod_line.supplier, shop=order.shop,
        product=prod_line.product, quantity=1)
    basket.set_plan(plan)
    subscriptions = basket.create_subscriptions_for_order(order)
    assert subscriptions
    return subscriptions
