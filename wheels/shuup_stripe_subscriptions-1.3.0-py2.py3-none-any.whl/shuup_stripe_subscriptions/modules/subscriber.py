# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.

import stripe
from django.conf import settings
from shuup.core.models import ProductMode
from shuup_subscriptions.enums import PlanInterval

from ..models import StripeCustomerSubscription, StripePlan, StripeSubscription


class StripeSubscriber(object):

    def __init__(self, secret_key, order):
        self.secret_key = secret_key
        self.order = order
        stripe.api_key = self.secret_key
        self.stripe_token = self.order.payment_data["stripe"]["token"]
        self.card_email = self.order.payment_data["stripe"]["email"]

    def get_or_create_plan(self, subscription, product):
        plan_data = {
            "id": subscription.plan.unique_key,
            "amount": int(subscription.plan.amount_value * 100),
            "interval": subscription.plan.interval.value,
            "currency": subscription.plan.shop.currency.lower(),
        }

        if settings.STRIPE_SUBSCRIPTIONS_API_VERSION == "2018":
            plan_data["product"] = {
                "id": product.id,
                "name": "%s - %s" % (product.name, subscription.plan.name),
            }
        else:
            plan_data["name"] = "%s - %s" % (product.name, subscription.plan.name)

        if subscription.plan.interval == PlanInterval.TWO_WEEKS:
            plan_data.update({
                "interval": PlanInterval.WEEK.value,
                "interval_count": 2
            })

        internal_obj = StripePlan.objects.filter(plan=subscription.plan).first()
        if internal_obj:
            # TODO: update something?
            stripe_plan = stripe.Plan.retrieve(internal_obj.external_id)
        else:
            stripe_plan = stripe.Plan.create(**plan_data)
            internal_obj = StripePlan.objects.create(
                plan=subscription.plan,
                external_id=stripe_plan["id"]
            )

        return (internal_obj, stripe_plan)

    def get_or_create_customer(self, order):
        """
        Get stripe customer either from StripeProfile or create new one

        :param stripe_token: got from stripe.js
        :type stripe_token: str
        :param card_email: customer email
        :type card_email: str
        :return: Stripe customer object
        """
        from ..models import StripeCustomer

        customer = order.customer
        if customer:
            internal_obj = StripeCustomer.objects.filter(customer=customer).first()
            if internal_obj:
                stripe_customer = stripe.Customer.retrieve(internal_obj.external_id)
                return (internal_obj, stripe_customer)

            customer_email = customer.email
            description = "Shuup Customer %d" % customer.pk
        else:
            customer_email = order.email
            description = "Anonymous customer"

        stripe_customer = stripe.Customer.create(
            email=customer_email,
            description=description,
            source=self.stripe_token
        )

        internal_obj = StripeCustomer.objects.create(
            customer=(customer or None),
            external_id=stripe_customer['id'],
        )
        return (internal_obj, stripe_customer)

    def get_or_create_subscription(self, subscription, stripe_customer, stripe_plan):
        internal_obj = StripeSubscription.objects.filter(subscription=subscription).first()
        if internal_obj:
            stripe_subscription = stripe.Subscription.retrieve(internal_obj.external_id, self.secret_key)
        else:
            payload = {
                "customer": stripe_customer["id"],
            }
            if subscription.plan.trial_period:
                end_date = subscription.plan.get_free_trial_end_date(subscription)
                if end_date:
                    payload["trial_end"] = int(end_date.timestamp())

            if settings.STRIPE_SUBSCRIPTIONS_API_VERSION == "2018":
                payload["items"] = [
                    {
                        "plan": stripe_plan["id"]
                    }
                ]
            else:
                payload["plan"] = stripe_plan["id"]

            stripe_subscription = stripe.Subscription.create(**payload)
            internal_obj = StripeSubscription.objects.create(
                subscription=subscription, external_id=stripe_subscription["id"])
        return (internal_obj, stripe_subscription)

    def handle_order(self):
        internal_customer, stripe_customer = self.get_or_create_customer(self.order)

        # create plan to stripe
        for product_line in self.order.lines.products().filter(product__mode=ProductMode.SUBSCRIPTION):
            subscription = product_line.subscription
            internal_plan, stripe_plan = self.get_or_create_plan(subscription, product_line.product)
            internal_sub, stripe_sub = self.get_or_create_subscription(subscription, stripe_customer, stripe_plan)

            StripeCustomerSubscription.objects.create(
                stripe_subscription=internal_sub,
                stripe_customer=internal_customer
            )
