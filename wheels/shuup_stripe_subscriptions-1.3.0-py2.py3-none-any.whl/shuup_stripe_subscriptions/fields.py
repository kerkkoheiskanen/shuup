import datetime
from decimal import Decimal

from django.conf import settings
from django.db import models
from django.utils import timezone


class TimestampDateTimeField(models.DateTimeField):
    """
    Django model field for storing high precision timestamps.

    The Python interface of this field uses datetime objects, but the
    internal database type is a decimal.  This allows higher precision
    than with datetime fields, since some DBMSs don't support sub-second
    precision for datetime fields.
    """
    description = "Datetime stored as unix timestamp"

    def __init__(self, max_digits=20, decimal_places=6, *args, **kwargs):
        self.max_digits = max_digits
        self.decimal_places = decimal_places
        self._decimal_field = models.DecimalField(
            max_digits=max_digits, decimal_places=decimal_places)
        super(TimestampDateTimeField, self).__init__(*args, **kwargs)

    def deconstruct(self):
        parent = super(TimestampDateTimeField, self)
        (name, path, args, kwargs) = parent.deconstruct()
        if self.max_digits != 20:
            kwargs['max_digits'] = self.max_digits
        if self.decimal_places != 6:
            kwargs['decimal_places'] = self.decimal_places
        return (name, path, args, kwargs)

    def get_internal_type(self):
        return 'DecimalField'

    def to_python(self, value):
        if isinstance(value, (int, float, Decimal)):
            return _timestamp_to_datetime(value)
        return super(TimestampDateTimeField, self).to_python(value)

    def from_db_value(self, value, expression, connection, context):
        return _timestamp_to_datetime(value)

    def get_db_prep_value(self, value, connection, prepared=False):
        if value is None:
            return None
        if not prepared:
            value = self.get_prep_value(value)
        return Decimal(_datetime_to_timestamp(value))

    def get_db_prep_save(self, value, connection):
        return self._decimal_field.get_db_prep_save(
            self.get_db_prep_value(value, connection), connection)

    def format_number(self, value):
        return self._decimal_field.format_number(value)


def _timestamp_to_datetime(timestamp, dt_cls=datetime.datetime):
    if settings.USE_TZ:
        return dt_cls.utcfromtimestamp(timestamp).replace(tzinfo=timezone.utc)
    else:
        return dt_cls.fromtimestamp(timestamp)


def _datetime_to_timestamp(dt):
    if timezone.is_naive(dt):
        tz = timezone.get_default_timezone()
        dt = timezone.make_aware(dt, tz)
    return (dt - _EPOCH).total_seconds()


_EPOCH = datetime.datetime.utcfromtimestamp(0).replace(tzinfo=timezone.utc)
