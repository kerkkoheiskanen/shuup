# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
from setuptools_gitver import get_version

__version__ = get_version(__name__)
default_app_config = __name__ + '.apps.AppConfig'
