# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.

from shuup_subscriptions.processors import SubscriptionProcessor

from .models import StripeSubscriptionPaymentProcessor


class StripeSubscriptionProcessor(SubscriptionProcessor):
    payment_processor = StripeSubscriptionPaymentProcessor

    @classmethod
    def supports_plan(cls, plan):
        return True
