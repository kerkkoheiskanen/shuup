import environ

env = environ.Env(DEBUG=(bool, False))

# Either 2015 or 2018
STRIPE_SUBSCRIPTIONS_API_VERSION = env('STRIPE_SUBSCRIPTIONS_API_VERSION', default='2015')
