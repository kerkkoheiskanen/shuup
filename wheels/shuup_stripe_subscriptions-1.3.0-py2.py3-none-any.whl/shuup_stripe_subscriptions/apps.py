# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.

import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_stripe_subscriptions"
    verbose_name = "Shuup Stripe Checkout integration"
    label = "shuup_stripe_subscriptions"
    provides = {
        "front_urls_pre": [
            "shuup_stripe_subscriptions.urls:urlpatterns"
        ],
        "front_service_checkout_phase_provider": [
            "shuup_stripe_subscriptions.checkout_phase:SubscriptionPhaseProvider",
        ],
        "service_provider_admin_form": [
            "shuup_stripe_subscriptions.admin_forms:StripeSubscriptionAdminForm",
        ],
        "payment_processor_wizard_form_def": [
            "shuup_stripe_subscriptions.admin_forms:StripeSubscriptionWizardFormDef",
        ],
        "subscription_processor": [
            "shuup_stripe_subscriptions.processors:StripeSubscriptionProcessor"
        ]
    }

    def ready(self):
        from shuup_subscriptions.signals import subscription_cancelled
        from .signal_handlers import handle_subscription_cancel
        subscription_cancelled.connect(handle_subscription_cancel, dispatch_uid="handle_subscription_cancel_stripe")
