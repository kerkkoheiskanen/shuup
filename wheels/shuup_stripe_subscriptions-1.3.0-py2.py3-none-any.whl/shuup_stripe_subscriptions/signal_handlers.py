import stripe

from shuup_stripe_subscriptions.enums import InvoiceStatus
from shuup_stripe_subscriptions.models import (
    StripeSubscription, StripeSubscriptionPaymentProcessor)


def handle_subscription_cancel(sender, subscription, user, **kwargs):
    stripe_subscription = StripeSubscription.objects.get(subscription=subscription)
    processor = StripeSubscriptionPaymentProcessor.objects.first()
    # cancel subscription
    sub = stripe.Subscription.retrieve(stripe_subscription.external_id, processor.secret_key)
    sub.delete()

    # mark all current invoices void
    for pending_invoice in subscription.invoices.filter(status=InvoiceStatus.PENDING):
        pending_invoice.status = InvoiceStatus.CANCELLED
        pending_invoice.save()
