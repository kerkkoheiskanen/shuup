from __future__ import unicode_literals

import datetime
import time

from django.conf import settings
from django.db import models
from django.utils import timezone
from django.utils.six import python_2_unicode_compatible
from enumfields import EnumField
from jsonfield import JSONField

from ..enums import EventHandlerResultCode
from ..fields import TimestampDateTimeField
from .processors import StripeSubscriptionPaymentProcessor


class WebhookEventLogEntryQuerySet(models.QuerySet):
    def old(self, max_age=None):
        max_age = max_age if max_age is not None else _get_max_log_age()
        limit = time.time() - max_age.total_seconds()
        return self.filter(received_on__lt=limit)

    def latest_n(self, n):
        return self.order_by('-received_on')[:n]

    def for_cleanup(self, keep_at_least=1000, max_age=None):
        """
        Filter log entries to clean-up.

        Filter to all log entries that are older than the given max_age,
        but exclude the newest entries.  Number of excluded entries is
        specified with the keep_at_least argument.

        If max_age is not specified it defaults to value of
        SHUUP_STRIPE_SUBSCRIPTIONS_LOG_AGE setting or 90 days if the
        setting is unset.

        :type keep_at_least: int
        :type max_age: datetime.timedelta|None
        :rtype: WebhookEventLogEntryQuerySet
        """
        to_keep = self.latest_n(keep_at_least)
        keep_ts = to_keep.aggregate(val=models.Min('received_on'))['val']
        rest = (self.exclude(received_on__gte=keep_ts) if keep_ts else self)
        return rest.old(max_age)


@python_2_unicode_compatible
class WebhookEventLogEntry(models.Model):
    received_on = TimestampDateTimeField(db_index=True)

    # request data
    request_path = models.CharField(max_length=200, blank=True)
    meta = JSONField(null=True, blank=True)
    body = models.BinaryField(null=True, blank=True)

    processor = models.ForeignKey(
        StripeSubscriptionPaymentProcessor, null=True, blank=True,
        on_delete=models.SET_NULL)
    event = JSONField(null=True, blank=True)
    result_code = EnumField(EventHandlerResultCode, blank=True, null=True)
    result_message = models.CharField(max_length=1000, blank=True)

    objects = WebhookEventLogEntryQuerySet.as_manager()

    class Meta:
        ordering = ('received_on',)

    @classmethod
    def log_request(cls, request, commit=True):
        received_on = timezone.now()
        meta = dict(
            (k, v) for (k, v) in request.META.items()
            if k.startswith('HTTP_') or k.startswith('REMOTE_'))
        log_entry = cls(
            received_on=received_on,
            request_path=request.path[:200],
            meta=meta,
            body=request.body)
        if commit:
            log_entry.save()
        return log_entry

    def __str__(self):
        result_code = self.result_code.value if self.result_code else ''
        result_msg = _elide_text(self.result_message, 20)
        return '{t}: processor={p} from={f} result={r} event={e}'.format(
            t=self.received_on,
            p=(self.processor.pk if self.processor else ''),
            f=((self.meta or {}).get('REMOTE_ADDR', '') or ''),
            r=(result_code + ('(' + result_msg + ')' if result_msg else '')),
            e=_get_elided_event_info(self.event),
        )


def _get_max_log_age():
    value = getattr(settings, 'SHUUP_STRIPE_SUBSCRIPTIONS_LOG_AGE', 90)
    if isinstance(value, datetime.timedelta):
        return value
    return datetime.timedelta(days=value)


def _elide_text(text, length):
    return text if len(text) < length else text[:length] + '...'


def _get_elided_event_info(event):
    if not event:
        return ''
    contents = ', '.join(
        '{}={!r}'.format(field, event[field])
        for field in ['id', 'type', 'livemode', 'created']
        if field in event)
    return ('{' + contents + ', ...}')
