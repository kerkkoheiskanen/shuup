# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.

import decimal

from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.utils.translation import ugettext_lazy as _
from enumfields import EnumIntegerField
from shuup.core.fields import CurrencyField, MoneyValueField
from shuup.core.pricing import TaxfulPrice
from shuup.utils.properties import MoneyPropped, TaxfulPriceProperty
from shuup_subscriptions.models import Subscription

from ..enums import InvoiceLineType, InvoiceStatus, InvoiceType
from .base import StripedModel


class Invoice(StripedModel):
    subscription = models.ForeignKey(Subscription, related_name="invoices", blank=True, null=True, editable=False)
    start_date = models.DateTimeField(verbose_name=_(u"start date"), null=True, blank=True, editable=False)
    end_date = models.DateTimeField(verbose_name=_(u"end date"), null=True, blank=True, editable=False)

    invoicing_date = models.DateTimeField(verbose_name=_(u"Invoicing date"), null=True, blank=True, editable=False)

    currency = CurrencyField(default=settings.SHUUP_HOME_CURRENCY, verbose_name=_("currency"), help_text=_(
        "The primary invoice currency."
    ))

    status = EnumIntegerField(InvoiceStatus, verbose_name=_(u"status"), default=InvoiceStatus.PENDING, editable=False)
    type = EnumIntegerField(InvoiceType, verbose_name=_("type"), default=InvoiceType.NORMAL, editable=False)

    created = models.DateTimeField(auto_now_add=True, editable=False)
    updated = models.DateTimeField(auto_now=True, editable=False)

    def __repr__(self):
        return '<{}: {}/{}, date: {}, total: {}, status: {}>'.format(
            type(self).__name__, self.pk, self.external_id,
            self.invoicing_date, self.total, self.status)

    @property
    def order(self):
        return self.subscription.order

    @property
    def total(self):
        total = self.lines.all().aggregate(total=models.Sum("amount_value"))
        total_value = total["total"] or decimal.Decimal("0.00")
        return TaxfulPrice(total_value, self.currency)


class InvoiceLine(MoneyPropped, StripedModel):
    invoice = models.ForeignKey(Invoice, related_name="lines", editable=False)
    type = EnumIntegerField(InvoiceLineType, verbose_name=_(u"type"), editable=False)

    amount_value = MoneyValueField(default=0)
    amount = TaxfulPriceProperty("amount_value", "invoice.currency")

    created = models.DateTimeField(auto_now_add=True, editable=False)
    updated = models.DateTimeField(auto_now=True, editable=False)

    def __repr__(self):
        return '<%s: invoice: %r, type: %s, amount: %s>' % (
            type(self).__name__, self.invoice.pk,
            self.type, self.amount)

    class Meta:
        unique_together = [("invoice", "type"), ]

    def clean(self):
        """
        Make sure that InvoiceLines is added only to PENDING invoices
        """
        if self.invoice.status != InvoiceStatus.PENDING:
            raise ValidationError(_(u"Can't create line to non pending invoice."), code="invoice_locked")

    def save(self, *args, **kwargs):
        self.full_clean()
        super(InvoiceLine, self).save(*args, **kwargs)
