# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.

from __future__ import unicode_literals

from django.db import models
from django.utils.crypto import get_random_string
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import PaymentProcessor, ServiceChoice


class StripeSubscriptionPaymentProcessor(PaymentProcessor):
    secret_key = models.CharField(max_length=100, verbose_name=_("Secret Key"))
    publishable_key = models.CharField(
        max_length=100, verbose_name=_("Publishable Key"))
    webhook_signing_key = models.CharField(
        max_length=100, blank=True,
        verbose_name=_("webhook signing secret"))
    webhook_slug = models.SlugField(
        unique=True, default=get_random_string,
        verbose_name=("slug for webhook URL"))

    def get_service_choices(self):
        return [ServiceChoice('stripe_subscriptions', _("Stripe Subscriptions"))]

    def get_payment_process_response(self, service, order, urls):
        # create plan to stripe if required
        return super(StripeSubscriptionPaymentProcessor, self).get_payment_process_response(service, order, urls)

    def process_payment_return_request(self, service, order, request):
        from ..modules.subscriber import StripeSubscriber
        if not order.is_paid():
            charger = StripeSubscriber(
                order=order,
                secret_key=self.secret_key
            )
            charger.handle_order()
