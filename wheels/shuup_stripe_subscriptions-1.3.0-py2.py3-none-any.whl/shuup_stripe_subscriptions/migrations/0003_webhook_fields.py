# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.utils.crypto

from shuup.utils.migrations import get_managers_for_migration


class Migration(migrations.Migration):

    dependencies = [
        ('shuup_stripe_subscriptions', '0002_charge_currency'),
    ]
    operations = [
        migrations.AlterModelManagers(
            name='stripesubscriptionpaymentprocessor',
            managers=get_managers_for_migration(),
        ),
        migrations.AddField(
            model_name='stripesubscriptionpaymentprocessor',
            name='webhook_signing_key',
            field=models.CharField(blank=True, max_length=100),
        ),
        migrations.AddField(
            model_name='stripesubscriptionpaymentprocessor',
            name='webhook_slug',
            field=models.SlugField(
                unique=True, default=django.utils.crypto.get_random_string),
        ),
    ]
