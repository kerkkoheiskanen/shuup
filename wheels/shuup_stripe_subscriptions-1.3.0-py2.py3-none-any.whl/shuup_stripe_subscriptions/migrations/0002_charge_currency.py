# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import shuup.core.fields
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('shuup_stripe_subscriptions', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='charge',
            name='currency',
            field=shuup.core.fields.CurrencyField(max_length=4, default='EUR'),
        ),
    ]
