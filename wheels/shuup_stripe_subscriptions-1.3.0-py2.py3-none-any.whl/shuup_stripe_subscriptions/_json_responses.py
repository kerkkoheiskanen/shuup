from __future__ import unicode_literals

from django.http import (
    HttpResponseBadRequest, HttpResponseNotFound, JsonResponse)


class JsonErrorResponse(JsonResponse):
    def __init__(self, error_message):
        super(JsonErrorResponse, self).__init__({'error': error_message})


class BadRequest(JsonErrorResponse, HttpResponseBadRequest):
    pass


class NotFound(JsonErrorResponse, HttpResponseNotFound):
    pass
