# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.

from django.conf.urls import url

from .webhook_views import webhook_view

urlpatterns = [
    url(r'^stripe-webhook/(?P<slug>(\w|-)+)/', webhook_view,
        name='stripe-subscriptions-webhook')
]
