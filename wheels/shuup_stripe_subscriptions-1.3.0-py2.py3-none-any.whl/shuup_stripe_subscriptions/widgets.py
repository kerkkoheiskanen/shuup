from django import forms


class SlugWithUrlWidget(forms.TextInput):
    def __init__(self, url_label=None, url_format=None, attrs=None):
        self.url_label = url_label
        self.url_format = url_format
        my_attrs = {'class': 'slug-with-url-widget'}
        my_attrs.update(attrs or {})
        super(SlugWithUrlWidget, self).__init__(my_attrs)

    def render(self, name, value, attrs=None):
        url_format = (self.url_format() if callable(self.url_format)
                      else self.url_format)
        my_attrs = {
            'data-url-format': url_format,
            'data-url-label': self.url_label,
        }
        my_attrs.update(attrs or {})
        return super(SlugWithUrlWidget, self).render(name, value, my_attrs)

    class Media:
        js = ['shuup_stripe_subscriptions/slug-with-url.js']
