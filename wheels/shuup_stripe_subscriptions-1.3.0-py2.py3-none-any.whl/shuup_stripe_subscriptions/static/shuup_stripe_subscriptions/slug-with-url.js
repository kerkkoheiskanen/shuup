$(function() {
    $('.slug-with-url-widget').each(function() {
        var urlFormat = $(this).data('url-format');
        var urlLabel = $(this).data('url-label');
        var urlInputId = $(this).attr('id') + '_url';

        if (!urlFormat || !urlLabel) return;

        var $formGroup = $(this).closest('div.form-group');
        if ($formGroup.length) {
            var $newFg = $('<div class="form-group"></div>');

            var $label = $('<label class="control-label"></label>');
            $label.attr('for', urlInputId);
            $label.text(urlLabel);
            $newFg.append($label);

            var $input = $('<input type="text" class="form-control">');
            $input.attr('id', urlInputId);
            $input.prop('readonly', true);
            $input.val(urlFormat.replace('{slug}',$(this).val()));
            $newFg.append($input);

            $formGroup.after($newFg);

            $(this).on('input', function(event) {
                $input.val(urlFormat.replace('{slug}',$(this).val()));
            });
        }
    });
});
