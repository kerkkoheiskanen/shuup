# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import json

import mock
import pytest
from django.core.urlresolvers import reverse
from django.test import Client, override_settings
from django.utils.translation import activate
from shuup.testing import factories


def get_dummy_session_manager():
    from shuup_quickbooks.auth import Oauth2SessionManager
    session_manager = Oauth2SessionManager(
        client_id="1",
        client_secret="2",
        access_token="3",
        base_url="4"
    )
    session_manager.refresh_token = 100
    session_manager.x_refresh_token_expires_in = 100
    session_manager.expires_in = 100
    return session_manager


@pytest.mark.django_db
def test_settings_view(admin_user):
    activate("en")
    factories.get_default_shop()
    settings = dict(
        QUICKBOOKS_AUTH_CALLBACK_URL="authcallback",
        QUICKBOOKS_CLIENT_ID="1",
        QUICKBOOKS_CLIENT_SECRET="2"
    )
    with override_settings(**settings):
        client = Client()
        admin_user.set_password("admin")
        admin_user.save()
        client.login(username=admin_user.username, password="admin")
        settings_url = reverse("shuup_admin:shuup_quickbooks.settings")

        with mock.patch("shuup_quickbooks.auth.Oauth2SessionManager"):
            response = client.get(settings_url)
            assert response.status_code == 200
            assert "QuickBooks Online is not yet connected" in response.content.decode("utf-8")
            assert "Synchronize" not in response.content.decode("utf-8")

        with mock.patch("quickbooks.QuickBooks.make_request"):
            _authorize_client(client)
            response = client.get(settings_url)
            assert response.status_code == 200

            assert "QuickBooks Online is not yet connected" not in response.content.decode("utf-8")
            assert "Synchronize" in response.content.decode("utf-8")


def _authorize_client(client):
    authorize_url = reverse("shuup_admin:shuup_quickbooks.authorize")

    with mock.patch("shuup_quickbooks.auth.Oauth2SessionManager.get_access_tokens") as get_access_token_mock:
        with mock.patch("shuup_quickbooks.utils.get_auth_session_manager") as get_auth_session_mock:
            session_manager = get_dummy_session_manager()
            get_auth_session_mock.return_value = session_manager
            get_access_token_mock.return_value = None

            response = client.get("{}?code=CODEX&company_id=456".format(authorize_url))
            assert response.status_code == 302

            get_auth_session_mock.assert_called()
            get_access_token_mock.assert_called_once_with("CODEX")

            assert client.session["quickbooks_auth"]["access_token"] == session_manager.access_token
            assert client.session["quickbooks_auth"]["access_token_expires_at"]
            assert client.session["quickbooks_auth"]["refresh_expires_at"]
            assert client.session["quickbooks_auth"]["company_id"] == "456"


@pytest.mark.django_db
def test_sync_view(admin_user):
    activate("en")
    factories.get_default_shop()
    settings = dict(
        QUICKBOOKS_AUTH_CALLBACK_URL="authcallback",
        QUICKBOOKS_CLIENT_ID="1",
        QUICKBOOKS_CLIENT_SECRET="2"
    )
    with override_settings(**settings):
        client = Client()
        admin_user.set_password("admin")
        admin_user.save()
        client.login(username=admin_user.username, password="admin")
        sync_url = reverse("shuup_admin:shuup_quickbooks.sync")

        with mock.patch("quickbooks.QuickBooks.make_request"):
            with mock.patch("shuup_quickbooks.utils.get_valid_session_manager") as get_valid_session_manager_mock:
                get_valid_session_manager_mock.return_value = None
                # Try to sync without a valid session
                response = client.post(sync_url)
                assert response.status_code == 302

                # get a valid session
                _authorize_client(client)

                with mock.patch("shuup_quickbooks.utils.get_valid_session_manager") as get_valid_session_mock:
                    get_valid_session_mock.return_value = get_dummy_session_manager()

                    with mock.patch("shuup_quickbooks.synchronizer.QuickBooksSynchronizer.synchronize") as sync_mock:
                        response = client.post(sync_url)

                    sync_mock.assert_called_once()


@pytest.mark.django_db
def test_auth_refresh_coverage():
    activate("en")
    factories.get_default_shop()

    with mock.patch("requests.post") as post_mock:
        class Response(object):
            status_code = 200
            text = json.dumps({
                "x_refresh_token_expires_in": 100,
                "access_token": "dummy",
                "token_type": "dummy",
                "refresh_token": "dummy",
                "expires_in": 100,
                "id_token": "dummy"
            })
        post_mock.return_value = Response()

        from shuup_quickbooks.auth import Oauth2SessionManager
        auth = Oauth2SessionManager(
            client_id="1",
            client_secret="2",
            access_token="3",
            base_url="4"
        )
        auth.refresh("test")
    post_mock.assert_called()
