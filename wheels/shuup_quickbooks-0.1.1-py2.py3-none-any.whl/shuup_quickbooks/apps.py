# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_quickbooks"
    verbose_name = "Shuup Quickbooks integration"
    label = "shuup_quickbooks"
    provides = {
        "front_urls_pre": [
            "shuup_quickbooks.urls:urlpatterns"
        ],
        "admin_module": [
            "shuup_quickbooks.admin_module:ShuupQuickBooksAdminModule"
        ],
        "quickbooks_object_synchronizer": [
            "shuup_quickbooks.synchronizer:DefaultQuickBooksObjectSynchronizer"
        ],
        "quickbooks_sync_objects_provider": [
            "shuup_quickbooks.objects_provider:DefaultSyncObjectProvider"
        ]
    }
