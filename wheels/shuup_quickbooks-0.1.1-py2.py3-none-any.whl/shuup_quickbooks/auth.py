# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import json

import requests
from quickbooks import Oauth2SessionManager as BaseOauth2SessionManager


class Oauth2SessionManager(BaseOauth2SessionManager):
    """
    Customize the SessionManager to add refresh token method

    There is already PR open for this but it is somewhat old:
    https://github.com/sidecars/python-quickbooks/pull/108
    """
    def refresh(self, refresh_token):
        headers = {
            'Accept': 'application/json',
            'content-type': 'application/x-www-form-urlencoded',
            'Authorization': self.get_auth_header()
        }
        payload = {
            'refresh_token': refresh_token,
            'grant_type': 'refresh_token'
        }
        request = requests.post(self.access_token_url, data=payload, headers=headers)
        if request.status_code != 200:
            return request.text

        bearer_raw = json.loads(request.text)

        self.x_refresh_token_expires_in = bearer_raw['x_refresh_token_expires_in']
        self.access_token = bearer_raw['access_token']
        self.token_type = bearer_raw['token_type']
        self.refresh_token = bearer_raw['refresh_token']
        self.expires_in = bearer_raw['expires_in']

        if 'id_token' in bearer_raw:
            self.id_token = bearer_raw['id_token']
