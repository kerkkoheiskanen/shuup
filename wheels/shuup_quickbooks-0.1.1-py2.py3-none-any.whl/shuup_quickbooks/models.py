# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.db import models
from django.utils.translation import ugettext_lazy as _


class QuickBooksSyncContact(models.Model):
    sync_date = models.DateTimeField(auto_now=True, verbose_name=_("synchronization date"), db_index=True)
    quickbooks_id = models.CharField(max_length=64, verbose_name=_("QuickBooks ID"))
    contact = models.OneToOneField("shuup.Contact", verbose_name=_("contact"), related_name="quickbooks_sync")

    class Meta:
        verbose_name = _("QuickBooks Synchronized Contact")
        verbose_name_plural = _("QuickBooks Synchronized Contacts")


class QuickBooksSyncOrder(models.Model):
    sync_date = models.DateTimeField(auto_now=True, verbose_name=_("synchronization date"), db_index=True)
    quickbooks_id = models.CharField(max_length=64, verbose_name=_("QuickBooks ID"))
    order = models.OneToOneField("shuup.Order", verbose_name=_("order"), related_name="quickbooks_sync")

    class Meta:
        verbose_name = _("QuickBooks Synchronized Order")
        verbose_name_plural = _("QuickBooks Synchronized Orders")


class QuickBooksSyncPaymentMethod(models.Model):
    sync_date = models.DateTimeField(auto_now=True, verbose_name=_("synchronization date"), db_index=True)
    quickbooks_id = models.CharField(max_length=64, verbose_name=_("QuickBooks ID"))
    payment_method = models.OneToOneField(
        "shuup.PaymentMethod",
        verbose_name=_("payment method"),
        related_name="quickbooks_sync"
    )

    class Meta:
        verbose_name = _("QuickBooks Synchronized Payment Method")
        verbose_name_plural = _("QuickBooks Synchronized Payment Methods")
