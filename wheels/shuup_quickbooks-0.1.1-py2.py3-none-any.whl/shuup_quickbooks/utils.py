# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from datetime import timedelta

from django.conf import settings
from django.utils.dateparse import parse_datetime
from django.utils.timezone import now


def get_auth_session_manager(access_token=None):
    """
    Get a session manager to authenticate
    """
    from shuup_quickbooks.auth import Oauth2SessionManager
    session_manager = Oauth2SessionManager(
        client_id=settings.QUICKBOOKS_CLIENT_ID,
        client_secret=settings.QUICKBOOKS_CLIENT_SECRET,
        base_url=settings.QUICKBOOKS_AUTH_CALLBACK_URL
    )
    if access_token:
        session_manager.access_token = access_token
    return session_manager


def save_auth_in_session(request, company_id, session_manager):
    now_datetime = now()
    quickbooks_auth = {
        "access_token": session_manager.access_token,
        "access_token_expires_at": (now_datetime + timedelta(seconds=session_manager.expires_in)).isoformat(),
        "refresh_token": session_manager.refresh_token,
        "refresh_expires_at": (
            (now_datetime + timedelta(seconds=session_manager.x_refresh_token_expires_in)).isoformat()
        ),
        "company_id": company_id
    }
    request.session["quickbooks_auth"] = quickbooks_auth


def clear_auth_session(request):
    request.session["quickbooks_auth"] = None


def get_valid_session_manager(request):
    """
    Get a session manager which has a valid access token
    Returns None if there is no valid sesion manager
    """
    quickbooks_auth = request.session.get("quickbooks_auth")
    if not quickbooks_auth:
        return None

    session_manager = get_auth_session_manager(quickbooks_auth["access_token"])

    access_token_expires_at = parse_datetime(quickbooks_auth["access_token_expires_at"])
    refresh_expires_at = parse_datetime(quickbooks_auth["refresh_expires_at"])

    # access token is expired, try the refresh token
    if access_token_expires_at < now():

        # damn, refresh token is also expired
        if refresh_expires_at < now():
            # clear the session data
            request.session["quickbooks_auth"] = None
            return None

        # try to refresh token
        request_result = session_manager.refresh(quickbooks_auth["refresh_token"])

        # failed to refresh the token
        if request_result:
            return None

        # save the auth data into the session
        save_auth_in_session(request, quickbooks_auth["company_id"], session_manager)

    return session_manager


def has_valid_configs():
    return all([
        settings.QUICKBOOKS_CLIENT_ID,
        settings.QUICKBOOKS_CLIENT_SECRET,
        settings.QUICKBOOKS_AUTH_CALLBACK_URL
    ])


def get_quickbooks_from_session(request, **kwargs):
    from shuup_quickbooks.objects import QuickBooks
    quickbooks_auth = request.session["quickbooks_auth"]
    session_manager = get_auth_session_manager(quickbooks_auth["access_token"])
    return QuickBooks(
        company_id=quickbooks_auth["company_id"],
        sandbox=settings.QUICKBOOKS_SANDBOX_MODE,
        session_manager=session_manager,
        minorversion=4,
        **kwargs
    )
