# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.templatetags.static import static
from shuup.xtheme.resources import add_resource, InlineScriptResource

from shuup_multivendor.utils.map import get_customer_location


def add_multivendor_resources(context, content):
    request = context.get("request")
    if not request:
        return

    match = request.resolver_match
    if not match:
        return

    if match.app_name == "shuup_admin":
        add_resource(context, "body_end", "%s?v=0.7.3.js" % static("shuup_multivendor/admin_scripts.js"))
    else:
        add_resource(context, "body_end", InlineScriptResource.from_vars("MULTIVENDOR_SETTINGS", {
            "gmaps_api_key": settings.SHUUP_MULTIVENDOR_GOOGLE_MAPS_KEY,
            "gmaps_countries": settings.SHUUP_MULTIVENDOR_GOOGLE_MAPS_COUNTRIES,
            "distance_unit": settings.SHUUP_MULTIVENDOR_DISTANCE_UNIT,
            "customer_location": get_customer_location(request.customer)
        }))
        add_resource(context, "body_end", "%s?v=0.7.3.js" % static("shuup_multivendor/scripts.js"))
