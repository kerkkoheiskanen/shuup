# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models
from django.db.transaction import atomic
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum, EnumField
from shuup.core.fields import CurrencyField, MoneyValueField
from shuup.core.models import (
    Order, OrderLine, OrderLineType, OrderStatus, OrderStatusRole, Product,
    Shop, ShuupModel, Supplier
)
from shuup.utils.i18n import format_money
from shuup.utils.properties import (
    MoneyPropped, PriceProperty, TaxlessPriceProperty
)

from shuup_multivendor.signals import vendor_withdrawal_requested

WITHDRAW_ORDER_LINE_ACCOUNTING_IDENTIFIER = "vendor_withdrawal"


class DistanceUnit(Enum):
    km = "km"
    mi = "mi"

    class Labels:
        km = _("Kilometers")
        mi = _("Miles")


class DayOfTheWeek(Enum):
    Monday = "monday"
    Tuesday = "tuesday"
    Wednesday = "wednesday"
    Thursday = "thursday"
    Friday = "friday"
    Saturday = "saturday"
    Sunday = "sunday"

    class Labels:
        Monday = _("Monday")
        Tuesday = _("Tuesday")
        Wednesday = _("Wednesday")
        Thursday = _("Thursday")
        Friday = _("Friday")
        Saturday = _("Saturday")
        Sunday = _("Sunday")


class SupplierPrice(MoneyPropped, ShuupModel):
    shop = models.ForeignKey(Shop, related_name="vendor_prices")
    product = models.ForeignKey(Product, related_name="vendor_prices")
    supplier = models.ForeignKey(Supplier, related_name="vendor_prices")
    amount_value = MoneyValueField()
    amount = PriceProperty("amount_value", "shop.currency", "shop.prices_include_tax")


class SupplierUser(models.Model):
    shop = models.ForeignKey(Shop, related_name="vendor_users")
    supplier = models.ForeignKey(Supplier, related_name="vendor_users")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="vendor_users")
    is_owner = models.BooleanField(verbose_name=_("is owner"), default=False)

    class Meta:
        unique_together = ("shop", "supplier", "user")

    @classmethod
    def get_owner(cls, supplier):
        item = cls.objects.filter(supplier=supplier, is_owner=True).first()
        if item:
            return item.user


class VendorContactDistance(models.Model):
    contact = models.ForeignKey("shuup.Contact", verbose_name=_("contact"), related_name="vendor_distances")
    supplier = models.ForeignKey("shuup.Supplier", verbose_name=_("supplier"), related_name="vendor_distances")
    distance = models.DecimalField(verbose_name=_("distance"), null=True, blank=True, max_digits=9, decimal_places=2)
    unit = EnumField(DistanceUnit, verbose_name=_("unit"))

    class Meta:
        unique_together = ("contact", "supplier")

    def __str__(self):
        return "{} => {} = {} {}".format(self.contact, self.supplier, self.distance, self.unit)


class VendorOrderLineRevenue(models.Model):
    order_line = models.OneToOneField(
        "shuup.OrderLine", verbose_name=_("order line"), related_name="vendor_revenue_percentage")
    percentage = models.DecimalField(verbose_name=_("percentage"), max_digits=4, decimal_places=2)
    revenue = TaxlessPriceProperty("revenue_value", "currency")
    revenue_value = MoneyValueField(editable=False, verbose_name=_("funds"), default=0)
    currency = CurrencyField(verbose_name=_("currency"))

    @classmethod
    def get_revenue_earned(cls, vendor_id, currency, order_ids=None):
        # since withdrawals are negative those are automatically counted
        # once refund order is completed
        sales_revenue_total_qs = VendorOrderLineRevenue.objects.filter(
            order_line__supplier_id=vendor_id,
            order_line__order__status__role=OrderStatusRole.COMPLETE,
            order_line__order__currency=currency
        ).exclude(
            order_line__type=OrderLineType.REFUND
        )

        refunded_sales_revenue_total_qs = VendorOrderLineRevenue.objects.filter(
            order_line__parent_line__supplier__id=vendor_id,
            order_line__type=OrderLineType.REFUND,
            order_line__order__status__role=OrderStatusRole.COMPLETE,
            order_line__order__currency=currency
        )

        if order_ids:
            sales_revenue_total_qs = sales_revenue_total_qs.filter(order_line__order_id__in=order_ids)
            refunded_sales_revenue_total_qs = refunded_sales_revenue_total_qs.filter(order_line__order_id__in=order_ids)

        return (
            (sales_revenue_total_qs.aggregate(total=models.Sum("revenue_value"))["total"] or 0) +
            (refunded_sales_revenue_total_qs.aggregate(total=models.Sum("revenue_value"))["total"] or 0)
        )


class VendorFunds(models.Model):
    supplier = models.ForeignKey("shuup.Supplier", related_name="funds", verbose_name=_('vendor'))
    funds = TaxlessPriceProperty("funds_value", "currency")
    funds_value = MoneyValueField(editable=False, verbose_name=_("funds"), default=0)
    currency = CurrencyField(verbose_name=_("currency"))

    class Meta:
        unique_together = ("supplier", "currency")
        verbose_name = _("Vendor Balance")
        verbose_name_plural = _("Vendor Balances")

    @classmethod
    def calculate_funds(cls, shop_id, vendor_id, currency):
        if not (shop_id and vendor_id and currency):
            return

        revenue_earned = VendorOrderLineRevenue.get_revenue_earned(vendor_id, currency)
        withdraws_total_value = OrderLine.objects.filter(
            accounting_identifier=WITHDRAW_ORDER_LINE_ACCOUNTING_IDENTIFIER,
            supplier_id=vendor_id,
            order__currency=currency
        ).exclude(
            order__status__role=OrderStatusRole.CANCELED,
        ).aggregate(total=models.Sum("base_unit_price_value"))["total"] or 0

        cls.objects.update_or_create(
            supplier_id=vendor_id,
            currency=currency,
            defaults={
                "funds_value": (revenue_earned + withdraws_total_value)
            }
        )

    @classmethod
    def get_funds(cls, vendor, currency):
        if not vendor:
            from decimal import Decimal
            from shuup.utils.money import Money
            return Money(Decimal(), currency)
        funds_obj, _ = VendorFunds.objects.get_or_create(supplier=vendor, currency=currency)
        return funds_obj.funds

    @classmethod
    def get_funds_formatted(cls, vendor, currency):
        return format_money(cls.get_funds(vendor, currency))

    @classmethod
    def create_withdrawal(cls, shop, vendor, customer, amount_value, currency, info=""):
        if amount_value < 0:
            raise ValidationError("Can not create negative withdrawal", code="negative-withdrawal-amount")

        if amount_value > cls.get_funds(vendor, currency).value:
            raise ValidationError("Amount exceeds funds available for withdrawal", code="withdrawal-exceeds-funds")

        with atomic():
            order = Order(
                shop=shop,
                currency=currency,
                customer=customer,
                billing_address=(vendor.contact_address.to_immutable() if vendor.contact_address else None),
                order_date=now(),
                status=OrderStatus.objects.get_default_initial(),
                admin_comment=info
            )
            order.save()
            order_line = OrderLine(
                order=order,
                text=_("Withdrawal for %(supplier_name)s" % {"supplier_name": vendor.name}),
                type=OrderLineType.OTHER,
                supplier=vendor,
                accounting_identifier=WITHDRAW_ORDER_LINE_ACCOUNTING_IDENTIFIER,
                quantity=1,
                base_unit_price_value=(-1 * amount_value)
            )
            order_line.save()
            order.cache_prices()
            order.save()
            vendor_withdrawal_requested.send(sender=cls, order=order, vendor=vendor, amount=amount_value, info=info)
            return order

    @classmethod
    def get_withdrawals_queryset(cls, vendor):
        order_ids = OrderLine.objects.filter(
            supplier_id=vendor,
            accounting_identifier=WITHDRAW_ORDER_LINE_ACCOUNTING_IDENTIFIER
        ).values_list("order_id", flat=True)
        return Order.objects.filter(id__in=order_ids)
