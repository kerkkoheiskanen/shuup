# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import datetime
from collections import defaultdict, OrderedDict
from decimal import Decimal
from functools import reduce

import six
from babel.dates import format_date
from django.contrib.auth import get_user_model
from django.db import connection
from django.db.models import Count, F, Sum
from django.db.models.functions import ExtractMonth, ExtractYear
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from shuup.admin.dashboard import (
    ChartDataType, ChartType, DashboardContentBlock, DashboardMoneyBlock,
    DashboardNumberBlock, MixedChart
)
from shuup.admin.modules.sales_dashboard.dashboard import (
    get_orders_by_currency, get_orders_for_shop, month_iter,
    OrderValueChartDashboardBlock
)
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import Category, Order, OrderLine, Shop, ShopProduct
from shuup.core.pricing import TaxlessPrice
from shuup.utils.dates import get_year_and_month_format
from shuup.utils.i18n import get_current_babel_locale


def get_vendor_block(request):
    return DashboardNumberBlock(
        id="vendor_count_block",
        color="orange",
        title=_("Vendors"),
        value=Shop.objects.count(),
        icon="fa fa-user",
        subtitle=_("All time")
    )


def registered_users_block(request, hours_ago=48):
    past = timezone.localtime(timezone.now()) - datetime.timedelta(hours=hours_ago)
    objs = get_user_model().objects.filter(date_joined__gte=past).values_list("pk", flat=True)
    return DashboardNumberBlock(
        id="registered_users_block",
        color="orange",
        title=_("New users"),
        value=len(set(objs)),
        icon="fa fa-user",
        subtitle=_("past %(number_of_hours)s hours") % {"number_of_hours": hours_ago}
    )


def get_recent_orders_block(request, currency, title, hours_ago=24, mode="non_completed"):
    orders = get_orders_by_currency(currency)

    if mode == "non_delivered":
        orders = orders.incomplete()
    elif mode == "non_completed":
        orders = orders.all()

    past = timezone.localtime(timezone.now()) - datetime.timedelta(hours=hours_ago)

    orders = orders.filter(created_on__gte=past)
    if not request.user.is_superuser:
        supplier = get_supplier(request)
        orders = orders.filter(shop=request.shop, lines__supplier=supplier)

    block = DashboardNumberBlock(
        id="recent_orders_%s" % mode,
        color="orange",
        title=title,
        value=orders.count(),
        icon="fa fa-user",
        subtitle=_("Recent %(type)s orders in the past %(number_of_hours)s hours") % {
            "type": mode.replace("_", " "), "number_of_hours": hours_ago}
    )
    return block


def get_favorite_categories_block(request, shop_id, supplier, order_ids):
    block = DashboardContentBlock.by_rendering_template(
        "favorite_categories",
        request,
        "shuup_multivendor/admin/dashboard/favorite_categories_block.jinja", {
            "categories": _get_favorite_categories(shop_id, supplier, order_ids),
            "title": _("Top Categories")
        }
    )
    block.size = "medium"
    return block


def get_favorite_products_block(request, shop_id, supplier, order_ids):
    block = DashboardContentBlock.by_rendering_template(
        "favorite_products",
        request,
        "shuup_multivendor/admin/dashboard/favorite_products_block.jinja", {
            "shop_products": _get_favorite_shop_products(shop_id, supplier, order_ids),
            "title": _("Top Products")
        }
    )
    block.size = "medium"
    return block


def get_new_customers_block(shop_id, order_ids, supplier, cutoff_date):
    return DashboardNumberBlock(
        id="new_customers_block",
        color="orange",
        title=_("New Customers"),
        value=_get_new_customers(shop_id, supplier, cutoff_date),
        icon="fa fa-user",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def get_returning_customers_block(shop_id, order_ids, supplier, cutoff_date):
    return DashboardNumberBlock(
        id="new_customers_block",
        color="orange",
        title=_("Returning Customers"),
        value=_get_returning_customers(shop_id, order_ids, supplier, cutoff_date),
        icon="fa fa-user",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def get_lifetime_sales_block(order_ids, supplier, currency="USD"):
    return DashboardMoneyBlock(
        id="lifetime_sales_sum",
        color="green",
        title=_("Total Sales"),
        value=(_get_lifetime_sales(order_ids, supplier, currency) or 0),
        currency=currency,
        icon="fa fa-line-chart",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def get_avg_purchase_size_block(order_ids, supplier, currency="USD"):
    return DashboardMoneyBlock(
        id="average_purchase_sum",
        color="blue",
        title=_("Average Sales Amount"),
        value=(_get_avg_purchase_size(order_ids, supplier, currency) or 0),
        currency=currency,
        icon="fa fa-shopping-cart",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def _get_favorite_categories(shop_id, supplier, order_ids):
    return Category.objects.filter(
        shop_products__shop_id=shop_id,
        shop_products__product__order_lines__order_id__in=order_ids,
        shop_products__product__order_lines__supplier=supplier
    ).annotate(
        total_sales=Count('shop_products__product__order_lines__quantity')
    ).order_by('-total_sales')[:20]


def _get_favorite_shop_products(shop_id, supplier, order_ids):
    return ShopProduct.objects.filter(
        shop_id=shop_id,
        product__order_lines__order__id__in=order_ids,
        product__order_lines__supplier=supplier
    ).annotate(
        total_sales=Sum('product__order_lines__quantity')
    ).order_by('-total_sales')[:20]


def _get_new_customers(shop_id, supplier, cutoff_date):
    query = """
        SELECT COUNT(pc.contact_ptr_id)
        FROM shuup_personcontact as pc
        WHERE %s < (
            SELECT o.order_date
            FROM shuup_order as o, shuup_orderline as ol
            WHERE o.id = ol.order_id
            AND pc.contact_ptr_id = o.customer_id
            AND o.shop_id = %s
            AND ol.supplier_id = %s
            ORDER BY o.order_date ASC
            LIMIT 1
        )
    """.strip()  # noqa
    cursor = connection.cursor()
    cursor.execute(query, [cutoff_date, shop_id, supplier.id])
    return cursor.fetchone()[0]


def _get_returning_customers(shop_id, order_ids, supplier, cutoff_date):
    return len(order_ids) - _get_new_customers(shop_id, supplier, cutoff_date)


def _get_lifetime_sales(order_ids, supplier, currency):
    taxless_total = TaxlessPrice(0, currency)
    for order in Order.objects.filter(id__in=order_ids):
        for line in order.lines.filter(supplier=supplier):
            taxless_total += line.taxless_price
    return taxless_total


def _get_avg_purchase_size(order_ids, supplier, currency):
    prices = []
    for order in Order.objects.filter(id__in=order_ids):
        for line in order.lines.filter(supplier=supplier):
            prices.append(line.taxless_price)
    return reduce(lambda x, y: x + y, prices) / len(prices)


class VendorValueChartDashboardBlock(OrderValueChartDashboardBlock):
    def get_chart(self):
        if self.cached_chart is not None:
            return self.cached_chart

        chart_options = {
            "scales": {
                "yAxes": [{
                    "ticks": {
                        "beginAtZero": True
                    }
                }]
            }
        }
        today = datetime.date.today()
        chart_start_date = today - datetime.timedelta(days=365)

        orders = get_orders_for_shop(self.request).complete().since((today - chart_start_date).days)
        order_lines = OrderLine.objects.filter(supplier=get_supplier(self.request), order__in=orders).values(
            year=ExtractYear("order__order_date"),
            month=ExtractMonth("order__order_date"),
        ).annotate(
            total_price=Sum(F("base_unit_price_value") * F("quantity") - F("discount_amount_value"))
        )

        sum_sales_data = defaultdict(Decimal)
        for year, month, total in order_lines.values_list("year", "month", "total_price"):
            month_date = datetime.date(year, month, 1)
            sum_sales_data[month_date] = total

        for (month, year) in month_iter(chart_start_date, today):
            sales_date = datetime.date(year, month, 1)
            if sales_date not in sum_sales_data:
                sum_sales_data[sales_date] = Decimal()

        # sort and recreated the ordered dict since we've put new items into
        sum_sales_data = OrderedDict(sorted(six.iteritems(sum_sales_data), key=lambda x: x[0]))

        locale = get_current_babel_locale()
        labels = [
            format_date(k, format=get_year_and_month_format(locale), locale=locale)
            for k in sum_sales_data
        ]
        mixed_chart = MixedChart(
            title=_("Sales per Month (past 12 months)"),
            labels=labels,
            data_type=ChartDataType.CURRENCY,
            options=chart_options,
            currency=self.currency,
            locale=locale
        )

        cumulative_sales = []
        average_sales = []

        # only calculate cumulative and average if there are at least 3 months
        if len(sum_sales_data) >= 3:
            count = 0
            total = Decimal()

            for month_sale in sum_sales_data.values():
                total = total + month_sale
                cumulative_sales.append(total)
                average_sales.append(total / (count+1))
                count = count + 1

        # this will be on top of all bars
        if average_sales:
            mixed_chart.add_data(_("Average Sales"), [v for v in average_sales], ChartType.LINE)

        # this will be under the cummulative bars
        mixed_chart.add_data(_("Sales"), [v for v in sum_sales_data.values()], ChartType.BAR)

        # this will be under all others charts
        if cumulative_sales:
            mixed_chart.add_data(_("Cumulative Total Sales"), [v for v in cumulative_sales], ChartType.BAR)

        self.cached_chart = mixed_chart
        return mixed_chart


def get_vendor_order_chart_dashboard_block(request, currency):
    return VendorValueChartDashboardBlock(id="vendor_order_value_chart", request=request)
