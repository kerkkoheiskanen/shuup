# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from logging import getLogger

from django import forms
from django.templatetags.static import static
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.image import ImageIDField
from shuup.xtheme.resources import add_resource

LOGGER = getLogger(__name__)


class VendorMapFilterPlugin(TemplatedPlugin):
    identifier = "multivendor_vendor_map_filter"
    name = _("Vendor Map")
    template_name = "shuup_multivendor/plugins/vendor_map.jinja"
    fields = [
        ("initial_map_position", forms.CharField(
            required=True,
            label=_("Fallback map position coordinates"),
            help_text=_(
                "Enter a pair of GPS coordinates that will be used as the fallback position "
                "on the map when the user location is not available using the format: latitude, longitude."
            )
        )),
        ("custom_pin", ImageIDField(
            required=False,
            label=_("Custom map pin"),
            help_text=_("Select an image to use as the vendor pin.")
        )),
        ("map_height", forms.IntegerField(required=True, label=_("Map height in pixels"), initial=400, min_value=1)),
        ("show_filter_alert", forms.BooleanField(
            required=False,
            label=_("Show filter info"),
            initial=True,
            help_text=_("Show the filter alert info when browsing the selected vendor products.")
        )),
        ("default_map_zoom", forms.IntegerField(required=False, label=_("Default map zoom"), initial=15)),
        ("init_map_collapsed", forms.BooleanField(
            required=False,
            label=_("Initialize the map collapsed"),
            initial=True
        )),
        ("location_no_permission_msg", forms.CharField(
            required=False,
            label=_("Message to show to the user when the location permission is turned off"),
            initial=_("Could not load your current locations since permission is turned off.")
        )),
        ("location_no_permission_no_address_msg", forms.CharField(
            required=False,
            label=_(
                "Message to show to the user when the location permission is turned off and user has no address set"
            ),
            initial=_(
                "Could not load your current locations since permission is turned off and you don’t have address set."
            ),
            help_text=_("This will be shown only for logged users.")
        ))
    ]

    def _render_message(self, context, config):
        template = self.config.get(config) or ""
        if not template:
            template = force_text(_("Could not load your current locations since permission is turned off."))

        from django.template import engines
        for engine_name in engines:
            engine = engines[engine_name]
            try:
                return engine.env.from_string(template).render(context)
            except Exception:
                LOGGER.exception("Failed to render message string in VendorMapFilterPlugin plugin")
                return force_text(_("(Error while rendering)"))

    def get_context_data(self, context):
        custom_pin = self.config.get("custom_pin")
        if custom_pin:
            from filer.models import Image
            custom_pin = Image.objects.filter(pk=custom_pin).first()

        request = context["request"]
        search_address = None
        if request.GET.get("address") and request.GET.get("location") and "," in request.GET["location"]:
            search_address = {
                "address": request.GET["address"],
                "location": request.GET["location"]
            }

        current_vendor = context.get("supplier")
        map_height = self.config.get("map_height")
        return {
            "vendor_map_settings": {
                "user": request.user.pk if request.user else None,
                "custom_pin": custom_pin.url if custom_pin else None,
                "initial_map_position": self.config.get("initial_map_position"),
                "map_height": "{}px".format(map_height) if map_height else None,
                "current_vendor": current_vendor.pk if current_vendor else None,
                "show_filter_alert": self.config.get("show_filter_alert", True),
                "default_map_zoom": self.config.get("default_map_zoom", 15),
                "init_map_collapsed": self.config.get("init_map_collapsed", True),
                "location_no_permission_msg": self._render_message(context, "location_no_permission_msg"),
                "location_no_permission_no_address_msg": self._render_message(
                    context, "location_no_permission_no_address_msg"
                ),
                "search_address": search_address
            }
        }

    def render(self, context):
        add_resource(context, "head_end", "%s?v=0.7.3.css" % static("shuup_multivendor/vendor-map.css"))
        add_resource(context, "body_end", "%s?v=0.7.3.js" % static("shuup_multivendor/vendor-map.js"))
        return super(VendorMapFilterPlugin, self).render(context)
