# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext as _
from shuup.admin.modules.orders.sections import BasicDetailsOrderSection


class MultivendorOrderDetailsSection(BasicDetailsOrderSection):
    """
    Just change the template.

    IMPORTANT: You must blacklist the Shuup OS default basic section provides,
    otherwise there will be duplicated basic order sections
    """
    name = _("Basic Details")
    template = "shuup_multivendor/admin/orders/_detail_section.jinja"
