# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.admin.shop_provider import get_shop

from shuup_multivendor.models import VendorFunds
from shuup_multivendor.utils.funds import (
    get_withdraw_help_text, is_vendor_funds_enabled
)


class PendingWithdrawalsForm(forms.Form):
    def __init__(self, *args, **kwargs):
        self.shop = kwargs.pop("shop")
        self.vendor = kwargs.pop("vendor")
        super(PendingWithdrawalsForm, self).__init__(*args, **kwargs)

    def get_withdrawals_queryset(self):
        return list(VendorFunds.get_withdrawals_queryset(self.vendor))

    def get_withdraw_help_text(self):
        return get_withdraw_help_text(self.shop)


class VendorPendingWithdrawalsFormPart(FormPart):
    priority = 90
    name = "funds_pending_withdrawal"

    def get_form_defs(self):
        shop = get_shop(self.request)
        if not is_vendor_funds_enabled(shop):
            return

        vendor = self.object
        if not VendorFunds.get_withdrawals_queryset(vendor).exists():
            return

        yield TemplatedFormDef(
            self.name,
            form_class=PendingWithdrawalsForm,
            template_name="shuup_multivendor/admin/vendor/open_withdrawals_template.jinja",
            required=False,
            kwargs={"vendor": vendor, "shop": shop}
        )
