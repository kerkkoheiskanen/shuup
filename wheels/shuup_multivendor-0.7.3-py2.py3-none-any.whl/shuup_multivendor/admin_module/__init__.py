# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from shuup_multivendor.admin_module.modules.discounts import \
    VendorDiscountsAdminModule
from shuup_multivendor.admin_module.modules.management import \
    MultivendorVendorAdminModule
from shuup_multivendor.admin_module.modules.orders import \
    MultivendorOrdersAdminModule
from shuup_multivendor.admin_module.modules.pages import \
    MultivendorSimpleCMSAdminModule
from shuup_multivendor.admin_module.modules.products import \
    MultivendorProductsAdminModule
from shuup_multivendor.admin_module.modules.settings import \
    VendorSettingsAdminModule
from shuup_multivendor.admin_module.modules.users import MultivendorUserModule

__all__ = [
    "VendorDiscountsAdminModule",
    "MultivendorVendorAdminModule",
    "MultivendorOrdersAdminModule",
    "MultivendorProductsAdminModule",
    "MultivendorSimpleCMSAdminModule",
    "MultivendorUserModule",
    "VendorSettingsAdminModule"
]
