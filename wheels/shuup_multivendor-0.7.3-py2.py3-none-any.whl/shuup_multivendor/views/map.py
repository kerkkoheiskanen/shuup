# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from calendar import timegm

from django.core.urlresolvers import reverse
from django.db import models
from django.db.models import Count, OuterRef, Subquery
from django.http.response import Http404, JsonResponse
from django.utils.cache import get_conditional_response
from django.utils.http import http_date
from django.views.generic import View
from rest_framework import serializers
from shuup.core.models import MutableAddress, Product, Supplier


class VendorAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = MutableAddress
        fields = (
            "street", "street2", "street3", "postal_code", "city",
            "region_code", "region", "country", "latitude", "longitude"
        )


class VendorSerializer(serializers.ModelSerializer):
    contact_address = VendorAddressSerializer()
    logo = serializers.SerializerMethodField()
    number_of_products = serializers.IntegerField()
    detail_url = serializers.SerializerMethodField()

    class Meta:
        model = Supplier
        fields = ("id", "name", "description", "logo", "contact_address", "number_of_products", "detail_url")

    def get_logo(self, instance):
        if instance.logo and instance.logo.url:
            request = self.context["request"]
            return request.build_absolute_uri(instance.logo.url)

    def get_detail_url(self, instance):
        return reverse("shuup:supplier", kwargs=dict(pk=instance.pk))


class VendorMapView(View):
    def head(self, request, *args, **kwargs):
        return self._get_vendor_json_response(request)

    def get(self, request, *args, **kwargs):
        if request.is_ajax():
            return self._get_vendor_json_response(request)
        # Nothing to see if not ajax request
        raise Http404()

    def _get_vendor_json_response(self, request):
        products = Product.objects.listed(request.shop, request.customer).filter(
            shop_products__suppliers__pk=OuterRef("pk")
        )
        vendors = Supplier.objects.enabled().filter(shops=request.shop)
        vendors_with_products_count = vendors.annotate(
            number_of_products=Subquery(
                products.order_by().values("shop_products__suppliers__pk").annotate(total=Count("*")).values("total"),
                output_field=models.IntegerField()
            )
        )

        last_vendor_modification = vendors.latest("modified_on").modified_on if vendors.exists() else None
        if last_vendor_modification:
            last_vendor_modification = timegm(last_vendor_modification.utctimetuple())

        response = get_conditional_response(request, last_modified=last_vendor_modification)
        if response is None:
            context = dict(request=self.request)
            vendors_data = VendorSerializer(vendors_with_products_count, many=True, context=context).data
            response = JsonResponse(vendors_data, safe=False)

        if last_vendor_modification and not response.has_header("Last-Modified"):
            # say to browsers that they can cache locally the response for 1 minute
            # after that they should do a HEAD request to check whether the content has changed
            response["Last-Modified"] = http_date(last_vendor_modification)
            response["Cache-Control"] = "max-age=60"   # 1 minute

        return response
