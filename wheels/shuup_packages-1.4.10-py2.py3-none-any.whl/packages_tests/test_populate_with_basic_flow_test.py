# -*- coding: utf-8 -*-
import pytest
import random

from django.conf import settings
from django.core import management
from django.db.models.signals import post_save
from django.test import override_settings
from shuup.core.models import Order, Product, SalesUnit, Supplier
from shuup.testing import factories

from packages.models import Package, PackageLocation
from packages.signal_handlers import handle_package_post_save


@override_settings(SHUUP_PACKAGES_AUTO_ATTACH_PRE_PACKS_TO_ORDER=True)
@pytest.mark.django_db
def test_populate():
    factories.get_default_product_type()
    sales_unit = SalesUnit.objects.create(identifier="pcs")  # Pretty harsh demand
    factories.get_default_tax_class()
    shop = factories.get_default_shop()

    identifier = "%s-package-based-stocks" % shop.id
    supplier = Supplier.objects.create(
        identifier=identifier, name=shop.name, module_identifier="package_supplier")
    supplier.shops = [shop]

    for i in range(0, 5):
        product = factories.create_product(
            sku="%s" % i, shop=shop, supplier=supplier, default_price=10,
            sales_unit=sales_unit
        )

    # Populate packages so that all products should have
    # 20 pre-packs in sale before creating orders.
    management.call_command("populate_inventory", *[], **{})
    # Reconnect the post save signal for stock updates
    post_save.connect(sender=Package, receiver=handle_package_post_save, dispatch_uid="handle_package_post_save")

    assert Package.objects.count() == 500
    for product in Product.objects.all():
        stock_status = supplier.get_stock_status(product.id)
        assert stock_status.logical_count == 20
        assert stock_status.physical_count == 20

        quantity = random.randint(1, 20)
        n_lines = int(20 / quantity)
        factories.create_order_with_product(
            product=product, supplier=supplier, quantity=quantity,
            taxless_base_unit_price=10, n_lines=n_lines, shop=shop)

        stock_status = supplier.get_stock_status(product.id)
        assert stock_status.logical_count == (20 - (quantity * n_lines))
        assert stock_status.physical_count == (20 - (quantity * n_lines))

    # Since 5 products we should have 5 orders in system
    #
    # 1. Lets cancel one of those
    assert Order.objects.valid().count() == 5
    canceled_location = PackageLocation.objects.filter(
        supplier=supplier, name=settings.SHUUP_PACKAGES_CANCEL_LOCATION_NAME).first()
    assert not canceled_location.sellable
    assert Package.objects.filter(location=canceled_location).count() == 0
    order_to_cancel = Order.objects.order_by("?").first()
    order_to_cancel.set_canceled()

    # Now signal handler should move packages linked to this order
    # to canceled location. Since canceled location is not sellable here
    # the stock statuses for products should be untouched.
    for product_lines in order_to_cancel.lines.products():
        stock_status = supplier.get_stock_status(product_lines.product.id)
        assert stock_status.logical_count < 20
        assert stock_status.physical_count < 20

    # Moving packages from cancelled location to counter
    # (which is sellabel location) should make stocks 20 again
    counter = PackageLocation.objects.filter(name="Counter 1", supplier=supplier).first()
    for package in Package.objects.filter(location=canceled_location):
        package.location = counter
        package.save()

    for product_lines in order_to_cancel.lines.products():
        stock_status = supplier.get_stock_status(product_lines.product.id)
        assert stock_status.logical_count == 20
        assert stock_status.physical_count == 20

    # 2. Lets create payment and fully refund order
    assert Order.objects.valid().count() == 4
    refunded_location = PackageLocation.objects.filter(
        supplier=supplier, name=settings.SHUUP_PACKAGES_REFUND_LOCATION_NAME).first()
    assert not refunded_location.sellable
    order_to_refund = Order.objects.valid().order_by("?").first()
    order_to_refund.create_payment(order_to_refund.taxful_total_price)
    assert order_to_refund.is_paid()
    order_to_refund.create_full_refund()

    # Now signal handler should move packages linked to this order
    # to refund location. Since canceled location is not sellable here
    # the stock statuses for products should be untouched.
    for product_lines in order_to_refund.lines.products():
        stock_status = supplier.get_stock_status(product_lines.product.id)
        assert stock_status.logical_count < 20
        assert stock_status.physical_count < 20

    # Moving packages from refund location to counter
    # (which is sellabel location) should make stocks 20 again
    counter = PackageLocation.objects.filter(name="Counter 1", supplier=supplier).first()
    for package in Package.objects.filter(location=refunded_location):
        package.location = counter
        package.save()

    for product_lines in order_to_refund.lines.products():
        stock_status = supplier.get_stock_status(product_lines.product.id)
        assert stock_status.logical_count == 20
        assert stock_status.physical_count == 20
