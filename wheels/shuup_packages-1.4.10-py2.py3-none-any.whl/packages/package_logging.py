# -*- coding: utf-8 -*-
from shuup.utils.analog import LogEntryKind


PRODUCT_CREATED_LOG_ENTRY_TEMPLATE = """
    Package (pid: %(package_id)s) created to location %(location)s (lid: %(location_id)s) with barcode: [%(barcode)s].
""".strip()


def create_package_created_log(package):
    message = PRODUCT_CREATED_LOG_ENTRY_TEMPLATE % {
        "package_id": package.id,
        "location": package.location if package.location else "Empty",
        "location_id": package.location.id if package.location else "Empty",
        "barcode": package.barcode
    }

    from packages.models import PackageLogEntry
    PackageLogEntry.objects.create(
        target=package,
        message=message[:256],
        kind=LogEntryKind.NOTE,
    )


PACKAGE_MOVE_LOG_ENTRY_TEMPLATE = """
    Package (pid: %(package_id)s) moved to location %(to_location)s (lid: %(to_location_id)s)
    from location %(from_location)s (lid: %(from_location_id)s)
""".strip()


def create_package_moved_log(package, old_location):
    message = PACKAGE_MOVE_LOG_ENTRY_TEMPLATE % {
        "package_id": package.id,
        "to_location": package.location if package.location else "Empty",
        "to_location_id": package.location.id if package.location else "Empty",
        "from_location": old_location,
        "from_location_id": old_location.id
    }

    from packages.models import PackageLogEntry
    PackageLogEntry.objects.create(
        target=package,
        message=message[:256],
        kind=LogEntryKind.EDIT,
    )


PACKAGE_CONDITION_CHANGED_LOG_ENTRY_TEMPLATE = """
    Package (pid: %(package_id)s) condition changed to %(to_condition)s (lid: %(to_condition_id)s)
    from location %(from_condition)s (lid: %(from_condition_id)s)
""".strip()


def create_package_condition_changed_log(package, old_condition):
    message = PACKAGE_CONDITION_CHANGED_LOG_ENTRY_TEMPLATE % {
        "package_id": package.id,
        "to_condition": package.condition if package.condition else "Unknown",
        "to_condition_id": package.condition.id if package.condition else "Unknown",
        "from_condition": old_condition,
        "from_condition_id": old_condition.id
    }

    from packages.models import PackageLogEntry
    PackageLogEntry.objects.create(
        target=package,
        message=message[:256],
        kind=LogEntryKind.EDIT,
    )


PACKAGE_BARCODE_UPDATED_LOG_ENTRY_TEMPLATE = """
    Package (pid: %(package_id)s) barcode changed to [%(to_barcode)s] from [%(from_barcode)s].
""".strip()


def create_barcode_changed_log(package, old_barcode):
    message = PACKAGE_BARCODE_UPDATED_LOG_ENTRY_TEMPLATE % {
        "package_id": package.id,
        "to_barcode": package.barcode,
        "from_barcode": old_barcode,
    }

    from packages.models import PackageLogEntry
    PackageLogEntry.objects.create(
        target=package,
        message=message[:256],
        kind=LogEntryKind.EDIT,
    )


PACKAGE_LINKED_TO_ORDER = """
    Package (pid: %(package_id)s) linked to order #%(order_id)s at order line: %(order_line_id)s.
""".strip()


def create_order_attached_to_package_log(package, order_id, order_line_id):
    message = PACKAGE_LINKED_TO_ORDER % {
        "package_id": package.id,
        "order_id": order_id,
        "order_line_id": order_line_id
    }

    from packages.models import PackageLogEntry
    PackageLogEntry.objects.create(
        target=package,
        message=message[:256],
        kind=LogEntryKind.EDIT,
    )


PACKAGE_CONTENT_WEIGHT_CHANGED_TEMPLATE = """
    Package (pid: %(package_id)s) content weight changed to %(to_weight)s from %(from_weight)s.
""".strip()


def create_package_content_weight_changed_log(package, old_content_weight):
    message = PACKAGE_CONTENT_WEIGHT_CHANGED_TEMPLATE % {
        "package_id": package.id,
        "to_weight": package.content_weight,
        "from_weight": old_content_weight
    }

    from packages.models import PackageLogEntry
    PackageLogEntry.objects.create(
        target=package,
        message=message[:256],
        kind=LogEntryKind.EDIT,
    )
