# -*- coding: utf-8 -*-
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from shuup.core.models import Order

from packages.models import Package, PackageMeasurement, PackageType


@receiver(post_save, sender=Order)  # noqa: too complex
def handle_order_measurements_automatically(sender, instance, **kwargs):
    """
    Handle order measurements automatically with pre packs

    Use oldest packages first.

    Warning! Should not be activated to instances or shops with
    bulk packages enabled.
    """
    if not settings.SHUUP_PACKAGES_AUTO_ATTACH_PRE_PACKS_TO_ORDER:
        return

    if PackageMeasurement.objects.filter(order=instance).exists():
        return  # Some measurements already made so we expect all good with this one.

    for order_line in instance.lines.products():
        packages = Package.objects.is_in_sale().filter(
            product_id=order_line.product_id, type=PackageType.PRE_PACKED,
        ).order_by("-created_on")[:order_line.quantity]

        for package in packages:
            PackageMeasurement.objects.create(
                package=package,
                last_weight=package.total_weight,
                total_weight=0,  # Always adjust pre-packs for order zero
                created_by=instance.creator,
                order=instance,
                order_line=order_line
            )

        order_line.supplier.update_stock(order_line.product.id)
