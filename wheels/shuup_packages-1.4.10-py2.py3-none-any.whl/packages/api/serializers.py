# -*- coding: utf-8 -*-
from functools import lru_cache

from django.utils.translation import ugettext_lazy as _
from rest_framework import exceptions, serializers
from shuup.api.fields import EnumField, FormattedDecimalField
from shuup.core.api.front_orders import OrderLineSerializer
from shuup.core.models import Product, ShopProduct

from packages.api.package import PackageSerializer
from packages.models import (
    BatchPackageTransfer, Package, PackageMeasurement,
    PackageRestockDestination, PackageType
)
from packages.modules import PackageSupplierModule


class OrderPackageSerializer(PackageSerializer):
    products = serializers.SerializerMethodField()

    class Meta(PackageSerializer.Meta):
        fields = ["id", "name", "type", "packaging_weight", "total_weight", "content_weight", "product", "products"]

    def get_products(self, package):
        return [package.product.id] + list(package.product.variation_children.values_list("id", flat=True))


class OrderPackagesOrderLineSerializer(OrderLineSerializer):
    total_net_weight = serializers.SerializerMethodField()

    class Meta(OrderLineSerializer.Meta):
        fields = ["id", "text", "quantity", "total_net_weight", "product"]

    def get_total_net_weight(self, line):
        return line.product.net_weight * line.quantity


class OrderPackagesSerializer(serializers.Serializer):
    lines = serializers.SerializerMethodField()
    packages = serializers.SerializerMethodField()

    @lru_cache()
    def get_order_lines(self, order):
        return [line for line in order.lines.products() if (
            line.supplier and line.supplier.module_identifier == PackageSupplierModule.identifier
        )]

    def get_lines(self, order):
        return OrderPackagesOrderLineSerializer(self.get_order_lines(order), many=True).data

    def get_packages(self, order):
        packages = Package.get_packages_for_order(order).distinct()
        return OrderPackageSerializer(packages, many=True, context=self.context).data


class BulkStockAdjustmentSerializer(serializers.Serializer):
    package = serializers.PrimaryKeyRelatedField(queryset=Package.objects.all())
    delta = FormattedDecimalField()
    destination = EnumField(PackageRestockDestination, required=False)


class OrderPackageStockAdjustmentSerializer(serializers.Serializer):
    pre_packed_lines = serializers.ListField(child=serializers.IntegerField(), required=False)
    bulk_weighing = BulkStockAdjustmentSerializer(many=True, required=False)
    restock_bulk = serializers.BooleanField(required=False)

    def validate(self, attrs):
        order = self.instance

        pre_packed_lines = attrs.get("pre_packed_lines")
        bulk_weighing = attrs.get("bulk_weighing")

        if not pre_packed_lines and not bulk_weighing:
            raise serializers.ValidationError(_("You should adjust the pre-packed or bulk."))

        if bulk_weighing:
            bulk_packages = []
            for bulk_weigh in bulk_weighing:
                if bulk_weigh["package"].id in bulk_packages:
                    msg = _("Duplicated bulk package in adjustment: {}.").format(bulk_weigh["package"])
                    raise serializers.ValidationError(msg)
                bulk_packages.append(bulk_weigh["package"].id)

        if pre_packed_lines and not attrs.get("restock_bulk"):
            order_line_ids = list(
                order.lines.products().filter(
                    supplier__module_identifier=PackageSupplierModule.identifier
                ).values_list("id", flat=True)
            )
            for pre_packed_line in pre_packed_lines:
                if pre_packed_line not in order_line_ids:
                    raise serializers.ValidationError(_("{} is an invalid line id.").format(pre_packed_line))

        return attrs

    def save(self, **kwargs):
        data = self.validated_data
        order = self.instance

        # make the adjustments for pre-packed
        pre_packed_lines = data.get("pre_packed_lines")
        if pre_packed_lines and not data.get("restock_bulk"):
            order_lines = order.lines.products().filter(id__in=pre_packed_lines)

            # take the first available order_line
            for order_line in order_lines:
                # use a packed for each quantity of the product
                for qty in range(int(order_line.quantity)):
                    package = Package.objects.filter(
                        product_id=order_line.product_id,
                        type=PackageType.PRE_PACKED,
                        has_orders=False
                    ).first()

                    if not package:
                        raise serializers.ValidationError(_("No pre-packed available."))

                    PackageMeasurement.objects.create(
                        package=package,
                        last_weight=package.total_weight,
                        total_weight=0,  # Always adjust pre-packs for order zero
                        created_by=self.context["request"].user,
                        order=order,
                        order_line=order_line
                    )
                    package.save()

        # make the adjustments for bulk packages
        for bulk_weighing in data.get("bulk_weighing", []):
            package = bulk_weighing["package"]

            if bulk_weighing.get("destination") == PackageRestockDestination.NEW_PACKAGE:
                original_package = Package.objects.get(id=package.id)
                # create a new package
                package.pk = None
                package.content_weight = 0
                package.total_weight = 0
                package.save()

                if hasattr(original_package, "batch_transfer"):
                    package_transfer = BatchPackageTransfer(
                        package=package,
                        batch=original_package.batch_transfer.batch,
                        quantity=0,
                        created_by=self.context["request"].user
                    )
                    package_transfer.full_clean()
                    package_transfer.save()

            PackageMeasurement.objects.create(
                package=package,
                last_weight=package.total_weight,
                total_weight=bulk_weighing["delta"],
                created_by=self.context["request"].user,
                order=order
            )
            package.save()


class ProductPackageConfigSerializer(serializers.Serializer):
    product = serializers.PrimaryKeyRelatedField(queryset=Product.objects.all_except_deleted(), required=False)
    net_weight = FormattedDecimalField(required=False)
    alert_limit = FormattedDecimalField(required=False, allow_null=True)

    def validate(self, attrs):
        data = super(ProductPackageConfigSerializer, self).validate(attrs)
        package = self.context["package"]
        product = data["product"]
        if not ShopProduct.objects.filter(supplier=package.supplier, product_id=product.id).exists():
            raise exceptions.ValidationError("Product does not exist.")

        if "net_weight" in data:
            if data["net_weight"] <= 0:
                raise exceptions.ValidationError("Weight needs to be positive value.")

        return data


class ProductPackageConfigsSerializer(serializers.Serializer):
    products = ProductPackageConfigSerializer(many=True, required=False)

    def create(self, data):
        package = self.context["package"]

        for product_config in data["products"]:
            product = product_config["product"]

            if "net_weight" in product_config:
                product.net_weight = product_config["net_weight"]
                product.save()

        return package


class PackageBasketMeasurementSerializer(serializers.Serializer):
    line_id = serializers.CharField()
    package = serializers.IntegerField()
    value = FormattedDecimalField(min_value=0, required=False, allow_null=True)

    def create(self, attrs):
        order = self.context["order"]
        basket = self.context["basket"]
        user = self.context["request"].user

        basket_line = basket.get_basket_line(attrs["line_id"])
        value = attrs.get("value")
        measurement = None

        if not basket_line:
            raise exceptions.ValidationError(_("Invalid line for measurement."))

        # find the corresponding order line for the basket line
        order_lines = [
            order_line
            for order_line in order.lines.filter(quantity=basket_line.quantity, product=basket_line.product)
            if order_line.extra_data["source_line_id"] == attrs["line_id"]
        ]
        order_line = order_lines[0] if order_lines else None

        if not order_line:
            raise exceptions.ValidationError(_("Failed to find order line for basket line measurement."))

        package = Package.objects.filter(supplier=order_line.supplier, id=attrs["package"]).first()
        if not package:
            raise exceptions.ValidationError(_("Invalid package for measurement."))

        if package.type == PackageType.PRE_PACKED:
            if order_line.product != package.product:
                raise exceptions.ValidationError(_("Order line product doesn't match package product."))

            measurement = PackageMeasurement.objects.create(
                package=package,
                last_weight=package.total_weight,
                total_weight=0,
                created_by=user,
                order=order,
                order_line=order_line
            )
            package.save()

        elif package.type == PackageType.BULK:
            variation_ids = list(package.product.variation_children.values_list("id", flat=True))
            if order_line.product.id not in ([package.product.id] + variation_ids):
                raise exceptions.ValidationError(_("Order line product doesn't match package product."))

            if value is None:
                raise exceptions.ValidationError(_("Invalid value for bulk measurement."))

            measurement = PackageMeasurement.objects.create(
                package=package,
                last_weight=package.total_weight,
                total_weight=value,
                created_by=user,
                order=order,
                order_line=order_line
            )
            package.save()

        return measurement
