# -*- coding: utf-8 -*-
from .batch import ShuupBatchViewSet
from .package import PackageSupplierViewSet


def populate_api(router):
    # For batch transfers, batch packages and product summary
    router.register("packages/batch", ShuupBatchViewSet)

    # For printing labels
    router.register("packages/package_supplier", PackageSupplierViewSet)
