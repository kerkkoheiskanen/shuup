# -*- coding: utf-8 -*-
from django.conf import settings
from django.db.models import Count, DecimalField, F, Q, Sum
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import OrderLine, OrderStatusRole, Product
from shuup.reports.report import ShuupReportBase
from shuup.utils.dates import to_datetime_range

from packages.models import Package
from packages.utils import get_supplier_from_request

LOCATIONS = [
    settings.SHUUP_PACKAGES_DESTROYED_LOCATION_NAME,
    settings.SHUUP_PACKAGES_LOST_LOCATION_NAME,
    settings.SHUUP_PACKAGES_RETURNED_TO_DISTRIBUTOR_LOCATION_NAME,
    settings.SHUUP_PACKAGES_OTHER_REDUCTION_LOCATION_NAME,
    settings.SHUUP_PACKAGES_SOLD_LOCATION_NAME
]


class CannabisComplianceReport(ShuupReportBase):
    identifier = "package-inventory-cannabis-compliance-report"
    title = _("Package Inventory - Cannabis Retailer Compliance Report")
    description = _("Compliance report for government of Canada.")
    filename_template = "cannabis-compliance-report-%(time)s"

    schema = [
        {"key": "name", "title": _("Name")},
        {"key": "sku", "title": _("SKU")},
        {"key": "opening_inventory_units", "title": _("Opening Inventory (Units)")},
        {"key": "opening_inventory_values", "title": _("Opening Inventory (Values)")},
        {"key": "quantity_purchased_units", "title": _("Quantity Purchased (Units)")},
        {"key": "quantity_purchased_values", "title": _("Quantity Purchased (Values)")},
        {"key": "returns_from_customers_units", "title": _("Returns from Customers (Units)")},
        {"key": "returns_from_customers_values", "title": _("Returns from Customers (Values)")},
        {"key": "other_additions_units", "title": _("Other Additions (Units)")},
        {"key": "other_additions_values", "title": _("Other Additions (Values)")},
        {"key": "quantity_sold_units", "title": _("Quantity sold (Units)")},
        {"key": "quantity_sold_values", "title": _("Quantity sold (Values)")},
        {"key": "quantity_destroyed_units", "title": _("Quantity destroyed (Units)")},
        {"key": "quantity_destroyed_values", "title": _("Quantity destroyed (Values)")},
        {"key": "quantity_lost_units", "title": _("Quantity Lost / Theft (Units)")},
        {"key": "quantity_lost_values", "title": _("Quantity Lost / Theft (Values)")},
        {"key": "returns_to_government_units", "title": _("Returns to Government (Units)")},
        {"key": "returns_to_government_values", "title": _("Returns to Government (Values)")},
        {"key": "other_reductions_units", "title": _("Other Reductions (Units)")},
        {"key": "other_reductions_values", "title": _("Other Reductions (Values)")}
    ]

    def get_objects(self):
        self.supplier = get_supplier_from_request(self.request)
        return Product.objects.all_except_deleted().filter(
            shop_products__suppliers=self.supplier).values_list("id", "sku", "translations__name")

    def get_opening_inventory_units_and_values(self, product):
        """
        Opening Inventory) = OrderReOrderReportMixinportMixin
        (Last Month’s Opening Inventory) + (Last Month’s Purchases) +
        (Last Month’s Returns) – (Last Month’s Returns to AGLC) –
        (Last Month’s Sales) – (Last Month’s Destructions) –
        (Last Month’s Theft/Lost Products) + (Last Month’s Other Additions) –
        (Last Month’s Other Reductions

        (Opening Inventory) =
        (Last Month’s Opening Inventory) + (Last Month’s Purchases) +
        (Last Month’s Returns) – (Last Month’s Returns to AGLC) –
        (Last Month’s Sales) – (Last Month’s Destructions) –
        (Last Month’s Thefts) + (Last Month’s Other Additions) – (Last Month’s Other
        Reductions)
        """
        results = (
            Package.objects.filter(
                product_id=product,
                supplier=self.supplier,
                measurements__created_on__lt=self.start_date
            ).exclude(
                Q(location__isnull=True) |
                Q(location__name__in=LOCATIONS)
            ).aggregate(
                total_units=Count("purchase_price_value"),
                total_value=Sum("purchase_price_value"),
            )
        )
        return results["total_units"] or 0, results["total_value"] or 0

    def get_returns_from_customers_units(self, product):
        """
        Returns from Customers) =
        (All returned eaches, of a given product, within a calendar month)
        *Any returns to the AGLC should not be accounted for in this calculation and
        if a return results in a destruction, the initial return must be accounted
        for in this calculation.
        """
        return 0  # A number ranging from 0 to 1,000,000

    def get_returns_from_customers_values(self, product):
        """
        Returns from Customers) =
        (The retail value of all returned eaches of a given product within a calendar
        month)
        *Any returns to the AGLC should not be accounted for in this calculation and if
        a return results in a destruction, the initial return must be accounted for in
        this calculation.
        """
        return 0  # A number ranging from 0 to 1,000,000 with a maximum of two decimal points

    def get_other_additions_units(self, product):
        """
        (Other Additions) =
        (All product eaches, of a given cannabis product, which are received by a
        cannabis retail establishment that are not a purchase or return)
        """
        return 0  # A number ranging from 0 to 1,000,000

    def get_other_additions_values(self, product):
        """
        Other Additions) =
        (All eaches, of a given product, which are accounted for at a retail
        establishment and received via legal means)
        """
        return 0  # A number ranging from $0 to $999,999,999 with a maximum of two decimal points

    def get_quantity_sold_units_and_values(self, product):
        """
        (Quantity Sold) = (All eaches of a given SKU sold within a calendar month)

        (Quantity Sold) = (All eaches, of a SKU, recorded in the total number of
        eaches sold within a calendar month)
        """
        results = OrderLine.objects.filter(supplier=self.supplier, product_id=product).exclude(
            Q(order__deleted=True) | Q(order__status__role=OrderStatusRole.CANCELED)
        ).aggregate(
            total_units=Sum("quantity"),
            total_value=Sum(F("base_unit_price_value") * F("quantity"), output_field=DecimalField())
        )
        return results["total_units"] or 0, results["total_value"] or 0

    def get_quantity_destroyed_units_and_value(self, product):
        """
        (Quantity Destroyed) =
        (All eaches of a given product or SKU destroyed on the premises of a cannabis
        retail establishment within a calendar month)

        (Quantity Destroyed) =
        (The retail value of all eaches of a given product or SKU destroyed on the
        premises of a cannabis retail establishment within a calendar month)
        """
        return self._get_reductions(product, settings.SHUUP_PACKAGES_DESTROYED_LOCATION_NAME)

    def get_quantity_lost_units_and_value(self, product):
        """
        (Quantity Lost / Theft) =
        (The retail value of eaches of a given product or SKU subject to criminal theft
        within a calendar month) + (Eaches of a given product or SKU that is lost
        within a calendar month)

        (Quantity Lost / Theft) =
        (The retail value of eaches of a given product or SKU subject to criminal theft
        within a calendar month) + (Eaches of a given product or SKU that is lost
        within a calendar month)
        """
        return self._get_reductions(product, settings.SHUUP_PACKAGES_LOST_LOCATION_NAME)

    def get_returns_to_government_units_and_value(self, product):
        """
        (Returns) =
        (Total number of eaches of a SKU returned to a cannabis retail establishment,
        with in a calendar month)
        *This calculation should take into account all returns which arrive at the
        store. In the event that a return is destroyed by the AGLC, it should still
        be accounted for in this calculation

        (Returns) =
        (Product eaches of a given product or SKU returned to a cannabis retail
        establishment)
        *This calculation should takshuupe into account all returns which arrive at the
        store. In the event that a return is destroyed by the AGLC, it should still
        be accounted for in this figure.
        """
        return self._get_reductions(product, settings.SHUUP_PACKAGES_RETURNED_TO_DISTRIBUTOR_LOCATION_NAME)

    def get_other_reductions_units_and_value(self, product):
        """
        (Other Reductions) =
        (All eaches of a given product which are unaccounted for at a retail
        establishment within a calendar month)

        (Other Reductions) =
        (The total retail value of all eaches of a given product which are unaccounted
        for at a retail establishment within a calendar month)
        """
        return self._get_reductions(product, settings.SHUUP_PACKAGES_OTHER_REDUCTION_LOCATION_NAME)

    def _get_reductions(self, product, location):
        results = (
            Package.objects.filter(
                product_id=product,
                supplier=self.supplier,
                location__name=location
            ).aggregate(
                total_units=Count("purchase_price_value"),
                total_value=Sum("purchase_price_value")
            )
        )
        return results["total_units"] or 0, results["total_value"] or 0

    def get_quantity_purchased_units_and_value(self, product, **kwargs):
        """
        (All purchased eaches of a given SKU within the reported calendar month)
        *Any returns/destructions/loss of a product should not be taken into account for this calculation.
        This includes any purchases from prior months.

        Quantity Purchased) =
        (The retail value of all purchased eaches of a given product or SKU within the
        reported calendar month)
        *Any returns/destructions/loss of a product should not be taken into account
        for this calculation. This includes any purchases from prior months.
        """
        purchases = Package.objects.filter(
            product_id=product,
            supplier=self.supplier,
            measurements__created_on__range=to_datetime_range(self.start_date, self.end_date)
        ).aggregate(
            total_units=Count("purchase_price_value"),
            total_value=Sum("purchase_price_value")
        )

        purchased_units = purchases["total_units"] or 0
        purchased_value = purchases["total_value"] or 0
        return (
            (
                purchased_units - kwargs["destroyed_units"] - kwargs["lost_units"] -
                kwargs["return_to_gov_units"] - kwargs["other_reductions_units"]
            ),
            (
                purchased_value - kwargs["destroyed_value"] - kwargs["lost_value"] -
                kwargs["return_to_gov_value"] - kwargs["other_reductions_value"]
            )
        )

    def get_data(self):
        data = []
        for product_id, sku, name in self.get_objects():
            opening_units, opening_value = self.get_opening_inventory_units_and_values(product_id)
            sold_units, sold_value = self.get_quantity_sold_units_and_values(product_id)

            destroyed_units, destroyed_value = self.get_quantity_destroyed_units_and_value(product_id)
            lost_units, lost_value = self.get_quantity_lost_units_and_value(product_id)
            return_to_gov_units, return_to_gov_value = self.get_returns_to_government_units_and_value(product_id)
            other_reductions_units, other_reductions_value = self.get_other_reductions_units_and_value(product_id)

            purchased_kwargs = {
                "destroyed_units": destroyed_units,
                "destroyed_value": destroyed_value,
                "lost_units": lost_units,
                "lost_value": lost_value,
                "return_to_gov_units": return_to_gov_units,
                "return_to_gov_value": return_to_gov_value,
                "other_reductions_units": other_reductions_units,
                "other_reductions_value": other_reductions_value
            }
            purchased_units, purchased_value = (
                self.get_quantity_purchased_units_and_value(product_id, **purchased_kwargs)
            )

            data.append({
                "name": name,
                "sku": sku,

                "opening_inventory_units": opening_units,
                "opening_inventory_values": opening_value,

                "returns_from_customers_units": self.get_returns_from_customers_units(product_id),  # Always zero
                "returns_from_customers_values": self.get_returns_from_customers_values(product_id),  # Always zero
                "other_additions_units": self.get_other_additions_units(product_id),  # Always zero
                "other_additions_values": self.get_other_additions_values(product_id),  # Always zero

                "quantity_sold_units": sold_units,
                "quantity_sold_values": sold_value,

                "quantity_destroyed_units": destroyed_units,
                "quantity_destroyed_values": destroyed_value,
                "quantity_lost_units": lost_units,
                "quantity_lost_values": lost_value,
                "returns_to_government_units": return_to_gov_units,
                "returns_to_government_values": return_to_gov_value,
                "other_reductions_units": other_reductions_units,
                "other_reductions_values": other_reductions_value,

                "quantity_purchased_units": purchased_units,
                "quantity_purchased_values": purchased_value,
            })

        return self.get_return_data(data, has_totals=False)
