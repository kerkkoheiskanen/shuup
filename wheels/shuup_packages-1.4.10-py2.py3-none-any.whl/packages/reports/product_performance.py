# -*- coding: utf-8 -*-
from django.db.models import DecimalField, F, Q, Sum
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import OrderLine, OrderStatusRole, Product, Shop
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import format_money, format_percent

from packages.models import PackageMeasurement
from packages.utils import get_supplier

from .forms import ProductPerfomanceForm


class ProductPerformanceReport(ShuupReportBase):
    identifier = "package-inventory-product-performance-report"
    title = _("Package Inventory - Product Performance")
    description = _(
        "This report shows the product performance for products stocked " +
        "with package inventory system. Use date range to filter sales. " +
        "Performance is count only for completed sales not by created packages."
    )
    filename_template = "product-performance-report-%(time)s"
    form_class = ProductPerfomanceForm

    schema = [
        {"key": "name", "title": _("Name")},
        {"key": "purchase_cost", "title": _("Purchase cost")},
        {"key": "avg_purchase_cost", "title": _("Average purchase cost per unit")},
        {"key": "qty_sold", "title": _("Quantity Sold")},
        {"key": "sales", "title": _("Total Sales")},
        {"key": "avg_sales", "title": _("Average sales price per unit")},
        {"key": "performance", "title": _("Performance")}
    ]

    def get_objects(self):
        self.shop = get_shop(self.request)
        combine_all_locations = self.options.get("combine_all_locations")
        shops = (
            Shop.objects.get_for_user(self.request.user) if combine_all_locations else [self.shop]
        )
        self.suppliers = []
        for shop in shops:
            supplier = get_supplier(shop, self.request.user)
            if supplier:
                self.suppliers.append(supplier)

        # Link this to packages supplier just in case supplier is
        # detached from product later.
        queryset = Product.objects.filter(packages__supplier__in=self.suppliers)
        if self.start_date:
            queryset = queryset.filter(order_lines__order__order_date__gte=self.start_date)

        if self.end_date:
            queryset = queryset.filter(order_lines__order__order_date__lte=self.end_date)

        product = self.options.get("product")
        if product:
            product_ids = Product.objects.filter(
                Q(id=product) | Q(variation_parent_id=product)).values_list("pk", flat=True)
            queryset = queryset.filter(id__in=product_ids)

        category = self.options["category"]
        if category:
            queryset = queryset.filter(
                Q(shop_products__categories=category) |
                Q(variation_parent__shop_products__categories=category)
            )

        purchase_order = self.options.get("purchase_order")
        if purchase_order:
            queryset = queryset.filter(
                packages__batch_transfer__batch__purchase_orders=purchase_order
            )
        return queryset.distinct()

    def get_data(self):
        data = []

        for product in self.get_objects():
            order_lines_queryset = OrderLine.objects.filter(
                product_id=product.id,
                supplier__in=self.suppliers,
                order__status__role=OrderStatusRole.COMPLETE
            )
            if self.start_date:
                order_lines_queryset = order_lines_queryset.filter(order__order_date__gte=self.start_date)

            if self.end_date:
                order_lines_queryset = order_lines_queryset.filter(order__order_date__lte=self.end_date)

            qty_sold = order_lines_queryset.aggregate(
                Sum("quantity")
            )["quantity__sum"] or 0

            sales = order_lines_queryset.aggregate(
                total=Sum(F("base_unit_price_value") * F("quantity"), output_field=DecimalField())
            )["total"] or 0
            avg_sales = (sales / qty_sold if qty_sold else 0)

            purchase_cost_qs = PackageMeasurement.objects.filter(
                package__supplier__in=self.suppliers,
                package__product_id=product.id,
                order_line__isnull=False,
                order__status__role=OrderStatusRole.COMPLETE
            )
            if self.start_date:
                purchase_cost_qs = purchase_cost_qs.filter(order__order_date__gte=self.start_date)

            if self.end_date:
                purchase_cost_qs = purchase_cost_qs.filter(order__order_date__lte=self.end_date)

            purchace_cost = purchase_cost_qs.aggregate(
                Sum("purchase_price_value")
            )["purchase_price_value__sum"] or 0
            avg_purchase_cost = (purchace_cost / qty_sold if qty_sold else 0)

            performance = None
            if purchace_cost:
                performance = (sales / purchace_cost)

            data.append({
                "name": product.safe_translation_getter("name"),
                "purchase_cost": format_money(self.shop.create_price(purchace_cost)),
                "avg_purchase_cost": format_money(self.shop.create_price(avg_purchase_cost)),
                "qty_sold": qty_sold,
                "sales": format_money(self.shop.create_price(sales)),
                "avg_sales": format_money(self.shop.create_price(avg_sales)),
                "performance": (format_percent(performance, 2) if performance else "-")
            })

        return self.get_return_data(data, has_totals=False)
