# -*- coding: utf-8 -*-
from django.db.models import Q, Sum
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import ShopProduct
from shuup.reports.report import ShuupReportBase

from packages.models import Package, PackageType
from packages.utils import get_supplier_from_request, is_bulk_enabled

from .forms import ProductReportForm


class PackageInventoryReport(ShuupReportBase):
    identifier = "package-inventory-packages-report"
    title = _("Package Inventory - Packages")
    description = _("This report shows total packages for all products.")
    filename_template = "package-inventory-report-%(time)s"
    form_class = ProductReportForm

    def __init__(self, **kwargs):
        super(PackageInventoryReport, self).__init__(**kwargs)
        shop = get_shop(self.request)
        self.schema = [
            {"key": "name", "title": _("Name")},
            {"key": "categories", "title": _("Categories")},
            {"key": "pre_packeds", "title": _("Pre packeds (qty)")}
        ]
        if shop and is_bulk_enabled(shop):
            self.schema.append({"key": "bulk_content", "title": _("Bulks weight (g)")})

    def get_objects(self):
        supplier = get_supplier_from_request(self.request)
        queryset = ShopProduct.objects.filter(suppliers=supplier)

        if self.options.get("product"):
            queryset = queryset.filter(product_id=self.options["product"])

        if self.options.get("category"):
            category = self.options["category"]
            queryset = queryset.filter(
                Q(categories=category) |
                Q(product__variation_parent__shop_products__categories=category)
            )

        return queryset.values_list(
            "id", "product_id", "product__translations__name",
            "product__variation_parent_id", "primary_category__translations__name"
        )

    def get_data(self):
        data = []

        shop = get_shop(self.request)
        supplier = get_supplier_from_request(self.request)
        base_package_query = Package.objects.filter(active=True, content_weight__gt=0, supplier=supplier)
        pre_packed_query = base_package_query.filter(type=PackageType.PRE_PACKED)
        bulk_package_query = base_package_query.filter(type=PackageType.BULK)

        for shop_product_id, product_id, product_name, parent_id, primary_category_name in self.get_objects():
            pre_packaged_count = pre_packed_query.filter(product_id=product_id).count()
            bulk_package_total_weight = 0
            if shop and is_bulk_enabled(shop):
                bulk_package_total_weight = bulk_package_query.filter(
                    product_id=product_id
                ).aggregate(
                    total_weight=Sum("content_weight")
                )["total_weight"] or 0

            data.append({
                "name": product_name,
                "categories": primary_category_name,
                "bulk_content": "%.3f" % (bulk_package_total_weight),
                "pre_packeds": pre_packaged_count,
                "parent_order": ("{}_child".format(parent_id) if parent_id else str(product_id))
            })

        data.sort(key=lambda x: (x["name"], x["parent_order"]))
        return self.get_return_data(data, has_totals=False)
