# -*- coding: utf-8 -*-
from babel.dates import format_datetime
from django.utils.translation import ugettext_lazy as _
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import format_number

from packages.models import PackageMeasurement
from packages.modules import PackageSupplierModule
from packages.utils import get_supplier_from_request

from .forms import PackageMeasurementsReportForm


class PackageMeasurementsReport(ShuupReportBase):
    identifier = "package-invenotry-measurement-report"
    title = _("Package Inventory - Packages Measurements")
    description = _("This report shows all the measurements for packages.")
    filename_template = "package-measurement-report-%(time)s"
    form_class = PackageMeasurementsReportForm

    schema = [
        {"key": "when", "title": _("When")},
        {"key": "order", "title": _("Order")},
        {"key": "batch", "title": _("Batch")},
        {"key": "package", "title": _("Package")},
        {"key": "previous_weight", "title": _("Previous Weight")},
        {"key": "new_weight", "title": _("New Weight")},
        {"key": "delta", "title": _("Delta")},
    ]

    def get_objects(self):
        self.supplier = get_supplier_from_request(self.request)
        measurements = PackageMeasurement.objects.filter(
            package__supplier=self.supplier,
            package__supplier__module_identifier=PackageSupplierModule.identifier
        )

        if self.options.get("batch"):
            measurements = measurements.filter(package__batch_transfer__batch=self.options["batch"])

        if self.options.get("purchase_order"):
            measurements = measurements.filter(
                package__batch_transfer__batch__purchase_orders=self.options["purchase_order"]
            )

        if self.options.get("sort_by") == "date":
            sort_by = ("created_on", "package__name")
        else:
            sort_by = ("package__name", "created_on")

        return measurements.order_by(*sort_by)

    def get_data(self):
        transfers = [
            {
                "when": format_datetime(transfer.created_on),
                "package": transfer.package.name,
                "order": transfer.order_id,
                "batch": transfer.package.batch_transfer.batch if hasattr(transfer.package, "batch_transfer") else None,
                "previous_weight": format_number(transfer.last_weight),
                "new_weight": format_number(transfer.total_weight),
                "delta": format_number(transfer.total_weight - transfer.last_weight),
            }
            for transfer in self.get_objects()
        ]
        return self.get_return_data(transfers, has_totals=False)
