# -*- coding: utf-8 -*-
from babel.dates import format_date
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import OrderLine, OrderStatusRole
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import get_current_babel_locale

from packages.models import Batch
from packages.utils import get_supplier_from_request

from .forms import BatchOrdersForm


class BatchOrdersReport(ShuupReportBase):
    identifier = "package-inventory-batch-orders-report"
    title = _("Package Inventory - Batch Orders")
    description = _("This report shows all completed orders for selected batch.")
    filename_template = "batch-orders-report-%(time)s"
    form_class = BatchOrdersForm

    schema = [
        {"key": "order_id", "title": _("Order id")},
        {"key": "order_date", "title": _("Order date")},
        {"key": "ordered_product", "title": _("Product name")},
        {"key": "ordered_qty", "title": _("Order quantity")},
        {"key": "customer_name", "title": _("Customer name")},
        {"key": "customer_phone", "title": _("Customer phone")},
        {"key": "customer_email", "title": _("Customer email")}
    ]

    def get_objects(self):
        supplier = get_supplier_from_request(self.request)
        return Batch.objects.filter(supplier=supplier, id=self.options["batch"])

    def get_data(self):
        data = []
        batches = self.get_objects()
        for batch in batches:
            # only use transfers that have order line attached
            transfers = batch.transfers.filter(
                package__measurements__order_line__isnull=False,
                package__measurements__order__status__role=OrderStatusRole.COMPLETE
            )

            batch_order_ids = list(
                set(list(transfers.values_list("package__measurements__order_id", flat=True)))
            )
            batch_order_lines = OrderLine.objects.filter(order_id__in=batch_order_ids, product__isnull=False)
            for order_line in batch_order_lines:
                order = order_line.order
                customer = order.customer
                name = (customer.name if customer else "-")
                phone = (customer.phone or "-" if customer else order.phone or "-")
                email = (customer.email or "-" if customer else order.email or "-")
                data.append({
                    "order_id": order.id,
                    "order_date": format_date(order.order_date, locale=get_current_babel_locale()),
                    "ordered_product": order_line.product.safe_translation_getter("name"),
                    "ordered_qty": order_line.quantity,
                    "customer_name": name,
                    "customer_phone": phone,
                    "customer_email": email
                })

        return self.get_return_data(data, has_totals=False)
