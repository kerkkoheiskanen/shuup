# -*- coding: utf-8 -*-
from .package import PackageSupplierModule

__all__ = ["PackageSupplierModule"]
