# -*- coding: utf-8 -*-
from django import forms
from django.conf import settings
from django.contrib import messages
from django.utils.translation import ugettext_lazy as _

from packages.models import Package, PackageLocation
from packages.utils import get_supplier_from_request


class QuickMovePackagesForm(forms.Form):

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        self.location = kwargs.pop("location")
        self.supplier = get_supplier_from_request(self.request)
        super(QuickMovePackagesForm, self).__init__(*args, **kwargs)

        self.fields["barcodes"] = forms.CharField(
            label=_("Barcodes"),
            required=True,
            widget=forms.Textarea()
        )

        help_text = _(
            "In case your packages shares barcodes the system needs to know where these packages is coming from."
        )
        self.fields["from_location"] = forms.ModelChoiceField(
            label=_("From location"),
            help_text=help_text,
            required=False,
            queryset=PackageLocation.objects.filter(supplier=self.supplier)
        )

    def clean_barcodes(self):
        barcodes = self.cleaned_data["barcodes"]
        barcodes_count = len(barcodes.splitlines())
        if barcodes_count > settings.SHUUP_PACKAGES_BARCODE_TRANSACTION_LIMIT:
            self.add_error(
                "barcodes",
                _("You can only set %(qty)s barcodes per transaction" % {
                    "qty": settings.SHUUP_PACKAGES_BARCODE_TRANSACTION_LIMIT
                })
            )

        return barcodes

    def save(self):
        data = self.cleaned_data
        form_location = data.get("from_location", None)
        unique_barcodes = [b.strip() for b in data["barcodes"].splitlines()]

        packages_moved_count = 0
        move_failed_count = 0
        failed_shared_barcodes = set()
        shared_barcodes_but_no_from_location = False
        for barcode in unique_barcodes:
            if not barcode:
                continue

            package = None
            packages = Package.objects.filter(supplier=self.supplier, barcode=barcode)
            multiple_packages = bool(packages.count() > 1)
            if multiple_packages and form_location:
                package = packages.filter(location=form_location).first()
                if not package:
                    failed_shared_barcodes.add(barcode)
            elif multiple_packages:
                shared_barcodes_but_no_from_location = True
                failed_shared_barcodes.add(barcode)
            else:
                package = packages.first()

            if package:
                package.location = self.location
                package.save()
                packages_moved_count += 1
            else:
                move_failed_count += 1

        message = _("Successfully moved %(count)s packages to this location." % {"count": packages_moved_count})
        messages.success(self.request, message)

        err_message = _("Could not move %(count)s packages to this location." % {"count": move_failed_count})
        messages.error(self.request, err_message)

        for failed_barcode in failed_shared_barcodes:
            err_message = _("Could not move %(barcode)s to location" % {"barcode": failed_barcode})
            messages.error(self.request, err_message)

        if shared_barcodes_but_no_from_location:
            err_message = _("Some of the barcodes was shared but no from location was defined.")
            messages.error(self.request, err_message)
