# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.admin.utils.picotable import Column, TextFilter
from shuup.admin.utils.views import PicotableListView
from shuup.utils.i18n import format_money, format_number

from packages.models import PurchaseOrder
from packages.utils import get_supplier_from_request


class PurchaseOrderListView(PicotableListView):
    model = PurchaseOrder
    default_columns = [
        Column(
            "number",
            _("Number"),
            sort_field="number",
            display="number",
            filter_config=TextFilter(
                filter_field="number",
                placeholder=_("Filter by number...")
            )
        ),
        Column(
            "provider",
            _("Distributor"),
            display="provider",
            filter_config=TextFilter(
                filter_field="provider__name",
                placeholder=_("Filter by distributor...")
            )),
        Column("purchase_total", _("Total purchase price"), display="get_purchase_total", sortable=False),
        Column("batches_count", _("Number of batches"), display="get_batches_count", sortable=False)
    ]

    def get_purchase_total(self, instance):
        shop = get_shop(self.request)
        if not shop:
            return "-"
        return format_money(shop.create_price(instance.purchased_total_value))

    def get_batches_count(self, instance):
        return format_number(instance.batches.count())

    def get_queryset(self):
        return PurchaseOrder.objects.filter(supplier=get_supplier_from_request(self.request))
