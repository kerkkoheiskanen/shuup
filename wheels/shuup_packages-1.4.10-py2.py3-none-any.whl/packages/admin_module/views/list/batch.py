# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from shuup.admin.toolbar import URLActionButton
from shuup.admin.utils.picotable import Column, TextFilter
from shuup.admin.utils.views import PicotableListView
from shuup.utils.i18n import format_number

from packages.models import Batch
from packages.utils import get_supplier_from_request


class BatchListView(PicotableListView):
    title = _("Inventory")
    model = Batch
    template_name = "packages/admin/inventory_list_picotable.jinja"
    default_columns = [
        Column(
            "name",
            _("Name"),
            filter_config=TextFilter(
                filter_field="name",
                placeholder=_("Filter by name...")
            )
        ),
        Column("quantity", _("Size"), sortable=False, display="format_quantity"),
        Column("available_quantity", _("Available for transfer"), sortable=False, display="available_for_sale"),
        Column(
            "purchase_order",
            _("Purchase order"),
            sortable=True,
            display="format_purchase_order",
            filter_config=TextFilter(
                placeholder=_("Filter by purchase order..."),
                filter_field="purchase_orders__number"
            )
        ),
        Column("created_on", _("Created on"), display="created_on"),
    ]

    def get_toolbar(self):
        toolbar = super().get_toolbar()
        toolbar.append(
            URLActionButton(
                url=reverse_lazy("shuup_admin:package_location.list"),
                text=_("Manage locations"),
                icon="fa fa-cube",
                extra_css_class="btn-default"
            )
        )
        return toolbar

    def format_purchase_order(self, instance, *args, **kwargs):
        return ", ".join(list(instance.purchase_orders.all().values_list("number", flat=True)))

    def format_quantity(self, instance, *args, **kwargs):
        sales_unit = (instance.sales_unit.symbol if instance.sales_unit else "")
        return "%(quantity)s %(sales_unit)s" % {
            "quantity": format_number(instance.quantity), "sales_unit": sales_unit
        }

    def available_for_sale(self, instance, *args, **kwargs):
        sales_unit = (instance.sales_unit.symbol if instance.sales_unit else "")
        return "%(quantity)s %(sales_unit)s" % {
            "quantity": format_number(instance.available_quantity), "sales_unit": sales_unit
        }

    def get_queryset(self):
        supplier = get_supplier_from_request(self.request)
        return Batch.objects.filter(supplier=supplier).order_by("-created_on")

    def get_context_data(self, **kwargs):
        context = super(BatchListView, self).get_context_data(**kwargs)
        context["title"] = self.title
        return context
