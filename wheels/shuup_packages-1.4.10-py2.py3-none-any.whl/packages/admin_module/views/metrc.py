# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import messages
from django.core.urlresolvers import reverse, reverse_lazy
from django.http.response import HttpResponseRedirect
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from django.views.generic import DetailView, TemplateView
from django.views.generic.edit import FormView
from shuup.admin.shop_provider import get_shop
from shuup.admin.toolbar import PostActionButton, Toolbar, URLActionButton
from shuup.admin.utils.picotable import Column, DateRangeFilter, TextFilter
from shuup.admin.utils.urls import get_model_url
from shuup.admin.utils.views import PicotableListView
from shuup.utils.analog import LogEntryKind

from packages.admin_module.forms import MetrcConfigForm
from packages.models import Batch, MetrcLog
from packages.utils import get_supplier_from_request


class MetrcSyncView(TemplateView):
    template_name = "packages/admin/metrc_sync.jinja"

    def post(self, request, **kwargs):
        from packages.metrc import Metrc, MetrcError
        metrc = Metrc(get_shop(request))
        errors = 0
        success = 0
        total = 0

        for order in metrc.get_not_sent_sales_receipt_orders():
            if metrc.should_send_sales_receipt(order):
                total += 1

                try:
                    if metrc.send_sales_receipt(order):
                        success += 1
                    else:
                        total -= 1
                except MetrcError:
                    errors += 1

        if total:
            msg = _("{} orders sent with success. {} were sent and returned errors.").format(success, errors)
            messages.success(request, msg)
        else:
            messages.success(request, _("No orders to send to Metrc"))

        return super().get(request)

    def get_context_data(self, **kwargs):
        context = super(MetrcSyncView, self).get_context_data(**kwargs)
        context["title"] = _("Metrc Synchronization")
        return context


class MetrcLogView(PicotableListView):
    model = MetrcLog
    default_columns = [
        Column(
            "created_on",
            _("Created on"),
            sort_field="created_on",
            filter_config=DateRangeFilter()
        ),
        Column("kind", _("Kind"), display=lambda instance: force_text(instance.kind).capitalize()),
        Column(
            "message",
            _("Message"),
            filter_config=TextFilter(
                filter_field="message",
                placeholder=_("Filter by message")
            )
        ),
        Column("user", _("User")),
        Column(
            "identifier",
            _("Identifier"),
            filter_config=TextFilter(
                filter_field="identifier",
                placeholder=_("Filter by identifier")
            )
        )
    ]

    def get_queryset(self):
        return super(MetrcLogView, self).get_queryset().filter(shop=get_shop(self.request))


class MetrcSettingsView(FormView):
    form_class = MetrcConfigForm
    template_name = "packages/admin/metrc_settings.jinja"
    success_url = reverse_lazy("shuup_admin:metrc.settings")

    def get_form_kwargs(self):
        kwargs = super(MetrcSettingsView, self).get_form_kwargs()
        kwargs["shop"] = get_shop(self.request)
        kwargs["request"] = self.request
        return kwargs

    def form_valid(self, form):
        form.save()
        messages.success(self.request, _("Metrc settings saved!"))
        return super(MetrcSettingsView, self).form_valid(form)

    def get_toolbar(self):
        toolbar = Toolbar()
        toolbar.extend([
            PostActionButton(
                icon="fa fa-save",
                form_id="metrc_settings",
                text=_("Save"),
                extra_css_class="btn-success"
            ),
            URLActionButton(
                url=reverse_lazy("shuup_admin:metrc.logs"),
                text=_("Log Events"),
                icon="fa fa-history",
                extra_css_class="btn-info"
            )
        ])
        return toolbar

    def get_context_data(self, **kwargs):
        context = super(MetrcSettingsView, self).get_context_data(**kwargs)
        context["title"] = _("Metrc Settings")
        context["toolbar"] = self.get_toolbar()
        return context


class BatchFinishMetrcPackageView(DetailView):
    model = Batch

    def get(self, request, *args, **kwargs):
        return HttpResponseRedirect(get_model_url(self.get_object()))

    def post(self, request, *args, **kwargs):
        batch = self.get_object()

        if batch.metrc_tag:
            from packages.models import MetrcLog
            from packages.metrc import Metrc, MetrcError
            shop = get_shop(request)
            metrc = Metrc(shop)

            if metrc.enabled:
                try:
                    metrc.finish_package(batch.metrc_tag)
                    MetrcLog.add_log_entry(
                        shop,
                        _("Metrc package {tag} finished.").format(tag=batch.metrc_tag),
                        kind=LogEntryKind.AUDIT,
                        user=request.user
                    )
                    messages.success(request, _("Package finished successfully!"))
                except MetrcError as exc:
                    messages.error(request, exc.message)
                    MetrcLog.add_log_entry(shop, exc.message, user=request.user, kind=LogEntryKind.ERROR)

        if request.GET.get("next"):
            return HttpResponseRedirect(request.GET["next"])
        return HttpResponseRedirect(reverse("shuup_admin:batch.edit", kwargs={"pk": batch.id}))

    def get_queryset(self):
        return Batch.objects.filter(supplier=get_supplier_from_request(self.request))
