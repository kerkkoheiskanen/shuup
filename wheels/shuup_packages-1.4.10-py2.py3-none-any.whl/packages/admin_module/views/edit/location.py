# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from shuup.admin.utils.views import CreateOrUpdateView

from packages.admin_module.forms import PackageLocationForm
from packages.models import PackageLocation
from packages.utils import get_supplier_from_request


class PackageLocationEditView(CreateOrUpdateView):
    model = PackageLocation
    form_class = PackageLocationForm
    template_name = "packages/admin/package_location_edit.jinja"
    context_object_name = "package_loc"

    def get_queryset(self):
        qs = PackageLocation.objects.filter(supplier=get_supplier_from_request(self.request))
        if not getattr(self.request.user, 'is_superuser', False):
            return qs.filter(staff_members=self.request.user)
        return qs

    def get_form_kwargs(self):
        kwargs = super(PackageLocationEditView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs
