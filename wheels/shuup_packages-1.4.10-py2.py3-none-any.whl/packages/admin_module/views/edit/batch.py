# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.conf import settings
from django.contrib import messages
from django.core.urlresolvers import reverse, reverse_lazy
from django.http.response import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic import DeleteView, DetailView, UpdateView
from shuup.admin.shop_provider import get_shop
from shuup.admin.toolbar import (
    JavaScriptActionButton, PostActionButton, Toolbar, URLActionButton
)
from shuup.admin.utils.urls import get_model_url
from shuup.admin.utils.views import CreateOrUpdateView

from packages.admin_module.create_packages_form import \
    CreatePackagesFromBarcodesForm
from packages.admin_module.forms import BatchForm, BatchProviderForm
from packages.models import Batch, BatchProvider, BatchState
from packages.utils import (
    allow_generating_labels, get_supplier_from_request, is_bulk_enabled
)


# Override base JavaScriptActionButton so we can remove btn-default from base css classes
class CustomJavaScriptActionButton(JavaScriptActionButton):
    base_css_classes = ("btn", "btn-primary")


class BatchEditView(CreateOrUpdateView):
    model = Batch
    form_class = BatchForm
    template_name = "packages/admin/batch_edit.jinja"
    context_object_name = "batch"

    def get_form_kwargs(self):
        kwargs = super(BatchEditView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs

    def get_queryset(self):
        return Batch.objects.filter(supplier=get_supplier_from_request(self.request))

    def get_toolbar(self):
        shop = get_shop(self.request)
        batch = self.get_object()
        toolbar = super().get_toolbar()

        if batch.transfers.exists():
            toolbar.append(
                URLActionButton(
                    url=reverse_lazy("shuup_admin:batch.packages", kwargs={"pk": batch.id}),
                    text=_("Edit packages"),
                    icon="fa fa-cube",
                    extra_css_class="btn-default"
                )
            )

        if batch.pk and batch.state == BatchState.Incoming:
            toolbar.append(
                PostActionButton(
                    post_url=reverse_lazy("shuup_admin:batch.delete", kwargs={"pk": batch.id}),
                    name="delete",
                    text=_("Delete"),
                    value=batch.id,
                    icon="fa fa-close",
                    confirm=_("Are you sure you wish to delete this batch?"),
                    extra_css_class="btn-danger"
                )
            )

        if batch.pk and batch.state == BatchState.Incoming:
            toolbar.append(
                PostActionButton(
                    post_url=reverse_lazy("shuup_admin:batch.received", kwargs={"pk": batch.id}),
                    name="received",
                    text=_("Mark as received"),
                    value=batch.id,
                    icon="fa fa-arrow-down",
                    confirm=_("Are you sure you wish to set this batch as received?"),
                    extra_css_class="btn-primary"
                )
            )

        if batch.state != BatchState.Incoming and allow_generating_labels(shop):
            toolbar.append(
                CustomJavaScriptActionButton(
                    onclick="window.createPackageTransfer()",
                    text=_("Create package transfer"),
                    icon="fa fa-exchange"
                )
            )

        if batch.state != BatchState.Incoming and not batch.is_in_grams() and batch.available_quantity:
            toolbar.append(
                URLActionButton(
                    url=reverse_lazy("shuup_admin:batch.create_packages_from_barcodes", kwargs={"pk": batch.id}),
                    text=_("Add pre-packed packages from barcodes"),
                    icon="fa fa-cube",
                    extra_css_class="btn-default",
                    required_permissions=("batch.create_packages_from_barcodes",)
                )
            )

        if batch.metrc_tag:
            from packages.metrc import Metrc, MetrcError
            try:
                package_info = Metrc(get_shop(self.request)).get_package(batch.metrc_tag)
                if not package_info.get("FinishedDate") and not package_info.get("ArchivedDate"):
                    toolbar.append(
                        PostActionButton(
                            post_url=reverse_lazy("shuup_admin:batch.finish_metrc_package", kwargs={"pk": batch.id}),
                            name="finish_package",
                            text=_("Finish Metrc Package"),
                            icon="fa fa-check",
                            confirm=_("Are you sure you wish to finish the Metrc package?"),
                            extra_css_class="btn-primary"
                        )
                    )
            except MetrcError:
                pass

        return toolbar

    def get_context_data(self, **kwargs):
        context = super(BatchEditView, self).get_context_data(**kwargs)
        batch = self.get_object()
        context["title"] = (batch.name if batch.pk else _("New Batch"))
        context["bulk_enabled"] = is_bulk_enabled(get_shop(self.request))

        if batch.metrc_tag:
            context["metrc_package"] = batch.metrc_tag

        return context


class BatchReceivedView(DetailView):
    model = Batch

    def get(self, request, *args, **kwargs):
        return HttpResponseRedirect(get_model_url(self.get_object()))

    def post(self, request, *args, **kwargs):
        batch = self.get_object()
        batch.set_received()
        messages.success(request, _("%s set as received.") % batch)
        if request.GET.get("next"):
            return HttpResponseRedirect(request.GET["next"])
        return HttpResponseRedirect(reverse("shuup_admin:batch.edit", kwargs={"pk": batch.id}))

    def get_queryset(self):
        return Batch.objects.filter(supplier=get_supplier_from_request(self.request))


class BatchProviderEditView(CreateOrUpdateView):
    model = BatchProvider
    form_class = BatchProviderForm
    template_name = "packages/admin/batch_provider_edit.jinja"
    context_object_name = "batch_provider"

    def get_form_kwargs(self):
        kwargs = super(BatchProviderEditView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs

    def get_queryset(self):
        return BatchProvider.objects.filter(supplier=get_supplier_from_request(self.request))


class BatchDeleteView(DeleteView):
    model = Batch
    success_url = reverse_lazy("shuup_admin:batch.list")

    def get_queryset(self):
        return Batch.objects.filter(supplier=get_supplier_from_request(self.request), transfers__isnull=True)

    def delete(self, request, *args, **kwargs):
        response = super().delete(request, *args, **kwargs)
        messages.success(self.request, _("Batch deleted."))
        if request.GET.get("next"):
            return HttpResponseRedirect(request.GET["next"])
        return response


class BatchCreatePackagesFromBarcodesView(UpdateView):
    model = Batch
    context_object_name = "batch"
    form_class = CreatePackagesFromBarcodesForm
    template_name = "packages/admin/add_pre_packed_packages_from_barcodes.jinja"
    add_form_errors_as_messages = True

    def get_queryset(self):
        return Batch.objects.filter(supplier=get_supplier_from_request(self.request))

    def get_success_url(self):
        object = self.get_object()
        return reverse_lazy("shuup_admin:batch.edit", kwargs={"pk": object.pk})

    def get_form_kwargs(self):
        kwargs = super(BatchCreatePackagesFromBarcodesView, self).get_form_kwargs()
        kwargs.pop("instance")  # Always new batch
        kwargs["request"] = self.request
        kwargs["batch"] = self.get_object()
        return kwargs

    def get_context_data(self, **kwargs):
        context = super(BatchCreatePackagesFromBarcodesView, self).get_context_data(**kwargs)
        batch = self.get_object()
        context["title"] = _("Create packages from barcodes for batch %s" % batch.name)

        toolbar = Toolbar()
        save_button = PostActionButton(
            icon="fa fa-check-circle",
            form_id="batch_form",
            text=_("Save"),
            extra_css_class="btn-success btn-save",
            required_permissions=("batch.create_packages_from_barcodes",),
        )
        toolbar.append(save_button)
        context["toolbar"] = toolbar
        context["max_barcodes"] = settings.SHUUP_PACKAGES_BARCODE_TRANSACTION_LIMIT

        return context
