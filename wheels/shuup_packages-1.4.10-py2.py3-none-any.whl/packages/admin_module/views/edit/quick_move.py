# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.conf import settings
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from django.views.generic import UpdateView
from shuup.admin.toolbar import PostActionButton, Toolbar

from packages.admin_module.quick_move_packages_form import \
    QuickMovePackagesForm
from packages.models import PackageLocation
from packages.utils import get_supplier_from_request


class PackagesQuickMoveView(UpdateView):
    model = PackageLocation
    context_object_name = "location"
    form_class = QuickMovePackagesForm
    template_name = "packages/admin/quick_move_packages_to_location.jinja"

    def get_queryset(self):
        return PackageLocation.objects.filter(supplier=get_supplier_from_request(self.request))

    def get_success_url(self):
        object = self.get_object()
        return reverse_lazy("shuup_admin:package_location.detail", kwargs={"pk": object.pk})

    def get_form_kwargs(self):
        kwargs = super(PackagesQuickMoveView, self).get_form_kwargs()
        kwargs.pop("instance")  # Always new batch
        kwargs["request"] = self.request
        kwargs["location"] = self.get_object()
        return kwargs

    def get_context_data(self, **kwargs):
        context = super(PackagesQuickMoveView, self).get_context_data(**kwargs)
        location = self.get_object()
        context["title"] = _("Move packages to %s" % location.name)

        toolbar = Toolbar()
        save_button = PostActionButton(
            icon="fa fa-check-circle",
            form_id="location_form",
            text=_("Save"),
            extra_css_class="btn-success btn-save",
            required_permissions=("package_location.quick_move",),
        )
        toolbar.append(save_button)
        context["toolbar"] = toolbar
        context["max_barcodes"] = settings.SHUUP_PACKAGES_BARCODE_TRANSACTION_LIMIT

        return context
