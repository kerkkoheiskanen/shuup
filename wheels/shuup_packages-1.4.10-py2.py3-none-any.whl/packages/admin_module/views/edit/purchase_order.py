# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import messages
from django.core.urlresolvers import reverse, reverse_lazy
from django.template.loader import render_to_string
from django.utils.translation import ugettext_lazy as _
from django.views.generic import DeleteView, DetailView, UpdateView
from shuup.admin.toolbar import (
    JavaScriptActionButton, PostActionButton, Toolbar
)
from shuup.admin.utils.views import CreateOrUpdateView
from shuup.utils.pdf import _fetch_static_resource_str, wrap_pdf_in_response

from packages.admin_module.forms import BatchForm, PurchaseOrderForm
from packages.models import PurchaseOrder
from packages.utils import get_supplier_from_request

try:
    import weasyprint
except ImportError:
    weasyprint = None


class PurchaseOrderEditView(CreateOrUpdateView):
    model = PurchaseOrder
    form_class = PurchaseOrderForm
    template_name = "packages/admin/purchase_order_edit.jinja"
    context_object_name = "purchase_order"

    def get_success_url(self):  # noqa (C901)
        purchase_order_id = self.object.pk
        if not self.object.batches.exists() and purchase_order_id:
            return reverse_lazy("shuup_admin:purchase_order.create_batch", kwargs={"pk": purchase_order_id})
        return reverse_lazy("shuup_admin:purchase_order.edit", kwargs={"pk": purchase_order_id})

    def get_queryset(self):
        return PurchaseOrder.objects.filter(supplier=get_supplier_from_request(self.request))

    def get_form_kwargs(self):
        kwargs = super(PurchaseOrderEditView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs

    def get_toolbar(self):
        toolbar = super().get_toolbar()
        if self.object.pk and self.object.batches.exists():
            url = reverse("shuup_admin:purchase_order.print", kwargs={"pk": self.object.id})
            toolbar.append(
                JavaScriptActionButton(
                    onclick="window.open('{}', '_blank');".format(url),
                    text=_("Print"),
                    icon="fa fa-print",
                    extra_css_class="btn-default"
                )
            )
        if self.object.pk:
            toolbar.append(
                PostActionButton(
                    post_url=reverse_lazy("shuup_admin:purchase_order.delete", kwargs={"pk": self.object.pk}),
                    name="delete",
                    text=_("Delete"),
                    value=self.object.pk,
                    icon="fa fa-close",
                    confirm=_("Are you sure you wish to delete this purchase order?"),
                    extra_css_class="btn-danger"
                )
            )
        return toolbar


class PurchaseOrderPrintView(DetailView):
    model = PurchaseOrder
    template_name = "packages/admin/purchase_order_print.jinja"
    context_object_name = "purchase_order"

    def get_queryset(self):
        return PurchaseOrder.objects.filter(supplier=get_supplier_from_request(self.request))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        supplier = get_supplier_from_request(self.request)
        context["shop"] = supplier.shops.first()
        # TODO: Re-enable supplier logo
        # purchase_order = self.get_object()
        # shop_logo = purchase_order.shop.logo
        #
        # if not shop_logo or not shop_logo.file:
        #    return context

        # TODO: Reactivate shop logo it seems that a little bit wrong logo and the print fail.
        # import base64
        # import mimetypes
        # shop_logo.file.seek(0)
        # encoded = base64.b64encode(shop_logo.file.read()).decode("utf-8")
        # content_type = mimetypes.guess_type(shop_logo.file.name)[0] or 'application/octet-stream'
        # shop_logo_b64 = "data:{};base64,{}".format(content_type, encoded)
        # context["shop_logo"] = shop_logo_b64

        return context

    def get(self, request, *args, **kwargs):
        self.object = self.get_object()
        stylesheets_paths = [
            "packages/purchase_order_print.css"
        ]
        stylesheets = [
            weasyprint.CSS(string=_fetch_static_resource_str(stylesheet))
            for stylesheet in stylesheets_paths
        ]
        context = self.get_context_data(object=self.object)
        weasyprint_html = weasyprint.HTML(string=render_to_string(self.template_name, context=context))

        pdf_data = weasyprint_html.write_pdf(stylesheets=stylesheets)
        response = wrap_pdf_in_response(pdf_data)
        response["Content-Disposition"] = "attachment; filename=purchase_order-{}".format(self.object.number)
        return response


class PurchaseOrderDeleteView(DeleteView):
    model = PurchaseOrder
    success_url = reverse_lazy("shuup_admin:purchase_order.list")

    def get_queryset(self):
        return PurchaseOrder.objects.filter(supplier=get_supplier_from_request(self.request))

    def delete(self, request, *args, **kwargs):
        response = super().delete(request, *args, **kwargs)
        messages.success(self.request, _("Purchase Order deleted."))
        return response


class PurchaseOrderCreateBatchView(UpdateView):
    model = PurchaseOrder
    context_object_name = "purchase_order"
    form_class = BatchForm
    template_name = "packages/admin/batch_edit.jinja"

    def get_queryset(self):
        return PurchaseOrder.objects.filter(supplier=get_supplier_from_request(self.request))

    def get_success_url(self):
        object = self.get_object()
        return reverse_lazy("shuup_admin:purchase_order.edit", kwargs={"pk": object.pk})

    def get_form_kwargs(self):
        kwargs = super(PurchaseOrderCreateBatchView, self).get_form_kwargs()
        kwargs.pop("instance")  # Always new batch
        kwargs["request"] = self.request
        kwargs["purchase_order"] = self.get_object()
        return kwargs

    def form_valid(self, form):
        batch = form.save()
        object = self.get_object()
        if not batch.provider:  # Fallback to purchase order provider
            batch.provider = object.provider
            batch.save()

        object.batches.add(batch)
        return super(PurchaseOrderCreateBatchView, self).form_valid(form)

    def get_context_data(self, **kwargs):
        context = super(PurchaseOrderCreateBatchView, self).get_context_data(**kwargs)
        purchase_order = self.get_object()
        context["title"] = _("Create batch of products for purchase order %s" % purchase_order.number)

        toolbar = Toolbar()
        save_button = PostActionButton(
            icon="fa fa-check-circle",
            form_id="batch_form",
            text=_("Save"),
            extra_css_class="btn-success btn-save",
            required_permissions=("batch.new",),
        )
        toolbar.append(save_button)
        context["toolbar"] = toolbar

        return context
