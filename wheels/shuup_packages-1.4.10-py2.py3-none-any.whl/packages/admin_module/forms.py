# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from decimal import Decimal

from django import forms
from django.core.urlresolvers import reverse_lazy
from django.db.transaction import atomic
from django.utils.translation import ugettext_lazy as _
from shuup.admin.forms.widgets import (
    QuickAddRelatedObjectMultiSelect, QuickAddRelatedObjectSelect
)
from shuup.admin.shop_provider import get_shop
from shuup.core.models import SalesUnit
from shuup.utils.analog import LogEntryKind
from shuup.utils.numbers import bankers_round

from packages.metrc import is_metrc_enabled, Metrc, MetrcError
from packages.models import (
    Batch, BatchProvider, BatchState, MetrcLog, PackageLocation, PurchaseOrder
)
from packages.utils import (
    get_sales_unit_for_grams, get_sales_unit_for_pieces,
    get_supplier_from_request, get_users_for_supplier, is_bulk_enabled
)


class QuickAddBatchProviderSelect(QuickAddRelatedObjectSelect):
    url = reverse_lazy("shuup_admin:batch_provider.new")


class QuickAddBatchSelect(QuickAddRelatedObjectMultiSelect):
    url = reverse_lazy("shuup_admin:batch.new")


class QuickAddLocationSelect(QuickAddRelatedObjectSelect):
    url = reverse_lazy("shuup_admin:package_location.new")


class PackageLocationForm(forms.ModelForm):
    class Meta:
        model = PackageLocation
        exclude = ["supplier"]

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        self.supplier = get_supplier_from_request(self.request)
        self.shop = get_shop(self.request)
        super(PackageLocationForm, self).__init__(*args, **kwargs)
        self.fields["staff_members"].queryset = get_users_for_supplier(self.supplier)

    def save(self, commit=True):
        self.instance.supplier = self.supplier
        instance = super(PackageLocationForm, self).save(commit)
        instance.staff_members.add(self.request.user)  # Ensure the one editing in list
        return instance


class BatchForm(forms.ModelForm):
    class Meta:
        model = Batch
        fields = [
            "name", "identifier", "metrc_tag", "notes", "provider", "quantity",
            "sales_unit", "purchase_price_value"
        ]
        widgets = {
            "provider": QuickAddBatchProviderSelect()
        }
        labels = {
            "name": _("Batch name"),
            "purchase_price_value": _("Batch purchase price value for entire batch")
        }
        help_texts = {
            "name": _("Human readable name for batch. For example product name."),
            "quantity": _("Quantity in selected sales unit."),
            "identifier": _("Unique identifier for this batch."),
            "purchase_price_value": _("Enter number value for batch purchase price in shop currency."),
            "provider": _("By default purchase order distributor is used."),
            "metrc_tag": _("Enter the unique 24 digit ID number.")
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        purchase_order = kwargs.pop("purchase_order", None)
        self.shop = get_shop(self.request)  # TODO: remove once the save is solved
        self.supplier = get_supplier_from_request(self.request)
        super(BatchForm, self).__init__(*args, **kwargs)
        self.fields["provider"].queryset = BatchProvider.objects.filter(supplier=self.supplier)
        if purchase_order:  # Creating batch for purchase order so no need for provider
            self.fields["provider"].widget = forms.HiddenInput()

        self.fields["notes"].widget.attrs["rows"] = 3

        pieces_sales_unit = get_sales_unit_for_pieces()
        if is_bulk_enabled(self.shop):
            sales_unit_ids = [pieces_sales_unit.id, get_sales_unit_for_grams().id]
            sales_unit_help_text = _(
                "Select a sales unit for batch. Unit used for batch transfers. " +
                "Selecting grams allows to create bulk-transfers to products with weight."
            )
        else:
            sales_unit_ids = [pieces_sales_unit.id]
            sales_unit_help_text = _(
                "Select a sales unit for batch. Unit used for batch transfers."
            )

        self.fields["sales_unit"].queryset = SalesUnit.objects.filter(id__in=sales_unit_ids)
        self.fields["sales_unit"].help_text = sales_unit_help_text
        self.fields["sales_unit"].required = True
        self.fields["sales_unit"].initial = pieces_sales_unit.id

        if self.instance and self.instance.pk and self.instance.state != BatchState.Incoming:
            del self.fields["provider"]
            del self.fields["sales_unit"]
            del self.fields["quantity"]
            del self.fields["purchase_price_value"]

        if is_metrc_enabled(self.shop):
            self.fields["identifier"].widget = forms.HiddenInput()
        else:
            del self.fields["metrc_tag"]

    def save(self, commit=True):
        with atomic():
            if not self.instance.pk:
                self.instance.created_by = self.request.user
                self.instance.supplier = self.supplier

            return super(BatchForm, self).save(commit)

    def _validate_metrc(self, data):    # noqa (C901)
        metrc_tag = data.get("metrc_tag")
        quantity = data.get("quantity") or self.instance.quantity
        sales_unit = data.get("sales_unit") or self.instance.sales_unit.pk

        metrc = Metrc(self.shop)
        if metrc_tag and metrc.enabled and (not self.instance.pk or self.instance.metrc_tag != metrc_tag):
            try:
                package_info = metrc.get_package(metrc_tag)
                if package_info.get("FinishedDate"):
                    self.add_error("metrc_tag", _("This package is already finished on Metrc."))

                metrc_quantity = Decimal(package_info.get("Quantity"))
                if bankers_round(metrc_quantity, 3) != bankers_round(quantity, 3):
                    msg = _("This package quantity doesn't match with Metrc package ({:.3f}).").format(metrc_quantity)
                    if "quantity" in self.fields:
                        self.add_error("quantity", msg)
                    else:
                        self.add_error("metrc_tag", msg)

                units_of_measure = metrc.get_units_of_measure()
                unit_of_measure = units_of_measure.get(package_info["UnitOfMeasureName"])

                if unit_of_measure:
                    unit_type = unit_of_measure["QuantityType"]

                    if unit_type == "VolumeBased":
                        msg = _("Volume-based packages are not supported.")
                        if "sales_unit" in self.fields:
                            self.add_error("sales_unit", msg)
                        else:
                            self.add_error("metrc_tag", msg)

                    elif unit_type == "CountBased" and sales_unit != get_sales_unit_for_pieces():
                        msg = _("Sales unit doesn't match. Metrc package is pieces based.")
                        if "sales_unit" in self.fields:
                            self.add_error("sales_unit", msg)
                        else:
                            self.add_error("metrc_tag", msg)

                    elif unit_type == "WeightBased" and sales_unit != get_sales_unit_for_grams():
                        msg = _("Sales unit doesn't match. Metrc package is weight based.")
                        if "sales_unit" in self.fields:
                            self.add_error("sales_unit", msg)
                        else:
                            self.add_error("metrc_tag", msg)

            except MetrcError as error:
                self.add_error("metrc_tag", error.message)

    def clean(self):
        cleaned_data = super(BatchForm, self).clean()
        self._validate_metrc(cleaned_data)
        if is_metrc_enabled(self.shop):
            # Since identifier field is hidden when METRC is enabled
            cleaned_data["identifier"] = cleaned_data["metrc_tag"]

        return cleaned_data


class BatchProviderForm(forms.ModelForm):
    class Meta:
        model = BatchProvider
        exclude = ["supplier"]

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        self.supplier = get_supplier_from_request(self.request)
        super(BatchProviderForm, self).__init__(*args, **kwargs)

    def save(self, commit=True):
        self.instance.supplier = self.supplier
        return super().save(commit)


class PurchaseOrderForm(forms.ModelForm):
    class Meta:
        model = PurchaseOrder
        fields = ["number", "date", "provider"]
        widgets = {
            "provider": QuickAddBatchProviderSelect(),
            "batches": QuickAddBatchSelect()
        }
        labels = {
            "number": "Order Number"
        }
        help_texts = {
            "number": "Enter unique purchase order number."
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        self.supplier = get_supplier_from_request(self.request)
        super().__init__(*args, **kwargs)

        self.fields["provider"].queryset = BatchProvider.objects.filter(supplier=self.supplier)

    def clean(self):
        data = super(PurchaseOrderForm, self).clean()
        number = data.get("number")
        if number:
            unique_check_qs = PurchaseOrder.objects.filter(number=number, supplier=self.supplier)
            if self.instance and self.instance.pk:
                unique_check_qs = unique_check_qs.exclude(pk=self.instance.pk)
            if unique_check_qs.exists():
                self.add_error("number", _("Order number already exists"))
        return data

    def save(self, commit=True):
        self.instance.supplier = self.supplier
        return super().save(commit)


class MetrcConfigForm(forms.Form):
    user_api_key = forms.CharField(label=_("Metrc User API Key"))
    facility_number = forms.CharField(label=_("Facility Number"))
    enabled = forms.BooleanField(required=False)

    def __init__(self, **kwargs):
        self.request = kwargs.pop("request")
        self.shop = kwargs.pop("shop")
        user_api_key, facility_number, enabled = Metrc(self.shop).get_config()
        super(MetrcConfigForm, self).__init__(**kwargs)
        self.fields["user_api_key"].initial = user_api_key
        self.fields["facility_number"].initial = facility_number
        self.fields["enabled"].initial = enabled

    def save(self):
        data = self.cleaned_data
        Metrc(self.shop).set_config(data["user_api_key"], data["facility_number"], data["enabled"])
        MetrcLog.add_log_entry(
            self.shop,
            _("Metrc configuration changed"),
            user=self.request.user,
            kind=LogEntryKind.EDIT
        )
