# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import PRODUCTS_MENU_CATEGORY
from shuup.admin.utils.urls import admin_url, derive_model_url

from packages.models import Package


class ShuupPackageModule(AdminModule):
    name = _("Packages")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:package.list")

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=_("Packages"),
                icon="fa fa-cube",
                url="shuup_admin:package.list",
                category=PRODUCTS_MENU_CATEGORY,
                ordering=5
            )
        ]

    def get_urls(self):
        return [
            admin_url(
                "package/packages/(?P<pk>\d+)/$$",
                "packages.admin_module.views.edit.package.PackageEditView",
                name="package.edit",
            ),
            admin_url(
                "package/packages/$",
                "packages.admin_module.views.PackageListView",
                name="package.list",
            ),
            admin_url(
                "package/packageslist-settings/",
                "shuup.admin.modules.settings.views.ListSettingsView",
                name="package.list_settings"
            )
        ]

    def get_model_url(self, object, kind, shop=None):
        return derive_model_url(Package, "shuup_admin:package", object, kind)
