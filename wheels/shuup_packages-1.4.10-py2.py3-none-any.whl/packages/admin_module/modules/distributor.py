# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule
from shuup.admin.utils.urls import admin_url, derive_model_url

from packages.models import BatchProvider


class ShuupBatchProviderModule(AdminModule):
    name = _("Batch Distributor")

    def get_urls(self):
        return [
            admin_url(
                "package/batch_provider/new/$",
                "packages.admin_module.views.BatchProviderEditView",
                name="batch_provider.new",
            ),
            admin_url(
                r"package/batch_provider/(?P<pk>\d+)/$",
                "packages.admin_module.views.BatchProviderEditView",
                name="batch_provider.edit",
            )
        ]

    def get_model_url(self, object, kind, shop=None):
        return derive_model_url(BatchProvider, "shuup_admin:batch_provider", object, kind)
