# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import PRODUCTS_MENU_CATEGORY
from shuup.admin.utils.urls import (
    admin_url, derive_model_url, get_edit_and_list_urls
)

from packages.models import PurchaseOrder


class ShuupPurchaseOrderModule(AdminModule):
    name = _("Purchase Order")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:purchase_order.list")

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=_("Purchase Orders"),
                icon="fa fa-cube",
                url="shuup_admin:purchase_order.list",
                category=PRODUCTS_MENU_CATEGORY,
                ordering=6
            )
        ]

    def get_urls(self):
        return get_edit_and_list_urls(
            url_prefix="^package/purchase_order",
            view_template="packages.admin_module.views.PurchaseOrder%sView",
            name_template="purchase_order.%s",
        ) + [
            admin_url(
                r"package/purchase_order/(?P<pk>\d+)/delete/$",
                "packages.admin_module.views.PurchaseOrderDeleteView",
                name="purchase_order.delete",
            ),
            admin_url(
                r"package/purchase_order/(?P<pk>\d+)/print/$",
                "packages.admin_module.views.PurchaseOrderPrintView",
                name="purchase_order.print",
            ),
            admin_url(
                r"package/purchase_order/(?P<pk>\d+)/create_batch/$",
                "packages.admin_module.views.PurchaseOrderCreateBatchView",
                name="purchase_order.create_batch",
            )
        ]

    def get_model_url(self, object, kind, shop=None):
        return derive_model_url(PurchaseOrder, "shuup_admin:purchase_order", object, kind)
