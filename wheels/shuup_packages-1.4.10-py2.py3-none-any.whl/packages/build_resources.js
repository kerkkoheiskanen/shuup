const { getParcelBuildCommand, runBuildCommands } = require("shuup-static-build-tools");

runBuildCommands([
    getParcelBuildCommand({
        cacheDir: "shuup-packages",
        outputDir: "static/packages",
        outputFileName: "shuup_packages",
        entryFile: "static_src/js/index.js"
    }),
    getParcelBuildCommand({
        cacheDir: "shuup-pos",
        outputDir: "static/packages",
        outputFileName: "shuup_packages",
        entryFile: "static_src/styles.less"
    }),
    getParcelBuildCommand({
        cacheDir: "shuup-pos",
        outputDir: "static/packages",
        outputFileName: "purchase_order_print",
        entryFile: "static_src/purchase_order_print.less"
    })
]);
