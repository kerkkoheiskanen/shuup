# -*- coding: utf-8 -*-
from time import time

from django.utils.translation import ugettext_lazy as _
from shuup.core import cache
from shuup.notify.base import Event, Variable
from shuup.notify.typology import Boolean, Model


class PackageAlertLimitReached(Event):
    cache_key_fmt = "package_stock_alert_%s_%s"

    identifier = "package_alert_limit_reached"
    name = _("Package Alert Limit Reached")

    supplier = Variable(_("Supplier"), type=Model("shuup.Supplier"))
    product = Variable(_("Product"), type=Model("shuup.Product"))
    dispatched_last_24hs = Variable(
        _("Fired in the last 24 hours?"),
        type=Boolean,
        help_text=_(
            "This will be True if this event was already dispatched "
            "in the last 24 hours for the same product and supplier. "
            "This is useful to prevent sending identical notifications in a short "
            "period of time."
        )
    )

    def __init__(self, **variable_values):
        cache_key = self.cache_key_fmt % (variable_values["supplier"].pk, variable_values["product"].pk)
        last_dispatch_time = cache.get(cache_key)

        if last_dispatch_time:
            last_dispatch = int((time() - last_dispatch_time) / 60 / 60)
            variable_values["dispatched_last_24hs"] = (last_dispatch < 24)
        else:
            variable_values["dispatched_last_24hs"] = False

        super(PackageAlertLimitReached, self).__init__(**variable_values)

    def run(self, shop):
        cache_key = self.cache_key_fmt % (self.variable_values["supplier"].pk, self.variable_values["product"].pk)
        cache.set(cache_key, time(), timeout=(60 * 60 * 24))
        super(PackageAlertLimitReached, self).run(shop=shop)
