export const PackageType = {
    Bulk: 0,
    PrePacked: 1
};

export const PackageTypeLabel = {
    [PackageType.Bulk]: gettext("Bulk"),
    [PackageType.PrePacked]: gettext("Pre packed")
};
