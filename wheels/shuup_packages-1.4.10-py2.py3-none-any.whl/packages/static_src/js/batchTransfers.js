import m from "mithril";
import prop from "mithril/stream";
import moment from "moment";
import { groupBy } from "lodash";


const BatchTransferGroupRow = {
    view(vnode) {
        const { batch, transfer, collapsable } = vnode.attrs;
        return (
            m(`tr.${collapsable ? "group" : ""}`,
                m("td.text-center", transfer.barcode),
                m("td.text-center", transfer.origin_package ? transfer.origin_package.name : gettext("Batch")),
                m("td.text-center", moment(transfer.created_on).format("L LTS")),
                m("td.text-center", transfer.product ? transfer.product.name : ""),
                m("td.text-center", `${parseFloat(transfer.transferred)} ${batch.sales_unit_symbol}`),
                m("td.text-center", ((transfer.has_orders && transfer.content_weight <= 0) ? gettext("Yes") : gettext("No"))),
                m("td.text-center", transfer.location ? transfer.location.name : "")
            )
        );
    }
};

const BatchTransferGroup = {
    oninit(vnode) {
        vnode.state.collapsed = prop(true);
    },
    view(vnode) {
        const { batch, transfers, group } = vnode.attrs;
        if (!transfers.length) return null;
        const title = transfers[0];
        return [
            m("tr.active", { key: `title-${group}` },
                m("td.text-center",
                    m("a.link.p2", {
                        onclick() {
                            vnode.state.collapsed(!vnode.state.collapsed());
                        }
                    }, vnode.state.collapsed() ? m("i.fa.fa-plus") : m("i.fa.fa-minus"))
                ),
                m("td.text-center", title.origin_package ? title.origin_package.name : gettext("Batch")),
                m("td.text-center", moment(title.created_on).format("L LTS")),
                m("td.text-center", title.product.name),
                m("td.text-center", interpolate(gettext("%s packages"), [transfers.length])),
                m("td.text-center"),
                m("td.text-center")
            ),
            vnode.state.collapsed() ? null : (
                transfers.map(transfer => (
                    m(BatchTransferGroupRow, {
                        collapsable: true,
                        transfer,
                        batch
                    })
                ))
            )
        ];
    }
};

const BatchTransfers = {
    view(vnode) {
        const transfers = vnode.attrs.transfers;
        const batch = vnode.attrs.batch;
        const transferGroups = groupBy(transfers, "transfer_group");
        const sortedTransfers = [];

        Object.keys(transferGroups).forEach((key) => {
            if (key === "null" || transferGroups[key].length === 1) {
                sortedTransfers.push(...transferGroups[key]);
            } else if (transferGroups[key].length) {
                sortedTransfers.push({
                    group: key,
                    transfers: transferGroups[key],
                    created_on: transferGroups[key][0].created_on
                });
            }
        });
        sortedTransfers.sort((a, b) => (moment(a.created_on) - moment(b.created_on)));

        return m(".batch-no-product-packages",
            m("h2.text-center", gettext("Transferred to")),
            m("table.table.table-hover.table-bordered",
                m("thead",
                    m("tr",
                        m("th.text-center", gettext("Barcode")),
                        m("th.text-center", gettext("Origin")),
                        m("th.text-center", gettext("When")),
                        m("th.text-center", gettext("Product")),
                        m("th.text-center", gettext("Quantity transferred")),
                        m("th.text-center", gettext("Is Sold")),
                        m("th.text-center", gettext("Location"))
                    )
                ),
                m("tbody",
                    sortedTransfers.map(transfer => (
                        transfer.group ? (
                            m(BatchTransferGroup, {
                                key: transfer.group,
                                batch,
                                group: transfer.group,
                                transfers: transfer.transfers
                            })
                        ) : m(BatchTransferGroupRow, {
                            key: transfer.id,
                            collapsable: false,
                            transfer,
                            batch
                        })
                    ))
                )
            )
        );
    }
};

export default BatchTransfers;
