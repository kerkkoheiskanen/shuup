import m from "mithril";
import prop from "mithril/stream";

import BatchInfo from "./batchInfo";
import BatchSummary from "./batchSummary";
import BatchTransfers from "./batchTransfers";
import BatchCreateTransferForm from "./batchCreateTransferForm";
import { getErrorListFromResponse, xhrConfig } from "./utils";


const BatchView = {
    oninit(vnode) {
        const batchId = vnode.attrs.batch;

        vnode.state.createTransferMode = prop(false);
        vnode.state.loading = prop(true);
        vnode.state.productSummary = prop([]);
        vnode.state.transfers = prop([]);
        vnode.state.batch = prop();

        vnode.state.refreshBatch = () => {
            m.request({
                url: `/api/packages/batch/${batchId}/`,
                config: xhrConfig
            }).then((data) => {
                vnode.state.batch(data);
            }, (response) => {
                const error = getErrorListFromResponse(response).shift();
                if (error) {
                    window.alertify.error(error);
                }
            });
        };

        vnode.state.refreshSummary = () => {
            vnode.state.loading(true);

            // fetch product summary
            m.request({
                url: `/api/packages/batch/${batchId}/product_summary/`,
                config: xhrConfig
            }).then((data) => {
                vnode.state.productSummary(data);
                vnode.state.loading(false);
            }, (response) => {
                const error = getErrorListFromResponse(response).shift();
                if (error) {
                    window.alertify.error(error);
                }
                vnode.state.loading(false);
            });

            m.request({
                url: `/api/packages/batch/${batchId}/transfers/`,
                config: xhrConfig
            }).then((data) => {
                vnode.state.transfers(data);
            });
        };

        window.createPackageTransfer = () => {
            vnode.state.createTransferMode(true);
            m.redraw();
        };

        vnode.state.refreshBatch();
        vnode.state.refreshSummary();
    },
    view(vnode) {
        const batch = vnode.state.batch();
        return m(".batch-summary",
            batch && (
                m(".row", m(".col-md-6.col-md-offset-3.col-sm-8.col-sm-offset-2", m(BatchInfo, { batch })))
            ),
            (vnode.state.createTransferMode() ? [
                m("hr"),
                m(BatchCreateTransferForm, {
                    batch,
                    onCancelPress() {
                        vnode.state.createTransferMode(false);
                    },
                    onCreateTransfer() {
                        // force reload the page to update the jinja template only
                        // when we have no summary yet
                        if (vnode.state.productSummary().length) {
                            vnode.state.createTransferMode(false);
                            vnode.state.refreshBatch();
                            vnode.state.refreshSummary();
                        } else {
                            window.location.reload(true);
                        }
                    }
                })
            ] : null),
            vnode.state.loading() ? (
                m(".text-center",
                    m("i.fa.fa-spin.fa-spinner.fa-2x")
                )
            ) : null,
            (batch && batch.state !== "incoming" && vnode.state.transfers().length) ? [
                m("hr"),
                vnode.state.productSummary().length ? (
                    m(BatchSummary, {
                        key: "summary",
                        salesUnit: vnode.state.batch().sales_unit_symbol,
                        products: vnode.state.productSummary()
                    })
                ) : null,
                (vnode.state.transfers().length) ? (
                    m(BatchTransfers, {
                        key: "transfers",
                        transfers: vnode.state.transfers(),
                        batch: vnode.state.batch()
                    })
                ) : null
            ] : null
        );
    }
};

export default BatchView;
