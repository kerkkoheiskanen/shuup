import m from "mithril";

const InputField = {
    view(vnode) {
        const {
            id, errors, helpText, type, value, labelText, placeholder, oninput, onchange, required, extraFieldAttrs
        } = vnode.attrs;
        return m(`.form-group.form-content.${errors ? "has-error" : ""}.${required ? "required-field" : ""}`,
            labelText && m("label.control-label", { for: id }, labelText),
            m(".form-input-group",
                m("input.form-control", {
                    id,
                    type: type || "text",
                    value,
                    placeholder,
                    oninput,
                    onchange,
                    ...extraFieldAttrs
                })
            ),
            errors && m(".help-block.error-block", errors),
            helpText && m(".", m("small.text-muted", helpText))
        );
    }
};

export default InputField;
