import m from "mithril";
import prop from "mithril/stream";

import { xhrConfig } from "./utils";
import SelectField from "./selectField";


const SetLocationMassAction = {
    oninit(vnode) {
        vnode.state.location = prop();
        vnode.state.locationOptions = prop([]);
        vnode.state.moving = prop(false);
        vnode.state.unmount = () => {
            m.mount(document.getElementById("location-set-overlay"), null);
        };
        // load locations
        m.request({
            url: "/api/packages/package_supplier/locations/",
            config: xhrConfig
        }).then((locations) => {
            vnode.state.locationOptions(locations.sort((a, b) => {
                if (a.name > b.name) return 1;
                if (a.name < b.name) return -1;
                return 0;
            }));
            if (vnode.state.locationOptions().length) {
                vnode.state.location(vnode.state.locationOptions()[0].id);
            }
        });
    },
    view(vnode) {
        return m(".location-mass-action-overlay", {
            onclick(e) {
                if (e.target === vnode.dom) {
                    vnode.state.unmount();
                }
            }
        },
            m(".location-mass-action",
                m("h3", gettext("Move package to new location")),
                m(".search-box-close", m("a.link", {
                    onclick() {
                        vnode.state.unmount();
                    }
                }, m("i.fa.fa-close"))),
                m("p.text-info",
                    interpolate(gettext("You selected %s packages."), [
                        (vnode.attrs.packages === "all") ? gettext("all") : vnode.attrs.packages.length
                    ])
                ),
                m(SelectField, {
                    id: "id_location",
                    labelText: gettext("The new location"),
                    value: vnode.state.location,
                    onchange: m.withAttr("value", vnode.state.location),
                    required: true,
                    options: vnode.state.locationOptions(),
                    helpText: gettext("All selected packages will be moved to this new location.")
                }),
                m("button.btn.btn-block.btn-primary", {
                    type: "button",
                    disabled: vnode.state.moving() ? "disabled" : "",
                    onclick() {
                        vnode.state.moving(true);
                        m.request({
                            method: "post",
                            url: "/api/packages/package_supplier/set_packages_location/",
                            config: xhrConfig,
                            data: {
                                packages: vnode.attrs.packages,
                                location: vnode.state.location()
                            }
                        }).then(() => {
                            vnode.state.unmount();
                            window.alertify.success(gettext("Success!."));
                            window.picotable.ctrl.refresh();
                        }, () => {
                            window.alertify.error(gettext("Error! Couldn't move packages to new location."));
                            vnode.state.moving(false);
                        });
                    }
                }, vnode.state.moving() ? gettext("Moving packages...") : gettext("Move packages"))
            )
        );
    }
};
export default SetLocationMassAction;
