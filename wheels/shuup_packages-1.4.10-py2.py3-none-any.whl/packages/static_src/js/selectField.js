import m from "mithril";

const ShuupQuickAddComponent = {
    oncreate(vnode) {
        window.setupQuickAdd($(vnode.dom).find("a"));
    },
    view(vnode) {
        const { url, fieldName } = vnode.attrs;
        return (
            m(".quick-add-btn",
                m("a.btn.btn-inverse", {
                    "data-url": `${url}?mode=iframe&quick_add_target=${fieldName}`,
                    "data-toggle": "popover",
                    "data-placement": "bottom",
                    "data-trigger": "hover",
                    "data-content": gettext("Create New")
                }, m("i.fa.fa-plus.text-primary"))
            )
        );
    }
};

const SelectField = {
    view(vnode) {
        const {
            id, errors, helpText, options, labelText, emptyOptionText, onchange, required,
            onQuickAddPress, quickAddUrl, fieldName
        } = vnode.attrs;
        return m(`.form-group.form-content.${errors ? "has-error" : ""}.${required ? "required-field" : ""}`,
            m("label.control-label", { for: id }, labelText),
            m(".form-input-group.d-flex",
                m("select.form-control", {
                    id,
                    onchange,
                    name: fieldName
                },
                    emptyOptionText ? (
                        m("option", { value: "" }, emptyOptionText)
                    ) : null,
                    options && options.map(item => (
                        m("option", {
                            value: item.id,
                            selected: item.selected ? "selected" : ""
                        }, item.name)
                    ))
                ),
                onQuickAddPress ? (
                    m("span.quick-add-btn",
                        m("a.btn.btn-inverse", {
                            onclick(e) {
                                e.preventDefault();
                                onQuickAddPress();
                            }
                        }, m("i.fa.fa-plus.text-primary"))
                    )
                ) : null,
                (quickAddUrl && fieldName) ? (
                    m(ShuupQuickAddComponent, {
                        url: quickAddUrl,
                        fieldName
                    })
                ) : null
            ),
            errors && m(".help-block.error-block", errors),
            helpText && m(".", m("small.text-muted", helpText))
        );
    }
};

export default SelectField;
