import m from "mithril";
import prop from "mithril/stream";

import { getTranslation } from "./utils";
import Select from "./selectField";


const ProductSelect = {
    oninit(vnode) {
        vnode.state.searchMode = prop(0);
        vnode.state.salesUnits = prop(0);
        vnode.state.categories = prop([]);
        vnode.state.primaryCategories = prop([]);
        vnode.state.secondaryCategories = prop([]);

        this.loadCategories(vnode);
    },
    oncreate(vnode) {
        $(vnode.dom).find("select").select2({
            minimumInputLength: 3,
            ajax: {
                url: "/admin/select/",
                dataType: "json",
                delay: 250,
                data(params) {
                    const query = {
                        search: params.term,
                        model: "shuup.Product"
                    };
                    if (vnode.state.searchMode()) {
                        query.searchMode = vnode.state.searchMode();
                    }
                    if (vnode.state.salesUnits()) {
                        query.salesUnits = vnode.state.salesUnits();
                    }
                    return query;
                },
                processResults(data) {
                    return {
                        results: data.results.map(result => ({
                            id: result.id,
                            text: result.name
                        }))
                    };
                }
            }
        });
    },
    onupdate(vnode) {
        vnode.state.searchMode(vnode.attrs.searchMode);
        vnode.state.salesUnits(vnode.attrs.salesUnits);
    },
    // onQuickAddPress(vnode) {
    //     window.QuickCreateProduct(
    //         vnode.state.categories(),
    //         vnode.state.primaryCategories(),
    //         vnode.state.secondaryCategories(),
    //         (product) => {
    //             const productOption = new Option(product.name, product.product, false, true);
    //             $(vnode.dom).find("select").append(productOption).trigger("change");
    //         }
    //     );
    // },
    loadCategories(vnode) {
        return m.request({
            url: "/api/pos/admin/category/",
            data: { status: 1 },  // Magical 1 is VISIBLE
        }).then((data) => {
            const categories = [...data.results];
            const formattedCategories = categories.map(cat => ({
                value: cat.id,
                label: getTranslation(cat, "name"),
                identifier: cat.identifier
            }));
            const primaryCategories = [
                {
                    value: 0,
                    label: gettext("Select a primary category"),
                    identifier: null
                },
                ...formattedCategories
            ];
            const secondaryCategories = [...formattedCategories];

            vnode.state.categories(categories);
            vnode.state.primaryCategories(primaryCategories);
            vnode.state.secondaryCategories(secondaryCategories);
        });
    },
    view(vnode) {
        return m(Select, {
            labelText: gettext("Product"),
            onchange: vnode.attrs.onchange,
            required: vnode.attrs.required,
            helpText: vnode.attrs.helpText,
            // FIXME: this was disabled due a requirement of Shuup Cloud Base scripts
            // Fix this with a smart solution
            // onQuickAddPress: vnode.state.categories().length ? () => this.onQuickAddPress(vnode) : null
        });
    }
};

export default ProductSelect;
