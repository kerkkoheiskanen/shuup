# -*- coding: utf-8 -*-
from shuup.core.models import Supplier


class CloudSupplierStrategy(object):

    def get_supplier(self, **kwargs):
        """
        Package supplier for current shop

        Add your business logic here in case you separate this
        app from Shuup POS

        :type shop: shuup.core.models.Shop
        :rtype: shuup.core.models.Supplier
        """
        shop = kwargs["shop"]
        try:
            from trees_shop.utils.suppliers import get_package_supplier_for_shop
            return get_package_supplier_for_shop(shop)
        except ImportError:
            return Supplier.objects.filter(shops__id=shop.pk).first()


class CloudSupplierUserStrategy(object):

    def get_users(self, **kwargs):
        shop = kwargs["supplier"].shops.first()
        return shop.staff_members.all()
