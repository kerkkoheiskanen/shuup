# -*- coding: utf-8 -*-
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "packages"
    verbose_name = "Shuup Packages"
    label = "packages"
    provides = {
        "supplier_module": ["packages.modules:PackageSupplierModule"],
        "api_populator": ["packages.api:populate_api"],
        "admin_module": [
            "packages.admin_module.modules.metrc:MetrcModule",
            "packages.admin_module.modules.batch:ShuupBatchModule",
            "packages.admin_module.modules.package:ShuupPackageModule",
            "packages.admin_module.modules.distributor:ShuupBatchProviderModule",
            "packages.admin_module.modules.location:ShuupPackageLocationModule",
            "packages.admin_module.modules.purchase_order:ShuupPurchaseOrderModule"
        ],
        "reports": [
            "packages.reports.product_stocks:ProductStockReport",
            "packages.reports.package_inventory:PackageInventoryReport",
            "packages.reports.batch_orders:BatchOrdersReport",
            "packages.reports.batch_performance:BatchPerformanceReport",
            "packages.reports.compliance:CannabisComplianceReport",
            "packages.reports.product_performance:ProductPerformanceReport",
        ],
        "notify_event": [
            "packages.notify_events:PackageAlertLimitReached"
        ]
    }

    def ready(self):
        # connect signals
        import packages.signal_handlers  # noqa (F401)
        import packages.fifo  # noqa (F401)
