def classproperty(getter):
    class ClassProperty(object):
        def __get__(self, instance, cls):
            return getter.__func__(cls)

    return ClassProperty()
