# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from shuup.core.models import ProductMode
from shuup.front.forms.order_forms import ProductOrderForm


class SubscriptionProductOrderForm(ProductOrderForm):
    template_name = "shuup_subscriptions/front/subscription_order.jinja"

    def is_compatible(self):
        return (self.product.mode == ProductMode.SUBSCRIPTION)
