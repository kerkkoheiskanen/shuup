# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_subscriptions"
    label = "shuup_subscriptions"
    provides = {
        "admin_module": [
            "shuup_subscriptions.admin_module:SubscriptionsAdminModule"
        ],
        "admin_product_toolbar_action_item": [
            "shuup_subscriptions.admin_module.toolbar:ProductToolbarActionItem"
        ],
        "admin_main_menu_updater": [
            "shuup_subscriptions.utils.admin:SubscriptionMainMenuUpdater",
        ],
        "admin_subscription_section": [
            "shuup_subscriptions.sections:SubscriptionInformationSection",
            "shuup_subscriptions.sections:SubscriptionContentsSection",
            "shuup_subscriptions.sections:SubscriptionPaymentsSection"
        ],
        "front_urls_pre": [
            "shuup_subscriptions.urls:urlpatterns"
        ],
        "front_product_order_form": [
            "shuup_subscriptions.utils.front:SubscriptionProductOrderForm"
        ],
        "subscription_processor": [
            "shuup_subscriptions.processors:ManualSubscriptionProcessor"
        ],
        'customer_dashboard_items': [
            'shuup_subscriptions.dashboard_items:SubscriptionItem'
        ],
        'service_behavior_component_form': [
            'shuup_subscriptions.behavior_components:SubscriptionProductsOnlyComponentForm'
        ]
    }

    def ready(self):
        from django.db.models.signals import post_save, pre_save
        from shuup.core.models import Product
        from shuup.core.order_creator.signals import order_creator_finished

        from .admin_module.signal_handlers import ensure_product_mode
        from .models import SubscriptionPayment
        from .utils.order import post_process_subscription_order
        from .utils.order import handle_payment_created

        # Ensure product mode before saving a Product
        pre_save.connect(ensure_product_mode, sender=Product)

        # Post-process subscription orders after creation
        order_creator_finished.connect(post_process_subscription_order)

        # Create recurring orders after payment is created
        post_save.connect(handle_payment_created, sender=SubscriptionPayment)
