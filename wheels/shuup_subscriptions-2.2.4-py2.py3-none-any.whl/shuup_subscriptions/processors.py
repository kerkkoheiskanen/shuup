# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from shuup.apps.provides import get_provide_objects
from shuup.core.models import CustomPaymentProcessor, PaymentMethod


class SubscriptionProcessor(object):
    payment_processor = None

    @classmethod
    def supports_plan(cls, plan):
        return False

    @classmethod
    def get_supported_processors(cls, plan):
        return [
            processor()
            for processor in get_provide_objects("subscription_processor")
            if processor.supports_plan(plan)
        ]

    def get_payment_methods(self):
        if self.payment_processor:
            return PaymentMethod.objects.filter(
                payment_processor__in=self.payment_processor.objects.all(), enabled=True)
        return PaymentMethod.objects.none()

    def activate_plan(self, subscription_line):
        """
        go to payment provider api and say that "now you should invoice this"
        :param subscription_line:
        :return:
        """
        pass

    @classmethod
    def external_id(cls, plan):
        return None


class ManualSubscriptionProcessor(SubscriptionProcessor):
    payment_processor = CustomPaymentProcessor

    @classmethod
    def supports_plan(cls, plan):
        return True
