# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('shuup', '0001_initial'),
        ('shuup_subscriptions', '0004_plan_changes'),
    ]

    operations = [
        migrations.CreateModel(
            name='SubscriptionProductsOnlyComponent',
            fields=[
                ('servicebehaviorcomponent_ptr', models.OneToOneField(serialize=False, auto_created=True, parent_link=True, primary_key=True, to='shuup.ServiceBehaviorComponent')),
            ],
            options={
                'abstract': False,
            },
            bases=('shuup.servicebehaviorcomponent',),
        ),
    ]
