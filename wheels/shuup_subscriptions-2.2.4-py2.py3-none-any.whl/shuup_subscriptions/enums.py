# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum


class PlanInterval(Enum):
    DAY = "day"
    WEEK = "week"
    TWO_WEEKS = "two_weeks"
    MONTH = "month"
    YEAR = "year"

    class Labels:
        DAY = _("daily")
        WEEK = _("weekly")
        TWO_WEEKS = _("every two weeks")
        MONTH = _("monthly")
        YEAR = _("yearly")



class TrialInterval(Enum):
    DAY = "day"
    WEEK = "week"
    TWO_WEEKS = "two_weeks"
    MONTH = "month"
    YEAR = "year"

    class Labels:
        DAY = _("a day")
        WEEK = _("a week")
        TWO_WEEKS = _("two weeks")
        MONTH = _("a month")
        YEAR = _("a year")



class SubscriptionCancellationMethod(Enum):
    IMMEDIATELY = 1
    PERIOD_END = 2
