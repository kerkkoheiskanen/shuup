# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.views.generic import DetailView, ListView
from shuup.front.views.dashboard import DashboardViewMixin

from shuup_subscriptions.models import Subscription


class SubscriptionViewMixin(object):
    model = Subscription

    def get_queryset(self):
        return super(SubscriptionViewMixin, self).get_queryset().filter(customer=self.request.customer).order_by("-id")


class SubscriptionListView(DashboardViewMixin, SubscriptionViewMixin, ListView):
    template_name = 'shuup_subscriptions/front/list.jinja'
    context_object_name = 'subscriptions'


class SubscriptionDetailView(DashboardViewMixin, SubscriptionViewMixin, DetailView):
    template_name = "shuup_subscriptions/front/detail.jinja"
    context_object_name = "subscription"
