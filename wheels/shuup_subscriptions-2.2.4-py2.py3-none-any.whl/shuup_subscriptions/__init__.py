from setuptools_gitver import get_version

__version__ = get_version(__name__)
default_app_config = __name__ + '.apps.AppConfig'
