# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.contrib import messages
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic import UpdateView
from shuup.admin.breadcrumbs import BreadcrumbedView
from shuup.admin.form_part import FormPartsViewMixin, SaveFormPartsMixin
from shuup.admin.forms import ShuupAdminForm
from shuup.admin.forms.widgets import TextEditorWidget
from shuup.admin.modules.products.views import ProductPackageView
from shuup.admin.modules.products.views.edit_package import (
    ProductChildrenFormPart)
from shuup.admin.toolbar import get_default_edit_toolbar
from shuup.admin.utils.views import CreateOrUpdateView
from shuup.apps.provides import get_provide_objects
from shuup.core.excs import NoPaymentToCreateException
from shuup.utils.money import Money

from shuup_subscriptions.admin_module.forms import (
    SubscriptionPaymentForm, SubscriptionProductPlanFormPart)
from shuup_subscriptions.models import Plan, Subscription, SubscriptionPayment
from shuup_subscriptions.utils.admin import ProductSubscriptionViewToolbar


class PlanForm(ShuupAdminForm):
    class Meta:
        model = Plan
        exclude = ["products"]
        widgets = {
            "description": TextEditorWidget()
        }


class PlanEditView(BreadcrumbedView, CreateOrUpdateView):
    model = Plan
    template_name = "shuup_subscriptions/admin/subscriptions/plan/edit.jinja"
    form_class = PlanForm
    context_object_name = "plan"
    add_form_errors_as_messages = True
    parent_name = _("Plans")
    parent_url = "shuup_admin:subscription.plan.list"

    def get_context_data(self, **kwargs):
        context = super(PlanEditView, self).get_context_data(**kwargs)
        context["title"] = _("Edit Plan: %s") % self.object
        return context

    def get_success_url(self):
        try:
            # do this because we use quick add
            return super(PlanEditView, self).get_success_url()
        except Exception:
            return reverse("shuup_admin:subscription.plan.edit", kwargs={"pk": self.object.pk})

    def get_toolbar(self):
        save_form_id = self.get_save_form_id()
        toolbar = get_default_edit_toolbar(self, save_form_id)
        return toolbar


class SubscriptionProductPackageView(ProductPackageView):
    template_name = "shuup_subscriptions/admin/subscriptions/product/edit_package.jinja"
    is_subscription = True
    form_part_classes = [ProductChildrenFormPart, SubscriptionProductPlanFormPart]
    toolbar_class = ProductSubscriptionViewToolbar

    def dispatch(self, request, *args, **kwargs):
        self.object = self.get_object()
        parent = self.object.get_all_package_parents().first()
        if parent:
            # By default, redirect to the first parent
            return HttpResponseRedirect(
                reverse("shuup_admin:subscription.subscription_product.edit", kwargs={"pk": parent.id})
            )
        return super(ProductPackageView, self).dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(ProductPackageView, self).get_context_data(**kwargs)
        context["title"] = _("Edit Subscription: %s") % self.object
        context["is_subscription"] = self.object.is_subscription_parent()
        context["subscription"] = self.is_subscription
        return context

    def get_form_parts(self, object):
        form_parts = super(ProductPackageView, self).get_form_parts(object)
        for fp in form_parts:
            fp.request = self.request
            fp.is_subscription = self.is_subscription
        return form_parts


class SubscriptionEditView(
        SaveFormPartsMixin, FormPartsViewMixin, BreadcrumbedView, UpdateView):
    model = Subscription
    template_name = "shuup_subscriptions/admin/subscriptions/edit.jinja"
    context_object_name = "subscription"
    base_form_part_classes = []
    form_part_class_provide_key = "admin_subscription_form_part"
    add_form_errors_as_messages = True
    parent_name = _("Subscriptions")
    parent_url = "shuup_admin:subscription.sub.list"

    def get_context_data(self, **kwargs):
        context = super(SubscriptionEditView, self).get_context_data(**kwargs)

        context['title'] = '{}'.format(context['subscription'])

        context["subscription_sections"] = []
        section_provides = sorted(get_provide_objects("admin_subscription_section"), key=lambda x: x.order)
        for admin_subscription_section in section_provides:
            if admin_subscription_section.visible_for_object(self.object):
                subscription_context = admin_subscription_section.get_context_data(self.object)
                context["subscription_sections"].append(admin_subscription_section)
                context[admin_subscription_section.identifier] = subscription_context
        return context


class SubscriptionPaymentEditView(BreadcrumbedView, CreateOrUpdateView):
    model = SubscriptionPayment
    template_name = "shuup_subscriptions/admin/subscriptions/payment/edit.jinja"
    form_class = SubscriptionPaymentForm
    context_object_name = "payment"
    add_form_errors_as_messages = True
    parent_name = _("Subscription Payments")
    parent_url = "shuup_admin:subscription.payment.list"

    def form_valid(self, form):
        subscription = form.cleaned_data["subscription"]
        amount = Money(form.cleaned_data["amount_value"], subscription.currency)
        if amount.value == 0:
            messages.error(self.request, _("Payment amount cannot be 0"))
            return self.form_invalid(form)
        try:
            payment = subscription.create_payment(amount, description="Manual payment")
            messages.success(self.request, _("Payment %s created.") % payment.payment_identifier)
        except NoPaymentToCreateException:
            messages.error(self.request, _("Order has already been paid"))
            return self.form_invalid(form)
