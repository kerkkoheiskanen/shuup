# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

import json

import pytest
from django.conf import settings
from django.core.urlresolvers import reverse
from shuup.testing import factories
from six.moves.urllib.parse import urlencode

from shuup_subscriptions.models import Plan


@pytest.mark.django_db
def test_plan_list_view(admin_client):
    shop = factories.get_default_shop()
    price = shop.create_price
    plan = Plan.objects.create(
        shop=shop, is_active=True, amount=price(3),
        name="Foobar Plan")

    # Check the view rendering
    result = admin_client.get(reverse('shuup_admin:subscription.plan.list'))
    assert result.status_code == 200
    page_content = result.content.decode('utf-8')
    assert '<h1 class="main-header">Plans</h1>' in page_content
    assert '<div id="picotable">' in page_content

    # Check the picotable contents
    picotable_data = load_picotable(
        admin_client, 'shuup_admin:subscription.plan.list')

    assert picotable_data['items'] ==[
        {'_abstract': [{
            'class': 'header',
            'text': 'Foobar Plan, €3.00 monthly'}],
          '_id': plan.pk,
          '_linked_in_mobile': True,
          '_url': '/sa/subscriptions/plan/{}/'.format(plan.pk),
          'amount': '€3.00',
          'interval': 'monthly',
          'is_active': 'True',
          'name': 'Foobar Plan',
          'type': 'Plan'}
    ]


def load_picotable(client, url_name, per_page=10, page=1):
    param = {'perPage': per_page, 'page': page}
    url = '{url}?{query}'.format(
        url=reverse(url_name),
        query=encode_json_url_params(jq=param))
    result = client.get(url)
    return json.loads(result.content.decode('utf-8'))


def encode_json_url_params(**params):
    param_list = [(k, json.dumps(v)) for (k, v) in params.items()]
    return urlencode(param_list)
