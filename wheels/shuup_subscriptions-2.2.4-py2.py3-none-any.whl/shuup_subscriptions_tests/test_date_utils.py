# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

import datetime

import pytest

from shuup_subscriptions.enums import PlanInterval
from shuup_subscriptions.utils.dates import (
    add_months_to_date, add_plan_interval_to_date, add_years_to_date)


def d(x):
    return datetime.datetime.strptime(x, '%Y-%m-%d').date()


def dt(x):
    return datetime.datetime.strptime(x, '%Y-%m-%d %H:%M')


def test_add_years_to_date():
    assert add_years_to_date(d('2017-03-05'), 3) == d('2020-03-05')
    assert add_years_to_date(d('2000-02-28'), 15) == d('2015-02-28')
    assert add_years_to_date(d('2000-02-29'), 15) == d('2015-03-01')
    assert add_years_to_date(d('2000-02-29'), -15) == d('1985-03-01')
    assert add_years_to_date(d('2000-03-01'), 15) == d('2015-03-01')
    assert add_years_to_date(d('1800-12-31'), 15) == d('1815-12-31')
    assert add_years_to_date(d('2200-01-01'), 15) == d('2215-01-01')
    assert add_years_to_date(d('2019-06-06'), 0) == d('2019-06-06')
    assert add_years_to_date(d('2019-06-06'), -2) == d('2017-06-06')
    assert add_years_to_date(dt('2019-06-06 11:45'), 5) == dt('2024-06-06 11:45')


def test_add_months_to_date():
    assert add_months_to_date(d('2017-03-05'), 5) == d('2017-08-05')
    assert add_months_to_date(d('2017-03-05'), 10) == d('2018-01-05')
    assert add_months_to_date(d('2017-03-05'), 22) == d('2019-01-05')
    assert add_months_to_date(d('2017-03-05'), 22) == d('2019-01-05')
    assert add_months_to_date(d('2000-02-29'), 1) == d('2000-03-29')
    assert add_months_to_date(d('2000-01-29'), 1) == d('2000-02-29')
    assert add_months_to_date(d('2001-01-29'), 1) == d('2001-02-28')
    assert add_months_to_date(d('2001-01-30'), 1) == d('2001-02-28')
    assert add_months_to_date(d('2001-01-31'), 1) == d('2001-02-28')
    assert add_months_to_date(d('2001-01-31'), 2) == d('2001-03-31')
    assert add_months_to_date(d('2001-01-31'), -1) == d('2000-12-31')
    assert add_months_to_date(dt('2004-05-31 18:23'), 17) == dt('2005-10-31 18:23')


@pytest.mark.parametrize('interval,start,expected', [
    (PlanInterval.DAY, dt('2005-10-31 21:34'), dt('2005-11-01 21:34')),
    (PlanInterval.WEEK, dt('2005-10-31 21:34'), dt('2005-11-07 21:34')),
    (PlanInterval.TWO_WEEKS, dt('2005-10-31 21:34'), dt('2005-11-14 21:34')),
    (PlanInterval.MONTH, dt('2005-10-31 21:34'), dt('2005-11-30 21:34')),
    (PlanInterval.YEAR, dt('2005-10-31 21:34'), dt('2006-10-31 21:34')),
])
def test_add_plan_interval_to_date(interval, start, expected):
    assert add_plan_interval_to_date(interval, start) == expected
    assert add_plan_interval_to_date(interval, start.date()) == expected.date()


def test_add_plan_interval_to_date_specials():
    assert add_plan_interval_to_date(None, d('2016-01-22')) == d('2016-01-22')
    assert add_plan_interval_to_date(42, d('2016-03-10')) is None
