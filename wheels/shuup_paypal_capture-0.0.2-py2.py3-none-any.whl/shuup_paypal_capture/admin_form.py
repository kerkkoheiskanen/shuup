# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.utils.translation import ugettext_lazy as _
from shuup.admin.forms import ShuupAdminForm

from .models import PaypalAuthorizeAndCapture


class PaypalCheckoutAdminForm(ShuupAdminForm):
    class Meta:
        model = PaypalAuthorizeAndCapture
        fields = '__all__'
        widgets = {
            "client_id": forms.PasswordInput(render_value=True),
            "client_secret": forms.PasswordInput(render_value=True),
        }
        help_textx = {
            "disclaimer": _("Show this disclaimer at checkout phase before customer authorizes the charge."),
            "is_live": _("Whether to use live/production API URL instead of sandbox.")
        }

    def __init__(self, **kwargs):
        super(PaypalCheckoutAdminForm, self).__init__(**kwargs)
        self.fields["disclaimer"].required = False
