# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.views.generic.edit import FormView
from shuup.front.checkout import (
    BasicServiceCheckoutPhaseProvider, CheckoutPhaseViewMixin
)

from .models import PaypalAuthorizeAndCapture

SHUUP_BASKET_PAYMENT_DATA_PAYPAL_KEY = "paypal-capture"
PAYPAL_DATA_AUTHORIZATION_ID_KEY = "auth-token"
STORAGE_KEY = "paypal-capture"


class PaypalTokenForm(forms.Form):
    authToken = forms.CharField(widget=forms.HiddenInput, required=True)


class PaypalCheckoutPhase(CheckoutPhaseViewMixin, FormView):
    service = None  # Injected by the method phase
    identifier = "paypal-capture"
    title = "Paypal Authorize"
    template_name = "shuup_paypal_capture/checkout_phase.jinja"
    form_class = PaypalTokenForm

    def get_paypal_context(self):
        payment_processor = self.service.payment_processor
        amount = self.request.basket.taxful_total_price
        config = {
            "client_id": payment_processor.client_id,
            "currency": amount.currency,
            "amount_value": amount.value,
            "disclaimer": payment_processor.disclaimer
        }
        return config

    def get_context_data(self, **kwargs):
        context = super(PaypalCheckoutPhase, self).get_context_data(**kwargs)
        context["paypal"] = self.get_paypal_context()
        return context

    def is_valid(self):
        return PAYPAL_DATA_AUTHORIZATION_ID_KEY in self.storage.get(STORAGE_KEY, {})

    def form_valid(self, form):
        self.storage[STORAGE_KEY] = {PAYPAL_DATA_AUTHORIZATION_ID_KEY: form.cleaned_data.get("authToken")}
        return super(PaypalCheckoutPhase, self).form_valid(form)

    def process(self):
        self.request.basket.payment_data[SHUUP_BASKET_PAYMENT_DATA_PAYPAL_KEY] = self.storage[STORAGE_KEY]


class PaypalCheckoutPhaseProvider(BasicServiceCheckoutPhaseProvider):
    phase_class = PaypalCheckoutPhase
    service_provider_class = PaypalAuthorizeAndCapture
