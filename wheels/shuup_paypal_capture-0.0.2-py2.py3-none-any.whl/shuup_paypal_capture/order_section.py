# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext as _
from shuup.admin.base import Section

from .checkout_phase import (
    PAYPAL_DATA_AUTHORIZATION_ID_KEY, SHUUP_BASKET_PAYMENT_DATA_PAYPAL_KEY
)
from .models import SERVICE_IDENTIFIER


class PaypalCaptureOrderSection(Section):
    identifier = "paypal_capture_capture_section"
    name = _("Paypal Capture")
    icon = "fa-paypal"
    template = "shuup_paypal_capture/order_section.jinja"
    order = 32

    @classmethod
    def visible_for_object(cls, order, request=None):
        if order.is_paid():
            return False

        payment_method = order.payment_method
        if not bool(payment_method and payment_method.choice_identifier == SERVICE_IDENTIFIER):
            return False

        if not order.payment_method.payment_processor:
            return False

        if not order.payment_data:
            return False

        paypal_data = order.payment_data.get(SHUUP_BASKET_PAYMENT_DATA_PAYPAL_KEY)
        return bool(paypal_data and paypal_data.get(PAYPAL_DATA_AUTHORIZATION_ID_KEY))
