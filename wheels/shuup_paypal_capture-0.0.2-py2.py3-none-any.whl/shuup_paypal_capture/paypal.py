# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json

import shuup.utils.http

from .checkout_phase import (
    PAYPAL_DATA_AUTHORIZATION_ID_KEY, SHUUP_BASKET_PAYMENT_DATA_PAYPAL_KEY
)


def _get_base_url(paypal_payment_processor):
    return "https://api%s.paypal.com" % ("" if getattr(paypal_payment_processor, "is_live", None) else ".sandbox")


def _get_paypal_token(paypal_payment_processor):
    oauth_api_url = "%s/v1/oauth2/token/" % (_get_base_url(paypal_payment_processor))

    response = shuup.utils.http.retry_request(
        method="post",
        url=oauth_api_url,
        headers={
            "Accept": "application/json",
        },
        data={
            "grant_type": "client_credentials"
        },
        auth=(paypal_payment_processor.client_id, paypal_payment_processor.client_secret),
        timeout=10,
    )
    response.raise_for_status()
    response_data = response.json()
    return '{} {}'.format(
        response_data['token_type'],
        response_data['access_token'],
    )


def _do_paypal_authorization(order, payment_processor, intent):
    amount = order.taxful_total_price.as_rounded()
    auth_id = order.payment_data[SHUUP_BASKET_PAYMENT_DATA_PAYPAL_KEY][PAYPAL_DATA_AUTHORIZATION_ID_KEY]
    authorization_api_url = (
        "%s/v2/payments/authorizations/%s/%s" % (_get_base_url(payment_processor), auth_id, intent)
    )
    token = _get_paypal_token(payment_processor)
    data = {
        "amount": {
            "value": "%s" % amount.value,
            "currency_code": amount.currency
        },
        "invoice_id": order.reference_number,
        "final_capture": True
    }

    return shuup.utils.http.retry_request(
        method="post",
        url=authorization_api_url,
        headers={
            "Accept": "application/json",
            "Authorization": token,
            "Content-Type": "application/json"
        },
        data=json.dumps(data).encode("UTF-8"),
        timeout=10
    )


def capture_order(paypal_payment_processor, service, order, request):
    if order.is_paid():
        return

    response = _do_paypal_authorization(order, paypal_payment_processor, "capture")
    response.raise_for_status()
    response_data = response.json()
    order.create_payment(
        order.taxful_total_price,
        payment_identifier="Paypal [%s]" % response_data["id"],
        description="Paypal %s (ref %s)" % (response_data["id"], order.reference_number)
    )
