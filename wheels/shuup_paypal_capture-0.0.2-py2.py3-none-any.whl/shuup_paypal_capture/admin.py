# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import logging

from django.contrib import messages
from django.http import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic import DetailView
from shuup.admin.base import AdminModule
from shuup.admin.shop_provider import get_shop
from shuup.admin.utils.urls import admin_url, get_model_url
from shuup.core.models import Order

from .paypal import capture_order

logger = logging.getLogger("shuup_paypal_capture.capture_authorization")


class PaypalAuthorizeAndCaptureModule(AdminModule):
    name = _("Paypal Authorize & Capture")

    def get_urls(self):
        return [
            admin_url(
                "^paypal-capture/(?P<pk>\d+)/$",
                "shuup_paypal_capture.admin.CaptureView",
                name="shuup_paypal_capture.capture_authorization"
            )
        ]


class CaptureView(DetailView):
    model = Order

    def get(self, request, *args, **kwargs):
        order = self.object = self.get_object()
        if order.is_paid():
            messages.error(request, _("Order is already fully paid."))
            return HttpResponseRedirect(get_model_url(self.get_object()))

        service = order.payment_method
        payment_processor = service.payment_processor
        capture_order(payment_processor, service, order, request)
        messages.success(request, _("Payment captured successfully."))
        return HttpResponseRedirect(get_model_url(self.get_object()))

    def get_queryset(self):
        return Order.objects.filter(shop=get_shop(self.request))
