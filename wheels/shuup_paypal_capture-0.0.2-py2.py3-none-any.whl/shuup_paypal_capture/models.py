# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.db import models
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import PaymentProcessor, ServiceChoice

SERVICE_IDENTIFIER = "authorize-and-capture"


class PaypalAuthorizeAndCapture(PaymentProcessor):
    client_id = models.CharField(verbose_name=_("Client ID"), max_length=128)
    client_secret = models.CharField(verbose_name=_("Client Secret"), max_length=128)
    disclaimer = models.CharField(
        verbose_name=_("Disclaimer"),
        max_length=512,
        default=_(
            "We use PayPal for secure payment handling. You will only be charged when your order completes."
        )
    )
    is_live = models.BooleanField(verbose_name=_("Is Live"), default=False)

    class Meta:
        verbose_name = _("Paypal authorize & capture")

    def get_service_choices(self):
        return [
            ServiceChoice(SERVICE_IDENTIFIER, _("Paypal authorize & capture"))
        ]

    def process_payment_return_request(self, service, order, request):
        from .paypal import capture_order
        capture_order(self, service, order, request)
