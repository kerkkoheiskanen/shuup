# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_paypal_capture"
    verbose_name = "Shuup Paypal Capture"
    label = "shuup_paypal_capture"
    provides = {
        "admin_module": [
            "shuup_paypal_capture.admin:PaypalAuthorizeAndCaptureModule",
        ],
        "admin_order_section": [
            "shuup_paypal_capture.order_section:PaypalCaptureOrderSection",
        ],
        "front_service_checkout_phase_provider": [
            "shuup_paypal_capture.checkout_phase:PaypalCheckoutPhaseProvider"
        ],
        "service_provider_admin_form": [
            "shuup_paypal_capture.admin_form:PaypalCheckoutAdminForm"
        ]
    }
