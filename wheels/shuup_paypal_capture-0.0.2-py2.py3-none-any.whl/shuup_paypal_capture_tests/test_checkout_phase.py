# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import mock
import pytest
from django.core.urlresolvers import reverse
from shuup.front.basket import get_basket
from shuup.testing.factories import get_default_shop, get_default_tax_class
from shuup.testing.utils import apply_request_middleware
from shuup.utils.excs import Problem

from shuup_paypal_capture.checkout_phase import PaypalCheckoutPhase
from shuup_paypal_capture.models import PaypalAuthorizeAndCapture, SERVICE_IDENTIFIER


@pytest.mark.django_db
def test_paypal_checkout_phase(rf):
    request = apply_request_middleware(rf.post("/"), shop=get_default_shop())
    request.session = {}
    request.basket = get_basket(request)

    disclaimer_text = "Le Sandbox"
    payment_processor = PaypalAuthorizeAndCapture.objects.create(
        client_id="id", client_secret="secret", disclaimer=disclaimer_text, name="PayPal"
    )
    assert not payment_processor.is_live  # test-mode is good default
    assert payment_processor.get_service_choices()[0].identifier == SERVICE_IDENTIFIER
    service = payment_processor.create_service(
        SERVICE_IDENTIFIER, shop=request.shop, tax_class=get_default_tax_class(), enabled=True
    )

    checkout_phase = PaypalCheckoutPhase(request=request, service=service)
    assert not checkout_phase.is_valid()  # We can't be valid just yet
    context = checkout_phase.get_context_data()
    assert context["paypal"]
    assert context["paypal"]["disclaimer"] == disclaimer_text
    request.method = "POST"

    token = "1234"
    request.POST = {"authToken": token}
    checkout_phase.get_success_url = lambda: reverse("shuup_admin:home")
    checkout_phase.post(request)
    assert checkout_phase.is_valid()  # We should be valid now
    assert request.session  # And things should've been saved into the session
    checkout_phase.process()  # And this should do things to the basket
    assert request.basket.payment_data["paypal-capture"]["auth-token"] == token
