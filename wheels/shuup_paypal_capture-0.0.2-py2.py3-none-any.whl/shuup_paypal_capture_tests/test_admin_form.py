# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import django
import pytest

from bs4 import BeautifulSoup
from django.test import override_settings
from django.utils import version

from shuup.admin.modules.service_providers.views import ServiceProviderEditView
from shuup.apps.provides import override_provides
from shuup.core.models import CustomCarrier, CustomPaymentProcessor
from shuup.testing.factories import (
    get_default_payment_method, get_default_shipping_method, get_default_shop
)
from shuup.testing.models import PseudoPaymentProcessor
from shuup.testing.utils import apply_all_middleware

from shuup_paypal_capture.models import PaypalAuthorizeAndCapture


def get_bs_object_for_view(request, view, user, object=None):
    """
    Help function to get BeautifulSoup object from the html rendered
    by the edit view.

    Also override ``service_provider_admin_form`` here to enable
    ``PseudoPaymentProcessor``
    """
    with override_provides("service_provider_admin_form", [
        "shuup.testing.service_forms.PseudoPaymentProcessorForm",
        "shuup_paypal_capture.admin_form:PaypalCheckoutAdminForm"
    ]):
        request = apply_all_middleware(request, user=user)
        response = view(request, pk=object.pk if object else None)
        if hasattr(response, "render"):
            response.render()
        assert response.status_code in [200, 302]
        return BeautifulSoup(response.content)


@pytest.mark.django_db
def test_new_paypal_provider_admin(rf, admin_user):
    sp_model = PaypalAuthorizeAndCapture
    type_param = "shuup_paypal_capture.paypalauthorizeandcapture"
    with override_settings(LANGUAGES=[("en", "en")]):
        get_default_shop()
        view = ServiceProviderEditView.as_view()
        url = "/?type=%s" % type_param
        soup = get_bs_object_for_view(rf.get(url), view, admin_user)
        selected_type = soup.find("select", attrs={"id": "id_type"}).find("option", selected=True)["value"]
        assert type_param == selected_type

        if sp_model:
            client_id = "123"
            client_secret = "456"
            data = {
                "type": type_param,
                "name__en": "Paypal",
                "enabled": True,
                "client_id": client_id,
                "client_secret": client_secret
            }
            get_bs_object_for_view(rf.post(url, data=data), view, admin_user)
            assert sp_model.objects.count() == 1
            provider = sp_model.objects.first()
            assert provider.client_id == client_id
            assert provider.client_secret == client_secret
            assert provider.disclaimer != ""  # There is default and this field is not required
            assert not provider.is_live
