# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import mock
import pytest

from django.contrib import messages
from shuup.testing import factories
from shuup.testing.utils import apply_request_middleware

from shuup_paypal_capture.admin import CaptureView
from shuup_paypal_capture.models import PaypalAuthorizeAndCapture, SERVICE_IDENTIFIER
from shuup_paypal_capture.order_section import PaypalCaptureOrderSection
from shuup_paypal_capture.paypal import _get_base_url


@pytest.mark.django_db
def test_order_section_visibility(rf):
    payment_processor = PaypalAuthorizeAndCapture.objects.create(
        client_id="id", client_secret="secret", name="PayPal"
    )
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    product = factories.get_default_product()
    order = factories.create_order_with_product(
        product=product, supplier=supplier, quantity=1,
        taxless_base_unit_price=52, tax_rate=0, shop=shop
    )
    request = apply_request_middleware(rf.get("/"), shop=shop)
    assert not PaypalCaptureOrderSection.visible_for_object(order, request)  # Wrong method

    payment_method = payment_processor.create_service(
        SERVICE_IDENTIFIER, shop=order.shop, tax_class=factories.get_default_tax_class(), enabled=True)
    order.payment_method = payment_method
    order.cache_prices()
    assert order.taxless_total_price.value > 0
    order.save()

    assert not PaypalCaptureOrderSection.visible_for_object(order, request)  # No paypal payment data

    order.payment_data = {
        "paypal-capture-wrong-key": {"auth-token": "blaah"}
    }
    order.save()

    assert not PaypalCaptureOrderSection.visible_for_object(order, request)

    order.payment_data = {
        "paypal-capture": {"auth-token": "blaah"}
    }
    order.save()

    assert PaypalCaptureOrderSection.visible_for_object(order, request)

    # Someone was able to remove payment processor from method -> should not blow up
    payment_method.payment_processor = None
    payment_method.save()

    assert not PaypalCaptureOrderSection.visible_for_object(order, request)

    payment_method.payment_processor = payment_processor
    payment_method.save()

    assert PaypalCaptureOrderSection.visible_for_object(order, request)

    order.create_payment(order.taxful_total_price)
    assert order.is_paid()

    assert not PaypalCaptureOrderSection.visible_for_object(order, request)
