# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import os
import pytest
from django.core.management import call_command
from six import StringIO


@pytest.mark.django_db
def test_makemigrations():
    out = StringIO()
    call_command("makemigrations", "--dry-run", stdout=out)
    assert "No changes detected" in out.getvalue()
