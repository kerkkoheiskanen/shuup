# -*- coding: utf-8 -*-
# This file is part of Shuup Paypal Basic addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import mock
import pytest

from django.contrib import messages
from shuup.testing import factories
from shuup.testing.utils import apply_request_middleware

from shuup_paypal_capture.admin import CaptureView
from shuup_paypal_capture.models import PaypalAuthorizeAndCapture, SERVICE_IDENTIFIER
from shuup_paypal_capture.paypal import _get_base_url

class PaypalData(dict):
    def __getattr__(self, attr):
        return self[attr]

    def json(self):
        return self

    def raise_for_status(self):
        pass



@pytest.mark.django_db
def test_capture_url(rf):
    payment_processor = PaypalAuthorizeAndCapture.objects.create(client_id="id", client_secret="secret", name="PayPal")
    assert not payment_processor.is_live
    assert "sandbox" in _get_base_url(payment_processor)

    payment_processor.is_live = True
    payment_processor.save()
    assert "sandbox" not in _get_base_url(payment_processor)


@pytest.mark.django_db
def test_capture(rf):
    payment_id = "horse"
    with mock.patch("shuup.utils.http.retry_request") as mocked:
        mocked.return_value = PaypalData(id=payment_id, token_type="Bearer", access_token="1234")

        payment_processor = PaypalAuthorizeAndCapture.objects.create(
            client_id="id", client_secret="secret", name="PayPal"
        )
        order = _create_order(payment_processor, factories.get_default_shop())
        assert order.payment_data["paypal-capture"]["auth-token"]
        payment_processor.process_payment_return_request(order.payment_method, order, rf.post("/"))
        assert order.is_paid()
        assert order.payments.first().payment_identifier == "Paypal [%s]" % payment_id

        # Capturing paid order should not create new payment
        payment_processor.process_payment_return_request(order.payment_method, order, rf.post("/"))
        assert order.payments.count() == 1


@pytest.mark.django_db
def test_manual_capture(rf, admin_user):
    shop = factories.get_default_shop()
    payment_id = "horse"
    with mock.patch("shuup.utils.http.retry_request") as mocked:
        mocked.return_value = PaypalData(id=payment_id, token_type="Bearer", access_token="1234")
        payment_processor = PaypalAuthorizeAndCapture.objects.create(
            client_id="id", client_secret="secret", name="PayPal"
        )
        order = _create_order(payment_processor, shop)
        assert order.payment_data["paypal-capture"]["auth-token"]
        request = apply_request_middleware(rf.get("/"), shop=shop, user=admin_user)
        response = CaptureView.as_view()(request, pk=order.pk)
        if hasattr(response, "render"):
            response.render()
        assert response.status_code in [301, 302]  # Redirect
        all_messages = list(messages.get_messages(request))
        assert len(all_messages) == 1
        assert all_messages[0].tags == "success"

        order.refresh_from_db()
        assert order.is_paid()
        assert order.payments.first().payment_identifier == "Paypal [%s]" % payment_id

        # Recapturing should not have effect
        request = apply_request_middleware(rf.get("/"), shop=shop, user=admin_user)
        response = CaptureView.as_view()(request, pk=order.pk)
        if hasattr(response, "render"):
            response.render()
        assert response.status_code in [301, 302]  # Redirect

        all_messages = list(messages.get_messages(request))
        assert len(all_messages) == 1
        assert all_messages[0].tags == "error"

        order.refresh_from_db()
        assert order.payments.count() == 1

 
def _create_order(payment_processor, shop, unit_price=100):
    product = factories.get_default_product()
    supplier = factories.get_default_supplier()
    order = factories.create_order_with_product(
        product=product, supplier=supplier, quantity=1,
        taxless_base_unit_price=unit_price, tax_rate=0, shop=shop
    )
    payment_method = payment_processor.create_service(
        SERVICE_IDENTIFIER, shop=order.shop, tax_class=factories.get_default_tax_class(), enabled=True)
    order.payment_method = payment_method
    order.cache_prices()
    assert order.taxless_total_price.value > 0
    if not order.payment_data:
        order.payment_data = {
            "paypal-capture": {"auth-token": "blaah"}
        }
    order.save()
    return order
