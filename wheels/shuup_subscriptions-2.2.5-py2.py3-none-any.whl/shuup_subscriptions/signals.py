import django.dispatch

subscription_cancelled = django.dispatch.Signal(providing_args=["subscription", "user", "skip_suspend"])
