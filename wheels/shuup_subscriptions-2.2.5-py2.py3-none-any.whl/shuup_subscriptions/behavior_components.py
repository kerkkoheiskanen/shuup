from shuup.admin.modules.services.forms import AlwaysChangedModelForm

from .models import SubscriptionProductsOnlyComponent


class SubscriptionProductsOnlyComponentForm(AlwaysChangedModelForm):
    class Meta:
        model = SubscriptionProductsOnlyComponent
        exclude = ["identifier"]
