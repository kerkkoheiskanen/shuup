# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.shortcuts import get_object_or_404
from django.utils.translation import ugettext_lazy as _
from django.views.generic import FormView
from shuup.core.models import Product
from shuup.front.basket import commands as basket_commands
from shuup.front.checkout import CheckoutPhaseViewMixin

from ._basket import SubscriptionBasket
from ._forms import SubscriptionPlanForm


class SubscriptionPlanPhase(CheckoutPhaseViewMixin, FormView):
    identifier = "subscription_plan"
    title = _("Plan")
    product = None
    form_class = SubscriptionPlanForm
    template_name = "shuup_subscriptions/checkout/subscription_plan.jinja"

    def dispatch(self, request, product_id, *args, **kwargs):
        product = get_object_or_404(Product, pk=product_id)  # type: Product
        shop_product = product.get_shop_instance(request.shop)
        if not shop_product.is_orderable(
                supplier=None, customer=request.customer, quantity=1,
                allow_cache=False):
            raise Exception("Not orderable")  # TODO: Fix

        # Add the product to the basket
        assert isinstance(self.basket, SubscriptionBasket)
        self.basket.clear_all()
        basket_commands.handle_add(request, self.basket, product_id=product.pk)
        self.basket.save()

        self.product = product
        self.shop_product = shop_product
        self.shop = request.shop

        return super(SubscriptionPlanPhase, self).dispatch(
            request, *args, **kwargs)

    def get_initial(self):
        initial = super(SubscriptionPlanPhase, self).get_initial()
        initial['plan'] = self.storage.get('plan_id')
        return initial

    def get_form_kwargs(self):
        kwargs = super(SubscriptionPlanPhase, self).get_form_kwargs()
        kwargs["product"] = self.product
        kwargs["shop"] = self.shop
        return kwargs

    def form_valid(self, form):
        self.storage.set("plan_id", form.cleaned_data['plan'].id)
        return super(SubscriptionPlanPhase, self).form_valid(form)

    def is_valid(self):
        return bool(self.storage.get("plan_id"))

    def process(self):
        if self.is_valid():
            assert isinstance(self.basket, SubscriptionBasket)
            self.basket.set_plan_by_id(self.storage.get("plan_id"))

    def get_context_data(self, **kwargs):
        context = super(SubscriptionPlanPhase, self).get_context_data(**kwargs)
        context["product"] = self.product
        return context
