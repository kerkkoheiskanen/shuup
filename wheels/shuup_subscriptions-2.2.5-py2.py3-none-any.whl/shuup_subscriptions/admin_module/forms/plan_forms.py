# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.utils.translation import ugettext_lazy as _
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.admin.forms.fields import Select2MultipleField

from shuup_subscriptions.admin_module.forms.widgets import QuickAddPlanSelect
from shuup_subscriptions.models import Plan


class SubscriptionProductPlanForm(forms.Form):
    """
    This form is visible when selecting plan for subscriptionproduct
    """
    plans = Select2MultipleField(
        model=Plan,
        widget=QuickAddPlanSelect,
        help_text=_("Select the plans that are usable with this subscription product."))

    def __init__(self, **kwargs):
        self.product = kwargs.pop("product")
        super(SubscriptionProductPlanForm, self).__init__(**kwargs)
        choices = [(psp.pk, psp.name)
                   for psp in Plan.objects.filter(products__in=[self.product]).all()]
        self.fields["plans"].widget.choices = choices
        self.fields["plans"].initial = [pk for pk, name in choices]

    def save(self, **kwargs):
        # remove products from all plans they exists
        for plan in Plan.objects.filter(products__in=[self.product]):
            plan.products.remove(self.product)

        # add product to selected plans
        ids = [int(id) for id in self.cleaned_data.get("plans", [])]
        for plan in Plan.objects.filter(id__in=ids):
            plan.products.add(self.product)


class SubscriptionProductPlanFormPart(FormPart):
    priority = 0

    def get_form_defs(self):
        yield TemplatedFormDef(
            name="product_plan",
            form_class=SubscriptionProductPlanForm,
            template_name="shuup_subscriptions/admin/subscriptions/product/package_form_part.jinja",
            required=False,
            kwargs={"product": self.object}
        )

    def form_valid(self, form):
        form["product_plan"].save()
