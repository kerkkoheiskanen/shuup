# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import ORDERS_MENU_CATEGORY, PRODUCTS_MENU_CATEGORY
from shuup.admin.utils.permissions import get_default_model_permissions
from shuup.admin.utils.urls import (
    admin_url, derive_model_url, get_edit_and_list_urls)

from ..models import Plan, Subscription, SubscriptionPayment

_MODEL_LIST = [
    (Plan, 'plan'),
    (Subscription, 'sub'),
    (SubscriptionPayment, 'payment'),
]


class SubscriptionsAdminModule(AdminModule):
    name = _(u"Subscriptions")

    def get_urls(self):
        return [
            admin_url(
                "^subscriptions/subscription-product/(?P<pk>\d+)/edit/$",
                "shuup_subscriptions.admin_module.views.SubscriptionProductPackageView",
                name="subscription.subscription_product.edit",
                permissions=self.get_required_permissions()
            ),
        ] + [
            admin_url(
                "^subscriptions/list-settings/",
                "shuup.admin.modules.settings.views.ListSettingsView",
                name="subscription.{}.list_settings".format(key),
                permissions=get_default_model_permissions(model),
            )
            for (model, key) in _MODEL_LIST
        ] + sum((
            get_edit_and_list_urls(
                url_prefix="^subscriptions/" + key,
                view_template=(
                    __name__ + '.views.{}%sView'.format(model.__name__)),
                name_template="subscription.{}.%s".format(key),
                permissions=get_default_model_permissions(model))
            for (model, key) in _MODEL_LIST), []
        )

    def get_menu_entries(self, request):
        return [
            MenuEntry(
                text=_("Plans"), icon="fa fa-file-text",
                url="shuup_admin:subscription.plan.list",
                category=PRODUCTS_MENU_CATEGORY,
                subcategory="subscriptions",
                ordering=3,
                aliases=[_("Show plans")]
            ),
            MenuEntry(
                text=_("Subscriptions"), icon="fa fa-file-text",
                url="shuup_admin:subscription.sub.list",
                category=ORDERS_MENU_CATEGORY,
                subcategory="subscriptions",
                ordering=4,
                aliases=[_("Show subscriptions")]
            ),
            MenuEntry(
                text=_("Payments"), icon="fa fa-money",
                url="shuup_admin:subscription.payment.list",
                category=ORDERS_MENU_CATEGORY,
                subcategory="subscriptions",
                ordering=4,
                aliases=[_("Show payments")]
            ),

        ]

    def get_required_permissions(self):
        return get_default_model_permissions(Plan)

    def get_model_url(self, object, kind, shop=None):
        for (model, key) in _MODEL_LIST:
            prefix = 'shuup_admin:subscription.' + key
            url = derive_model_url(model, prefix, object, kind)
            if url:
                return url
        return None
