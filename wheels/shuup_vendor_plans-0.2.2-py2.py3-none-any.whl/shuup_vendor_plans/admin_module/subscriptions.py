# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.admin.utils.permissions import has_permission

from shuup_vendor_plans.utils import get_subscriptions_for_supplier


class VendorSubscriptionsForm(forms.Form):
    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        self.instance = kwargs.pop("instance")
        super().__init__(*args, **kwargs)
        self.subscriptions = get_subscriptions_for_supplier(self.instance)
        self.can_see_subs_details = has_permission(self.request.user, "subscription.sub.edit")
        self.can_cancel_subs = has_permission(self.request.user, "shuup_vendor_plans.cancel_subscription")


class VendorSubscriptionsFormPart(FormPart):
    priority = 10

    def get_form_defs(self):
        if not has_permission(self.request.user, "shuup_vendor_plans.vendor-subscriptions"):
            return []
        if not self.object.pk or not get_subscriptions_for_supplier(self.object).exists():
            return []

        yield TemplatedFormDef(
            "vendor_subscriptions",
            VendorSubscriptionsForm,
            template_name="shuup_vendor_plans/admin/vendor_subscriptions.jinja",
            required=False,
            kwargs={
                "instance": self.object,
                "request": self.request
            }
        )
