# -*- coding: utf-8 -*-
# This file is part of Shuup Vendor Plans Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
PLAN_CATEGORY_DATA = {
    "name": "Plans",
    "slug": "plans",
    "identifier": "plans",
    "visible_in_menu": False,
}


PLANS = {
    "usd": [
        {"name": "us_simple", "description": "$29 per month.", "amount_value": 29, "is_active": True},
        {"name": "us_essential", "description": "$49 per month", "amount_value": 49, "is_active": True},
        {"name": "us_plus", "description": "$99 per month", "amount_value": 99, "is_active": True},
    ],
    "aud": [
        {"name": "aud_simple", "description": "$29 per month.", "amount_value": 29, "is_active": True},
        {"name": "aud_essential", "description": "$49 per month", "amount_value": 49, "is_active": True},
        {"name": "aud_plus", "description": "$99 per month", "amount_value": 99, "is_active": True},
    ],
    "eur": [
        {"name": "eu_simple", "description": "29€ kuukaudessa.", "amount_value": 29, "is_active": True},
        {"name": "eu_essential", "description": "49€ kuukaudessa", "amount_value": 49, "is_active": True},
        {"name": "eu_plus", "description": "99€ kuukaudessa", "amount_value": 99, "is_active": True},
    ],
    "cad": [
        {"name": "ca_simple", "description": "$29 per month.", "amount_value": 29, "is_active": True},
        {"name": "ca_essential", "description": "$49 per month", "amount_value": 49, "is_active": True},
        {"name": "ca_plus", "description": "$99 per month", "amount_value": 99, "is_active": True},
    ]
}
