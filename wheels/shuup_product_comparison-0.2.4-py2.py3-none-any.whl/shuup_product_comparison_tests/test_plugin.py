# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json

import pytest
from django.core.urlresolvers import reverse
from django.test.client import Client
from django.utils.translation import activate

from shuup.core.models import Attribute, ProductAttribute
from shuup.front.apps.carousel.plugins import CarouselPlugin
from shuup.testing import factories
from shuup.themes.classic_gray.theme import ClassicGrayTheme
from shuup.xtheme._theme import get_current_theme, set_current_theme
from shuup.xtheme.layout import Layout
from shuup.xtheme.models import SavedViewConfig, SavedViewConfigStatus
from shuup_product_comparison.plugins import (
    ComparisonAddPlugin, ShowComparisonPlugin
)

DEFAULT_USER_PWD = "ADMIN"


@pytest.mark.parametrize("show_text", [True, False])
@pytest.mark.django_db
def test_comparison_add_plugin(show_text):
    shop, products, client = _setup_comparison_test()
    set_current_theme(ClassicGrayTheme.identifier, shop)
    theme = get_current_theme(shop)
    assert theme.identifier == ClassicGrayTheme.identifier

    # injects the ComparisonAddPlugin
    layout = Layout(theme, "product_extra_1")
    layout.begin_row()
    layout.begin_column({"md": 12})
    layout.add_plugin(ComparisonAddPlugin.identifier, {"show_text": show_text})

    svc = SavedViewConfig(
        theme_identifier=theme.identifier,
        shop=shop,
        view_name="ProductDetailView",
        status=SavedViewConfigStatus.CURRENT_DRAFT
    )
    svc.set_layout_data(layout.placeholder_name, layout)
    svc.save()
    svc.publish()

    product = products[0]
    product_url = reverse("shuup:product", kwargs=dict(pk=product.id, slug=product.slug))
    response = client.get(product_url)
    assert response.status_code == 200
    content = response.content.decode("utf-8")

    assert ("Add to comparison" in content) is show_text
    assert 'data-product-id="%d"' % product.id in content


@pytest.mark.django_db
def test_show_comparison_plugin():
    shop, products, client = _setup_comparison_test()
    set_current_theme(ClassicGrayTheme.identifier, shop)
    theme = get_current_theme(shop)
    assert theme.identifier == ClassicGrayTheme.identifier

    # injects the ShowComparisonPlugin
    layout = Layout(theme, "category_menu_extras")
    layout.begin_row()
    layout.begin_column({"xs": 12})
    layout.add_plugin(ShowComparisonPlugin.identifier, {})

    svc = SavedViewConfig(
        theme_identifier=theme.identifier,
        shop=shop,
        view_name="CategoryView",
        status=SavedViewConfigStatus.CURRENT_DRAFT
    )
    svc.set_layout_data(layout.placeholder_name, layout)
    svc.save()
    svc.publish()

    product = products[0]
    category = product.get_shop_instance(shop).categories.first()
    category_url = reverse("shuup:category", kwargs=dict(pk=category.id, slug=product.slug))

    response = client.get(category_url)
    content = response.content.decode("utf-8")
    assert "Nothing to compare" in content

    _add_for_comparison(client, products[:4])
    response = client.get(category_url)
    assert response.status_code == 200
    content = response.content.decode("utf-8")

    assert "Compare products" in content
    for product in products[:4]:
        assert 'data-product-id="%d"' % product.id in content


def _add_for_comparison(client, products):
    for product in products:
        comparison_add_url = reverse("shuup:comparison_add", kwargs=dict(pk=product.pk))
        response = client.post(comparison_add_url)
        assert response.status_code == 200
        result = json.loads(response.content.decode("utf-8"))
        assert result["ok"]


def _setup_comparison_test():
    activate("en")
    shop = factories.get_default_shop()
    category = factories.get_default_category()

    user = factories.create_random_user("en")
    user.set_password(DEFAULT_USER_PWD)
    user.save()

    product_type = factories.get_default_product_type()
    products = []
    for x in range(5):
        product = factories.create_product(
            "product-%d" % x,
            shop=shop,
            supplier=factories.get_default_supplier(),
            default_price=x,
            name="Product %d" % x,
            type=product_type
        )
        shop_product = product.get_shop_instance(shop)
        shop_product.categories.add(category)
        products.append(product)

        attribute1 = Attribute.objects.get(identifier="awesome")
        attribute2 = Attribute.objects.get(identifier="bogomips")
        ProductAttribute.objects.create(attribute=attribute1, product=product, numeric_value=1)
        ProductAttribute.objects.create(attribute=attribute2, product=product, numeric_value=x)

    client = Client()
    client.login(username=user.username, password=DEFAULT_USER_PWD)

    return shop, products, client
