# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json

import pytest
from django.core.urlresolvers import reverse
from django.test.client import Client
from django.utils.translation import activate

from shuup.core.models import Attribute, AttributeType, AttributeVisibility
from shuup.front.apps.carousel.plugins import CarouselPlugin
from shuup.testing import factories
from shuup.themes.classic_gray.theme import ClassicGrayTheme
from shuup.xtheme._theme import get_current_theme, set_current_theme
from shuup.xtheme.layout import Layout
from shuup.xtheme.models import SavedViewConfig, SavedViewConfigStatus
from shuup_product_comparison.models import ComparableAttribute
from shuup_product_comparison.plugins import (
    ComparisonAddPlugin, ShowComparisonPlugin
)

DEFAULT_USER_PWD = "ADMIN"


@pytest.mark.django_db
def test_admin_attribute_form(admin_user):
    activate("en")
    shop = factories.get_default_shop()
    attributes = factories.get_default_attribute_set()

    admin_user.set_password(DEFAULT_USER_PWD)
    admin_user.save()

    client = Client()
    client.login(username=admin_user.username, password=DEFAULT_USER_PWD)

    attribute = attributes[0]
    attribute_url = reverse("shuup_admin:attribute.edit", kwargs=dict(pk=attribute.pk))
    response = client.get(attribute_url)
    assert response.status_code == 200
    content = response.content.decode("utf-8")
    assert 'name="comparable"' in content
    assert 'id="id_comparable"' in content
    assert not ComparableAttribute.objects.filter(attribute=attribute).exists()

    payload = {
        "name__en": attribute.name,
        "identifier": attribute.identifier,
        "searchable": True,
        "type": AttributeType.UNTRANSLATED_STRING.value,
        "visibility_mode": AttributeVisibility.SHOW_ON_PRODUCT_PAGE.value,
        "comparable": True
    }
    response = client.post(attribute_url, data=payload)
    assert response.status_code == 302
    assert ComparableAttribute.objects.filter(attribute=attribute).exists()

    payload["comparable"] = False
    response = client.post(attribute_url, data=payload)
    assert response.status_code == 302
    assert not ComparableAttribute.objects.filter(attribute=attribute).exists()
