const { getParcelBuildCommand, runBuildCommands } = require("shuup-static-build-tools");

runBuildCommands([
    getParcelBuildCommand({
        cacheDir: "shuup-product-comparison",
        outputDir: "static/shuup_product_comparison/js",
        outputFileName: "scripts",
        entryFile: "static_src/js/index.js"
    }),
    getParcelBuildCommand({
        cacheDir: "shuup-product-comparison",
        outputDir: "static/shuup_product_comparison/css",
        entryFile: "static_src/less/style.less"
    })
]);
