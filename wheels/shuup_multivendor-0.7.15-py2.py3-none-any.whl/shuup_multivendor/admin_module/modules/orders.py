# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import ORDERS_MENU_CATEGORY
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.urls import admin_url


class MultivendorOrdersAdminModule(AdminModule):
    name = _("Vendor Orders")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:shuup_multivendor.order_list")

    def get_urls(self):
        return [
            admin_url(
                r"^multivendor/orders/(?P<pk>\d+)/set-line-status/$",
                "shuup_multivendor.admin_module.views.set_order_line_status",
                name="shuup_multivendor.set_line_status",
            ),
            admin_url(
                r"^multivendor/orders/(?P<pk>\d+)/lines$",
                "shuup_multivendor.admin_module.views.OrderLineListView",
                name="shuup_multivendor.order_line_list",
            ),
            admin_url(
                r"^multivendor/orders/$",
                "shuup_multivendor.admin_module.views.OrderListView",
                name="shuup_multivendor.order_list",
            ),
            admin_url(
                "^multivendor/orders/(?P<pk>\d+)/create-shipment/(?P<supplier_pk>\d+)/$",
                "shuup_multivendor.admin_module.views.shipments.MultivendorOrderCreateShipmentView",
                name="shuup_multivendor.create-shipment"
            ),
            admin_url(
                "^multivendor/shipments/(?P<pk>\d+)/delete/$",
                "shuup_multivendor.admin_module.views.shipments.MultivendorShipmentDeleteView",
                name="shuup_multivendor.delete-shipment"
            ),
            admin_url(
                "^multivendor/orders/(?P<pk>\d+)/create-refund/$",
                "shuup_multivendor.admin_module.views.orders.MultivendorOrderCreateRefundView",
                name="shuup_multivendor.create-refund"
            )
        ]

    def get_menu_entries(self, request):
        if not get_supplier(request):
            return []

        return [
            MenuEntry(
                text=_("Orders"),
                icon="fa fa-inbox",
                url="shuup_admin:shuup_multivendor.order_list",
                category=ORDERS_MENU_CATEGORY,
                subcategory="orders"
            )
        ]
