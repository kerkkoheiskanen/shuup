# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.core.urlresolvers import reverse
from shuup.admin.modules.orders.views.shipment import (
    OrderCreateShipmentView, ShipmentDeleteView
)
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import Order, OrderLine, Shipment


class MultivendorOrderCreateShipmentView(OrderCreateShipmentView):
    def get_queryset(self):
        supplier_pk = self._get_supplier_id()
        supplier = get_supplier(self.request)
        if supplier_pk != supplier.pk:
            return Order.objects.none()

        order_pk = int(self.kwargs["pk"])
        if not OrderLine.objects.filter(supplier=supplier, order_id=order_pk).exists():
            return Order.objects.none()

        return Order.objects.all()

    def get_success_url(self):
        return reverse("shuup_admin:shuup_multivendor.order_line_list", kwargs={"pk": int(self.kwargs["pk"])})


class MultivendorShipmentDeleteView(ShipmentDeleteView):
    def get_queryset(self):
        return Shipment.objects.filter(supplier=get_supplier(self.request))

    def get_success_url(self):
        return reverse("shuup_admin:shuup_multivendor.order_line_list", kwargs={"pk": self.get_object().order.pk})
