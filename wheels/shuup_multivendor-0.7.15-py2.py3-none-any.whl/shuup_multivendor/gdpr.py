# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.core.urlresolvers import reverse
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ugettext
from shuup import configuration
from shuup.front.providers import FormFieldDefinition, FormFieldProvider
from shuup.simple_cms.models import Page

CONSENT_PAGE_KEY = "multivendor_gdpr_consent_page_ids"


def get_active_consent_pages(shop):
    return configuration.get(shop, CONSENT_PAGE_KEY, [])


def save_active_consent_pages(shop, pages):
    configuration.set(shop, CONSENT_PAGE_KEY, pages)


def get_possible_consent_pages(shop):
    return Page.objects.filter(shop=shop, deleted=False)


class GDPRRegistrationFieldProvider(FormFieldProvider):
    error_message = _("You must accept to this to register.")

    def get_fields(self, **kwargs):
        request = kwargs.get("request", None)
        if not request:
            return []

        fields = []
        for page_id in get_active_consent_pages(request.shop):
            page = Page.objects.filter(id=page_id).first()
            if not page:
                continue

            key = "mv_accept_{}".format(page.id)
            field = forms.BooleanField(
                label=mark_safe(ugettext(
                    "I have read and accept the <a href='{}' target='_blank' class='gdpr_consent_doc_check'>{}</a>"
                ).format(reverse("shuup:cms_page", kwargs=dict(url=page.url)), page.title)),
                required=True,
                error_messages=dict(required=self.error_message)
            )
            definition = FormFieldDefinition(name=key, field=field)
            fields.append(definition)
        return fields
