# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.db.models import Q
from django.db.transaction import atomic
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import (
    ContactGroup, PersonContact, ProductVisibility, ShopProduct
)
from shuup.utils.analog import LogEntryKind

from shuup_multivendor.models import SupplierUser
from shuup_multivendor.signals import (
    vendor_shop_product_approval_revoked, vendor_shop_product_approved
)

SHOP_PRODUCT_APPROVAL_REQUIRED_KEY = "shuup_multivendor_shop_product_approval_required"
SHOP_PRODUCT_APPROVED_IDENTIFIER = "shuup_multivendor_shop_product_approved"
SHOP_PRODUCT_APPROVAL_REVOKED_IDENTIFIER = "shuup_multivendor_shop_product_approval_revoked"
SHOP_PRODUCT_VENDOR_CONTACT_GROUP_IDENTIFIER = "shuup_multivendor_shop_product_approval_contact_group"


def get_vendors_shop_product_visibility_contact_group(shop, vendor):
    identifier = "%s-%s-%s" % (shop.pk, vendor.pk, SHOP_PRODUCT_VENDOR_CONTACT_GROUP_IDENTIFIER)
    return ContactGroup.objects.get_or_create(
        identifier=identifier,
        shop=shop,
        defaults=dict(
            name=_("{vendor_name} - Vendor Shop Product Visibility Group").format(vendor_name=vendor.name)
        )
    )[0]


def ensure_vendor_users_in_shop_product_visibility_group(shop, vendor):
    vendor_group = get_vendors_shop_product_visibility_contact_group(shop, vendor)
    vendor_group.members = PersonContact.objects.filter(
        user_id__in=vendor.vendor_users.values_list("user_id", flat=True))


@atomic
def set_approval_missing_visibility_limit(shop_product):
    for vendor in shop_product.suppliers.all():
        vendor_group = get_vendors_shop_product_visibility_contact_group(shop_product.shop, vendor)
        vendor_group.visible_products.add(shop_product)
    ShopProduct.objects.filter(pk=shop_product.pk).update(visibility_limit=ProductVisibility.VISIBLE_TO_GROUPS)


@atomic
def clear_approval_visibility_limits(shop_product):
    for vendor in shop_product.suppliers.all():
        vendor_approval_group = get_vendors_shop_product_visibility_contact_group(shop_product.shop, vendor)
        vendor_approval_group.visible_products.remove(shop_product)
    ShopProduct.objects.filter(pk=shop_product.pk).update(visibility_limit=ProductVisibility.VISIBLE_TO_ALL)


def is_shop_product_approved(shop_product):
    return shop_product.log_entries.filter(identifier=SHOP_PRODUCT_APPROVED_IDENTIFIER).exists()


@atomic
def revoke_shop_product_approval(shop_product, user=None):
    shop_product.log_entries.filter(identifier=SHOP_PRODUCT_APPROVED_IDENTIFIER).delete()
    shop_product.add_log_entry(
        message=_("Shop product approved revoked."),
        identifier=SHOP_PRODUCT_APPROVAL_REVOKED_IDENTIFIER,
        kind=LogEntryKind.AUDIT,
        user=user)
    set_approval_missing_visibility_limit(shop_product)
    vendor_shop_product_approval_revoked.send(sender=ShopProduct, shop_product=shop_product, user=user)


@atomic
def set_shop_product_approved(shop_product, user=None):
    shop_product.add_log_entry(
        message=_("Shop product approved for sale."),
        identifier=SHOP_PRODUCT_APPROVED_IDENTIFIER,
        kind=LogEntryKind.AUDIT,
        user=user)
    clear_approval_visibility_limits(shop_product)
    vendor_shop_product_approved.send(sender=ShopProduct, shop_product=shop_product, is_auto_approved=False, user=user)


@atomic
def set_shop_product_auto_approved(shop_product, user=None):
    extra = {
        "suppliers_on_approval": [shop_product.suppliers.values_list("id", flat=True)]
    }

    shop_product.add_log_entry(
        message=_("Shop product approved automatically since vendor is exempt from approval process."),
        identifier=SHOP_PRODUCT_APPROVED_IDENTIFIER,
        kind=LogEntryKind.AUDIT,
        user=user,
        extra=extra)
    clear_approval_visibility_limits(shop_product)
    vendor_shop_product_approved.send(sender=ShopProduct, shop_product=shop_product, is_auto_approved=True, user=user)


def filter_not_approved_shop_products_from_other_vendors(queryset, vendor):
    return queryset.filter(
        Q(
            Q(log_entries__identifier=SHOP_PRODUCT_APPROVED_IDENTIFIER) |
            Q(
                ~Q(log_entries__identifier=SHOP_PRODUCT_APPROVED_IDENTIFIER) &
                Q(suppliers=vendor)
            )
        )
    )


def filter_product_waiting_approval(queryset):
    return queryset.filter(
        ~Q(log_entries__identifier__in=[SHOP_PRODUCT_APPROVED_IDENTIFIER, SHOP_PRODUCT_APPROVAL_REVOKED_IDENTIFIER])
    )


def is_shop_product_approval_required_for_vendor(vendor):
    if not (vendor and vendor.options):
        return settings.SHUUP_MULTIVENDOR_PRODUCTS_REQUIRES_APPROVAL_DEFAULT

    return vendor.options.get(
        SHOP_PRODUCT_APPROVAL_REQUIRED_KEY,
        settings.SHUUP_MULTIVENDOR_PRODUCTS_REQUIRES_APPROVAL_DEFAULT
    )


def set_shop_product_approval_required_for_vendor(vendor, value):
    options = vendor.options or {}
    options.update({SHOP_PRODUCT_APPROVAL_REQUIRED_KEY: bool(value)})
    vendor.options = options
    vendor.save(update_fields=("options",))


def is_shop_product_approval_required_for_user(shop_product, user):
    if is_shop_product_approved(shop_product):
        return False

    for supplier_user in SupplierUser.objects.filter(user=user):
        if not is_shop_product_approval_required_for_vendor(supplier_user.supplier):
            return False
    return True
