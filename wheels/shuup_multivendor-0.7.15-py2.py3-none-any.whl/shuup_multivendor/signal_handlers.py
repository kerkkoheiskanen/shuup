# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

from django.conf import settings
from django.db.models.signals import post_save
from shuup.core.models import (
    Order, OrderLine, PersonContact, ShopProduct, Supplier
)

from shuup_multivendor.utils.geocode import ensure_address_geoposition

from .models import VendorFunds, VendorOrderLineRevenue
from .signals import vendor_shop_product_saved
from .utils.funds import (
    get_vendor_revenue_percentage, is_vendor_funds_enabled, is_withdrawal_line
)
from .utils.product import (
    is_shop_product_approval_required_for_user, is_shop_product_approved,
    set_approval_missing_visibility_limit, set_shop_product_auto_approved
)


def shop_product_post_save(shop_product, request, **kwargs):

    def auto_approve_for_staff(user, shop):
        if getattr(user, "is_superuser", False):
            return True
        return (shop and user.is_staff and shop.staff_members.filter(pk=user.pk).exists())

    if not is_shop_product_approved(shop_product):
        if auto_approve_for_staff(request.user, shop_product.shop):
            set_shop_product_auto_approved(shop_product, user=request.user)
        elif is_shop_product_approval_required_for_user(shop_product, request.user):
            set_approval_missing_visibility_limit(shop_product)
        else:
            set_shop_product_auto_approved(shop_product, user=request.user)


def vendor_post_save(sender, instance, raw, created, **kwargs):
    if instance.contact_address:
        ensure_address_geoposition(instance.contact_address)


def contact_post_save(sender, instance, raw, created, **kwargs):
    # TODO: move this to an async task queue
    address_field = "default_{}".format(settings.SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS)
    address = getattr(instance, address_field, None)
    if address:
        ensure_address_geoposition(address)


def on_order_line_post_save(sender, instance, created, **kwargs):
    supplier = (instance.parent_line.supplier if instance.parent_line else instance.supplier)
    if not supplier:
        return

    if is_withdrawal_line(instance):
        return

    if is_vendor_funds_enabled(instance.shop):
        vendor_revenue_percentage = Decimal(get_vendor_revenue_percentage(instance.supplier, instance.order.shop))
    else:
        vendor_revenue_percentage = Decimal("0")

    revenue, created = VendorOrderLineRevenue.objects.get_or_create(
        order_line=instance, defaults={"percentage": vendor_revenue_percentage})
    revenue.revenue_value = instance.taxless_price.amount.value * (revenue.percentage / 100)
    revenue.save()


def on_order_post_save(sender, instance, created, **kwargs):
    if is_vendor_funds_enabled(instance.shop):
        shop_id = instance.shop.pk
        currency = instance.shop.currency
        supplier_ids = set(instance.lines.values_list("supplier_id", flat=True))
        for supplier_id in supplier_ids:
            if not supplier_id:
                continue
            VendorFunds.calculate_funds(shop_id, supplier_id, currency)


vendor_shop_product_saved.connect(
    shop_product_post_save, sender=ShopProduct, dispatch_uid="multivendor_shop_product_post_save")
post_save.connect(vendor_post_save, sender=Supplier, dispatch_uid="multivendor_vendor_post_save")
post_save.connect(contact_post_save, sender=PersonContact, dispatch_uid="multivendor_contact_post_save")
post_save.connect(on_order_post_save, sender=Order, dispatch_uid="multivendor_funds_on_order_post_save")
post_save.connect(on_order_line_post_save, sender=OrderLine, dispatch_uid="multivendor_funds_on_order_line_post_save")
