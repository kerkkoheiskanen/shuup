# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from __future__ import unicode_literals

import json
import re
import time

import pytest
import stripe

from shuup_stripe_subscriptions.models import (
    StripeSubscriptionPaymentProcessor)
from shuup_stripe_subscriptions.webhook_views import webhook_view

from . import events


@pytest.mark.django_db
def test_test_event(rf):
    result = call_view_with_event(rf, events.TEST_EVENT)
    check_result(result, 200, message="Test event received successfully")


@pytest.mark.django_db
def test_invoice_payment_succeeded(rf):
    result = call_view_with_event(rf, events.INVOICE_PAYMENT_SUCCEEDED)
    check_result(result, 200, message="Unknown subscription")


def call_view_with_event(rf, event):
    processor = StripeSubscriptionPaymentProcessor.objects.create(
        secret_key='x', publishable_key='x', webhook_signing_key='zz')

    request = rf.post('/', data=json.dumps(event),
                      content_type='application/json')
    add_stripe_signature(request, 'zz')
    return webhook_view(request, processor.webhook_slug)


@pytest.mark.django_db
def test_error_checking(rf):
    processor = StripeSubscriptionPaymentProcessor.objects.create(
        secret_key='x', publishable_key='x', webhook_signing_key='zz')

    result = webhook_view(rf.get('/'), 'nonexisting_slug')
    check_result(result, 404, error="No such payment processor")

    def check_error(request, status_code, error):
        result = webhook_view(request, processor.webhook_slug)
        check_result(result, status_code, error=error)

    request = rf.post('/', data=b'Invalid UTF-8 \xe4',
                      content_type='application/json')
    check_error(request, 400, "Invalid encoding, expecting UTF-8")

    request = rf.get('/')
    check_error(request, 400, "Stripe signature header is missing")

    request.META['HTTP_STRIPE_SIGNATURE'] = 'duh'
    check_error(request, 400, "Invalid signature")

    add_stripe_signature(request, 'zz')
    check_error(request, 400, "Invalid JSON data")

    request = rf.post('/', data=json.dumps('hello'),
                      content_type='application/json')
    add_stripe_signature(request, 'zz')
    check_error(request, 400, "Expecting a dict")

    request = rf.post('/', data=json.dumps({'hello': 'world'}),
                      content_type='application/json')
    add_stripe_signature(request, 'zz')
    check_error(request, 400, "No \"id\" in JSON data")


def add_stripe_signature(request, secret):
    timestamp = time.time()
    payload = request.body.decode('utf-8')
    signed_payload = '{:.0f}.{}'.format(timestamp, payload)
    sig = stripe.WebhookSignature._compute_signature(signed_payload, secret)
    request.META['HTTP_STRIPE_SIGNATURE'] = 't={:.0f},v1={}'.format(timestamp, sig)


def check_result(result, status_code, message=None, error=None):
    content = json.loads(result.content.decode('utf-8'))
    if message:
        assert re.match(message + '$', content['message'])
        assert 'error' not in content
    if error:
        assert re.match(error + '$', content['error'])
        assert 'message' not in content
    assert result.status_code == status_code
