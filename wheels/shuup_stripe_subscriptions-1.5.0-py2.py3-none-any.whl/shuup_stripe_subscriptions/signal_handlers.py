# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import stripe
from shuup import configuration
from shuup_stripe_subscriptions.enums import InvoiceStatus
from shuup_stripe_subscriptions.models import (
    StripeSubscription, StripeSubscriptionPaymentProcessor
)
from shuup_subscriptions.enums import SubscriptionCancellationMethod


def handle_subscription_cancel(sender, subscription, user, **kwargs):
    stripe_subscription = StripeSubscription.objects.filter(subscription=subscription).first()
    if not stripe_subscription:
        # Nothing todo here I guess the subscriptions was not paid with Stripe
        return

    processor = StripeSubscriptionPaymentProcessor.objects.first()
    # cancel subscription
    stripe.api_key = processor.secret_key

    cancel_method = configuration.get(None, "cancel_method", SubscriptionCancellationMethod.IMMEDIATELY.value)
    if cancel_method == SubscriptionCancellationMethod.IMMEDIATELY.value:
        stripe.Subscription.delete(stripe_subscription.external_id)
        stripe_subscription.delete()
    else:
        stripe.Subscription.modify(
            stripe_subscription.external_id,
            cancel_at_period_end=True
        )

    # mark all current invoices void
    for pending_invoice in subscription.invoices.filter(status=InvoiceStatus.PENDING):
        pending_invoice.status = InvoiceStatus.CANCELLED
        pending_invoice.save()
