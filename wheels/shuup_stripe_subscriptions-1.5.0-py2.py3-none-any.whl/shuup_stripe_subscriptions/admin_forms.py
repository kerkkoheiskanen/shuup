# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from django.utils.translation import ugettext_lazy as _

from shuup.admin.forms import ShuupAdminForm
from shuup.admin.modules.service_providers.wizard_form_defs import (
    ServiceWizardFormDef
)
from shuup.admin.modules.service_providers.wizard_forms import (
    ServiceWizardForm
)

from .models import StripeSubscriptionPaymentProcessor
from .utils import get_webhook_url_format
from .widgets import SlugWithUrlWidget


class StripeSubscriptionAdminForm(ShuupAdminForm):
    class Meta:
        model = StripeSubscriptionPaymentProcessor
        fields = '__all__'
        widgets = {
            'webhook_slug': SlugWithUrlWidget(
                url_label=_("Webhook URL"),
                url_format=get_webhook_url_format),
        }


class StripeSubscriptionWizardForm(ServiceWizardForm):
    class Meta:
        model = StripeSubscriptionPaymentProcessor
        fields = (
            'name', 'service_name',
            'secret_key', 'publishable_key',
            'webhook_signing_key', 'webhook_slug',
        )

    def __init__(self, **kwargs):
        super(StripeSubscriptionWizardForm, self).__init__(**kwargs)
        if not self.provider:
            return
        service = self.get_payment_method()
        if not service:
            return
        self.fields["service_name"].initial = service.name
        self.fields["secret_key"].initial = self.provider.secret_key
        self.fields["publishable_key"].initial = self.provider.publishable_key
        self.fields["webhook_signing_key"].initial = self.provider.webhook_signing_key
        self.fields["webhook_slug"].initial = self.provider.webhook_slug


class StripeSubscriptionWizardFormDef(ServiceWizardFormDef):
    def __init__(self):
        super(StripeSubscriptionWizardFormDef, self).__init__(
            name="stripe_subscriptions",
            form_class=StripeSubscriptionWizardForm,
            template_name="shuup_stripe_subscriptions/wizard_form.jinja"
        )
