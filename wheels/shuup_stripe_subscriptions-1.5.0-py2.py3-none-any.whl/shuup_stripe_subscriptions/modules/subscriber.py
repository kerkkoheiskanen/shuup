# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

import stripe
from django.conf import settings
from shuup.core.models import ProductMode
from shuup_subscriptions.enums import PlanInterval

from ..models import StripeCustomerSubscription, StripePlan, StripeSubscription


class StripeSubscriber(object):

    def __init__(self, secret_key, order):
        self.secret_key = secret_key
        self.order = order
        stripe.api_key = self.secret_key
        self.stripe_token = self.order.payment_data["stripe"].get("token")
        self.stripe_customer = self.order.payment_data["stripe"].get("customer")
        self.card_email = self.order.payment_data["stripe"].get("email")

        # stripe_account is used for connected accounts
        self.stripe_account = self.order.payment_data["stripe"].get("stripe_account")

    def get_or_create_plan(self, subscription, product):
        plan_data = {
            "id": subscription.plan.unique_key,
            "amount": int(subscription.plan.amount_value * 100),
            "interval": subscription.plan.interval.value,
            "currency": subscription.plan.shop.currency.lower(),
            "product": {
                "id": product.id,
                "name": "%s - %s" % (product.name, subscription.plan.name),
            }
        }

        if subscription.plan.interval == PlanInterval.TWO_WEEKS:
            plan_data.update({
                "interval": PlanInterval.WEEK.value,
                "interval_count": 2
            })

        if self.stripe_account:
            plan_data["stripe_account"] = self.stripe_account

        internal_obj = StripePlan.objects.filter(plan=subscription.plan).first()
        if internal_obj:
            # TODO: update something?

            search_kwargs = dict()
            if self.stripe_account:
                search_kwargs["stripe_account"] = self.stripe_account

            stripe_plan = stripe.Plan.retrieve(internal_obj.external_id, **search_kwargs)
        else:
            stripe_plan = stripe.Plan.create(**plan_data)
            internal_obj = StripePlan.objects.create(
                plan=subscription.plan,
                external_id=stripe_plan["id"]
            )

        return (internal_obj, stripe_plan)

    def get_or_create_customer(self, order):
        """
        Get stripe customer either from StripeProfile or create new one

        :param stripe_token: got from stripe.js
        :type stripe_token: str
        :param card_email: customer email
        :type card_email: str
        :return: Stripe customer object
        """
        from ..models import StripeCustomer

        # for connected accounts, create a shared customer
        if self.stripe_customer and self.stripe_account:
            token = stripe.Token.create(
                customer=self.stripe_customer,
                stripe_account=self.stripe_account,
                api_key=self.secret_key
            )
            stripe_customer = stripe.Customer.create(
                source=token.id,
                stripe_account=self.stripe_account,
                api_key=self.secret_key
            )
            internal_obj = StripeCustomer.objects.get_or_create(
                customer=order.customer,
                external_id=stripe_customer.id
            )[0]
            return (internal_obj, stripe_customer)

        customer = order.customer
        if customer:
            internal_obj = StripeCustomer.objects.filter(customer=customer).first()
            if internal_obj:
                stripe_customer = stripe.Customer.retrieve(internal_obj.external_id)
                return (internal_obj, stripe_customer)

            if self.stripe_customer:
                internal_obj = StripeCustomer.objects.filter(external_id=self.stripe_customer).first()
                if internal_obj:
                    stripe_customer = stripe.Customer.retrieve(self.stripe_customer)
                    return (internal_obj, stripe_customer)

            customer_email = customer.email
            description = "Shuup Customer %d" % customer.pk
        else:
            customer_email = order.email
            description = "Anonymous customer"

        if self.stripe_customer:
            stripe_customer = stripe.Customer.retrieve(self.stripe_customer)
            internal_obj = StripeCustomer.objects.create(
                customer=(customer or None),
                external_id=self.stripe_customer,
            )
            return (internal_obj, stripe_customer)

        stripe_customer = stripe.Customer.create(
            email=customer_email,
            description=description,
            source=self.stripe_token
        )

        internal_obj = StripeCustomer.objects.create(
            customer=(customer or None),
            external_id=stripe_customer['id'],
        )
        return (internal_obj, stripe_customer)

    def get_or_create_subscription(self, subscription, stripe_customer, stripe_plan):
        internal_obj = StripeSubscription.objects.filter(subscription=subscription).first()
        if internal_obj:
            stripe_subscription = stripe.Subscription.retrieve(internal_obj.external_id, self.secret_key)
        else:
            payload = {
                "customer": stripe_customer["id"],
                "items": [{
                    "plan": stripe_plan["id"]
                }]
            }
            if subscription.plan.trial_period:
                end_date = subscription.plan.get_free_trial_end_date(subscription)
                if end_date:
                    payload["trial_end"] = int(end_date.timestamp())

            if self.stripe_account:
                payload["stripe_account"] = self.stripe_account

            stripe_subscription = stripe.Subscription.create(**payload)
            internal_obj = StripeSubscription.objects.create(
                subscription=subscription, external_id=stripe_subscription["id"])
        return (internal_obj, stripe_subscription)

    def handle_order(self):
        internal_customer, stripe_customer = self.get_or_create_customer(self.order)

        # create plan to stripe
        for product_line in self.order.lines.products().filter(product__mode=ProductMode.SUBSCRIPTION):
            subscription = product_line.subscription
            internal_plan, stripe_plan = self.get_or_create_plan(subscription, product_line.product)
            internal_sub, stripe_sub = self.get_or_create_subscription(subscription, stripe_customer, stripe_plan)

            StripeCustomerSubscription.objects.create(
                stripe_subscription=internal_sub,
                stripe_customer=internal_customer
            )
