# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import django.db.models.deletion
import enumfields.fields
import jsonfield.fields
from django.db import migrations, models

from ..enums import EventHandlerResultCode
from ..fields import TimestampDateTimeField


class Migration(migrations.Migration):

    dependencies = [
        ('shuup_stripe_subscriptions', '0003_webhook_fields'),
    ]

    operations = [
        migrations.CreateModel(
            name='WebhookEventLogEntry',
            fields=[
                ('id', models.AutoField(
                    primary_key=True, serialize=False, auto_created=True)),
                ('received_on', TimestampDateTimeField(db_index=True)),
                ('request_path', models.CharField(max_length=200, blank=True)),
                ('meta', jsonfield.fields.JSONField(null=True, blank=True)),
                ('body', models.BinaryField(null=True, blank=True)),
                ('processor', models.ForeignKey(
                    null=True, blank=True,
                    to=('shuup_stripe_subscriptions'
                        '.StripeSubscriptionPaymentProcessor'),
                    on_delete=django.db.models.deletion.SET_NULL)),
                ('event', jsonfield.fields.JSONField(null=True, blank=True)),
                ('result_code',
                 enumfields.fields.EnumField(
                     enum=EventHandlerResultCode,
                     blank=True, null=True, max_length=10)),
                ('result_message', models.CharField(
                    blank=True, max_length=1000)),
            ],
            options={
                'ordering': ('received_on',),
            },
        ),
    ]
