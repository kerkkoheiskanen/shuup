# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

#: The accounting identifier for order lines that will be considered as points spent
#: Without this identifier, the spent points won't be calculated
REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER = "reward_points_spent"


#: Indicates whether the rewards system is enabled by default for all vendors
REWARD_VENDORS_DEFAULT_ENABLED = True
