# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db import transaction
from django.db.models.signals import post_save
from django.dispatch import receiver

from shuup.core.models import Order
from shuup.core.signals import payment_created, refund_created
from shuup_rewards_multivendor.models import RewardCount
from shuup_rewards_multivendor.utils import adjust_order


def adjust_points_for_order(order):
    with transaction.atomic():
        adjust_order(order)
        RewardCount.recalculate(order.shop_id, order.customer_id)


@receiver(payment_created, dispatch_uid="shuup_rewards_multivendor_on_payment_created")
def on_payment_created(order, payment, **kwargs):
    adjust_points_for_order(order)


@receiver(refund_created, dispatch_uid="shuup_rewards_multivendor_on_refund_created")
def on_refund_created(order, refund_lines, **kwargs):
    adjust_points_for_order(order)


@receiver(post_save, sender=Order, dispatch_uid="shuup_rewards_multivendor_on_order_post_save")
def on_order_post_save(sender, instance, *args, **kwargs):
    adjust_points_for_order(instance)
