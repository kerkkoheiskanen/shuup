# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db.models import Q
from django.utils.translation import ugettext_lazy as _

from shuup.core.models import PersonContact
from shuup.front.utils.dashboard import DashboardItem
from shuup_rewards_multivendor.models import RewardCount


class CustomerRewardsDashboardItem(DashboardItem):
    template_name = "shuup_rewards_multivendor/customer_rewards_dashboard_item.jinja"
    title = _("Rewards")
    icon = "fa fa-trophy"
    _url = "shuup:multivendor_rewards.customer_dashboard"

    def get_context(self):
        context = super(CustomerRewardsDashboardItem, self).get_context()
        context["rewards"] = RewardCount.objects.filter(
            Q(customer=self.request.customer, shop=self.request.shop),
            Q(Q(net_count__gt=0) | Q(gross_count__gt=0))
        ).distinct()
        return context

    def show_on_menu(self):
        return isinstance(self.request.customer, PersonContact)

    def show_on_dashboard(self):
        return isinstance(self.request.customer, PersonContact)
