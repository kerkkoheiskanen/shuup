# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db.models import Q
from django.views.generic import TemplateView

from shuup.front.views.dashboard import DashboardViewMixin
from shuup_rewards_multivendor.models import RewardCount


class CustomerRewardsDashboardView(DashboardViewMixin, TemplateView):
    template_name = "shuup_rewards_multivendor/customer_rewards_dashboard.jinja"

    def get_context_data(self, **kwargs):
        context = super(CustomerRewardsDashboardView, self).get_context_data(**kwargs)
        context["rewards"] = RewardCount.objects.filter(
            Q(customer=self.request.customer, shop=self.request.shop),
            Q(Q(net_count__gt=0) | Q(gross_count__gt=0))
        ).distinct()
        return context
