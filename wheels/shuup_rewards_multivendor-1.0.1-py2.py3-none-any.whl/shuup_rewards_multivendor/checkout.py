# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from collections import defaultdict
from decimal import Decimal

from django import forms
from django.conf import settings
from django.http.response import HttpResponseRedirect
from django.utils.lru_cache import lru_cache
from django.utils.translation import ugettext_lazy as _
from django.views.generic.edit import FormView

from shuup.core.models import PersonContact
from shuup.front.checkout import CheckoutPhaseViewMixin
from shuup.utils.form_group import FormGroup
from shuup_rewards_multivendor import utils


class RewardsLinePointsForm(forms.Form):
    line_id = forms.CharField(widget=forms.HiddenInput())
    points = forms.IntegerField(
        min_value=0,
        label=_("Amount of points to use"),
        required=False
    )


class RewardsPointsForm(forms.Form):
    apply_points = forms.BooleanField(required=False, widget=forms.HiddenInput())


class RewardsPointsPhase(CheckoutPhaseViewMixin, FormView):
    identifier = "rewards_points"
    title = _("Rewards Points")
    template_name = "shuup_rewards_multivendor/checkout_rewards_points.jinja"

    def get_form(self, form_class=None):
        form_group = FormGroup(**self.get_form_kwargs())
        form_group.add_form_def("base", form_class=RewardsPointsForm)

        for line, spend_point_attrs in self.get_spend_point_lines(self.request).items():
            form_group.add_form_def(
                "reward_line_{}".format(line.line_id),
                form_class=RewardsLinePointsForm,
                required=False,
                kwargs=dict(
                    initial={
                        "line": line,
                        "line_id": line.line_id,
                        "points": spend_point_attrs["points"],
                        "net_points": spend_point_attrs["supplier_points"],
                        "unit_required_points": spend_point_attrs["unit_required_points"],
                        "required_points": spend_point_attrs["required_points"],
                        "discount_amount": spend_point_attrs["discount_amount"],
                    }
                )
            )

        return form_group

    def is_valid(self):
        if not (bool(self.basket.customer) and isinstance(self.basket.customer, PersonContact)):
            return True

        points_used_by_supplier = defaultdict(Decimal)

        for line in self.basket.get_final_lines():
            if line.supplier and line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
                points_used_by_supplier[line.supplier] += line.quantity

        for supplier, points in points_used_by_supplier.items():
            net_points, gross_points = utils.get_current_points(self.basket.shop, self.basket.customer, supplier)

            if points > net_points:
                return False

        return True

    def process(self):
        pass

    def should_skip(self):
        if not (bool(self.basket.customer) and isinstance(self.basket.customer, PersonContact)):
            return True
        return not bool(self.get_spend_point_lines(self.request))

    def is_visible_for_user(self):
        return not self.should_skip()

    def form_valid(self, form):
        base_form = form.forms["base"]

        if base_form.cleaned_data["apply_points"]:
            # remove all points spending lines
            remove_lines_ids = []
            for line in self.basket.get_final_lines():
                if line.supplier and line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
                    remove_lines_ids.append(line.line_id)
            for line_id in remove_lines_ids:
                self.basket.delete_line(line_id)

            spend_points_data = {}
            for form_name, points_form in form.forms.items():
                if not form_name.startswith("reward_line_"):
                    continue
                elif not points_form.has_changed():
                    points = int(Decimal(points_form.initial["points"]))
                    spend_points_data[points_form.initial["line_id"]] = points
                else:
                    points = int(Decimal(points_form.cleaned_data["points"] or 0))
                    spend_points_data[points_form.cleaned_data["line_id"]] = points

            for line_id, points in spend_points_data.items():
                if points > 0:
                    parent_line = self.basket.get_basket_line(line_id)
                    self.basket.add_line(**utils.get_spend_points_source_line_attrs(
                        self.basket,
                        parent_line.supplier,
                        parent_line,
                        points
                    ))

            # return the the same phase
            return HttpResponseRedirect(self.checkout_process.get_phase_url(self))

        return super(RewardsPointsPhase, self).form_valid(form)

    @lru_cache()
    def get_spend_point_lines(self, request):
        spend_point_lines = dict()

        for line in self.basket.get_final_lines():
            if not line.supplier:
                continue
            elif line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
                continue

            net_points, gross_points = utils.get_current_points(self.basket.shop, self.basket.customer, line.supplier)

            if net_points > Decimal():
                shop = self.basket.shop
                unit_required_points = utils.round_purchase_points(
                    utils.get_line_purchase_required_points(shop, line, True)
                )
                required_points = utils.round_purchase_points(
                    utils.get_line_purchase_required_points(shop, line)
                )
                points_used = 0
                discount_amount = None

                # check whether there is already spend lines attached to this parent
                children_lines = self.basket.find_lines_by_parent_line_id(line.line_id)
                for child_line_data in children_lines:
                    child_line = self.basket.get_basket_line(child_line_data["line_id"])
                    if child_line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
                        points_used = utils.round_purchase_points(child_line.quantity)
                        discount_amount = child_line.discount_amount
                        break

                spend_point_lines[line] = {
                    "price_per_point": 0,
                    "supplier_points": net_points,
                    "points": points_used,
                    "discount_amount": discount_amount,
                    "unit_required_points": unit_required_points,
                    "required_points": required_points
                }

        return spend_point_lines
