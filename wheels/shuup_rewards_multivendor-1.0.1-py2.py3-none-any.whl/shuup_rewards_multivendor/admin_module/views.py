# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.contrib import messages
from django.core.urlresolvers import reverse_lazy
from django.db.models import F
from django.http.response import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic import DetailView, FormView

from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.toolbar import Toolbar, URLActionButton
from shuup.admin.utils.picotable import Column
from shuup.admin.utils.views import PicotableListView
from shuup.core.models import PersonContact
from shuup_rewards_multivendor.admin_module.forms import GrantUserPointsForm
from shuup_rewards_multivendor.models import RewardAdjustment, RewardCount
from shuup_rewards_multivendor.utils import get_current_points


class UsersPointsListView(PicotableListView):
    model = PersonContact
    default_columns = [
        Column("name", _("Customer"), sort_field="name"),
        Column("net_count", _("Net points"), display="format_net_count"),
        Column("gross_count", _("Gross points"), display="format_gross_count"),
    ]

    def get_queryset(self):
        return self.model.objects.filter(
            multivendor_reward_count__supplier=get_supplier(self.request),
            multivendor_reward_count__shop=get_shop(self.request),
        ).annotate(
            net_count=F("multivendor_reward_count__net_count"),
            gross_count=F("multivendor_reward_count__gross_count"),
        ).order_by("multivendor_reward_count__customer__first_name")

    def format_net_count(self, instance):
        return instance.net_count

    def format_gross_count(self, instance):
        return instance.gross_count

    def get_object_url(self, instance):
        return reverse_lazy("shuup_admin:multivendor_rewards.user_points.detail", kwargs=dict(pk=instance.pk))


class UserPointsDetailView(DetailView):
    model = PersonContact
    context_object_name = "contact"
    template_name = "shuup_rewards_multivendor/user_points_detail.jinja"

    def get_queryset(self):
        return self.model.objects.filter(
            multivendor_reward_count__supplier=get_supplier(self.request),
            multivendor_reward_count__shop=get_shop(self.request),
        )

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data["toolbar"] = self.get_toolbar()
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        net_points, gross_points = get_current_points(shop, self.object, supplier)
        context_data["net_points"] = net_points
        context_data["gross_points"] = gross_points
        context_data["points_transactions"] = RewardAdjustment.objects.filter(
            shop=shop,
            supplier=supplier,
            customer=self.object
        ).order_by("-created_on")
        return context_data

    def get_toolbar(self):
        toolbar = Toolbar.for_view(self)

        if self.object.pk:
            url = "{}?contact={}".format(reverse_lazy("shuup_admin:multivendor_rewards.grant_points"), self.object.pk)
            toolbar.append(
                URLActionButton(
                    url=url,
                    text=_("Grant user points"),
                    extra_css_class="btn-info",
                    icon="fa fa-trophy",
                    required_permissions=("multivendor_rewards.grant_points",)
                )
            )

        return toolbar


class GrantUserPointsView(FormView):
    form_class = GrantUserPointsForm
    template_name = "shuup_rewards_multivendor/user_points_grant.jinja"

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs

    def form_valid(self, form):
        contact = form.cleaned_data["contact"]
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        points = form.cleaned_data["points"]
        RewardCount.grant_points(shop, contact, supplier, points)
        messages.success(self.request, _("Points granted to the customer!"))
        return HttpResponseRedirect(
            reverse_lazy("shuup_admin:multivendor_rewards.user_points.detail", kwargs=dict(pk=contact.pk))
        )
