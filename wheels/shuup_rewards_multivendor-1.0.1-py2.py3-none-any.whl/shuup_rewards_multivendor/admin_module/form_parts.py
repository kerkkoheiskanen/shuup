# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import ShopProduct
from shuup_rewards_multivendor import utils
from shuup_rewards_multivendor.admin_module.forms import (
    ProductRewardsForm, ShopRewardsConfigurationForm,
    VendorRewardsConfigurationForm
)
from shuup_rewards_multivendor.utils import configuration as rewards_config


class VendorRewardsConfigurationFormPart(FormPart):
    priority = 10
    name = "multivendor_rewards"
    form = VendorRewardsConfigurationForm

    def get_form_defs(self):
        if self.object.pk:
            shop = get_shop(self.request)

            # round the value according to the currency
            vendor_spend_points_price_per_point = utils.round_transaction_points(
                rewards_config.get_vendor_price_per_point_on_spend(shop, self.object)
            )
            vendor_earn_points_price_per_point = utils.round_transaction_points(
                rewards_config.get_vendor_price_per_point_on_earn(shop, self.object)
            )
            initial = dict(
                rewards_enabled=rewards_config.is_vendor_rewards_enabled(shop, self.object),
                vendor_earn_points_price_per_point=vendor_earn_points_price_per_point,
                vendor_spend_points_price_per_point=vendor_spend_points_price_per_point,
                vendor_earn_total_percentage=rewards_config.get_vendor_earn_total_percentage(shop, self.object),
            )
        else:
            initial = dict()

        yield TemplatedFormDef(
            name=self.name,
            form_class=self.form,
            template_name="shuup_rewards_multivendor/vendor_rewards_configuration.jinja",
            required=False,
            kwargs=dict(
                initial=initial,
                request=self.request
            )
        )

    def form_valid(self, form):
        data = form.cleaned_data.get(self.name)
        if data and self.object.pk:
            shop = get_shop(self.request)

            rewards_config.set_vendor_rewards_enabled(
                shop,
                self.object,
                data.get("rewards_enabled")
            )
            rewards_config.set_vendor_price_per_point_on_spend(
                shop,
                self.object,
                utils.round_transaction_points(data.get("vendor_spend_points_price_per_point"))
            )
            rewards_config.set_vendor_price_per_point_on_earn(
                shop,
                self.object,
                utils.round_transaction_points(data.get("vendor_earn_points_price_per_point"))
            )
            rewards_config.set_vendor_earn_total_percentage(
                shop,
                self.object,
                data.get("vendor_earn_total_percentage")
            )


class ProductRewardsFormPart(FormPart):
    priority = 20
    name = "multivendor_rewards_product"

    def get_form_defs(self):
        initial = {}
        product = self.object.product if isinstance(self.object, ShopProduct) else self.object

        if self.object.pk:
            supplier = get_supplier(self.request)
            initial = {
                "rewards_disabled": rewards_config.is_product_rewards_disabled(supplier, product),
                "purchase_required_points": utils.round_purchase_points(
                    rewards_config.get_product_required_points(supplier, product)
                )
            }

        yield TemplatedFormDef(
            name=self.name,
            form_class=ProductRewardsForm,
            template_name="shuup_rewards_multivendor/product_rewards_configuration.jinja",
            required=False,
            kwargs={"initial": initial}
        )

    def form_valid(self, form):
        if self.name in form.forms and form[self.name].has_changed():
            product = self.object.product if isinstance(self.object, ShopProduct) else self.object
            supplier = get_supplier(self.request)

            rewards_disabled = form[self.name].cleaned_data.get("rewards_disabled", False)
            purchase_required_points = utils.round_purchase_points(
                form[self.name].cleaned_data.get("purchase_required_points", 0)
            )

            rewards_config.set_product_rewards_disabled(supplier, product, rewards_disabled)
            rewards_config.set_product_purchase_required_points(supplier, product, purchase_required_points)


class ShopRewardsConfigurationFormPart(FormPart):
    priority = 10
    name = "shop_rewards"
    form = ShopRewardsConfigurationForm

    def get_form_defs(self):
        if self.object.pk:
            # round the value according to the currency
            spend_points_price_per_point = utils.round_transaction_points(
                rewards_config.get_shop_price_per_point_on_spend(self.object)
            )
            earn_points_price_per_point = utils.round_transaction_points(
                rewards_config.get_shop_price_per_point_on_earn(self.object)
            )
            initial = dict(
                rewards_enabled=rewards_config.is_shop_rewards_enabled(self.object),
                earn_points_price_per_point=earn_points_price_per_point,
                spend_points_price_per_point=spend_points_price_per_point,
                earn_total_percentage=rewards_config.get_shop_earn_total_percentage(self.object),
            )
        else:
            initial = dict()

        yield TemplatedFormDef(
            name=self.name,
            form_class=self.form,
            template_name="shuup_rewards_multivendor/shop_rewards_configuration.jinja",
            required=False,
            kwargs=dict(
                initial=initial,
                request=self.request
            )
        )

    def form_valid(self, form):
        data = form.cleaned_data.get(self.name)
        if data and self.object.pk:
            rewards_config.set_shop_rewards_enabled(self.object, data.get("rewards_enabled"))
            rewards_config.set_shop_price_per_point_on_spend(
                self.object,
                utils.round_transaction_points(data.get("spend_points_price_per_point"))
            )
            rewards_config.set_shop_price_per_point_on_earn(
                self.object,
                utils.round_transaction_points(data.get("earn_points_price_per_point"))
            )
            rewards_config.set_shop_earn_total_percentage(
                self.object,
                data.get("earn_total_percentage")
            )
