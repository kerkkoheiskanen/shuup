# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal, ROUND_CEILING
from uuid import uuid4

from django.conf import settings
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ugettext

from shuup.core.models import (
    CompanyContact, Order, OrderLine, OrderLineType, Supplier
)
from shuup_rewards_multivendor.utils import configuration as rewards_config

PURCHASE_POINTS_PRECISION = Decimal("1")
TRANSACTION_POINT_PRECISION = Decimal("0.000001")


def round_purchase_points(value):
    """
    Round points using ceiling, it means when user requires 10.1 points,
    it will actually require 11 full points
    """
    return Decimal(value).quantize(PURCHASE_POINTS_PRECISION, rounding=ROUND_CEILING)


def round_transaction_points(value):
    """
    Round points for transactions display
    """
    return Decimal(value).quantize(TRANSACTION_POINT_PRECISION)


def format_transaction_points(value):
    """
    Round and format points for transactions display
    """
    return ("%f" % float(round_transaction_points(value))).rstrip("0").rstrip(".")


def get_earn_points_order_line_total_amount(line):
    """
    Returns the total price amount that is considered when calculating points.
    By default, the taxless price
    """
    return line.taxless_price.value


def get_earn_points_unit_order_line_amount(line):
    """
    Returns the unit price amount that is considered when calculating points.
    By default, the taxless price
    """
    return line.taxless_base_unit_price.value


def get_purchase_order_line_amount(line):
    """
    Returns the total line price amount that is used to calculate
    how much points are required to purchase the line

    To make the line zero using a discount, the taxful price is needed
    """
    return line.price.value


def get_purchase_unit_order_line_amount(line):
    """
    Returns the unit price amount that is used to calculate
    how much points are required to purchase the line

    To make the line zero using a discount, the taxful price is needed
    """
    return line.base_unit_price.value


def _get_adjustment_amount_for_line(line, unit=False):
    # when the line is spent, return the full amount
    if line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
        return get_purchase_unit_order_line_amount(line) if unit else get_purchase_order_line_amount(line)

    percentage = rewards_config.get_vendor_earn_total_percentage(line.order.shop, line.supplier)
    if not percentage:
        return Decimal()

    # use precision of 4 decimals
    percentage = (Decimal(percentage) * Decimal(0.01)).quantize(Decimal("0.0001"))
    price = get_earn_points_unit_order_line_amount(line) if unit else get_earn_points_order_line_total_amount(line)
    return (price * percentage)


def get_adjustment_amount_for_order_line(order_line, unit=False):
    assert isinstance(order_line, OrderLine)
    return _get_adjustment_amount_for_line(order_line, unit)


def get_spent_amount_points_from_attached_lines(parent_line):
    """
    Returns the total discounts from spend points for the parent line

    It will loop over all spend points attached to the given `parent_line`
    and sum the amount of discount.

    The return will be negative if there is spend lines
    """
    assert isinstance(parent_line, OrderLine)
    spent_points_total_amount = Decimal()
    spend_points_lines = parent_line.child_lines.filter(
        supplier_id=parent_line.supplier_id,
        accounting_identifier=settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER
    )
    for spend_points_line in spend_points_lines:
        spent_points_total_amount += get_earn_points_order_line_total_amount(spend_points_line)
    return spent_points_total_amount


def get_points_from_order_line(order_line):
    """
    Returns the first adjustment delta if exists or the calculated number of points otherwise
    """
    assert isinstance(order_line, OrderLine)
    shop = order_line.order.shop

    if not rewards_config.is_vendor_rewards_enabled(shop, order_line.supplier):
        return Decimal()
    elif order_line.product and rewards_config.is_product_rewards_disabled(order_line.supplier, order_line.product):
        return Decimal()

    points = Decimal()

    first_adjustment = order_line.multivendor_reward_adjustments.first()
    if first_adjustment:
        points = first_adjustment.delta
    else:
        base_amount = get_adjustment_amount_for_order_line(order_line)

        if order_line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
            points = -order_line.quantity
        else:
            spent_points_total_amount = get_spent_amount_points_from_attached_lines(order_line)
            base_amount += spent_points_total_amount

            points = currency_to_earn_points(shop, order_line.supplier, base_amount)

    return points


def _adjust_order_line_for_spent_points(order, order_line):
    """
    Create the adjustment
    """
    assert isinstance(order, Order)
    assert isinstance(order_line, OrderLine)
    from shuup_rewards_multivendor.models import AdjustmentType, RewardAdjustment

    if not order_line.multivendor_reward_adjustments.exists():
        if order_line.type == OrderLineType.REFUND:
            points = order_line.quantity
        else:
            points = -order_line.quantity

        RewardAdjustment.create_for_source(order_line, **dict(
            customer=order.customer,
            supplier=order_line.supplier,
            shop=order.shop,
            delta=points,
            price_per_point=order_line.taxless_base_unit_price,
            type=AdjustmentType.SPEND_REFUND if order_line.type == OrderLineType.REFUND else AdjustmentType.SPEND
        ))


def _adjust_order_line_for_earning_points(order, order_line):
    assert isinstance(order, Order)
    assert isinstance(order_line, OrderLine)
    from shuup_rewards_multivendor.models import AdjustmentType, RewardAdjustment

    if not order_line.multivendor_reward_adjustments.exists():
        points = get_points_from_order_line(order_line)

        RewardAdjustment.create_for_source(order_line, **dict(
            customer=order.customer,
            supplier=order_line.supplier,
            shop=order.shop,
            delta=points,
            price_per_point=rewards_config.get_vendor_price_per_point_on_earn(order.shop, order_line.supplier),
            type=AdjustmentType.EARN_REFUND if order_line.type == OrderLineType.REFUND else AdjustmentType.EARN
        ))


def _adjust_refund_order_line(order, order_line):
    assert isinstance(order, Order)
    assert isinstance(order_line, OrderLine)
    from shuup_rewards_multivendor.models import AdjustmentType, RewardAdjustment
    parent_line = order_line.parent_line

    if parent_line and not order_line.multivendor_reward_adjustments.exists():
        parent_line_adjustment = parent_line.multivendor_reward_adjustments.last()

        if parent_line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
            adjustment_type = AdjustmentType.SPEND_REFUND
        else:
            adjustment_type = AdjustmentType.EARN_REFUND

        points = (parent_line_adjustment.delta * (order_line.taxless_price / order_line.parent_line.taxless_price))

        RewardAdjustment.create_for_source(order_line, **dict(
            customer=order.customer,
            supplier=order_line.supplier,
            shop=order.shop,
            delta=points,
            price_per_point=parent_line_adjustment.price_per_point,
            type=adjustment_type
        ))


def adjust_order(order):
    """
    Adjust order rewards (for paid orders)

    three mechanics:
        1. spend rewards
        2. give rewards based on the order value
    """

    # nothing to be done
    if not order.is_paid() or not order.customer or isinstance(order.customer, CompanyContact):
        return

    for order_line in order.lines.filter(supplier__isnull=False).select_related("order"):
        if not rewards_config.is_vendor_rewards_enabled(order.shop, order_line.supplier):
            continue

        if order_line.type == OrderLineType.REFUND:
            # create adjustments for refunds
            _adjust_refund_order_line(order, order_line)
        elif order_line.accounting_identifier == settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER:
            # create adjustments for spent points
            _adjust_order_line_for_spent_points(order, order_line)
        else:
            # create adjustment for earning points
            _adjust_order_line_for_earning_points(order, order_line)

    return order


def points_to_currency(points, price_per_point):
    return (Decimal(points) * Decimal(price_per_point))


def currency_to_points(amount, price_per_point):
    if not price_per_point:
        return Decimal()
    return (Decimal(amount) / Decimal(price_per_point))


def spend_points_to_currency(shop, supplier, points):
    assert isinstance(supplier, Supplier)
    price_per_point = rewards_config.get_vendor_price_per_point_on_spend(shop, supplier)
    if not price_per_point:
        return Decimal()
    return points_to_currency(points, price_per_point)


def earn_points_to_currency(shop, supplier, points):
    assert isinstance(supplier, Supplier)
    return points_to_currency(points, rewards_config.get_vendor_price_per_point_on_earn(shop, supplier))


def currency_to_spend_points(shop, supplier, amount):
    assert isinstance(supplier, Supplier)
    price_per_point = rewards_config.get_vendor_price_per_point_on_spend(shop, supplier)
    if not price_per_point:
        return Decimal()
    return currency_to_points(amount, price_per_point)


def currency_to_earn_points(shop, supplier, amount):
    assert isinstance(supplier, Supplier)
    return currency_to_points(amount, rewards_config.get_vendor_price_per_point_on_earn(shop, supplier))


def get_current_points(shop, customer, supplier):
    """
    Returns the current net and gross points count for the shop and customer

    :rtype tuple[int, int]
    """
    from shuup_rewards_multivendor.models import RewardCount
    count = RewardCount.objects.filter(customer=customer, shop=shop, supplier=supplier).first()
    if count:
        return (count.net_count, count.gross_count)
    return (0, 0)


def calculate_purchasable_units(parent_line, current_points, required_points):
    """
    Discover how many items we can purchase with points
    in case the line contains more than 1 quantity, we need to
    add the correct amount of discount to purchase the items with
    the existent points
    """

    # how many items can we purchase with customer points?
    purchasable_units = current_points // required_points

    # now get the quantity we are going to spend with points
    purchase_units = min(int(parent_line.quantity), purchasable_units)

    # get the taxful unit price for unit
    price_per_unit = parent_line.taxful_base_unit_price.value

    # calculate the discount amount to match the number of purchasable units
    discount_amount = (price_per_unit * purchase_units)

    # calculate number the points spent
    points = required_points * purchase_units

    return (discount_amount, points)


def get_spend_points_source_line_attrs(order_source, supplier, parent_line, points, **kwargs):
    """ Returns the kwargs to be used when adding the spend points line to OrderSource or Basket """
    if not parent_line.line_id:
        raise ValidationError(
            _("The parent line must has a valid id"),
            code="invalid-parent-line-id"
        )
    elif parent_line.supplier != supplier:
        raise ValidationError(
            _("The parent line supplier must be equal to supplier"),
            code="invalid-parent-line-supplier"
        )

    if parent_line.product:
        if rewards_config.is_product_rewards_disabled(parent_line.supplier, parent_line.product):
            raise ValidationError(
                _("The product {item} can't be paid with points").format(item=parent_line.text),
                code="cant-be-paid-with-points"
            )

        # check the required number of points to purchase this product
        required_purchase_points = rewards_config.get_product_required_points(parent_line.supplier, parent_line.product)
        if required_purchase_points > Decimal():

            if points and points > required_purchase_points:
                (discount_amount, points) = calculate_purchasable_units(parent_line, points, required_purchase_points)
            else:
                raise ValidationError(
                    _("Not enough points to spend on this product."),
                    code="product-not-enough-required-points"
                )
        else:
            # make sure to limit the max number of points to be used on this line
            max_points = currency_to_spend_points(
                order_source.shop,
                parent_line.supplier,
                get_purchase_order_line_amount(parent_line)
            )
            points = min(max_points, points)
            # convert the number of points into discount amount
            discount_amount = spend_points_to_currency(order_source.shop, supplier, points)

    line_attrs = dict(
        type=OrderLineType.DISCOUNT,
        supplier=supplier,
        quantity=points,
        base_unit_price=order_source.create_price(0),
        discount_amount=order_source.create_price(discount_amount),
        line_id="spend_points_{}_{}".format(supplier.pk, uuid4().hex),
        parent_line_id=parent_line.line_id,
        accounting_identifier=settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER,
        text=(ugettext("{points} Reward Points")).format(points=round_purchase_points(points)),
    )
    line_attrs.update(kwargs)
    return line_attrs


def get_line_purchase_required_points(shop, line, unit=False):
    """
    Returns the required amount of points needed to purchase each unit of the given line
    """
    if line.product:
        product_required_points = rewards_config.get_product_required_points(line.supplier, line.product)
        if product_required_points:
            return product_required_points if unit else product_required_points * line.quantity

    return currency_to_spend_points(
        shop,
        line.supplier,
        get_purchase_unit_order_line_amount(line) if unit else get_purchase_order_line_amount(line)
    )
