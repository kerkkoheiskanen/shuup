# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

from django.conf import settings

from shuup import configuration
from shuup.core.models import Shop, Supplier


def is_shop_rewards_enabled(shop):
    """ Get whether the rewards system is enabled for the given shop. Default is True """
    assert isinstance(shop, Shop)
    return configuration.get(shop, "multivendor_rewards_enabled", True)


def set_shop_rewards_enabled(shop, status):
    assert isinstance(shop, Shop)
    return configuration.set(shop, "multivendor_rewards_enabled", status)


def get_shop_price_per_point_on_earn(shop):
    """ Get the price per point that is used to convert money into points when user earns points """
    assert isinstance(shop, Shop)
    return Decimal(configuration.get(shop, "multivendor_rewards_price_per_point_on_earn") or 0)


def set_shop_price_per_point_on_earn(shop, price_per_point):
    """ Sets the price per point that is used to convert money into points when user earns points """
    assert isinstance(shop, Shop)
    return configuration.set(shop, "multivendor_rewards_price_per_point_on_earn", price_per_point)


def get_shop_price_per_point_on_spend(shop):
    """ Get the price per point that is used to convert a money amounts into points when user spends points """
    assert isinstance(shop, Shop)
    return Decimal(configuration.get(shop, "multivendor_rewards_price_per_point_on_spend") or 0)


def set_shop_price_per_point_on_spend(shop, price_per_point):
    """ Sets the price per point that is used to convert money amounts into points when user spends points """
    assert isinstance(shop, Shop)
    return configuration.set(shop, "multivendor_rewards_price_per_point_on_spend", price_per_point)


def get_shop_earn_total_percentage(shop):
    """ Get the percentage of a total that is used to calculate the points. Default is 100 """
    assert isinstance(shop, Shop)
    return Decimal(configuration.get(shop, "multivendor_rewards_earn_total_percentage", 100))


def set_shop_earn_total_percentage(shop, percentage):
    """ Sets the percentage of a total that is used to calculate the points """
    assert isinstance(shop, Shop)
    return configuration.set(shop, "multivendor_rewards_earn_total_percentage", percentage)


def is_vendor_rewards_enabled(shop, supplier):
    """ Get whether the rewards system is enabled for the given supplier. """
    assert isinstance(supplier, Supplier)

    # disabled globally for the shop
    if not is_shop_rewards_enabled(shop):
        return False

    return configuration.get(
        shop,
        "multivendor_rewards_enabled:{}".format(supplier.pk),
        settings.REWARD_VENDORS_DEFAULT_ENABLED
    )


def set_vendor_rewards_enabled(shop, supplier, status):
    assert isinstance(supplier, Supplier)
    return configuration.set(shop, "multivendor_rewards_enabled:{}".format(supplier.pk), status)


def get_vendor_price_per_point_on_earn(shop, supplier):
    """ Get the price per point that is used to convert money into points when user earns points """
    assert isinstance(supplier, Supplier)
    default = get_shop_price_per_point_on_earn(shop) or 0
    return Decimal(
        configuration.get(shop, "multivendor_rewards_price_per_point_on_earn:{}".format(supplier.pk)) or default
    )


def set_vendor_price_per_point_on_earn(shop, supplier, price_per_point):
    """ Sets the price per point that is used to convert money into points when user earns points """
    assert isinstance(supplier, Supplier)
    return configuration.set(
        shop,
        "multivendor_rewards_price_per_point_on_earn:{}".format(supplier.pk),
        price_per_point
    )


def get_vendor_price_per_point_on_spend(shop, supplier):
    """ Get the price per point that is used to convert a money amounts into points when user spends points """
    assert isinstance(supplier, Supplier)
    default = get_shop_price_per_point_on_spend(shop) or 0
    return Decimal(
        configuration.get(shop, "multivendor_rewards_price_per_point_on_spend:{}".format(supplier.pk)) or default
    )


def set_vendor_price_per_point_on_spend(shop, supplier, price_per_point):
    """ Sets the price per point that is used to convert money amounts into points when user spends points """
    assert isinstance(supplier, Supplier)
    return configuration.set(
        shop,
        "multivendor_rewards_price_per_point_on_spend:{}".format(supplier.pk),
        price_per_point
    )


def get_vendor_earn_total_percentage(shop, supplier):
    """ Get the percentage of a total that is used to calculate the points. Default is 100 """
    assert isinstance(supplier, Supplier)
    default = get_shop_earn_total_percentage(shop) or 100
    return Decimal(
        configuration.get(shop, "multivendor_rewards_earn_total_percentage:{}".format(supplier.pk)) or default
    )


def set_vendor_earn_total_percentage(shop, supplier, percentage):
    """ Sets the percentage of a total that is used to calculate the points """
    assert isinstance(supplier, Supplier)
    return configuration.set(shop, "multivendor_rewards_earn_total_percentage:{}".format(supplier.pk), percentage)


def set_product_purchase_required_points(supplier, product, required_purchase_points):
    """ Sets the required number of points to purchase a product with points """
    from shuup_rewards_multivendor.models import RewardsProductConfiguration
    RewardsProductConfiguration.objects.update_or_create(
        supplier=supplier,
        product=product,
        defaults=dict(required_purchase_points=required_purchase_points)
    )


def get_product_required_points(supplier, product):
    """ Gets the required number of points to purchase a product with points """
    from shuup_rewards_multivendor.models import RewardsProductConfiguration
    rewards_product_configuration = RewardsProductConfiguration.objects.filter(
        supplier=supplier,
        product=product,
    ).first()
    return rewards_product_configuration.required_purchase_points if rewards_product_configuration else Decimal()


def set_product_rewards_disabled(supplier, product, disabled):
    """ Sets whether a given product is disabled to be paid with points """
    from shuup_rewards_multivendor.models import RewardsProductConfiguration
    RewardsProductConfiguration.objects.update_or_create(
        supplier=supplier,
        product=product,
        defaults=dict(disabled=disabled)
    )


def is_product_rewards_disabled(supplier, product):
    """ Returns whether a given product is disabled to be paid with points """
    from shuup_rewards_multivendor.models import RewardsProductConfiguration
    rewards_product_configuration = RewardsProductConfiguration.objects.filter(
        supplier=supplier,
        product=product,
    ).first()
    return rewards_product_configuration.disabled if rewards_product_configuration else False
