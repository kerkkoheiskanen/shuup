# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

import pytest
from django.conf import settings
from django.core.exceptions import ValidationError

from shuup.core.basket import get_basket, get_basket_command_dispatcher
from shuup.core.defaults.order_statuses import create_default_order_statuses
from shuup.core.models import OrderLineType, Supplier
from shuup.core.order_creator import OrderCreator
from shuup.testing import factories
from shuup.testing.utils import apply_request_middleware
from shuup.utils.numbers import bankers_round
from shuup_rewards_multivendor import utils
from shuup_rewards_multivendor.models import RewardCount


def bround(value):
    return bankers_round(value, 2)


@pytest.mark.django_db
def test_spend_points_on_basket(rf):
    product_price = Decimal(50)
    initial_points = 200
    spend_points = 30

    # the expected final points is 190 because customer can not earn points
    # from the amount that is being discounted with points
    #
    # 1. Earned 200 points
    # 2. Creates an order of $50.
    # 3. Spend 30 points which worth $30 of discount
    # 4. The total basket will be $20, and this should be the amount to use to accumulate points
    #
    expected_final_points = 190

    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    product = factories.create_product("product", shop, supplier, product_price)
    customer = factories.create_random_person("en")

    # 1 point = $1
    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)

    RewardCount.grant_points(shop, customer, supplier, initial_points)
    assert utils.get_current_points(shop, customer, supplier) == (Decimal(initial_points), Decimal(initial_points))

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    basket = get_basket(request)
    basket.shipping_method = factories.get_default_shipping_method()
    basket.payment_method = factories.get_default_payment_method()
    basket.customer = customer
    basket.status = factories.get_initial_order_status()
    basket.add_product(supplier, shop, product, 1)

    assert basket.total_price.value == product_price
    assert not list(basket.get_validation_errors())

    # add spending line attached to the first product line
    product_lines = basket.get_product_lines()
    basket.add_line(**utils.get_spend_points_source_line_attrs(basket, supplier, product_lines[0], spend_points))
    assert not list(basket.get_validation_errors())
    assert basket.total_price.value == (product_price - spend_points)
    assert utils.get_current_points(shop, customer, supplier) == (Decimal(initial_points), Decimal(initial_points))

    order_creator = OrderCreator()
    order = order_creator.create_order(basket)
    order.customer = customer
    order.save()
    order.create_payment(order.taxful_total_price)

    assert utils.get_current_points(shop, customer, supplier) == (expected_final_points, expected_final_points)


@pytest.mark.django_db
def test_spend_points_command_handler(rf):
    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    user = factories.create_random_user()
    user.set_password("password")
    user.save()
    customer = factories.create_random_person("en")
    customer.user = user
    customer.save()

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)   # 1 point = $1
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 0.5)  # 1 point = $0.5
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)

    # the expected final points is 155 because customer can not earn points
    # from the amount that is being discounted with points
    #
    # 1. Earned 50 points
    # 2. Creates an order of $150.
    # 3. Spend 30 points which worth $30 of discount
    # 4. The total basket will be $120, and this should be the amount to use to accumulate points
    product_price = Decimal(150)
    initial_points = 50
    spend_points = 30       # $15 as 1 pt = $0.5
    expected_final_points = 155

    product = factories.create_product("product", shop, supplier, product_price)

    RewardCount.grant_points(shop, customer, supplier, initial_points)
    assert utils.get_current_points(shop, customer, supplier) == (Decimal(initial_points), Decimal(initial_points))

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    request.basket.shipping_method = factories.get_default_shipping_method()
    request.basket.payment_method = factories.get_default_payment_method()
    request.basket.customer = customer
    request.basket.status = factories.get_initial_order_status()

    basket_dispatcher = get_basket_command_dispatcher(request)
    response = basket_dispatcher.get_command_handler("add")(
        request=request,
        basket=request.basket,
        product_id=product.pk,
        supplier_id=supplier.pk
    )
    assert response["ok"]
    line_id = response["line_id"]

    response = basket_dispatcher.get_command_handler("spend_points")(
        request=request,
        basket=request.basket,
        line_id=line_id,
        points=spend_points
    )
    assert response["ok"]
    assert response["spent"] == spend_points
    assert not list(request.basket.get_validation_errors())

    order_creator = OrderCreator()
    order = order_creator.create_order(request.basket)
    order.customer = customer
    order.save()
    order.create_payment(order.taxful_total_price)

    assert utils.get_current_points(shop, customer, supplier) == (expected_final_points, expected_final_points)


@pytest.mark.django_db
def test_spend_points_command_handler_errors(rf):
    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    user = factories.create_random_user()
    user.set_password("password")
    user.save()
    customer = factories.create_random_person("en")
    customer.user = user
    customer.save()

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)   # 1 point = $1
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 0.5)  # 1 point = $0.5
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    product_price = Decimal(100)
    product = factories.create_product("product", shop, supplier, product_price)

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    request.basket.shipping_method = factories.get_default_shipping_method()
    request.basket.payment_method = factories.get_default_payment_method()
    request.basket.status = factories.get_initial_order_status()
    basket_dispatcher = get_basket_command_dispatcher(request)

    # add a product
    response = basket_dispatcher.get_command_handler("add")(
        request=request,
        basket=request.basket,
        product_id=product.pk,
        supplier_id=supplier.pk
    )
    assert response["ok"]
    line_id = response["line_id"]

    # try spending points without customer
    with pytest.raises(ValidationError) as invalid_customer_exc:
        basket_dispatcher.get_command_handler("spend_points")(
            request=request,
            basket=request.basket,
            line_id="invalid",
            points=100
        )
    assert invalid_customer_exc.value.code == "customer-not-found"

    request.basket.customer = customer

    # try spending points using an invalid line
    with pytest.raises(ValidationError) as invalid_line_exc:
        basket_dispatcher.get_command_handler("spend_points")(
            request=request,
            basket=request.basket,
            line_id="invalid",
            points=100
        )
    assert invalid_line_exc.value.code == "basket-line-id-not-found"

    request.basket.add_line(
        line_id="no-supplier-line",
        type=OrderLineType.OTHER,
        quantity=1,
        base_unit_price=request.basket.create_price(10),
        text="Strange Line"
    )

    # try spending points using a line with no supplier
    with pytest.raises(ValidationError) as invalid_supplier_exc:
        basket_dispatcher.get_command_handler("spend_points")(
            request=request,
            basket=request.basket,
            line_id="no-supplier-line",
            points=100
        )
    assert invalid_supplier_exc.value.code == "basket-line-doesnt-contain-supplier"

    RewardCount.grant_points(shop, customer, supplier, 1)
    assert utils.get_current_points(shop, customer, supplier) == (Decimal(1), Decimal(1))

    # try spending more points that user owns
    with pytest.raises(ValidationError) as not_enough_points_exc:
        basket_dispatcher.get_command_handler("spend_points")(
            request=request,
            basket=request.basket,
            line_id=line_id,
            points=100
        )
    assert not_enough_points_exc.value.code == "not-enough-points"

    RewardCount.grant_points(shop, customer, supplier, 1000)

    # now spend more points that the price of the line.
    # It should use the number of points needed to make the line zero
    response = basket_dispatcher.get_command_handler("spend_points")(
        request=request,
        basket=request.basket,
        line_id=line_id,
        points=1000
    )
    assert response["ok"]
    assert response["spent"] == utils.currency_to_spend_points(shop, supplier, product_price)


@pytest.mark.django_db
def test_spend_points_basket_validator(rf):
    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    product = factories.create_product("product", shop, supplier, 100)
    customer = factories.create_random_person("en")

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    basket = get_basket(request)
    basket.shipping_method = factories.get_default_shipping_method()
    basket.payment_method = factories.get_default_payment_method()
    basket.customer = customer
    basket.status = factories.get_initial_order_status()
    basket.add_product(supplier, shop, product, 1)

    assert basket.total_price.value == Decimal(100)
    assert not list(basket.get_validation_errors())

    # add spending line attached to the first product line
    product_lines = basket.get_product_lines()
    basket.add_line(**utils.get_spend_points_source_line_attrs(basket, supplier, product_lines[0], 10))

    # not enough points
    assert list(basket.get_validation_errors())[0].code == "not-enough-points"


@pytest.mark.django_db
def test_spend_points_product_required_points(rf):
    product_price = 100
    product_required_points = 2000

    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    product = factories.create_product("product", shop, supplier, product_price)
    customer = factories.create_random_person("en")

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)

    # configure this product to be orderable with 2000 points each
    utils.configuration.set_product_purchase_required_points(supplier, product, product_required_points)

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    basket = get_basket(request)
    basket.shipping_method = factories.get_default_shipping_method()
    basket.payment_method = factories.get_default_payment_method()
    basket.customer = customer
    basket.status = factories.get_initial_order_status()

    # add 2 units
    product_line = basket.add_product(supplier, shop, product, 2)

    assert basket.total_price.value == Decimal(product_price * 2)
    assert not list(basket.get_validation_errors())

    RewardCount.grant_points(shop, customer, supplier, 100000)

    # try spending points but don't use the required number of points to pay a single product
    basket_dispatcher = get_basket_command_dispatcher(request)
    with pytest.raises(ValidationError) as not_enough_points_exc:
        basket_dispatcher.get_command_handler("spend_points")(
            request=request,
            basket=request.basket,
            line_id=product_line.line_id,
            points=100
        )
    assert not_enough_points_exc.value.code == "product-not-enough-required-points"

    # force adding a line manually, bypassing the validation in `get_spend_points_source_line_attrs`
    basket.add_line(
        supplier=supplier,
        type=OrderLineType.DISCOUNT,
        quantity=1500,
        text="use points",
        base_unit_price=basket.create_price(1),
        line_id="spend_points",
        accounting_identifier=settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER,
        parent_line_id=product_line.line_id
    )
    # not enough points for the product
    assert list(basket.get_validation_errors())[0].code == "product-not-enough-required-points"


@pytest.mark.django_db
def test_spend_points_product_required_points_multi_products(rf):
    product_price = 100
    product_required_points = 5000
    initial_points = 10000

    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    product1 = factories.create_product("product1", shop, supplier, product_price)
    product2 = factories.create_product("product2", shop, supplier, product_price)
    customer = factories.create_random_person("en")

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    RewardCount.grant_points(shop, customer, supplier, initial_points)

    utils.configuration.set_product_purchase_required_points(supplier, product1, product_required_points)

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    basket = get_basket(request)
    basket.shipping_method = factories.get_default_shipping_method()
    basket.payment_method = factories.get_default_payment_method()
    basket.customer = customer
    basket.status = factories.get_initial_order_status()

    product1_line = basket.add_product(supplier, shop, product1, 3)
    product2_line = basket.add_product(supplier, shop, product2, 2)

    # use all initial points, can pay only 2 items
    basket.add_line(**utils.get_spend_points_source_line_attrs(basket, supplier, product1_line, initial_points))
    # add discount for other item
    basket.add_line(**utils.get_spend_points_source_line_attrs(basket, supplier, product2_line, 100))

    # not enough points to use
    assert list(basket.get_validation_errors())[0].code == "not-enough-points"


@pytest.mark.django_db
def test_spend_points_product_disabled(rf):
    product_price = 100
    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    product = factories.create_product("product", shop, supplier, product_price)
    customer = factories.create_random_person("en")

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    utils.configuration.set_product_rewards_disabled(supplier, product, True)

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    basket = get_basket(request)
    basket.shipping_method = factories.get_default_shipping_method()
    basket.payment_method = factories.get_default_payment_method()
    basket.customer = customer
    basket.status = factories.get_initial_order_status()

    # add 2 units
    product_line = basket.add_product(supplier, shop, product, 2)

    assert basket.total_price.value == Decimal(product_price * 2)
    assert not list(basket.get_validation_errors())

    RewardCount.grant_points(shop, customer, supplier, 100000)

    # try spending points but the product doesn't accept to be paid with points
    basket_dispatcher = get_basket_command_dispatcher(request)
    with pytest.raises(ValidationError) as error:
        basket_dispatcher.get_command_handler("spend_points")(
            request=request,
            basket=request.basket,
            line_id=product_line.line_id,
            points=1
        )
    assert error.value.code == "cant-be-paid-with-points"

    # force adding a line manually, bypassing the validation in `get_spend_points_source_line_attrs`
    basket.add_line(
        supplier=supplier,
        type=OrderLineType.DISCOUNT,
        quantity=1,
        text="use points",
        base_unit_price=basket.create_price(1),
        line_id="spend_points",
        accounting_identifier=settings.REWARD_POINTS_SPENT_ACCOUNTING_IDENTIFIER,
        parent_line_id=product_line.line_id
    )
    # item cant be paid with points
    assert list(basket.get_validation_errors())[0].code == "cant-be-paid-with-points"


@pytest.mark.django_db
def test_spend_points_multi_supplier(rf):
    create_default_order_statuses()
    shop = factories.get_default_shop()
    supplier1 = factories.get_default_supplier()
    supplier2 = Supplier.objects.create(name="Supplier2")

    supplier1_initial_pts = 1000
    supplier2_initial_pts = 50
    supplier1_product_price = 100
    supplier2_product_price = 30

    product1 = factories.create_product("product1", shop, supplier1, supplier1_product_price)
    product2 = factories.create_product("product2", shop, supplier2, supplier2_product_price)
    customer = factories.create_random_person("en")

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier1, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier1, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier1, True)
    RewardCount.grant_points(shop, customer, supplier1, supplier1_initial_pts)

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier2, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier2, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier2, True)
    RewardCount.grant_points(shop, customer, supplier2, supplier2_initial_pts)

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    basket = get_basket(request)
    basket.shipping_method = factories.get_default_shipping_method()
    basket.payment_method = factories.get_default_payment_method()
    basket.customer = customer
    basket.status = factories.get_initial_order_status()

    product1_line = basket.add_product(supplier1, shop, product1, 1)
    product2_line = basket.add_product(supplier2, shop, product2, 1)

    # use all points
    basket.add_line(**utils.get_spend_points_source_line_attrs(basket, supplier1, product1_line, 9999999))
    basket.add_line(**utils.get_spend_points_source_line_attrs(basket, supplier2, product2_line, 9999999))

    order_creator = OrderCreator()
    order = order_creator.create_order(request.basket)
    order.customer = customer
    order.save()
    order.create_payment(order.taxful_total_price)

    assert utils.get_current_points(shop, customer, supplier1)[0] == supplier1_initial_pts - supplier1_product_price
    assert utils.get_current_points(shop, customer, supplier2)[0] == supplier2_initial_pts - supplier2_product_price


@pytest.mark.parametrize("prices_include_tax", [True, False])
@pytest.mark.django_db
def test_spend_points_taxed(rf, prices_include_tax):
    initial_pts = 500
    product_price = 100
    tax_rate = 0.20     # 20% of tax

    create_default_order_statuses()
    shop = factories.get_default_shop()
    shop.prices_include_tax = prices_include_tax
    shop.save()
    tax = factories.get_tax("sales-tax", "Sales Tax", Decimal(tax_rate))
    factories.create_default_tax_rule(tax)

    supplier = factories.get_default_supplier()

    product = factories.create_product("product", shop, supplier, product_price)
    customer = factories.create_random_person("en")

    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    RewardCount.grant_points(shop, customer, supplier, initial_pts)

    request = apply_request_middleware(rf.get("/"), shop=shop, customer=customer)
    basket = get_basket(request)
    basket.shipping_method = factories.get_default_shipping_method()
    basket.payment_method = factories.get_default_payment_method()
    basket.customer = customer
    basket.status = factories.get_initial_order_status()

    product_line = basket.add_product(supplier, shop, product, 1)

    if prices_include_tax:
        taxful_price = bround(Decimal(product_price))
        taxless_price = bround(Decimal(product_price / Decimal(1 + tax_rate)))
    else:
        taxful_price = bround(Decimal(product_price * Decimal(1 + tax_rate)))
        taxless_price = bround(Decimal(product_price))

    assert bround(product_line.taxful_price.value) == taxful_price
    assert bround(product_line.taxless_price.value) == taxless_price

    if prices_include_tax:
        assert bround(utils.get_purchase_order_line_amount(product_line)) == taxful_price
        assert bround(utils.get_purchase_unit_order_line_amount(product_line)) == taxful_price
    else:
        assert bround(utils.get_purchase_order_line_amount(product_line)) == taxless_price
        assert bround(utils.get_purchase_unit_order_line_amount(product_line)) == taxless_price

    assert bround(utils.get_earn_points_order_line_total_amount(product_line)) == taxless_price
    assert bround(utils.get_earn_points_unit_order_line_amount(product_line)) == taxless_price

    discount_line = basket.add_line(**utils.get_spend_points_source_line_attrs(basket, supplier, product_line, 99999))

    order_creator = OrderCreator()
    order = order_creator.create_order(request.basket)
    order.customer = customer
    order.save()
    order.create_payment(order.taxful_total_price)
    assert order.taxful_total_price.value == Decimal()
    spent_points = discount_line.quantity

    assert utils.get_current_points(shop, customer, supplier)[0] == int(initial_pts - spent_points)
