# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from shuup.core.models import get_person_contact
from shuup.core.order_creator import OrderSource
from shuup.testing.factories import (
    get_address, get_default_shop, get_initial_order_status,
    get_payment_method, get_shipping_method
)


def seed_source(user, shop=None):
    source_shop = shop or get_default_shop()
    source = OrderSource(source_shop)
    billing_address = get_address()
    shipping_address = get_address(name="Shippy Doge")
    source.status = get_initial_order_status()
    source.billing_address = billing_address
    source.shipping_address = shipping_address
    source.customer = get_person_contact(user)
    source.payment_method = get_payment_method(shop)
    source.shipping_method = get_shipping_method(shop)
    assert source.payment_method_id == get_payment_method(shop).id
    assert source.shipping_method_id == get_shipping_method(shop).id
    return source
