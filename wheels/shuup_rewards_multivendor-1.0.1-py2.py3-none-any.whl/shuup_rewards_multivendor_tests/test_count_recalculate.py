# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import pytest

from shuup.core.models import Order
from shuup.testing import factories
from shuup.testing.factories import (
    create_order_with_product, create_product, create_random_person,
    get_default_shop, get_default_supplier
)
from shuup_rewards_multivendor import utils
from shuup_rewards_multivendor.models import (
    AdjustmentType, RewardAdjustment, RewardCount
)


@pytest.mark.django_db
def test_count_recalculate_basic():
    shop = get_default_shop()

    adjustments = [
        (20, 20),
        (-1, 19),
        (2, 21),
        (0, 21),
        (-22, -1),
    ]

    for x in range(1, 20):
        random_customer = create_random_person()
        for i, (delta, after) in enumerate(adjustments, start=1):
            RewardAdjustment.objects.create(
                delta=delta,
                shop_id=shop.id,
                customer_id=random_customer.id,
                supplier=factories.get_default_supplier(),
                type=AdjustmentType.EARN
            )

            assert RewardAdjustment.objects.count() == i + ((x-1)*5)
            assert RewardCount.objects.count() == x

            count_obj = RewardCount.objects.filter(shop_id=shop.id, customer_id=random_customer.id).first()
            assert count_obj.net_count == after
            assert count_obj.gross_count == after

    # About 19 customers with 5 adjustment each
    assert RewardAdjustment.objects.count() == 95  # 19 * 5


@pytest.mark.django_db
def test_count_recalculate_with_orders():
    shop = get_default_shop()
    supplier = get_default_supplier()
    supplier = factories.get_default_supplier()
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    product = create_product("cat", shop=shop, supplier=supplier, default_price=10)
    random_customer = create_random_person()

    # Add 30 points for the customer
    RewardCount.grant_points(shop, random_customer, supplier, 30)
    assert utils.get_current_points(shop, random_customer, supplier) == (30, 30)

    # In the settings the price per point is 1 (it takes 1 points to pay 1 dollar product)
    # this order worth 10 points
    order = create_order_with_product(
        product=product,
        supplier=supplier,
        quantity=1,
        taxless_base_unit_price=10,
        shop=shop
    )
    order.customer = random_customer
    order.save()

    assert order.taxful_total_price.value == 10
    assert Order.objects.paid().count() == 0

    order.create_payment(order.taxful_total_price)
    assert utils.get_current_points(shop, random_customer, supplier) == (40, 40)

    order.create_full_refund()
    assert utils.get_current_points(shop, random_customer, supplier) == (30, 30)
