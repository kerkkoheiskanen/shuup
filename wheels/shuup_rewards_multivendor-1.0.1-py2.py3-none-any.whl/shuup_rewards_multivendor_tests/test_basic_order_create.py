# -*- coding: utf-8 -*-
# This file is part of Shuup Rewards Multivendor Addon.
#
# Copyright (c) 2012-2019, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from decimal import Decimal

import pytest

from shuup.core.models import AnonymousContact, Order
from shuup.testing import factories
from shuup_rewards_multivendor import utils
from shuup_rewards_multivendor.models import RewardAdjustment, RewardCount


@pytest.mark.django_db
def test_order_for_anonymous():
    order_total = Decimal(10)
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    product = factories.create_product("dof", shop=shop, supplier=supplier, default_price=order_total)
    order = factories.create_order_with_product(
        product=product, supplier=supplier, quantity=1, taxless_base_unit_price=order_total, shop=shop)
    order.customer = AnonymousContact()
    order.save()
    order.create_payment(order.taxful_total_price)

    assert order.taxful_total_price.value == Decimal(order_total)
    assert Order.objects.paid().count() == 1
    assert RewardCount.objects.filter(shop_id=shop.id).count() == 0
    assert RewardAdjustment.objects.count() == 0

    # now set the customer to see what happens, it should generate points
    order.customer = factories.create_random_person()
    order.save()
    assert Order.objects.paid().count() == 1
    assert RewardCount.objects.filter(shop_id=shop.id).count() == 1
    assert RewardAdjustment.objects.count() == 1


@pytest.mark.django_db
def test_order_creates_proper_adjustments():
    order_total = Decimal(10)
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    product = factories.create_product("dof", shop=shop, supplier=supplier, default_price=order_total)
    order = factories.create_order_with_product(
        product=product, supplier=supplier, quantity=1, taxless_base_unit_price=order_total, shop=shop)
    order.customer = AnonymousContact()
    order.save()
    order.create_payment(order.taxful_total_price)

    assert order.taxful_total_price.value == Decimal(order_total)
    assert Order.objects.paid().count() == 1
    assert RewardCount.objects.filter(shop_id=shop.id).count() == 0
    assert RewardAdjustment.objects.count() == 0

    # now set the customer to see what happens, it should generate points
    order.customer = factories.create_random_person()
    order.save()
    assert Order.objects.paid().count() == 1

    assert RewardCount.objects.filter(shop=shop).count() == 1
    adjustment = RewardCount.objects.filter(shop_id=shop.id).first()
    assert adjustment.gross_count == int(order.taxful_total_price_value)
    assert adjustment.net_count == int(order.taxful_total_price_value)
    assert RewardAdjustment.objects.count() == 1


@pytest.mark.django_db
def test_order_for_company():
    order_total = Decimal(10)
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    utils.configuration.set_vendor_rewards_enabled(shop, supplier, True)
    utils.configuration.set_vendor_price_per_point_on_earn(shop, supplier, 1)
    utils.configuration.set_vendor_price_per_point_on_spend(shop, supplier, 1)
    product = factories.create_product("dof", shop=shop, supplier=supplier, default_price=order_total)
    order = factories.create_order_with_product(
        product=product, supplier=supplier, quantity=1, taxless_base_unit_price=order_total, shop=shop)

    customer = factories.create_random_company()
    order.customer = customer
    order.save()
    order.create_payment(order.taxful_total_price)

    assert order.taxful_total_price.value == Decimal(order_total)
    assert Order.objects.paid().count() == 1
    assert RewardCount.objects.filter(shop_id=shop.id).count() == 0
    assert RewardAdjustment.objects.count() == 0

    # now set the customer to see what happens, it should generate points
    order.customer = factories.create_random_person()
    order.save()
    assert Order.objects.paid().count() == 1
    assert RewardCount.objects.filter(shop_id=shop.id).count() == 1
    assert RewardAdjustment.objects.count() == 1
