"""
https://docs.djangoproject.com/en/dev/_modules/django/db/models/functions/math/
"""
import math

from django.db.models.fields import DecimalField, FloatField, IntegerField
from django.db.models.lookups import Transform


class NumericOutputFieldMixin:
    def _resolve_output_field(self):
        source_expressions = self.get_source_expressions()
        if any(isinstance(s.output_field, DecimalField) for s in source_expressions):
            return DecimalField()
        if any(isinstance(s.output_field, IntegerField) for s in source_expressions):
            return FloatField()
        return super()._resolve_output_field() if source_expressions else FloatField()


class Round(Transform):
    function = 'ROUND'
    lookup_name = 'round'
    arity = 2


class Degrees(NumericOutputFieldMixin, Transform):
    function = 'DEGREES'
    lookup_name = 'degrees'

    def as_oracle(self, compiler, connection, **extra_context):
        return super().as_sql(
            compiler, connection,
            template='((%%(expressions)s) * 180 / %s)' % math.pi,
            **extra_context
        )


class ACos(NumericOutputFieldMixin, Transform):
    function = 'ACOS'
    lookup_name = 'acos'


class Cos(NumericOutputFieldMixin, Transform):
    function = 'COS'
    lookup_name = 'cos'


class Radians(NumericOutputFieldMixin, Transform):
    function = 'RADIANS'
    lookup_name = 'radians'

    def as_oracle(self, compiler, connection, **extra_context):
        return super().as_sql(
            compiler, connection,
            template='((%%(expressions)s) * %s / 180)' % math.pi,
            **extra_context
        )


class Sin(NumericOutputFieldMixin, Transform):
    function = 'SIN'
    lookup_name = 'sin'
