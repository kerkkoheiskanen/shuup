# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db import models
from django.utils.translation import ugettext_lazy as _
from enumfields import Enum, EnumField


class DistanceUnit(Enum):
    km = "km"
    mi = "mi"

    class Labels:
        km = _("Kilometers")
        mi = _("Miles")


class VendorContactDistance(models.Model):
    contact = models.ForeignKey("shuup.Contact", verbose_name=_("contact"), related_name="vendor_distances")
    supplier = models.ForeignKey("shuup.Supplier", verbose_name=_("supplier"), related_name="vendor_distances")
    distance = models.DecimalField(verbose_name=_("distance"), null=True, blank=True, max_digits=9, decimal_places=2)
    unit = EnumField(DistanceUnit, verbose_name=_("unit"))

    class Meta:
        unique_together = ("contact", "supplier")

    def __str__(self):
        return "{} => {} = {} {}".format(self.contact, self.supplier, self.distance, self.unit)
