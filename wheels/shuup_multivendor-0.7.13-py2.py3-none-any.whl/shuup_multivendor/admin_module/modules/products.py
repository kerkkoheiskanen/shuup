# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import PRODUCTS_MENU_CATEGORY
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.urls import admin_url


class MultivendorProductsAdminModule(AdminModule):
    name = _("Vendor Products")
    breadcrumbs_menu_entry = MenuEntry(name, url="shuup_admin:shuup_multivendor.products_list")

    def get_urls(self):
        urls = [
            admin_url(
                r"^multivendor/products/$",
                "shuup_multivendor.admin_module.views.ProductListView",
                name="shuup_multivendor.products_list",
            ),
            admin_url(
                r"^multivendor/products/toggle-sale/$",
                "shuup_multivendor.admin_module.views.ToggleSaleView",
                name="shuup_multivendor.products_toggles_sale",
            ),
            admin_url(
                r"^multivendor/products/set-price/$",
                "shuup_multivendor.admin_module.views.SetPriceView",
                name="shuup_multivendor.products_set_price",
            )
        ]
        if settings.SHUUP_MULTIVENDOR_ENABLE_CUSTOM_PRODUCTS:
            urls += [
                admin_url(
                    r"^multivendor/products/new/$",
                    "shuup_multivendor.admin_module.views.ProductEditView",
                    name="shuup_multivendor.products_new",
                    kwargs={"pk": None}
                ),
                admin_url(
                    r"^multivendor/products/(?P<pk>\d+)/$",
                    "shuup_multivendor.admin_module.views.ProductEditView",
                    name="shuup_multivendor.products_edit"
                ),
                admin_url(
                    r"^multivendor/products/(?P<pk>\d+)/delete/$",
                    "shuup_multivendor.admin_module.views.ProductDeleteView",
                    name="shuup_multivendor.products_delete"
                )
            ]
        return urls

    def get_menu_entries(self, request):
        if not get_supplier(request):
            return []

        return [
            MenuEntry(
                text=_("Products"),
                icon="fa fa-image",
                url="shuup_admin:shuup_multivendor.products_list",
                category=PRODUCTS_MENU_CATEGORY,
                subcategory="products"
            )
        ]
