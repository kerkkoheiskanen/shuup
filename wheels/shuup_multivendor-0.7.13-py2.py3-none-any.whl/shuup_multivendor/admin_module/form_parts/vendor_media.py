# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.conf import settings
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.admin.utils.permissions import get_missing_permissions

from shuup_multivendor.admin_module.forms.vendor_media import (
    VendorImageMediaFormSet, VendorMediaFormSet
)


class BaseVendorMediaFormPart(FormPart):
    required_permissions = ["shuup_multivendor.upload_media", "shuup_multivendor.attach_media"]

    def get_form_defs(self):
        if not self.object.pk or get_missing_permissions(self.request.user, self.required_permissions):
            return

        yield TemplatedFormDef(
            self.name,
            self.formset,
            template_name="shuup_multivendor/supplier/edit_media_form.jinja",
            required=False,
            kwargs={
                "vendor": self.object,
                "languages": settings.LANGUAGES,
                "request": self.request
            }
        )

    def form_valid(self, form):
        if self.name in form.forms:
            frm = form.forms[self.name]
            frm.save()


class VendorMediaFormPart(BaseVendorMediaFormPart):
    name = "media"
    priority = 2
    formset = VendorMediaFormSet


class VendorImageMediaFormPart(BaseVendorMediaFormPart):
    name = "images"
    priority = 2
    formset = VendorImageMediaFormSet
