# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.conf import settings
from django.contrib import messages
from django.forms import BaseModelFormSet
from django.forms.formsets import DEFAULT_MAX_NUM, DEFAULT_MIN_NUM
from django.utils.translation import ugettext_lazy as _
from filer.models import Image
from shuup.utils.multilanguage_model_form import (
    MultiLanguageModelForm, to_language_codes
)

from shuup_multivendor.models import VendorMedia, VendorMediaKind


class BaseVendorMediaForm(MultiLanguageModelForm):
    class Meta:
        model = VendorMedia
        fields = (
            "file",
            "ordering",
            "external_url",
            "public",
            "title",
            "description",
            "kind"
        )

    def __init__(self, **kwargs):
        self.vendor = kwargs.pop("vendor")
        self.allowed_media_kinds = kwargs.pop("allowed_media_kinds")
        super(BaseVendorMediaForm, self).__init__(**kwargs)

        self.fields["file"].widget = forms.HiddenInput()
        self.fields["file"].required = True

        if self.allowed_media_kinds:
            # multiple media kinds allowed, filter the choices list to reflect the `self.allowed_media_kinds`
            allowed_kinds_values = set(v.value for v in self.allowed_media_kinds)
            self.fields["kind"].choices = [
                (value, choice)
                for value, choice in self.fields["kind"].choices
                if value in allowed_kinds_values
            ]

            if len(self.allowed_media_kinds) == 1:
                # only one media kind given, no point showing the dropdown
                self.fields["kind"].widget = forms.HiddenInput()

            self.fields["kind"].initial = self.allowed_media_kinds[0]

        self.file_url = self.instance.url

    def get_thumbnail(self, request):
        """
        Get thumbnail url.

        If thumbnail creation fails for whatever reason,
        an error message is displayed for user.
        """
        try:
            thumbnail = self.instance.get_thumbnail()
        except Exception as error:
            msg = _("Thumbnail generation of %(media)s failed: %(error)s") % {"media": self.instance, "error": error}
            messages.error(request, msg)
            thumbnail = None
        return thumbnail

    def pre_master_save(self, instance):
        instance.vendor = self.vendor


class BaseVendorMediaFormSet(BaseModelFormSet):
    validate_min = False
    min_num = DEFAULT_MIN_NUM
    validate_max = False
    max_num = DEFAULT_MAX_NUM
    absolute_max = DEFAULT_MAX_NUM
    model = VendorMedia
    can_delete = True
    can_order = False
    extra = 0

    allowed_media_kinds = []

    def __init__(self, *args, **kwargs):
        self.vendor = kwargs.pop("vendor")
        self.request = kwargs.pop("request", None)
        self.default_language = kwargs.pop("default_language", getattr(settings, "PARLER_DEFAULT_LANGUAGE_CODE"))
        self.languages = to_language_codes(kwargs.pop("languages", ()), self.default_language)
        kwargs.pop("empty_permitted", None)  # this is unknown to formset
        super(BaseVendorMediaFormSet, self).__init__(*args, **kwargs)

    def get_queryset(self):
        qs = VendorMedia.objects.filter(vendor=self.vendor)
        if self.allowed_media_kinds:
            qs = qs.filter(kind__in=self.allowed_media_kinds)
        return qs

    def form(self, **kwargs):
        kwargs.setdefault("languages", self.languages)
        kwargs.setdefault("vendor", self.vendor)
        kwargs.setdefault("allowed_media_kinds", self.allowed_media_kinds)
        return self.form_class(**kwargs)

    def save(self, commit=True):
        forms = self.forms or []
        for form in forms:
            form.request = self.request
        super(BaseVendorMediaFormSet, self).save(commit)


class VendorMediaForm(BaseVendorMediaForm):
    def __init__(self, **kwargs):
        super(VendorMediaForm, self).__init__(**kwargs)
        self.fields["file"].required = False

    def clean_external_url(self):
        external_url = self.cleaned_data.get("external_url")

        # if form has been deleted, we don't want to validate fields
        if "DELETE" in self.changed_data:
            return external_url

        file = self.cleaned_data.get("file")
        if external_url and file:
            raise forms.ValidationError(_("Use only URL or file, not both"))
        return external_url


class VendorMediaFormSet(BaseVendorMediaFormSet):
    form_class = VendorMediaForm
    allowed_media_kinds = [VendorMediaKind.GENERIC_FILE, VendorMediaKind.DOCUMENTATION]


class VendorImageMediaForm(BaseVendorMediaForm):
    def __init__(self, **kwargs):
        super(VendorImageMediaForm, self).__init__(**kwargs)
        self.fields["file"].widget = forms.HiddenInput()

    def clean_file(self):
        file = self.cleaned_data.get("file")
        if file and not isinstance(file, Image):
            raise forms.ValidationError(_("Only images allowed in this field"))
        return file


class VendorImageMediaFormSet(VendorMediaFormSet):
    allowed_media_kinds = [VendorMediaKind.IMAGE]
    form_class = VendorImageMediaForm
