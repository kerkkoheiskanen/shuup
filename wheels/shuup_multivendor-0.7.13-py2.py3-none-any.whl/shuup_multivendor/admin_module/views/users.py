# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse, reverse_lazy
from django.db.transaction import atomic
from django.utils.translation import ugettext_lazy as _
from shuup.admin.modules.users.views import (
    UserDetailView, UserListView, UserResetPasswordView
)
from shuup.admin.modules.users.views.detail import UserDetailToolbar
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.toolbar import (
    DropdownActionButton, DropdownItem, PostActionButton
)
from shuup.admin.utils.picotable import ChoicesFilter, Column, TextFilter
from shuup.core.models import PersonContact

from shuup_multivendor.models import SupplierUser
from shuup_multivendor.signals import vendor_pre_save
from shuup_multivendor.utils.permissions import \
    get_vendor_permission_group_for_shop


class MultivendorUserListView(UserListView):
    default_columns = [
        Column("username", _("Username"), filter_config=TextFilter()),
        Column("email", _("Email"), filter_config=TextFilter()),
        Column("first_name", _("First Name"), filter_config=TextFilter()),
        Column("last_name", _("Last Name"), filter_config=TextFilter()),
        Column(
            "is_active", _("Active"),
            filter_config=ChoicesFilter([(False, _("no")), (True, _("yes"))], default=True)
        )
    ]

    def get_object_url(self, instance):
        return reverse_lazy("shuup_admin:multivendor_user.detail", kwargs=dict(pk=instance.pk))

    def get_queryset(self):
        qs = super(MultivendorUserListView, self).get_queryset()
        supplier = get_supplier(self.request)
        shop = get_shop(self.request)
        owner = SupplierUser.get_owner(supplier)
        if self.request.user != owner:
            qs = qs.exclude(vendor_users__is_owner=True)

        return qs.filter(
            vendor_users__shop=shop, vendor_users__supplier=supplier
        )


class MultivendorUserDetailToolbar(UserDetailToolbar):
    def _build_existing_user(self):
        user = self.user
        reset_password_button = DropdownItem(
            url=reverse("shuup_admin:multivendor_user.reset-password", kwargs={"pk": user.pk}),
            disable_reason=(_("User has no email address") if not getattr(user, 'email', '') else None),
            text=_("Send Password Reset Email"), icon="fa fa-envelope",
            required_permissions=["multivendor_user.reset-password"]
        )
        menu_items = [reset_password_button]
        person_contact = PersonContact.objects.filter(user=user).first()
        if person_contact:
            contact_url = reverse("shuup_admin:contact.detail", kwargs={"pk": person_contact.pk})
            menu_items.append(DropdownItem(
                url=contact_url,
                icon="fa fa-search",
                text=_("Contact Details"),
                required_permissions=["contact.detail"]
            ))

        self.append(DropdownActionButton(
            menu_items,
            icon="fa fa-star",
            text=_(u"Actions"),
            extra_css_class="btn-info",
        ))
        if not user.is_active:
            self.append(PostActionButton(
                post_url=self.request.path,
                name="set_is_active",
                value="1",
                icon="fa fa-check-circle",
                text=_(u"Activate User"),
                extra_css_class="btn-gray",
            ))
        else:
            self.append(PostActionButton(
                post_url=self.request.path,
                name="set_is_active",
                value="0",
                icon="fa fa-times-circle",
                text=_(u"Deactivate User"),
                extra_css_class="btn-gray",
            ))


class MultivendorUserDetailView(UserDetailView):
    def get_queryset(self):
        qs = super(MultivendorUserDetailView, self).get_queryset()
        supplier = get_supplier(self.request)
        shop = get_shop(self.request)
        owner = SupplierUser.get_owner(supplier)
        if self.request.user != owner:
            qs = qs.exclude(vendor_users__is_owner=True)

        return qs.filter(
            vendor_users__shop=shop, vendor_users__supplier=supplier
        )

    def get_return_url(self):
        return reverse_lazy("shuup_admin:multivendor_user.list")

    def get_new_url(self):
        return reverse_lazy("shuup_admin:multivendor_user.new")

    def get_success_url(self):  # noqa (C901)
        next_url = self.request.POST.get("__next")
        if next_url == "return":
            return self.get_return_url()
        elif next_url == "new":
            return self.get_new_url()

        return reverse_lazy("shuup_admin:multivendor_user.detail", kwargs=dict(pk=self.object.pk))

    @atomic
    def save_form(self, form):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        vendor_pre_save.send(
            sender=type(User), request=self.request, shop=shop, supplier=supplier, instance=self.object)
        super(MultivendorUserDetailView, self).save_form(form)
        supplier = get_supplier(self.request)
        shop = get_shop(self.request)
        user = self.object
        user.is_staff = True
        user.save()
        user.groups.add(get_vendor_permission_group_for_shop(shop))
        SupplierUser.objects.get_or_create(supplier=supplier, shop=shop, user=user)

    def get_toolbar(self):
        return MultivendorUserDetailToolbar(view=self)


class MultivendorUserResetPasswordView(UserResetPasswordView):
    def get_queryset(self):
        qs = super(MultivendorUserResetPasswordView, self).get_queryset()
        supplier = get_supplier(self.request)
        shop = get_shop(self.request)
        owner = SupplierUser.get_owner(supplier)
        if self.request.user != owner:
            qs = qs.exclude(vendor_users__is_owner=True)

        return qs.filter(
            vendor_users__shop=shop, vendor_users__supplier=supplier
        )
