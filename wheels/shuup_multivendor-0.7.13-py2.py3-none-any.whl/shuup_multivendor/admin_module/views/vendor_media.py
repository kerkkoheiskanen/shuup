# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

from django.db.models import Q
from django.db.transaction import atomic
from django.http.response import JsonResponse
from django.utils.encoding import force_text
from django.utils.translation import ugettext as _
from django.views.generic import View
from filer.models import File, Folder
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.permissions import has_permission
from shuup.core.models import MediaFile, MediaFolder, Supplier
from shuup.utils.filer import filer_file_from_upload, filer_image_from_upload

from shuup_multivendor.models import VendorMedia, VendorMediaKind


class VendorMediaBulkAdderView(View):
    """
    Adds media in bulk to a pre-existing vendor.
    """
    @atomic     # noqa(C901)
    def post(self, *args, **kwargs):
        ids = self.request.POST.getlist("file_ids")
        vendor_id = kwargs.pop("pk")
        kind = self.request.POST.get("kind")
        shop = self.request.shop

        if not ids or not vendor_id:
            return JsonResponse({"response": "error", "message": "bad request"}, status=400)

        if not has_permission(self.request.user, "shuup_multivendor.attach_media"):
            return JsonResponse({"response": "error", "message": "permission denied"}, status=403)

        is_staff_member = (self.request.user in shop.staff_members.all() or self.request.user.is_superuser)

        supplier = get_supplier(self.request)
        if not is_staff_member and (not supplier or str(supplier.pk) != str(vendor_id)):
            return JsonResponse({"response": "error", "message": "permission denied for this vendor"}, status=403)

        supplier = Supplier.objects.filter(pk=vendor_id, shops=shop).first()

        if not supplier:
            return JsonResponse({"response": "error", "message": "invalid vendor or shop"}, status=400)

        if kind == "images":
            kind = VendorMediaKind.IMAGE
        elif kind == "media":
            kind = VendorMediaKind.GENERIC_FILE
        else:
            return JsonResponse({"response": "error", "message": "invalid file kind: %s" % kind}, status=400)

        for file_id in ids:
            if not File.objects.filter(id=file_id).exists():
                return JsonResponse({"response": "error", "message": "invalid file id: %s" % file_id}, status=400)

        for file_id in ids:
            if not VendorMedia.objects.filter(vendor=vendor_id, file_id=file_id, kind=kind).exists():
                VendorMedia.objects.create(vendor_id=vendor_id, file_id=file_id, kind=kind)

        return JsonResponse({"response": "success", "message": force_text(_("Files added to vendor."))})


def _filer_file_to_json_dict(file):
    """
    :type file: filer.models.File
    :rtype: dict
    """
    assert file.is_public

    try:
        thumbnail = file.easy_thumbnails_thumbnailer.get_thumbnail({
            'size': (128, 128),
            'crop': True,
            'upscale': True,
            'subject_location': file.subject_location
        })
    except Exception:
        thumbnail = None
    return {
        "id": file.id,
        "name": file.label,
        "size": file.size,
        "url": file.url,
        "thumbnail": (thumbnail.url if thumbnail else None),
        "date": file.uploaded_at.isoformat()
    }


def _filer_folder_to_json_dict(folder, children=None):
    """
    :type file: filer.models.Folder|None
    :type children: list(filer.models.Folder)
    :rtype: dict
    """
    if folder and children is None:
        # This allows us to pass `None` as a pseudo root folder
        children = folder.get_children()
    return {
        "id": folder.pk if folder else 0,
        "name": folder.name if folder else _("Root"),
        "children": [_filer_folder_to_json_dict(child) for child in children]
    }


def _ensure_media_folder(shop, folder):
    media_folder, created = MediaFolder.objects.get_or_create(folder=folder)
    if not media_folder.shops.filter(id=shop.id).exists():
        media_folder.shops.add(shop)


def _get_folder_query_filter(shop):
    return Q(Q(media_folder__isnull=True) | Q(media_folder__shops__isnull=True) | Q(media_folder__shops=shop))


def _get_folder_query(shop, folder=None):
    queryset = Folder.objects.filter(_get_folder_query_filter(shop))
    if folder:
        queryset = queryset.filter(id=folder.id)
    return queryset


def _ensure_media_file(shop, file):
    media_file, created = MediaFile.objects.get_or_create(file=file)
    if not media_file.shops.filter(id=shop.id).exists():
        media_file.shops.add(shop)


def get_folder_name(folder):
    return (folder.name if folder else _("Root"))


def get_or_create_folder(shop, path):
    folders = path.split("/")
    parent = None
    child = None
    created = False
    for folder in folders:
        if folder != "":
            child, created = Folder.objects.get_or_create(parent=parent, name=folder)
            _ensure_media_folder(shop, child)
            parent = child
    return child


def media_upload(request, *args, **kwargs):
    """
    TODO: Add support for all shops of the vendor
    """
    shop = get_shop(request)
    try:
        folder_id = int(request.POST.get("folder_id") or request.GET.get("folder_id") or 0)
        path = request.POST.get("path") or request.GET.get("path") or None
        if folder_id != 0:
            folder = _get_folder_query(shop).get(pk=folder_id)
        elif path:
            folder = get_or_create_folder(shop, path)
        else:
            folder = None  # Root folder upload. How bold!
    except Exception as exc:
        return JsonResponse({"error": "Invalid folder: %s" % force_text(exc)})

    try:
        upload_file = request.FILES["file"]

        if upload_file.content_type.startswith("image/"):
            filer_file = filer_image_from_upload(request, path=folder, upload_data=upload_file)
        else:
            filer_file = filer_file_from_upload(request, path=folder, upload_data=upload_file)

        _ensure_media_file(shop, filer_file)
    except Exception as exc:
        return JsonResponse({"error": force_text(exc)})

    return JsonResponse({
        "file": _filer_file_to_json_dict(filer_file),
        "message": _("%(file)s uploaded to %(folder)s") % {
            "file": filer_file.label,
            "folder": get_folder_name(folder)
        }
    })
