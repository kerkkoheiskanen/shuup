# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from django.conf import settings
from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _

from shuup.admin.form_part import TemplatedFormDef
from shuup.admin.forms.widgets import TextEditorWidget
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.toolbar import NewActionButton, Toolbar
from shuup.admin.utils.urls import derive_model_url
from shuup.apps.provides import get_provide_objects
from shuup.simple_cms.admin_module.views import (
    PageForm, PageBaseFormPart,
    PageDeleteView, PageEditView, PageListView,
)
from shuup.simple_cms.models import Page


class MVPageForm(PageForm):
    class Meta:
        model = Page
        fields = [
            "title",
            "url",
            "content",
            "template_name"
        ]
        widgets = {
            "content": TextEditorWidget(attrs={"data-height": 500, "data-noresize": "true"})
        }

    def __init__(self, **kwargs):
        self.request = kwargs.pop("request")
        kwargs.setdefault("required_languages", ())  # No required languages here
        super(PageForm, self).__init__(**kwargs)
        del self.fields["available_from"]
        del self.fields["available_to"]

        self.fields["template_name"] = forms.ChoiceField(
            label=_("Template"),
            required=False,
            choices=[
                (simple_cms_template.template_path, simple_cms_template.name)
                for simple_cms_template in get_provide_objects("simple_cms_template")
            ]
        )

    def save(self, commit=True):
        self.instance.supplier = get_supplier(self.request)
        return super(MVPageForm, self).save(commit)


class MVPageBaseFormPart(PageBaseFormPart):
    def get_form_defs(self):
        yield TemplatedFormDef(
            self.name,
            MVPageForm,
            template_name="shuup_multivendor/admin/pages/_edit_base_page_form.jinja",
            required=True,
            kwargs={
                "instance": self.object,
                "languages": settings.LANGUAGES,
                "request": self.request
            }
        )

    def form_valid(self, form):
        is_new = bool(not self.object.pk)
        self.object = form[self.name].save()
        if not self.object.created_by:
            self.object.created_by = self.request.user
        self.object.modified_by = self.request.user
        if is_new and settings.SHUUP_MULTIVENDOR_REQUIRE_APPROVAL_FOR_CMS_PAGES:
            self.object.available_from = None
        self.object.save()


class MVPageEditView(PageEditView):
    base_form_part_classes = [MVPageBaseFormPart, ]

    def get_return_url(self):
        return reverse("shuup_admin:multivendor_simple_cms.page.edit", kwargs={"pk": self.object.pk})

    def get_new_url(self):
        return reverse("shuup_admin:multivendor_simple_cms.page.new")

    def get_delete_url(self):
        url = None
        if self.object.pk:
            url = reverse("shuup_admin:multivendor_simple_cms.page.delete", kwargs={"pk": self.object.pk})
        return url

    def get_success_url(self):
        return reverse("shuup_admin:multivendor_simple_cms.page.edit", kwargs={"pk": self.object.pk})

    def get_queryset(self):
        return super(MVPageEditView, self).get_queryset().filter(supplier=get_supplier(self.request))


class MVPageListView(PageListView):
    url_identifier = "multivendor_simple_cms.page"

    def get_object_url(self, instance):
        return derive_model_url(Page, "shuup_admin:multivendor_simple_cms.page", instance, "edit")

    def get_toolbar(self):
        toolbar = Toolbar()
        toolbar.append(NewActionButton(reverse("shuup_admin:multivendor_simple_cms.page.new")))
        toolbar.extend(Toolbar.for_view(self))
        return toolbar

    def get_queryset(self):
        return super(MVPageListView, self).get_queryset().filter(supplier=get_supplier(self.request))


class MVPageDeleteView(PageDeleteView):

    def get_queryset(self):
        return super(MVPageDeleteView, self).get_queryset().filter(supplier=get_supplier(self.request))

    def get_success_url(self):
        return reverse("shuup_admin:multivendor_simple_cms.page.list")
