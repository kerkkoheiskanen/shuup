import haversine from "haversine";


export function getVendorCoords(vendor) {
    return {
        latitude: parseFloat(vendor.contact_address.latitude),
        longitude: parseFloat(vendor.contact_address.longitude)
    };
}

export function getVendorDistance(vendor, fromLocation) {
    return haversine(getVendorCoords(vendor), fromLocation, {
        unit: (window.MULTIVENDOR_SETTINGS.distance_unit === "mi" ? "mile" : "km")
    });
}

export function getFormattedDistance(distance) {
    return interpolate("%s%s", [Number(distance).toFixed(1), window.MULTIVENDOR_SETTINGS.distance_unit])
}

export function geocodeLatLng(position, countries = []) {
    return new Promise((resolve, reject) => {
        const geocoder = new google.maps.Geocoder();
        const componentRestrictions = {};

        if (countries.length) {
            componentRestrictions.country = countries.join(",");
        }

        const cacheKey = interpolate("geocode:%s,%s", [position.lat, position.lng]);
        try {
            const cachedResults = window.localStorage.getItem(cacheKey);
            if (cachedResults) {
                resolve(JSON.parse(cachedResults));
                return;
            }
        } catch { }

        geocoder.geocode({ location: position, componentRestrictions }, (results, status) => {
            if (status == "OK") {
                try {
                    window.localStorage.setItem(cacheKey, JSON.stringify(results));
                } catch { }
                resolve(results);
            } else {
                reject(status);
            }
        });
    });
}

export function getBestGeocodeResult(results) {
    if (results.length === 0) {
        return null;
    }
    const roofTop = results.find(result => result.geometry && result.geometry.location_type == "ROOFTOP");
    const range = results.find(result => result.geometry && result.geometry.location_type == "RANGE_INTERPOLATED");
    const approx = results.find(result => result.geometry && result.geometry.location_type == "APPROXIMATE");
    return roofTop || range || approx || results[0];
}

export function refreshFiltersInPlace() {
    if (window.refreshFilters) {
        const scrollY = window.scrollY;
        window.refreshFilters();
        // do not scroll to product list here
        window.scrollTo(0, scrollY);
    }
}

export function updateCurrentLocationFilter(latitude, longitude) {
    // update products filters
    const locationStr = [latitude, longitude].join(",");
    $(".filter-location-field").val(locationStr);
    refreshFiltersInPlace();
}

export function setMapLocation(lat, lng) {
    if (window.VendorMap) {
        const position = { lat, lng };
        window.VendorMap.setUserPosition(position);
        window.VendorMap.setCenter(position);
        window.VendorMap.panToCenter();
    }
}
