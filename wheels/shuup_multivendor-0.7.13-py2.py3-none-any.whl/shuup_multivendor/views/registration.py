# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.contrib.auth import authenticate, get_user_model, login
from django.core.urlresolvers import reverse_lazy
from django.http.response import HttpResponseRedirect
from django.views.generic import FormView, TemplateView
from shuup.utils.importing import cached_load

from shuup_multivendor.utils.permissions import \
    ensure_vendor_permissions_for_shop


class VendorRegistrationView(FormView):
    template_name = "shuup_multivendor/supplier/registration.jinja"

    def get_form_class(self):
        return cached_load("SHUUP_MULTIVENDOR_VENDOR_REGISTRATION_FORM")

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated():
            return HttpResponseRedirect(reverse_lazy("shuup_admin:shuup_multivendor.dashboard.supplier"))
        return super(VendorRegistrationView, self).get(request, *args, **kwargs)

    def get_success_url(self):
        if self.request.user.is_authenticated():
            return reverse_lazy("shuup_admin:shuup_multivendor.dashboard.supplier")
        return reverse_lazy("shuup:vendor_registration_complete")

    def form_valid(self, form):
        new_user = form.save()
        # make the user created have correct permissions
        ensure_vendor_permissions_for_shop(self.request.shop)
        if new_user and new_user.is_active:
            authenticate(**{
                get_user_model().USERNAME_FIELD: new_user.get_username(),
                'password': form.cleaned_data["vendor_user"]['password1']
            })
            login(self.request, new_user)

        return super(VendorRegistrationView, self).form_valid(form)

    def get_form_kwargs(self):
        kwargs = super(VendorRegistrationView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs


class VendorRegistrationCompleteView(TemplateView):
    template_name = "shuup_multivendor/supplier/registration_complete.jinja"
