# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import pytest

from django.core import mail
from django.core.exceptions import ValidationError
from shuup.core.models import MutableAddress
from shuup.notify.models import Script
from shuup.testing import factories

from shuup_messages.models import Message


NOTIFICATION_STEP_DATA = [
    {
        "conditions": [
            {
                "identifier": "non_empty",
                "v": {"variable":"to_email"},
                "template_data": {}
            }
        ],
        "actions": [
            {
                "identifier": "send_email",
                "recipient": {
                    "variable": "to_email"},
                    "language": {"constant":"en"},
                    "template_data": {
                        "en": {
                            "subject": "New message received",
                            "body_template": "",
                            "body": "{{ message.message }}",
                            "content_type": "plain"
                        }
                    }
            }
        ],
        "next": "continue",
        "cond_op": "all",
        "enabled": "true"
    }
]


@pytest.mark.django_db
def test_message_notifications():
    shop = factories.get_default_shop()
    shop_email = "shop@exmple.com"
    shop_phone = "1239876"
    shop.contact_address = MutableAddress.objects.create(
        name="Olympic Stadium",
        street="1 Hellow World Street",
        city="LA",
        country="US",
        email=shop_email,
        phone=shop_phone
    )
    shop.save()

    supplier = factories.get_default_supplier()
    supplier_email = "supplier@exmple.com"
    supplier_phone = "5349876"
    supplier.contact_address = MutableAddress.objects.create(
        name="The Place",
        street="Where is this street?",
        city="Vancity",
        country="CA",
        email=supplier_email,
        phone=supplier_phone
    )
    supplier.save()
    
    sc = Script.objects.create(
        name="Message received",
        event_identifier="shuup_messages_message_received",
        enabled=True,
        shop=shop
    )
    sc.set_serialized_steps(NOTIFICATION_STEP_DATA)
    sc.save()

    n_outbox_pre = len(mail.outbox)
    # Supplier sends message to admin
    msg = Message.objects.create(from_supplier=supplier, to_shop=shop, message="hi!")
    assert len(mail.outbox) == n_outbox_pre + 1
    latest_mail = mail.outbox[-1]
    assert latest_mail.to[0] == shop_email
    assert latest_mail.subject == "New message received"
    assert latest_mail.body == "hi!"

    n_outbox_pre = len(mail.outbox)
    # Shop sends message back to supplier
    msg = Message.objects.create(from_shop=shop, to_supplier=supplier, message="hihi!")
    assert len(mail.outbox) == n_outbox_pre + 1
    latest_mail = mail.outbox[-1]
    assert latest_mail.to[0] == supplier_email
    assert latest_mail.subject == "New message received"
    assert latest_mail.body == "hihi!"

    contact = factories.create_random_person(shop=shop)
    assert contact.email

    n_outbox_pre = len(mail.outbox)
    # Supplier sends message to contact
    msg = Message.objects.create(from_supplier=supplier, to_contact=contact, message="hello world!")
    assert len(mail.outbox) == n_outbox_pre + 1
    latest_mail = mail.outbox[-1]
    assert latest_mail.to[0] == contact.email
    assert latest_mail.subject == "New message received"
    assert latest_mail.body == "hello world!"
