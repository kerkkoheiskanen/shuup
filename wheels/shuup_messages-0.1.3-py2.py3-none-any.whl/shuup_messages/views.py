# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic import TemplateView
from shuup.core.models import get_person_contact, OrderLine, Supplier
from shuup.front.views.dashboard import DashboardViewMixin

from shuup_messages.models import Message


class ContactVendorForm(forms.Form):
    name = forms.CharField(max_length=256)
    business_name = forms.CharField(max_length=256)
    email = forms.EmailField(max_length=256)
    phone_number = forms.CharField(max_length=64)
    message = forms.CharField(widget=forms.Textarea)

    def save(self, from_contact, to_shop=None, to_supplier=None):
        data = self.cleaned_data
        Message.objects.create(
            sender_name=data["name"],
            sender_phone=data["phone_number"],
            sender_email=data["email"],
            message=data["message"],
            from_contact=from_contact,
            to_shop=to_shop,
            to_supplier=to_supplier,
        )


class ContactVendorView(DashboardViewMixin, TemplateView):
    template_name = "shuup_messages/messages.jinja"

    def get_context_data(self, **kwargs):
        context = super(ContactVendorView, self).get_context_data(**kwargs)
        customer = get_person_contact(self.request.user)

        context["suppliers"] = list(Supplier.objects.filter(
            id__in=(
                OrderLine.objects.filter(
                    order__customer=customer, supplier__isnull=False
                ).values_list("supplier_id", flat=True)
            )
        ))

        return context

    @staticmethod
    def post(request):
        data = request.POST
        next = data.get("next", "/")

        form_data = {
            "name": data.get("name"),
            "business_name": data.get("business_name"),
            "email": data.get("email"),
            "phone_number": data.get("phone_number"),
            "message": data.get("message"),
        }

        form = ContactVendorForm(form_data)

        supplier_pk = data.get("supplier_pk")

        if supplier_pk == 'shop':
            supplier = None
        else:
            supplier = Supplier.objects.get(pk=supplier_pk)

        if form.is_valid():
            if supplier is None:
                form.save(to_shop=request.shop, from_contact=request.person)
                messages.success(request, _("Message sent to marketplace admin successfully!"))
            else:
                form.save(to_supplier=supplier, from_contact=request.person)
                messages.success(request, _("Message sent to vendor successfully!"))
        else:
            for field in form.errors:
                messages.error(request, _("Error in the following field: %(field)s") % {"field": field})

        return HttpResponseRedirect(next)
