# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_messages"
    label = "shuup_messages"
    provides = {
        "admin_module": [
            "shuup_messages.admin.MessageModule",
        ],
        "notify_event": [
            "shuup_messages.notify_events:MessageReceived",
        ],
        "customer_dashboard_items": [
            "shuup_messages.dashboard_items:MessagesDashboardItem"
        ],
        "front_urls": [
            "shuup_messages.urls:urlpatterns"
        ]
    }

    def ready(self):
        import shuup_messages.signal_handlers  # noqa: F401
