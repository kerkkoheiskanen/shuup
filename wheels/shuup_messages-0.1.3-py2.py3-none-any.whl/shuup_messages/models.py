# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.core.exceptions import ValidationError
from django.db import models
from django.utils.translation import ugettext_lazy as _
from jsonfield import JSONField
from shuup.utils.analog import define_log_model, LogEntryKind


class Message(models.Model):
    created_on = models.DateTimeField(auto_now_add=True, db_index=True)
    modified_on = models.DateTimeField(auto_now=True)

    message = models.TextField(verbose_name=_("message"))
    extra = JSONField(blank=True, null=True, verbose_name=_("extra"))

    from_shop = models.ForeignKey(
        "shuup.Shop", verbose_name=_("from shop"), related_name="sent_messages", null=True, blank=True)
    from_supplier = models.ForeignKey(
        "shuup.Supplier", verbose_name=_("from supplier"), related_name="sent_messages", null=True, blank=True)
    from_contact = models.ForeignKey(
        "shuup.Contact", verbose_name=_("from contact"), related_name="sent_messages", null=True, blank=True)

    to_shop = models.ForeignKey(
        "shuup.Shop", verbose_name=_("to shop"), related_name="received_messages", null=True, blank=True)
    to_supplier = models.ForeignKey(
        "shuup.Supplier", verbose_name=_("to supplier"), related_name="received_messages", null=True, blank=True)
    to_contact = models.ForeignKey(
        "shuup.Contact", verbose_name=_("to contact"), related_name="received_messages", null=True, blank=True)

    sender_name = models.CharField(max_length=256, blank=True, verbose_name=_('sender name'))
    sender_phone = models.CharField(max_length=64, blank=True, verbose_name=_('sender phone'))
    sender_email = models.EmailField(max_length=256, blank=True, verbose_name=_('sender email'))

    read = models.BooleanField(default=False, verbose_name=_("Read"))
    read_by = models.ForeignKey(
        "shuup.Contact", verbose_name=_("read by"), related_name="read_messages", null=True)

    deleted = models.BooleanField(default=False, verbose_name=("deleted"))

    def __str__(self):
        return _("Message #{id}").format(id=self.pk)

    def _validate(self):
        if not (self.from_shop or self.from_supplier or self.from_contact):
            raise ValidationError(_("Message is missing sender."))

        if not (self.to_shop or self.to_supplier or self.to_contact):
            raise ValidationError(_("Message is missing recipient."))

        if self.from_shop and self.from_supplier:
            raise ValidationError(_("Can not have both from shop and from supplier set for message."))

        if self.to_shop and self.to_supplier:
            raise ValidationError(_("Can not have both to shop and to supplier set for message."))

    def _ensure_sender_values(self):
        targets_to_source_fields = [
            ("sender_name", ["public_name", "name"]),
            ("sender_phone", ["phone"]),
            ("sender_email", ["email"])
        ]
        sources = [
            self.from_shop,
            (self.from_shop.contact_address if self.from_shop else None),
            self.from_supplier,
            (self.from_supplier.contact_address if self.from_supplier else None),
            self.from_contact,
        ]
        for target, source_fields in targets_to_source_fields:
            if not getattr(self, target, None):
                found_value = False
                for source in sources:
                    if not source or found_value:
                        continue

                    for source_field in source_fields:
                        if getattr(source, source_field, None):
                            setattr(self, target, getattr(source, source_field))
                            found_value = True
                            break

    def save(self, *args, **kwargs):
        self._validate()
        self._ensure_sender_values()
        return super(Message, self).save(*args, **kwargs)

    def delete(self, using=None):
        raise NotImplementedError("Not implemented: Use `soft_delete()` for messages.")

    def soft_delete(self, user=None):
        if not self.deleted:
            self.deleted = True
            self.add_log_entry("Deleted.", kind=LogEntryKind.DELETION, user=user)
            super(Message, self).save(update_fields=("deleted",))


MessageLogEntry = define_log_model(Message)
