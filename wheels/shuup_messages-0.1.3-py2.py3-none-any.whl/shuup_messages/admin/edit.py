# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from django.core.urlresolvers import reverse_lazy
from django.db.models import Q
from django.utils.translation import ugettext_lazy as _
from shuup.admin.forms.widgets import TextEditorWidget
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.toolbar import PostActionButton, Toolbar, URLActionButton
from shuup.admin.utils.views import CreateOrUpdateView
from shuup.core.models import Contact, get_person_contact, Shop, Supplier
from shuup.utils.analog import LogEntryKind

from shuup_messages.models import Message

FIXED_TARGET_KEYS = ["to_shop_id", "to_supplier_id", "to_contact_id"]


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        exclude = (
            "created_by", "modified_by", "to_contact",
            "from_shop", "from_supplier", "from_contact", "extra",
            "sender_name", "sender_phone", "sender_email", "read", "read_by",
            "deleted"
        )
        widgets = {
            "message": TextEditorWidget(attrs={"data-height": 600, "data-noresize": "true"})
        }

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop("request")
        self.supplier = get_supplier(self.request)
        self.shop = get_shop(self.request)
        found_target = False
        for target_key in FIXED_TARGET_KEYS:
            val = kwargs.pop(target_key, None)
            if val:
                setattr(self, target_key, val)
                found_target = True
                break

        super(MessageForm, self).__init__(*args, **kwargs)

        if not found_target:
            # No fixed target for this message so let's figure out available
            # options for shop staff or supplier.
            user = self.request.user
            if self.supplier:
                # We do not have fixed to_shop but supplier is selected.
                #
                # This means we allow current user to select shop to send
                # this message to.
                self.fields["to_shop"] = forms.ModelChoiceField(
                    label=_("To Shop"),
                    queryset=self.supplier.shops.all(),
                    required=False,
                )
            elif getattr(user, "is_superuser", False):
                pass  # Superuser can send to all suppliers
            else:
                self.fields.pop("to_shop")

            if self.shop and self.shop.staff_members.filter(id=self.request.user.pk).exists():
                # We do not have fixed to_supplier but this message is from
                # shop staff.
                #
                # This means we allow current user to select supplier to send
                # this message to.
                self.fields["to_supplier"] = forms.ModelChoiceField(
                    label=_("To Supplier"),
                    queryset=self.shop.suppliers.enabled(),
                    required=False,
                )
            elif getattr(user, "is_superuser", False):
                pass  # Superuser can send to all suppliers
            else:
                self.fields.pop("to_supplier")
        else:
            self.fields.pop("to_shop")
            self.fields.pop("to_supplier")

    def save(self, commit=True):
        for target_key in FIXED_TARGET_KEYS:
            val = getattr(self, target_key, None)
            if val:
                # Basically here we set fixed target for this message
                # which is originally passed through kwargs to this form
                setattr(self.instance, target_key, val)

        if self.shop and self.shop.staff_members.filter(id=self.request.user.pk).exists():
            self.instance.from_shop = self.shop
        elif self.supplier:
            self.instance.from_supplier = self.supplier
        self.instance.from_contact = get_person_contact(self.request.user)

        instance = super(MessageForm, self).save(commit)
        return instance


class MessageEditView(CreateOrUpdateView):
    model = Message
    form_class = MessageForm
    template_name = "shuup_messages/admin/edit.jinja"
    context_object_name = "messages"

    def get(self, request, *args, **kwargs):
        response = super(MessageEditView, self).get(request, *args, **kwargs)
        message = self.get_object()
        if message.pk:
            shop = get_shop(request)
            supplier = get_supplier(request)
            contact = get_person_contact(self.request.user)
            can_mark_as_read = False
            if shop and shop.staff_members.filter(id=request.user.pk).exists():
                can_mark_as_read = bool(shop == message.to_shop)
            elif supplier:
                can_mark_as_read = bool(shop == message.to_supplier)
            elif getattr(self.request.user, "is_superuser", False) and message.to_contact == contact:
                can_mark_as_read = True

            if can_mark_as_read:
                message.read = True
                message.read_by = get_person_contact(request.user)
                message.save(update_fields=("read", "read_by"))
                message.add_log_entry("Mark as read", kind=LogEntryKind.EDIT, user=request.user)

        return response

    def get_queryset(self):
        qs = Message.objects.filter(deleted=False)
        supplier = get_supplier(self.request)
        if supplier:
            qs = qs.filter(Q(to_supplier=supplier) | Q(from_supplier=supplier))

        shop = get_shop(self.request)
        if shop and shop.staff_members.filter(id=self.request.user.pk).exists():
            qs = qs.filter(Q(to_shop=shop) | Q(from_shop=shop))

        return qs

    def get_form_kwargs(self):
        kwargs = super(MessageEditView, self).get_form_kwargs()
        kwargs["request"] = self.request
        if self.kwargs["pk"] is None:
            for target_key in FIXED_TARGET_KEYS:
                val = self.kwargs.get(target_key, None)
                if val:
                    kwargs.update({target_key: val})
                    break

        return kwargs

    def get_context_data(self, **kwargs):
        context = super(MessageEditView, self).get_context_data()
        if self.kwargs["pk"] is None:
            for target_key in FIXED_TARGET_KEYS:
                val = self.kwargs.get(target_key, None)
                if val:
                    if target_key == "to_shop_id":
                        shop = Shop.objects.filter(id=val).first()
                        context.update({
                            "title": _("New message to %(target)s") % {"target": shop.public_name},
                            "with_list_url": reverse_lazy("shuup_admin:message.list_with_shop", kwargs={"pk": val})
                        })
                    elif target_key == "to_supplier_id":
                        supplier = Supplier.objects.filter(id=val).first()
                        context.update({
                            "title": _("New message to %(target)s") % {"target": supplier.name},
                            "with_list_url": reverse_lazy("shuup_admin:message.list_with_supplier", kwargs={"pk": val})
                        })
                    elif target_key == "to_contact_id":
                        contact_name = Contact.objects.filter(id=val).values_list("name", flat=True)[0]
                        context.update({
                            "title": _("New message to %(target)s") % {"target": contact_name},
                            "with_list_url": reverse_lazy("shuup_admin:message.list_with_contact", kwargs={"pk": val})
                        })
                    break
        return context

    def get_success_url(self):
        return reverse_lazy("shuup_admin:message.list")

    def get_toolbar(self):
        toolbar = Toolbar()
        message = self.get_object()
        if not message.pk:
            toolbar.append(PostActionButton(
                icon="fa fa-envelope",
                form_id="messages_form",
                text=_("Send"),
                extra_css_class="btn-success btn-save"
            ))

        if (self.request.GET.get("mode", "") != "iframe"):
            toolbar.append(URLActionButton(
                url=reverse_lazy("shuup_admin:message.list"),
                icon="fa fa-arrow-left",
                text=_("Back to messages"),
                extra_css_class="btn-primary",
                required_permissions="message.list"
            ))

        return toolbar
