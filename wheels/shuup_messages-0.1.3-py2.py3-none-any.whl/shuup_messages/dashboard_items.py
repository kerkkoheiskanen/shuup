# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from shuup.front.utils.dashboard import DashboardItem


class MessagesDashboardItem(DashboardItem):
    title = _("Messages")
    icon = "fa fa-envelope"
    _url = "shuup:contact_vendor"

    def show_on_menu(self):
        return settings.SHUUP_MESSAGES_SHOW_DASHBOARD_ITEM

    def show_on_dashboard(self):
        return False
