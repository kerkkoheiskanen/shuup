/**
 * This file is part of Shuup Multivendor.
 *
 * Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
 *
 * This source code is licensed under the OSL-3.0 license found in the
 * LICENSE file in the root directory of this source tree.
 */
const { getParcelBuildCommand, runBuildCommands } = require("shuup-static-build-tools");

runBuildCommands([
    getParcelBuildCommand({
        cacheDir: "shuup_multivendor",
        outputDir: "static/shuup_multivendor/",
        entryFile: "static_src/js/scripts.js",
        outputFileName: "scripts"
    }),
    getParcelBuildCommand({
        cacheDir: "shuup_multivendor",
        outputDir: "static/shuup_multivendor/",
        entryFile: "static_src/less/front.less"
    }),
    getParcelBuildCommand({
        cacheDir: "shuup_multivendor",
        outputDir: "static/shuup_multivendor/",
        entryFile: "static_src/js/map/index.js",
        outputFileName: "vendor-map"
    }),
    getParcelBuildCommand({
        cacheDir: "shuup_multivendor",
        outputDir: "static/shuup_multivendor/",
        entryFile: "static_src/less/vendor.less"
    }),
]);
