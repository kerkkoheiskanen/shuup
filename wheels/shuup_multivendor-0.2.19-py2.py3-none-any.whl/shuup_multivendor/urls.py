# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.conf.urls import url

from .views import (
    LoginView, SupplierView, VendorMapView, VendorRegistrationCompleteView,
    VendorRegistrationView
)

urlpatterns = [
    url(r"^login/$", LoginView.as_view(), name="login"),
    url(r"^v/register/$", VendorRegistrationView.as_view(), name="vendor_registration"),
    url(r"^v/register/complete/$", VendorRegistrationCompleteView.as_view(), name="vendor_registration_complete"),
    url(r"^v/map/$", VendorMapView.as_view(), name="vendor_map"),
    url(r"^v/(?P<pk>\d+)/$", SupplierView.as_view(), name="supplier"),
]


def model_url(context, model, absolute=False, **kwargs):
    from shuup.core.models import Supplier
    if isinstance(model, Supplier):
        from django.core.urlresolvers import reverse
        return reverse("shuup:supplier", kwargs=dict(pk=model.pk))
