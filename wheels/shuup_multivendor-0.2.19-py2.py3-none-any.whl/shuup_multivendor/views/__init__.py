# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from .login import LoginView
from .map import VendorMapView
from .registration import (
    VendorRegistrationCompleteView, VendorRegistrationView
)
from .vendor import SupplierView

__all__ = [
    "LoginView",
    "SupplierView",
    "VendorRegistrationView",
    "VendorRegistrationCompleteView",
    "VendorMapView"
]
