# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from shuup.core import cache
from shuup.core.signals import context_cache_item_bumped  # noqa
from shuup.core.utils import context_cache

CHEAPEST_SUPPLIER_CACHE_KEY = "cheapest_supplier_price_{shop_id}_{product_id}"


def get_cached_cheapest_supplier(shop_id, product_id):
    return cache.get(CHEAPEST_SUPPLIER_CACHE_KEY.format(shop_id=shop_id, product_id=product_id))


def cache_cheapest_supplier(shop_id, product_id, supplier):
    key = CHEAPEST_SUPPLIER_CACHE_KEY.format(shop_id=shop_id, product_id=product_id)
    cache.set(key, supplier)


def bump_cheapest_supplier(shop_id, product_id):
    cache.bump_version(CHEAPEST_SUPPLIER_CACHE_KEY.format(shop_id=shop_id, product_id=product_id))


def bump_storefront_caches(shop):
    from shuup.front.utils import cache as cache_utils
    context_cache.bump_cache_for_item(cache_utils.get_listed_products_cache_item(shop))
    context_cache.bump_cache_for_item(cache_utils.get_best_selling_products_cache_item(shop))
    context_cache.bump_cache_for_item(cache_utils.get_newest_products_cache_item(shop))
    context_cache.bump_cache_for_item(cache_utils.get_products_for_category_cache_item(shop))
    context_cache.bump_cache_for_item(cache_utils.get_random_products_cache_item(shop))
