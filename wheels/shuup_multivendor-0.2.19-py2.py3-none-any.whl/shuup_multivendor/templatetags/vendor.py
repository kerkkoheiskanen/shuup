# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from __future__ import unicode_literals

import django_jinja
import jinja2
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _

from shuup_multivendor.models import DayOfTheWeek
from shuup_multivendor.supplier_provider import get_supplier

WEEKDAY_MAP = {
    index: choice[0]
    for index, choice in enumerate(DayOfTheWeek.choices())
}


@django_jinja.library.global_function
def get_vendor_address_lines(address):
    if not address:
        return []
    lines = [
        address.street,
        address.street2,
        address.street3,
        address.city,
        address.region,
        address.region_code,
        address.postal_code
    ]
    lines = [line for line in lines if line]
    return lines


@django_jinja.library.global_function
@jinja2.contextfunction
def get_current_vendor(context):
    return get_supplier(context["request"])


@django_jinja.library.global_function
def render_vendor_opening_hours(supplier):
    if not supplier.options or not supplier.options.get("opening_periods"):
        return ""

    opening_periods = supplier.options["opening_periods"]
    weekday = WEEKDAY_MAP[now().weekday()]
    periods = [opening_period for opening_period in opening_periods if opening_period["day_of_week"] == weekday]
    periods.sort(key=lambda period: period["start"])

    if not periods:
        return ""

    return _("Opening hours: {periods}").format(
        periods=", ".join(["{}-{}".format(period["start"], period["end"]) for period in periods])
    )
