# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_multivendor"
    verbose_name = "Shuup Multivendor"
    label = "shuup_multivendor"
    provides = {
        "admin_module": [
            "shuup_multivendor.dashboards:SalesDashboardModule",
            "shuup_multivendor.admin_module:MultivendorProductsAdminModule",
            "shuup_multivendor.admin_module:MultivendorOrdersAdminModule",
            "shuup_multivendor.admin_module:MultivendorVendorAdminModule",
            "shuup_multivendor.admin_module:VendorSettingsAdminModule"
        ],
        "pricing_module": [
            "shuup_multivendor.pricing:SupplierPricingModule"
        ],
        "reports": [
            "shuup_multivendor.reports:ProductReport",
            "shuup_multivendor.reports:FullVendorSalesReport",
            "shuup_multivendor.reports:VendorSalesReport",
            "shuup_multivendor.reports:VendorSummaryReport"
        ],
        "xtheme_plugin": [
            "shuup_multivendor.plugins:SupplierLinksPlugin",
            "shuup_multivendor.plugins:VendorMapFilterPlugin"
        ],
        "xtheme_resource_injection": [
            "shuup_multivendor.plugins:add_resources",
            "shuup_multivendor.resources:add_multivendor_resources"
        ],
        "front_urls": [
            "shuup_multivendor.urls:urlpatterns"
        ],
        "front_model_url_resolver": [
            "shuup_multivendor.urls.model_url"
        ],
        "xtheme_layout": [
            "shuup_multivendor.layouts.SupplierLayout",
            "shuup_multivendor.layouts.SupplierProductLayout"
        ],
        "admin_shop_form_part": [
            "shuup_multivendor.admin_module.form_parts.vendor.VendorConfigurationFormPart"
        ],
        "admin_vendor_product_form_part": [
            "shuup_multivendor.admin_module.form_parts.simple_supplier:SimpleSupplierFormPart"
        ],
        "notify_event": [
            "shuup_multivendor.notify_events:VendorRegistered",
            "shuup_multivendor.notify_events:VendorApproved",
            "shuup_multivendor.notify_events:VendorOrderReceived",
            "shuup_multivendor.notify_events:OrderLineStatusChanged",
            "shuup_multivendor.notify_events:AllOrderLinesCompleted",
            "shuup_multivendor.notify_events:VendorOrderCompleted"
        ],
        "multivendor_order_line_list_mass_actions_provider": [
            "shuup_multivendor.admin_module.mass_actions:OrderLineCreateShipmentMassActionProvider"
        ],
        "admin_order_section": [
            "shuup_multivendor.admin_module.sections:MultivendorOrderDetailsSection"
        ],
        "front_extend_product_list_form": [
            "shuup_multivendor.product_list_modifiers:VendorDistanceProductListFilter",
            "shuup_multivendor.product_list_modifiers:VendorMapFilter"
        ]
    }

    def ready(self):
        # connect signals
        import shuup_multivendor.notify_events  # noqa
        import shuup_multivendor.signal_handlers  # noqa
