# -*- coding: utf-8 -*-
from decimal import Decimal

from django import forms
from django.conf import settings
from django.templatetags.static import static
from django.utils.translation import ugettext_lazy as _
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.image import ImageIDField
from shuup.xtheme.resources import add_resource


class VendorMapFilterPlugin(TemplatedPlugin):
    identifier = "multivendor_vendor_map_filter"
    name = _("Vendor Map")
    template_name = "shuup_multivendor/plugins/vendor_map.jinja"
    fields = [
        ("distance_unit", forms.ChoiceField(
            required=True,
            choices=[
                ("mile", _("Miles")),
                ("km", _("Kilometers")),
            ],
            label=_("Distance unit"),
            initial="mile",
            help_text=_("Select the unit to use when displaying distances.")
        )),
        ("initial_map_position", forms.CharField(
            required=True,
            label=_("Fallback map position coordinates"),
            help_text=_(
                "Enter a pair of GPS coordinates that will be used as the fallback position "
                "on the map when the user location is not available using the format: latitude, longitude."
            )
        )),
        ("custom_pin", ImageIDField(
            required=False,
            label=_("Custom map pin"),
            help_text=_("Select an image to use as the vendor pin.")
        )),
        ("map_height", forms.IntegerField(required=True, label=_("Map height in pixels"), initial=400, min_value=1)),
        ("show_filter_alert", forms.BooleanField(
            required=False,
            label=_("Show filter info"),
            initial=True,
            help_text=_("Show the filter alert info when browsing the selected vendor products.")
        )),
        ("default_map_zoom", forms.IntegerField(required=False, label=_("Default map zoom"), initial=15)),
        ("init_map_collapsed", forms.BooleanField(
            required=False,
            label=_("Initialize the map collapsed"),
            initial=True
        ))
    ]

    def get_context_data(self, context):
        custom_pin = self.config.get("custom_pin")
        customer_location = None

        if custom_pin:
            from filer.models import Image
            custom_pin = Image.objects.filter(pk=custom_pin).first()

        request = context["request"]
        if request.customer:
            address_field = "default_{}".format(settings.SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS)
            address = getattr(request.customer, address_field, None)
            if address and address.latitude and address.longitude:
                customer_location = dict(
                    lat=Decimal(address.latitude),
                    lng=Decimal(address.longitude)
                )

        current_vendor = context.get("supplier")
        map_height = self.config.get("map_height")
        return {
            "vendor_map_settings": {
                "gmaps_api_key": settings.SHUUP_MULTIVENDOR_GOOGLE_MAPS_KEY,
                "custom_pin": custom_pin.url if custom_pin else None,
                "distance_unit": self.config.get("distance_unit"),
                "initial_map_position": self.config.get("initial_map_position"),
                "map_height": "{}px".format(map_height) if map_height else None,
                "current_vendor": current_vendor.pk if current_vendor else None,
                "show_filter_alert": self.config.get("show_filter_alert", True),
                "default_map_zoom": self.config.get("default_map_zoom", 15),
                "init_map_collapsed": self.config.get("init_map_collapsed", True)
            },
            "customer_location": customer_location
        }

    def render(self, context):
        add_resource(context, "head_end", "%s?v=0.2.19.css" % static("shuup_multivendor/vendor-map.css"))
        add_resource(context, "body_end", "%s?v=0.2.19.js" % static("shuup_multivendor/vendor-map.js"))
        return super(VendorMapFilterPlugin, self).render(context)
