# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.core.urlresolvers import reverse
from django.utils.translation import ugettext_lazy as _
from shuup.utils.i18n import format_money
from shuup.xtheme import TemplatedPlugin
from shuup.xtheme.plugins.forms import TranslatableField

from shuup_multivendor.models import SupplierPrice


class SupplierLinksPlugin(TemplatedPlugin):
    identifier = "shuup_multivendor_product_supplier_links"
    name = _("Vendor Options To Product Detail")
    template_name = "shuup_multivendor/plugins/product_supplier_links.jinja"
    required_context_variables = ["shop_product", "supplier"]

    fields = [
        ("title", TranslatableField(
            label=_("Title"),
            required=False,
            initial=_("Also Supplied By:")
        ))
    ]

    def get_context_data(self, context):
        context = dict(context)
        shop_product = context["shop_product"]
        supplier = context["supplier"]
        suppliers_data = []
        prices_query = SupplierPrice.objects.filter(
            product=shop_product.product,
            shop=shop_product.shop,
            supplier__enabled=True,
            supplier__shop_products__id=shop_product.id
        ).exclude(supplier=supplier).order_by("amount_value")
        for supplier_price in prices_query:
            url = reverse(
                "shuup:supplier-product", kwargs={
                    "supplier_pk": supplier_price.supplier.pk,
                    "pk": supplier_price.product.pk,
                    "slug": supplier_price.product.slug
                }
            )
            suppliers_data.append((url, supplier_price.supplier.name, format_money(supplier_price.amount)))

        return {
            "title": self.get_translated_value("title"),
            "suppliers_data": suppliers_data
        }
