# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import itertools
from decimal import Decimal

from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.pricing import TaxfulPrice, TaxlessPrice
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import format_number

from shuup_multivendor.reports.utils import OrderMixin, OrderReportForm


class VendorSalesReport(OrderMixin, ShuupReportBase):
    identifier = "multivendor_sales_report"
    title = _("Vendor Sales Report")
    form_class = OrderReportForm

    filename_template = "sales-report-%(time)s"
    schema = [
        {"key": "text", "title": _("Product")},
        {"key": "product_count", "title": _("Count")},
        {"key": "quantity", "title": _("Quantity")},
        {"key": "taxless_total", "title": _("Taxless Total")},
        {"key": "taxful_total", "title": _("Taxful Total")},
    ]

    def extract_name(self, entity):
        return entity.text

    def get_data(self):
        order_lines = self.get_objects().order_by("-order__order_date")
        self.shop = get_shop(self.request)  # TODO: ensure shop is set properly

        data = []
        # # TODO: maybe make raw sql query in future
        for product_name, order_lines in itertools.groupby(order_lines, key=self.extract_name):
            taxless_total = TaxlessPrice(0, currency=self.shop.currency)
            taxful_total = TaxfulPrice(0, currency=self.shop.currency)
            product_count = 0
            quantity = Decimal()

            for line in order_lines:
                quantity += line.quantity
                taxless_total += line.taxless_price
                taxful_total += line.taxful_price
                product_count += line.quantity

            data.append({
                "text": product_name,
                "quantity": format_number(quantity),
                "product_count": int(product_count),
                "taxless_total": taxless_total.as_rounded().value,
                "taxful_total": taxful_total.as_rounded().value,
            })

        return self.get_return_data(data)
