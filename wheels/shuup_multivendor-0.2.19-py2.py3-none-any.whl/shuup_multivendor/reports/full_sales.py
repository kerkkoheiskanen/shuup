# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.reports.report import ShuupReportBase
from shuup.utils.i18n import format_number, get_locally_formatted_datetime

from shuup_multivendor.reports.utils import OrderMixin, OrderReportForm


class FullVendorSalesReport(OrderMixin, ShuupReportBase):
    identifier = "multivendor_full_sales_report"
    title = _("Vendor Full Sales Report")
    form_class = OrderReportForm

    filename_template = "vendor-full-sales-report-%(time)s"
    schema = [
        {"key": "order", "title": _("Order")},
        {"key": "date", "title": _("Date")},
        {"key": "customer_name", "title": _("Customer Name")},
        {"key": "text", "title": _("Product")},
        {"key": "quantity", "title": _("Quantity")},
        {"key": "taxless_total", "title": _("Taxless Total")},
        {"key": "taxful_total", "title": _("Taxful Total")},
    ]

    def get_data(self):
        order_lines = self.get_objects().order_by("-order__order_date")
        self.shop = get_shop(self.request)  # TODO: ensure shop is set properly

        data = []
        for line in order_lines:
            data.append({
                "order": str(line.order_id),
                "date": get_locally_formatted_datetime(line.order.order_date),
                "customer_name": line.order.get_customer_name(),
                "text": line.text,
                "quantity": format_number(line.quantity),
                "taxless_total": line.taxless_price.as_rounded().value,
                "taxful_total": line.taxful_price.as_rounded().value,
            })
        return self.get_return_data(data)
