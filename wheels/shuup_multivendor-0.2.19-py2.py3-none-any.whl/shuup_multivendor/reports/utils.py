# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django import forms
from django.db.models import Q
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.core.models import Category, Order, OrderLine, Product, ProductMode
from shuup.reports.forms import BaseReportForm, ShuupReportForm
from shuup.utils.dates import to_datetime_range

from shuup_multivendor.supplier_provider import get_supplier


class OrderReportForm(BaseReportForm):
    def __init__(self, *args, **kwargs):
        super(OrderReportForm, self).__init__(*args, **kwargs)
        self.fields["shop"] = forms.CharField(initial=get_shop(self.request).id, widget=forms.HiddenInput())


class ProductReportForm(ShuupReportForm):
    category = forms.ChoiceField(
        required=False, label=_("Category"), help_text=_("Filter results by category"))
    product = forms.ChoiceField(
        required=False, label=_("Product"), help_text=_("Filter results by product"))

    def __init__(self, *args, **kwargs):
        super(ProductReportForm, self).__init__(*args, **kwargs)

        shop = get_shop(self.request)
        categories = Category.objects.filter(shops=shop).distinct()
        self.fields["category"].choices = [(None, "---")] + [
            (category.pk, category.safe_translation_getter("name")) for category in categories
        ]

        supplier = get_supplier(self.request)
        products = Product.objects.filter(
            mode__in=[ProductMode.VARIATION_CHILD, ProductMode.NORMAL],
            shop_products__suppliers=supplier
        ).distinct()
        self.fields["product"].choices = [(None, "---")] + [
            (product.pk, product.safe_translation_getter("name")) for product in products
        ]


class OrderMixin(object):
    def get_objects(self):
        if self.start_date and self.end_date:
            (start, end) = to_datetime_range(self.start_date, self.end_date)
            queryset = Order.objects.filter(
                shop=self.shop, order_date__range=(start, end))
        else:
            queryset = Order.objects.filter(shop=self.shop)
        creator = self.options.get("creator")
        orderer = self.options.get("orderer")
        customer = self.options.get("customer")
        filters = Q()
        if creator:
            filters &= Q(creator__in=creator)
        if orderer:
            filters &= Q(orderer__in=orderer)
        if customer:
            filters &= Q(customer__in=customer)

        supplier = get_supplier(self.request)
        orders = queryset.filter(filters).complete().valid().order_by("-order_date")
        return OrderLine.objects.filter(order__in=orders, supplier=supplier)
