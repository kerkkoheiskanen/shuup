# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django.conf import settings
from django.db.models.signals import post_save
from shuup.core.models import PersonContact, Supplier

from shuup_multivendor.utils.geocode import (
    ensure_address_geoposition, recalculate_contact_distances,
    recalculate_vendor_distances
)


def vendor_post_save(sender, instance, raw, created, **kwargs):
    # TODO: move this to an async task queue
    if instance.contact_address and ensure_address_geoposition(instance.contact_address):
        recalculate_vendor_distances(instance)


def contact_post_save(sender, instance, raw, created, **kwargs):
    # TODO: move this to an async task queue
    address_field = "default_{}".format(settings.SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS)
    address = getattr(instance, address_field, None)
    if address and ensure_address_geoposition(address):
        recalculate_contact_distances(instance)


post_save.connect(vendor_post_save, sender=Supplier, dispatch_uid="multivendor_vendor_post_save")
post_save.connect(contact_post_save, sender=PersonContact, dispatch_uid="multivendor_contact_post_save")
