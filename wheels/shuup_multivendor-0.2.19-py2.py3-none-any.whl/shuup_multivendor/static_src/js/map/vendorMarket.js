import m from "mithril";

const VendorMarkerContent = {
    view(vnode) {
        return (
            m(".html-marker", m(".vendor-name", vnode.attrs.vendor.name))
        )
    }
};

function createVendorMarker({ vendor, position, icon, map }) {
    const latlng = new google.maps.LatLng(position.lat, position.lng);

    class VendorMarker extends window.google.maps.OverlayView {
        constructor() {
            super();

            this.vendor = vendor;
            this.icon = icon;
            this.latlng = latlng;
            this.opacity = 1;
            this.zindex = 1;

            this.pin = new window.google.maps.Marker({ position, icon, id: vendor.id })
            google.maps.event.addDomListener(this.pin, 'click', event => {
                google.maps.event.trigger(this, 'click');
            });

            this.setMap(map);
        }
        onAdd() {
            this.div = document.createElement('div');
            this.div.style.position = "absolute";
            google.maps.event.addDomListener(this.div, 'click', event => {
                google.maps.event.trigger(this, 'click');
            });
            const panes = this.getPanes();
            panes.overlayLayer.appendChild(this.div);
        }
        setMap(map) {
            super.setMap(map);
            this.pin.setMap(map);
            this.map = map;
        }
        draw() {
            const point = this.getProjection().fromLatLngToDivPixel(this.latlng);
            this.div.style.left = `${point.x}px`;
            this.div.style.top = `${point.y}px`;
            this.div.style.zIndex = this.zindex;
            this.div.style.opacity = this.opacity;
            this.pin.setZIndex(this.zindex);
            this.pin.setOpacity(this.opacity);
            m.render(this.div, m(VendorMarkerContent, { vendor }));
        }
        onRemove() {
            this.div.parentNode.removeChild(this.div);
            this.div = null;
        }
        getPosition() {
            return this.latlng;
        }
        getDraggable() {
            return false;
        }
        setZIndex(zindex) {
            this.zindex = zindex;
        }
        setIcon(icon) {
            this._icon = icon;
            this.pin.setIcon(icon);
        }
        setOpacity(opacity) {
            this.opacity = opacity;
        }
        getOpacity() {
            return this.opacity;
        }
        getZIndex() {
            return this.zindex;
        }
    }
    return new VendorMarker();
}

export default createVendorMarker;
