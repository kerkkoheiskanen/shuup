# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import datetime
from functools import reduce

from django.contrib.auth import get_user_model
from django.db import connection
from django.db.models import Count, Sum
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from shuup.admin.dashboard import (
    DashboardContentBlock, DashboardMoneyBlock, DashboardNumberBlock
)
from shuup.admin.modules.sales_dashboard.dashboard import (
    get_orders_by_currency
)
from shuup.core.models import Category, Order, Shop, ShopProduct
from shuup.core.pricing import TaxlessPrice

from shuup_multivendor.supplier_provider import get_supplier


def get_vendor_block(request):
    return DashboardNumberBlock(
        id="vendor_count_block",
        color="orange",
        title=_("Vendors"),
        value=Shop.objects.count(),
        icon="fa fa-user",
        subtitle=_("All time")
    )


def registered_users_block(request, hours_ago=48):
    past = timezone.localtime(timezone.now()) - datetime.timedelta(hours=hours_ago)
    objs = get_user_model().objects.filter(date_joined__gte=past).values_list("pk", flat=True)
    return DashboardNumberBlock(
        id="registered_users_block",
        color="orange",
        title=_("New users"),
        value=len(set(objs)),
        icon="fa fa-user",
        subtitle=_("past %(number_of_hours)s hours") % {"number_of_hours": hours_ago}
    )


def get_recent_orders_block(request, currency, title, hours_ago=24, mode="non_completed"):
    orders = get_orders_by_currency(currency)

    if mode == "non_delivered":
        orders = orders.incomplete()
    elif mode == "non_completed":
        orders = orders.all()

    past = timezone.localtime(timezone.now()) - datetime.timedelta(hours=hours_ago)

    orders = orders.filter(created_on__gte=past)
    if not request.user.is_superuser:
        supplier = get_supplier(request)
        orders = orders.filter(shop=request.shop, lines__supplier=supplier)

    block = DashboardNumberBlock(
        id="recent_orders_%s" % mode,
        color="orange",
        title=title,
        value=orders.count(),
        icon="fa fa-user",
        subtitle=_("Recent %(type)s orders in the past %(number_of_hours)s hours") % {
            "type": mode.replace("_", " "), "number_of_hours": hours_ago}
    )
    return block


def get_favorite_categories_block(request, shop_id, supplier, order_ids):
    block = DashboardContentBlock.by_rendering_template(
        "favorite_categories",
        request,
        "shuup_multivendor/admin/dashboard/favorite_categories_block.jinja", {
            "categories": _get_favorite_categories(shop_id, supplier, order_ids),
            "title": _("Top Categories")
        }
    )
    block.size = "small"
    return block


def get_favorite_products_block(request, shop_id, supplier, order_ids):
    block = DashboardContentBlock.by_rendering_template(
        "favorite_products",
        request,
        "shuup_multivendor/admin/dashboard/favorite_products_block.jinja", {
            "shop_products": _get_favorite_shop_products(shop_id, supplier, order_ids),
            "title": _("Top Products")
        }
    )
    block.size = "medium"
    return block


def get_new_customers_block(shop_id, order_ids, supplier, cutoff_date):
    return DashboardNumberBlock(
        id="new_customers_block",
        color="orange",
        title=_("New Customers"),
        value=_get_new_customers(shop_id, supplier, cutoff_date),
        icon="fa fa-user",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def get_returning_customers_block(shop_id, order_ids, supplier, cutoff_date):
    return DashboardNumberBlock(
        id="new_customers_block",
        color="orange",
        title=_("Returning Customers"),
        value=_get_returning_customers(shop_id, order_ids, supplier, cutoff_date),
        icon="fa fa-user",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def get_lifetime_sales_block(order_ids, supplier, currency="USD"):
    return DashboardMoneyBlock(
        id="lifetime_sales_sum",
        color="green",
        title=_("Total Sales"),
        value=(_get_lifetime_sales(order_ids, supplier, currency) or 0),
        currency=currency,
        icon="fa fa-line-chart",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def get_avg_purchase_size_block(order_ids, supplier, currency="USD"):
    return DashboardMoneyBlock(
        id="average_purchase_sum",
        color="blue",
        title=_("Average Sales Amount"),
        value=(_get_avg_purchase_size(order_ids, supplier, currency) or 0),
        currency=currency,
        icon="fa fa-shopping-cart",
        subtitle=_("based on %s orders") % len(order_ids)
    )


def _get_favorite_categories(shop_id, supplier, order_ids):
    return Category.objects.filter(
        shop_products__shop_id=shop_id,
        shop_products__product__order_lines__order_id__in=order_ids,
        shop_products__product__order_lines__supplier=supplier
    ).annotate(
        total_sales=Count('shop_products__product__order_lines__quantity')
    ).order_by('-total_sales')[:20]


def _get_favorite_shop_products(shop_id, supplier, order_ids):
    return ShopProduct.objects.filter(
        shop_id=shop_id,
        product__order_lines__order__id__in=order_ids,
        product__order_lines__supplier=supplier
    ).annotate(
        total_sales=Sum('product__order_lines__quantity')
    ).order_by('-total_sales')[:20]


def _get_new_customers(shop_id, supplier, cutoff_date):
    query = """
        SELECT COUNT(pc.contact_ptr_id)
        FROM shuup_personcontact as pc
        WHERE %s < (
            SELECT o.order_date
            FROM shuup_order as o, shuup_orderline as ol
            WHERE o.id = ol.order_id  
            AND pc.contact_ptr_id = o.customer_id 
            AND o.shop_id = %s 
            AND ol.supplier_id = %s
            ORDER BY o.order_date ASC
            LIMIT 1
        )
    """.strip()  # noqa
    cursor = connection.cursor()
    cursor.execute(query, [cutoff_date, shop_id, supplier.id])
    return cursor.fetchone()[0]


def _get_returning_customers(shop_id, order_ids, supplier, cutoff_date):
    return len(order_ids) - _get_new_customers(shop_id, supplier, cutoff_date)


def _get_lifetime_sales(order_ids, supplier, currency):
    taxless_total = TaxlessPrice(0, currency)
    for order in Order.objects.filter(id__in=order_ids):
        for line in order.lines.filter(supplier=supplier):
            taxless_total += line.taxless_price
    return taxless_total


def _get_avg_purchase_size(order_ids, supplier, currency):
    prices = []
    for order in Order.objects.filter(id__in=order_ids):
        for line in order.lines.filter(supplier=supplier):
            prices.append(line.taxless_price)
    return reduce(lambda x, y: x + y, prices) / len(prices)
