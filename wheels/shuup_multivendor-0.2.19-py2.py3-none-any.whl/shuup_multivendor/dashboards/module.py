# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import datetime

from django.contrib.auth import get_user_model
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule
from shuup.admin.currencybound import CurrencyBound
from shuup.admin.dashboard import DashboardNumberBlock
from shuup.admin.modules.sales_dashboard.dashboard import (
    get_orders_by_currency
)
from shuup.admin.utils.urls import admin_url
from shuup.core.models import Shop


class SalesDashboardModule(CurrencyBound, AdminModule):
    name = _("Vendor Sales Dashboard")

    def get_dashboard_blocks(self, request):
        currency = self.currency
        if not currency:
            shop = request.shop
            currency = shop.currency

        if request.user.is_superuser:
            # vendors
            yield get_vendor_block(request)
        # new users
        yield registered_users_block(request)
        title = _("New Orders")
        yield get_recent_orders_block(request, "USD", title)

        title = _("In Delivery")
        yield get_recent_orders_block(request, "USD", title, mode="non_delivered")

    def get_urls(self):
        return [
            admin_url(
                r'^multivendor/dashboard/$',
                "shuup_multivendor.admin_module.views.SupplierDashboardView",
                name='shuup_multivendor.dashboard.supplier'
            )
        ]


def get_vendor_block(request):
    return DashboardNumberBlock(
        id="vendor_count_block",
        color="orange",
        title=_("Vendors"),
        value=Shop.objects.count(),
        icon="fa fa-user",
        subtitle=_("All time")
    )


def registered_users_block(request, hours_ago=48):
    past = timezone.localtime(timezone.now()) - datetime.timedelta(hours=hours_ago)
    objs = get_user_model().objects.filter(date_joined__gte=past).values_list("pk", flat=True)
    return DashboardNumberBlock(
        id="registered_users_block",
        color="orange",
        title=_("New users"),
        value=len(set(objs)),
        icon="fa fa-user",
        subtitle=_("past %(number_of_hours)s hours") % {"number_of_hours": hours_ago}
    )


def get_recent_orders_block(request, currency, title, hours_ago=24, mode="non_completed"):
    orders = get_orders_by_currency(currency)

    if mode == "non_delivered":
        orders = orders.incomplete()
    elif mode == "non_completed":
        orders = orders.all()

    past = timezone.localtime(timezone.now()) - datetime.timedelta(hours=hours_ago)

    orders = orders.filter(created_on__gte=past)
    if not request.user.is_superuser:
        orders = orders.filter(shop=request.shop)

    block = DashboardNumberBlock(
        id="recent_orders_%s" % mode,
        color="orange",
        title=title,
        value=orders.count(),
        icon="fa fa-user",
        subtitle=_("Recent %(type)s orders in the past %(number_of_hours)s hours") % {
            "type": mode.replace("_", " "), "number_of_hours": hours_ago}
    )
    return block
