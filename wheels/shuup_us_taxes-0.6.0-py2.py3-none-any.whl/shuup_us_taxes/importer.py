# -*- coding: utf-8 -*-
import csv
import decimal
import glob
import os
from collections import defaultdict

from django.conf import settings
from django.db.transaction import atomic
from django.http.response import JsonResponse
from django.utils import translation
from django.utils.text import slugify

from shuup.core.models import Tax, TaxClass
from shuup.default_tax.models import TaxRule


class TaxImporter(object):

    def __init__(self):
        self.original_language = translation.get_language()
        self.country_code = "US"
        identifier = settings.USA_TAX_DEFAULT_TAX_IDENTIFIER
        self.tax_class, _ = TaxClass.objects.update_or_create(identifier=identifier, defaults={
            "name": "Product Sales Tax",
        })
        additional_ids = settings.USA_TAX_ADDITIONAL_TAX_CLASS_IDENTIFIERS
        self.additional_tax_classes = list(TaxClass.objects.filter(identifier__in=additional_ids))

        self.data_path = os.path.join(os.path.dirname(__file__), "taxes")
        translation.activate(settings.PARLER_DEFAULT_LANGUAGE_CODE)

        self.range_by_tax_code = {}
        self.processed_codes = set()

    @atomic
    def import_taxes(self):
        """
        Import US taxes to Shuup

        Disable all taxes and tax rules that can not be found from
        the tax material that is present in ../taxes data.

        :return: JSONResponse indicating the end result of this import
        """
        try:
            # Read all tax ranges from tax data
            self._get_range_by_tax_area_mapping()
            # Mark all taxes and rax rules disabled
            Tax.objects.update(enabled=False)
            TaxRule.objects.update(enabled=False)
            self._process_tax_data()
            return JsonResponse({"success": "OK!"})
        except Exception:
            from raven.contrib.django.raven_compat.models import client
            client.captureException()
        finally:
            translation.activate(self.original_language)

    def _get_range_by_tax_area_mapping(self):
        for file in glob.glob("%s/*.csv" % self.data_path):
            zip_codes = defaultdict(list)
            seen_zip_codes_for_state = defaultdict(list)
            with open(file) as fp:
                records = csv.DictReader(fp)
                for row in records:
                    state = row.get("State")
                    city = row.get("TaxRegionName")
                    rate = decimal.Decimal(row.get("EstimatedCombinedRate"))
                    code = _get_tax_code_from_csv_row(self.country_code, state, city, rate)
                    zip_code = int(row.get("ZipCode"))
                    zip_codes[code].append(zip_code)
                    if zip_code in seen_zip_codes_for_state[state]:
                        raise Exception("Duplicate zip codes for state.")
                    seen_zip_codes_for_state[state].append(zip_code)

            for code, list_of_zip_codes in zip_codes.items():
                ranged = []
                for start, stop in _get_range(sorted(list_of_zip_codes)):
                    if start == stop:
                        ranged.append(start)
                    else:
                        ranged.append("%d-%d" % (start, stop))
                self.range_by_tax_code[code] = ",".join(map(str, ranged))

    def _process_tax_data(self):
        for file in glob.glob("%s/*.csv" % self.data_path):
            with open(file) as fp:
                records = csv.DictReader(fp)
                for i, row in enumerate(records):
                    self._process_tax_row_in_csv(row)

    def _process_tax_row_in_csv(self, data):
        state = data.get("State")
        city = data.get("TaxRegionName")

        # Just to make sure compare individual taxes to combined rate
        rate = decimal.Decimal(data.get("EstimatedCombinedRate"))
        rate_county = decimal.Decimal(data.get("EstimatedCountyRate"))
        rate_city = decimal.Decimal(data.get("EstimatedCityRate"))
        rate_special = decimal.Decimal(data.get("EstimatedSpecialRate"))
        rate_state = decimal.Decimal(data.get("StateRate"))
        combined = sum([rate_state, rate_county, rate_city, rate_special])
        assert combined == rate, "Rate %s and combined %s did not match" % (rate, combined)
        assert rate is not None

        # create tax
        name = "Sales Tax - %s, %s" % (city.title(), state)
        if len(name) > 128:
            raise Exception("Tax name too long %s" % (len(name)))

        code = _get_tax_code_from_csv_row(self.country_code, state, city, rate)
        if code in self.processed_codes:
            return
        if len(code) > 64:
            raise Exception("Tax code too long %s" % len(code))

        tax, _ = Tax.objects.update_or_create(code=code, defaults={"name": name, "enabled": True, "rate": rate})

        zip_codes_range = self.range_by_tax_code[code]
        rule, tax_rule_created = TaxRule.objects.update_or_create(
            country_codes_pattern=self.country_code,
            region_codes_pattern=state,
            postal_codes_pattern=zip_codes_range,
            tax=tax,
            defaults={
                "enabled": True
            }
        )
        if tax_rule_created:
            for tx in self.additional_tax_classes:
                rule.tax_classes.add(tx)
            rule.tax_classes.add(self.tax_class)

        self.processed_codes.add(code)


def _get_range(lst):
    last = None
    span_start = None
    for value in lst:
        if span_start is not None and value > last + 1:
            yield (span_start, last)
            span_start = None
        if span_start is None:
            span_start = value
        last = value
    yield (span_start, last)


def _get_tax_code_from_csv_row(country_code, state, city, rate):
    return ("%s-%s-%s-%s" % (country_code, state, rate, slugify(city))).replace(".", "")[:64]
