# -​*- coding: utf-8 -*​-
import shuup.apps


class AppConfig(shuup.apps.AppConfig):
    name = "shuup_us_taxes"
    provides = {
        "admin_module": [
            "shuup_us_taxes.admin_module:USTaxesAdminModule"
        ]
    }
