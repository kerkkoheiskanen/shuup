# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import logging
from functools import lru_cache

from django.conf import settings
from django.contrib import messages
from django.core.urlresolvers import reverse
from django.http.response import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from django.views.generic.base import TemplateView, View
from shuup.admin.shop_provider import get_shop
from shuup.admin.toolbar import Toolbar, URLActionButton
from shuup.utils.excs import Problem

logger = logging.getLogger(__name__)


@lru_cache()
def get_sync_objects_providers(shop):
    from shuup.apps.provides import get_provide_objects
    from shuup_quickbooks.constants import QUICKBOOKS_SYNC_OBJECTS_PROVIDER_PROVIDES_KEY
    return [
        objects_provider(shop)
        for objects_provider in get_provide_objects(QUICKBOOKS_SYNC_OBJECTS_PROVIDER_PROVIDES_KEY)
    ]


class QuickBooksSessionViewMixin(object):
    def get(self, request, *args, **kwargs):
        from shuup_quickbooks.utils import has_valid_configs
        if not has_valid_configs():
            raise Problem(_("Check your QuickBooks settings."))
        return super(QuickBooksSessionViewMixin, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super(QuickBooksSessionViewMixin, self).get_context_data(**kwargs)
        from shuup_quickbooks.utils import get_valid_session_manager
        sesion_manager = get_valid_session_manager(self.request)
        context.update({
            "sesion_manager": sesion_manager,
            "is_authorized": (sesion_manager is not None)
        })
        return context


class AuthorizeView(View):
    def get(self, request, *args, **kwargs):
        from shuup_quickbooks.utils import get_auth_session_manager, save_auth_in_session
        code = request.GET.get("code")
        company_id = request.GET.get("company_id")

        if code and company_id:
            session_manager = get_auth_session_manager()
            request_result = session_manager.get_access_tokens(code)

            if request_result:
                messages.error(request, _("Authorization failed."))
                logger.error("QuickBook authorization failed: %s", request_result)
            else:
                save_auth_in_session(request, company_id, session_manager)

        return HttpResponseRedirect(reverse("shuup_admin:shuup_quickbooks.settings"))


class DisconnectView(View):
    def post(self, request, *args, **kwargs):
        from shuup_quickbooks.utils import clear_auth_session
        clear_auth_session(request)
        return HttpResponseRedirect(reverse("shuup_admin:shuup_quickbooks.settings"))


class SettingsView(QuickBooksSessionViewMixin, TemplateView):
    template_name = "shuup_quickbooks/admin/settings.jinja"

    def get_context_data(self, **kwargs):
        context = super(SettingsView, self).get_context_data(**kwargs)
        context["is_new"] = False

        if context.get("is_authorized"):
            from shuup_quickbooks.utils import get_quickbooks_from_session
            context["toolbar"] = self.get_toolbar()
            context["quickbooks"] = get_quickbooks_from_session(self.request, load_preferences=True, load_company=True)
        else:
            from shuup_quickbooks.utils import get_auth_session_manager
            session_manager = get_auth_session_manager()
            authorize_url = self.request.build_absolute_uri(reverse("shuup_admin:shuup_quickbooks.authorize"))
            callback_url = settings.QUICKBOOKS_AUTH_CALLBACK_URL or reverse("shuup:quickbooks.auth_callback")
            auth_url = session_manager.get_authorize_url(callback_url, state=authorize_url)
            context["authorize_url"] = auth_url
        return context

    def get_toolbar(self):
        toolbar = Toolbar()
        toolbar.append(
            URLActionButton(
                reverse("shuup_admin:shuup_quickbooks.sync"),
                text=_("Synchronize"),
                icon="fa fa-refresh",
                extra_css_class="btn-primary"
            )
        )
        return toolbar


class SyncView(QuickBooksSessionViewMixin, TemplateView):
    template_name = "shuup_quickbooks/admin/sync.jinja"

    def get_used_providers(self):
        """
        Check whether there is something to sync, if so, return False
        """
        shop = get_shop(self.request)
        providers = []
        for sync_objects_provider in get_sync_objects_providers(shop):
            for exists in sync_objects_provider.get_sync_objects():
                providers.append(sync_objects_provider)
                break
        return providers

    def get_context_data(self, **kwargs):
        context = super(SyncView, self).get_context_data(**kwargs)
        context.update({
            "title": _("QuickBooks Synchronization"),
            "sync_url": reverse("shuup_admin:shuup_quickbooks.sync"),
            "shop": get_shop(self.request),
            "used_providers": self.get_used_providers()
        })
        return context

    def post(self, request, *args, **kwargs):
        from shuup_quickbooks.utils import get_valid_session_manager
        from shuup_quickbooks.synchronizer import QuickBooksSynchronizer, SyncError

        session_manager = get_valid_session_manager(request)
        if not session_manager:
            messages.error(request, _("Not connected to QuickBooks."))
            return HttpResponseRedirect(reverse("shuup_admin:shuup_quickbooks.settings"))

        quickbooks_auth = request.session.get("quickbooks_auth")
        synchronizer = QuickBooksSynchronizer(get_shop(self.request), quickbooks_auth["company_id"], session_manager)
        sync_results = list(synchronizer.synchronize())
        sync_errors = [sync_result for sync_result in sync_results if isinstance(sync_result, SyncError)]

        # some sync error occurred
        if sync_errors:
            msg = _("Couldn't synchronize {objects_count} object(s).").format(objects_count=len(sync_errors))
            messages.error(request, msg)

        return self.get(request, *args, **kwargs)

    def get(self, request, *args, **kwargs):
        from shuup_quickbooks.utils import get_valid_session_manager
        # we don't have a valid session, so redirect to settings
        if not get_valid_session_manager(request):
            messages.error(request, _("Not connected to QuickBooks."))
            return HttpResponseRedirect(reverse("shuup_admin:shuup_quickbooks.settings"))

        return super(SyncView, self).get(request, *args, **kwargs)
