# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

QUICKBOOKS_SYNC_OBJECTS_PROVIDER_PROVIDES_KEY = "quickbooks_sync_objects_provider"
QUICKBOOKS_OBJECT_SYNCHRONIZER_PROVIDES_KEY = "quickbooks_object_synchronizer"
