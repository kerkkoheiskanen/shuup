# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

# QuickBooks API Client ID
QUICKBOOKS_CLIENT_ID = None

# QuickBooks API Client Secret
QUICKBOOKS_CLIENT_SECRET = None

# QuickBooks Sandbox Mode
QUICKBOOKS_SANDBOX_MODE = False

# QuickBooks Authorization Redirect URI
QUICKBOOKS_AUTH_CALLBACK_URL = ""
