# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from quickbooks import QuickBooks as BaseQuickBooks
from quickbooks.objects import CompanyInfo
from quickbooks.objects.base import QuickbooksReadOnlyObject


class SyncError(Exception):
    def __init__(self, message, sync_object, code=None):
        super(SyncError, self).__init__()
        self.message = message
        self.sync_object = sync_object
        self.code = code


class SyncSuccess(object):
    def __init__(self, sync_object, synced_object):
        self.sync_object = sync_object
        self.synced_object = synced_object


class Preferences(QuickbooksReadOnlyObject):
    """
    Preferences object that is not included in python-quickbooks
    """
    qbo_object_name = "Preferences"
    TaxPrefs = None


class QuickBooks(BaseQuickBooks):
    preferences = Preferences()
    company_info = CompanyInfo()

    def __init__(self, **kwargs):
        super(QuickBooks, self).__init__()

        if Preferences.qbo_object_name not in self._BUSINESS_OBJECTS:
            self._BUSINESS_OBJECTS.append(Preferences.qbo_object_name)

        if kwargs.get("load_preferences"):
            self._load_preferences()

        if kwargs.get("load_company"):
            self._load_company()

    def _load_preferences(self):
        preferences = Preferences.all(qb=self)
        if preferences:
            self.preferences = preferences[0]

    def _load_company(self):
        companies = CompanyInfo.all(qb=self)
        if companies:
            self.company_info = companies[0]

    @property
    def ast_enabled(self):
        # AST = Automated Sales Tax
        return self.preferences and self.preferences.TaxPrefs and ("PartnerTaxEnabled" in self.preferences.TaxPrefs)

    @property
    def using_sales_tax(self):
        return self.preferences and self.preferences.TaxPrefs and self.preferences.TaxPrefs.get("UsingSalesTax", False)


class BaseSyncObjectProvider(object):
    # Description of what objects this provides
    # This will be presented to users
    description = None

    def __init__(self, shop, **kwargs):
        self.shop = shop

    def get_sync_objects(self, **kwargs):
        """
        Return an iterator of objects that needs to be synchronized
        """
        return []


class BaseObjectSynchronizer(object):
    # set the synchronization priority for this synchronizer
    # useful when this should run after other known synchronizers
    priority = 0

    def __init__(self, synchronizer):
        self.synchronizer = synchronizer

    def synchronize_object(self, sync_object, **kwargs):
        """
        Returns None if or a SyncError instance when the sync fails
        Returns SyncSuccess when the sync
        """
        return None
