# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import Order

from .objects import BaseSyncObjectProvider


class DefaultSyncObjectProvider(BaseSyncObjectProvider):
    def _get_queryset(self):
        return Order.objects.complete().filter(shop=self.shop, quickbooks_sync__isnull=True)

    def get_sync_objects(self, **kwargs):
        return self._get_queryset()

    @property
    def description(self):
        return _("{orders_count} fully completed order(s)").format(orders_count=self._get_queryset().count())
