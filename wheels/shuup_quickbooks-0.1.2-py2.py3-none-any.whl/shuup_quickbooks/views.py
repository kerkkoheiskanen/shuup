# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import logging
import urllib.parse as urlparse
from urllib.parse import urlencode

from django.core.urlresolvers import reverse
from django.http.response import HttpResponseRedirect
from django.views.generic.base import View

logger = logging.getLogger(__name__)


class AuthCallbackView(View):
    def get(self, request, *args, **kwargs):
        """
        As QuickBooks should have a fixed list of URIs to be the auth callback,
        this view will receive the params in ANY shop domain and will
        redirect them to the correct Admin page, in order to save them
        in the correct request session.
        """
        code = request.GET.get("code")
        company_id = request.GET.get("realmId")
        state = request.GET.get("state")    # this will contain the original shop admin URL to redirect to

        if code and company_id and state:
            params = dict(company_id=company_id, code=code)
            url_parts = list(urlparse.urlparse(state))
            query = dict(urlparse.parse_qsl(url_parts[4]))
            query.update(params)
            url_parts[4] = urlencode(query)
            redirect = urlparse.urlunparse(url_parts)

            return HttpResponseRedirect(redirect)

        # fail
        return HttpResponseRedirect(reverse("shuup_admin:shuup_quickbooks.settings"))
