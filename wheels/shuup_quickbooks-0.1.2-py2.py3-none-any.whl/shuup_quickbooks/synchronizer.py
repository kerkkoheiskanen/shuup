# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import logging
from decimal import Decimal
from functools import lru_cache

from django.conf import settings
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from quickbooks.objects import Account, Address, Customer, EmailAddress, Item
from quickbooks.objects import PaymentMethod as QBPaymentMethod
from quickbooks.objects import (
    PhoneNumber, Ref, SalesItemLine, SalesItemLineDetail, SalesReceipt,
    TaxAgency, TaxCode, TaxRate, TaxRateDetails, TaxService, TxnTaxDetail,
    WebAddress
)
from shuup.apps.provides import get_provide_objects
from shuup.core.models import OrderLineType, PersonContact
from shuup.utils.i18n import format_percent
from shuup.utils.money import Money

from shuup_quickbooks.constants import (
    QUICKBOOKS_OBJECT_SYNCHRONIZER_PROVIDES_KEY,
    QUICKBOOKS_SYNC_OBJECTS_PROVIDER_PROVIDES_KEY
)
from shuup_quickbooks.models import (
    QuickBooksSyncContact, QuickBooksSyncOrder, QuickBooksSyncPaymentMethod
)
from shuup_quickbooks.objects import (
    BaseObjectSynchronizer, SyncError, SyncSuccess
)
from shuup_quickbooks.signals import post_sync_object, pre_sync_object

logger = logging.getLogger(__name__)


def get_ref(value):
    ref = Ref()
    ref.name = None
    ref.type = None
    ref.value = value
    return ref


OrderLineTypeMap = {
    OrderLineType.PRODUCT: _("Sales"),
    OrderLineType.REFUND: _("Refund"),
    OrderLineType.PAYMENT: _("Payment"),
    OrderLineType.SHIPPING: _("Shipping"),
    OrderLineType.ROUNDING: _("Rounding"),
    OrderLineType.DISCOUNT: _("Discount")
}


class QuickBooksSynchronizer(object):
    def __init__(self, shop, company_id, session_manager):
        from shuup_quickbooks.objects import QuickBooks
        self.shop = shop
        self.session_manager = session_manager
        self.client = QuickBooks(
            company_id=company_id,
            sandbox=settings.QUICKBOOKS_SANDBOX_MODE,
            session_manager=session_manager,
            minorversion=4,
            load_preferences=True,
            load_company=True
        )

        # instantiate provides
        self.sync_objects_providers = [
            objects_provider(shop)
            for objects_provider in get_provide_objects(QUICKBOOKS_SYNC_OBJECTS_PROVIDER_PROVIDES_KEY)
        ]
        self.object_synchronizers = [
            object_synchronizer(self)
            for object_synchronizer in get_provide_objects(QUICKBOOKS_OBJECT_SYNCHRONIZER_PROVIDES_KEY)
        ]

    def synchronize(self):
        # first iterate over all object providers, they will
        # yield all objects needed to be synchronized
        for sync_object_provider in self.sync_objects_providers:

            # iterate over all objects that need to be synchronized for this object provider
            for sync_object in sync_object_provider.get_sync_objects():
                # signal that we started to sync this object
                pre_sync_object.send(sender=type(self), instance=sync_object, synchronizer=self)

                synchronizers = [object_synchronizer for object_synchronizer in self.object_synchronizers]
                # sort them by an order
                synchronizers.sort(key=lambda sync: sync.priority)

                # now, iterate over all object synchronizers, one should know how to synchronize this object
                for object_synchronizer in synchronizers:
                    sync_result = object_synchronizer.synchronize_object(sync_object)

                    if sync_result is None:
                        continue

                    yield sync_result

                    # if the sync was successful, we don't need to continue iterating over the others
                    if isinstance(sync_result, SyncSuccess):
                        post_sync_object.send(
                            sender=type(self),
                            instance=sync_object,
                            synced_object=sync_result.synced_object,
                            synchronizer=self
                        )
                        break


class DefaultQuickBooksObjectSynchronizer(BaseObjectSynchronizer):
    """
    The default QuickBooks synchronizer just know how to deal with Shuup.Order
    """
    def synchronize_object(self, sync_object, **kwargs):
        from shuup.core.models import Order
        if isinstance(sync_object, Order):
            try:
                synced_order = self._get_synced_order(sync_object)
                return SyncSuccess(sync_object, synced_order)
            except Exception as exc:
                logger.exception(exc)
                return SyncError(force_text(exc), sync_object)

        return None

    @lru_cache()
    def _get_default_tax_agency(self):
        if TaxAgency.qbo_object_name not in self.synchronizer.client._BUSINESS_OBJECTS:
            self.synchronizer.client._BUSINESS_OBJECTS.append(TaxAgency.qbo_object_name)

        name = force_text(_("Shuup Calculated Taxes"))
        tax_agencies = TaxAgency.filter(Name=name, qb=self.synchronizer.client)
        if tax_agencies:
            return tax_agencies[0]

        tax_agency = TaxAgency()
        tax_agency.DisplayName = name
        tax_agency.save(qb=self.synchronizer.client)
        return tax_agency

    @lru_cache()
    def _get_default_income_account(self):
        # get the default account for Income
        accounts = Account.where(
            "AccountType = 'Income' and AccountSubType = 'SalesOfProductIncome'",
            max_results=1,
            qb=self.synchronizer.client
        )
        if accounts:
            return accounts[0]

        account = Account()
        account.Name = force_text(_("Sales of Product Income"))
        account.Classification = "Revenue"
        account.AccountType = "Income"
        account.AccountSubType = "SalesOfProductIncome"
        account.save(qb=self.synchronizer.client)
        return account

    @lru_cache()
    def _get_default_asset_account(self):
        # get the default account for Inventory
        accounts = Account.where(
            "AccountType = 'Other Current Asset' and AccountSubType = 'Inventory'",
            max_results=1,
            qb=self.synchronizer.client
        )
        if accounts:
            return accounts[0]

        account = Account()
        account.Name = force_text(_("Inventory Asset"))
        account.Classification = "Asset"
        account.AccountType = "Other Current Asset"
        account.AccountSubType = "Inventory"
        account.save(qb=self.synchronizer.client)
        return account

    def _get_synced_contact(self, contact):
        # already synced
        if hasattr(contact, "quickbooks_sync") and contact.quickbooks_sync:
            return get_ref(contact.quickbooks_sync.quickbooks_id)

        # make sure we don't duplicate customers
        customers = Customer.filter(FullyQualifiedName=contact.full_name, qb=self.synchronizer.client)
        if customers:
            return customers[0].to_ref()

        customer = Customer()

        if isinstance(contact, PersonContact):
            customer.GivenName = contact.first_name
            customer.FamilyName = contact.last_name
        else:
            customer.CompanyName = contact.name

        customer.Suffix = contact.suffix
        customer.FullyQualifiedName = contact.full_name
        customer.Notes = contact.merchant_notes
        customer.Active = contact.is_active
        customer.Taxable = True

        if contact.default_billing_address:
            customer.BillAddr = self._get_address_object(contact.default_billing_address)

        if contact.default_shipping_address:
            customer.ShipAddr = self._get_address_object(contact.default_shipping_address)

        if contact.phone:
            customer.PrimaryPhone = PhoneNumber()
            customer.PrimaryPhone.FreeFormNumber = contact.phone

        if contact.email:
            customer.PrimaryEmailAddr = EmailAddress()
            customer.PrimaryEmailAddr.Address = contact.email

        if contact.www:
            customer.WebAddr = WebAddress()
            customer.WebAddr.URI = contact.www

        customer.save(qb=self.synchronizer.client)

        QuickBooksSyncContact.objects.create(contact=contact, quickbooks_id=customer.Id)

        return get_ref(customer.Id)

    @lru_cache()
    def _get_anonymous_customer(self):
        name = force_text(_("Anonymous"))
        customers = Customer.filter(DisplayName=name, qb=self.synchronizer.client)

        if customers:
            return customers[0].to_ref()

        customer = Customer()
        customer.DisplayName = name
        customer.save(qb=self.synchronizer.client)
        return customer.to_ref()

    def _get_synced_order(self, order):
        # already synced
        if hasattr(order, "quickbooks_sync") and order.quickbooks_sync:
            return get_ref(order.quickbooks_sync.quickbooks_id)

        sale = SalesReceipt()
        sale.Line = [line for line in [self._get_line_object(order_line) for order_line in order.lines.all()] if line]
        sale.DocNumber = order.id
        sale.TxnDate = order.order_date.isoformat()
        sale.CurrencyRef = get_ref(order.currency)
        sale.ApplyTaxAfterDiscount = False
        sale.GlobalTaxCalculation = "TaxExcluded"

        tax_summary = order.get_tax_summary()
        if tax_summary:
            tax_total = Money(currency=order.shop.currency)

            for tax in tax_summary:
                tax_total += tax.tax_amount

            sale.TxnTaxDetail = TxnTaxDetail()
            sale.TxnTaxDetail.TotalTax = force_text(tax_total.value)

            """
            Manage sales tax for US locales
            # no-qa
            https://developer.intuit.com/docs/00_quickbooks_online/2_build/60_tutorials/0061_manage_sales_tax_for_us_locales#/Overriding_Sales_Tax

            Overriding Sales Tax

            To override automatic sales tax calculation, supply the following at create time:
                - Your value via the TxnTaxDetail.TotalTax attribute
                - The tax code via the TxnTaxDetail.TxnTaxCodeRef attribute

            For companies using automated sales tax, TxnTaxDetail.TotalTax amount is honored.
            Supplied tax amount is prorated across associated tax rates in the AST-assigned tax code.
            TxnTaxDetail.TxnTaxCodeRef passed in with the request is overridden with an AST-assigned tax code.
            """
            zero = Money(0, currency=order.shop.currency)
            if tax_total > zero and self.synchronizer.client.company_info.Country == "US":
                from shuup.core.models import Tax
                taxes = Tax.objects.filter(id__in=[tax.tax_id for tax in tax_summary])
                sale.TxnTaxDetail.TxnTaxCodeRef = self._get_tax_code_for_taxes(taxes)

        if order.email:
            sale.BillEmail = EmailAddress()
            sale.BillEmail.Address = order.email

        if order.billing_address:
            sale.BillAddr = self._get_address_object(order.billing_address)

        if order.shipping_address:
            sale.ShipAddr = self._get_address_object(order.shipping_address)

        if order.customer:
            sale.CustomerRef = self._get_synced_contact(order.customer)
        else:
            # as the order MUST contain a customer
            # get or create the default anonymous customer
            sale.CustomerRef = self._get_anonymous_customer()

        if order.payment_method:
            sale.PaymentMethodRef = self._get_synced_payment_method(order.payment_method)

        sale.save(qb=self.synchronizer.client)

        # link the order
        QuickBooksSyncOrder.objects.create(order=order, quickbooks_id=sale.Id)

        return sale

    @lru_cache()
    def _fetch_tax_code_by_name(self, name):
        tax_codes = TaxCode.filter(Name=name, qb=self.synchronizer.client)
        if tax_codes:
            return tax_codes[0]

    @lru_cache()
    def _get_synced_sales_tax_rate(self, name):
        tax_rates = TaxRate.filter(Name=name, qb=self.synchronizer.client)
        if tax_rates:
            return tax_rates[0]

    def _get_tax_code_for_taxes(self, taxes):
        total_rate = sum([tax.rate for tax in taxes])
        tax_ids = sorted([str(tax.id) for tax in taxes])
        tax_code_name = force_text(_("{tax_rate_perc} ({tax_ids})").format(
            tax_rate_perc=format_percent(total_rate, 2),
            tax_ids="-".join(tax_ids)
        ))

        tax_code = self._fetch_tax_code_by_name(tax_code_name)
        if tax_code:
            return get_ref(tax_code.Id)

        tax_service = TaxService()
        tax_service.TaxCode = tax_code_name

        for tax in taxes:
            rate_details = TaxRateDetails()
            tax_rate = self._get_synced_sales_tax_rate(tax.code)

            if tax_rate:
                rate_details.TaxRateId = tax_rate.Id
            else:
                rate_details.TaxRateName = tax.code

            rate_details.RateValue = force_text(tax.rate * Decimal(100))
            rate_details.TaxAgencyId = self._get_default_tax_agency().Id
            rate_details.TaxApplicableOn = "Sales"

            tax_service.TaxRateDetails.append(rate_details)

        tax_service.save(qb=self.synchronizer.client)

        self._fetch_tax_code_by_name.cache_clear()
        self._get_synced_sales_tax_rate.cache_clear()

        tax_codes = TaxCode.filter(Name=tax_code_name, qb=self.synchronizer.client)
        if tax_codes:
            return get_ref(tax_codes[0].Id)

    @lru_cache()
    def _get_tax_code_for_non_taxed(self):
        tax_code_name = force_text(_("Zero-rated"))
        tax_code = self._fetch_tax_code_by_name(tax_code_name)
        if tax_code:
            return get_ref(tax_code.Id)

        tax_service = TaxService()
        tax_service.TaxCode = tax_code_name

        rate_details = TaxRateDetails()
        zero_tax_rate_name = force_text(_("Zero"))

        tax_rate = self._get_synced_sales_tax_rate(zero_tax_rate_name)
        if tax_rate:
            rate_details.TaxRateId = tax_rate.Id
        else:
            rate_details.TaxRateName = zero_tax_rate_name

        rate_details.RateValue = "0"
        rate_details.TaxAgencyId = self._get_default_tax_agency().Id
        rate_details.TaxApplicableOn = "Sales"
        tax_service.TaxRateDetails.append(rate_details)
        tax_service.save(qb=self.synchronizer.client)

        tax_codes = TaxCode.filter(Name=tax_code_name, qb=self.synchronizer.client)
        if tax_codes:
            return get_ref(tax_codes[0].Id)

    @lru_cache()
    def _get_synced_payment_method(self, payment_method):
        # already synced
        if hasattr(payment_method, "quickbooks_sync") and payment_method.quickbooks_sync:
            return get_ref(payment_method.quickbooks_sync.quickbooks_id)

        # check whether is there some payment method with same name to avoid duplicates
        payment_methods = QBPaymentMethod.filter(Name=payment_method.name, qb=self.synchronizer.client)
        if payment_methods:
            qb_payment_method = payment_methods[0]
        else:
            qb_payment_method = QBPaymentMethod()
            qb_payment_method.Name = payment_method.name
            qb_payment_method.save(qb=self.synchronizer.client)

        # link payment method
        QuickBooksSyncPaymentMethod.objects.get_or_create(
            payment_method=payment_method,
            quickbooks_id=qb_payment_method.Id
        )

        return get_ref(qb_payment_method.Id)

    def _get_line_object(self, order_line):
        line = SalesItemLine()
        line.Description = order_line.text

        line.DetailType = "SalesItemLineDetail"
        line_detail = SalesItemLineDetail()
        line.SalesItemLineDetail = line_detail

        line_detail.Qty = order_line.quantity
        line_detail.ItemRef = self._get_line_item_object(order_line.type)
        line_detail.DiscountAmt = force_text(order_line.taxful_discount_amount.value)
        line_detail.TaxInclusiveAmt = force_text(order_line.taxful_price.value)

        """
        Manage tax for Non-US locales
        # no-qa
        https://developer.intuit.com/docs/00_quickbooks_online/2_build/60_tutorials/0060_manage_sales_tax_for_non-us_locales#/Overriding_sales_tax

        Overriding sales tax

        To override automatic sales tax calculation for a given tax rate,
        supply a TxnTaxDetail element in the create request with the following fields set:
            TxnTaxDetail.TotalTax—the new total tax amount.
            TxnTaxDetail.TaxLine.TaxLineDetail.TaxRateRef—the tax rate that is overridden.
                You must send all TaxRateRefs of a TaxCode even if you are modifying just one of them.
            TxnTaxDetail.TaxLine.Amount—The amount of tax contributed by the tax rate.
            TxnTaxDetail.TaxLine.TaxLineDetail.TaxPercent—The new tax percent to use.

        A QuickBooks company file comes pre-populated with tax rates.
        Some tax rates are non-editable and an attempt to override them generates a business validation error.
        Non-editable tax rates are those whose TaxRate.DisplayType attribute is set to ReadOnly.
        """
        if self.synchronizer.client.company_info.Country != "US":
            if order_line.taxes.exists():
                taxes = [tax_line.tax for tax_line in order_line.taxes.all()]
                line_detail.TaxCodeRef = self._get_tax_code_for_taxes(taxes)
            else:
                line_detail.TaxCodeRef = self._get_tax_code_for_non_taxed()

        # User has configured to use sales tax
        # so we need to split the product amount from the sales tax
        if self.synchronizer.client.using_sales_tax:
            if order_line.taxes.exists():
                line.Amount = force_text(order_line.taxless_price.value)
                line_detail.UnitPrice = force_text(order_line.taxless_discounted_unit_price.value)

                # Taxed for US
                if self.synchronizer.client.company_info.Country == "US":
                    line_detail.TaxCodeRef = get_ref("TAX")
            else:
                # as we don't have taxes, the taxful property is the right one to use
                line.Amount = force_text(order_line.taxful_price.value)
                line_detail.UnitPrice = force_text(order_line.taxful_discounted_unit_price.value)

                # NON taxed for US
                if self.synchronizer.client.company_info.Country == "US":
                    line_detail.TaxCodeRef = get_ref("NON")
        else:
            # No need to worry about taxes, just send the full taxful amount
            line.Amount = force_text(order_line.taxful_price.value)
            line_detail.UnitPrice = force_text(order_line.taxful_discounted_unit_price.value)

            # NON taxed for US
            if self.synchronizer.client.company_info.Country == "US":
                line_detail.TaxCodeRef = get_ref("NON")

        return line

    @lru_cache()
    def _get_line_item_object(self, order_line_type):
        name = force_text(OrderLineTypeMap[order_line_type])

        items = Item.filter(Name=name, qb=self.synchronizer.client, max_results=1)
        if items:
            return items[0].to_ref()

        item = Item()
        item.Taxable = True
        item.Type = "Service"
        item.ItemCategoryType = "Service"

        if order_line_type == OrderLineType.PRODUCT:
            item.Type = "NonInventory"
            item.ItemCategoryType = "Product"

        item.Name = name
        item.IncomeAccountRef = self._get_default_income_account().to_ref()
        item.AssetAccountRef = self._get_default_asset_account().to_ref()
        item.save(qb=self.synchronizer.client)
        return item.to_ref()

    @lru_cache()
    def _get_address_object(self, address):
        addr = Address()
        addr.Line1 = address.street
        addr.Line2 = address.street2
        addr.Line3 = address.street3
        addr.Line4 = address.region
        addr.City = address.city
        addr.CountrySubDivisionCode = address.region_code
        addr.Country = address.country.code
        addr.PostalCode = address.postal_code
        addr.Lat = address.latitude
        addr.Long = address.longitude
        return addr
