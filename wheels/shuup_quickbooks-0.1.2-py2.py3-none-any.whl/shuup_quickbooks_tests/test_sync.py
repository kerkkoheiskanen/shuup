# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from uuid import uuid4

import mock
import pytest
from django.test import override_settings
from django.utils.translation import activate
from shuup.core.models import OrderStatus
from shuup.testing import factories


def get_generic_qb_object():
    from quickbooks.objects.base import QuickbooksTransactionEntity

    class GenericObject(QuickbooksTransactionEntity):
        def __init__(self):
            super(GenericObject, self).__init__()
            self.Id = "1"

        def to_ref(self):
            return {
                "Id": "1"
            }
    return GenericObject()


@pytest.mark.parametrize("prices_include_tax,taxes,pref_using_sales_tax,country,filter_finds_objects", [
    (True, False, True, "US", False),
    (True, True, True, "US", False),
    (False, False, True, "US", False),
    (False, True, True, "US", False),
    (True, False, False, "US", False),
    (True, True, False, "US", False),
    (False, False, False, "US", False),
    (False, True, False, "US", False),

    (True, False, True, "CA", False),
    (True, True, True, "CA", False),
    (False, False, True, "CA", False),
    (False, True, True, "CA", False),
    (True, False, False, "CA", False),
    (True, True, False, "CA", False),
    (False, False, False, "CA", False),
    (False, True, False, "CA", False),

    (True, False, True, "CA", True),
    (True, True, True, "CA", True),
    (False, False, True, "CA", True),
    (False, True, True, "CA", True),
    (True, False, False, "CA", True),
    (True, True, False, "CA", True),
    (False, False, False, "CA", True),
    (False, True, False, "CA", True),
])
@pytest.mark.django_db
def test_sync_orders(prices_include_tax, taxes, pref_using_sales_tax, country, filter_finds_objects):
    """
    A simple coverage test to avoid mainly syntax errors
    """
    activate("en")
    shop = factories.get_default_shop()
    shop.prices_include_tax = prices_include_tax
    product = factories.create_product("p1", shop, factories.get_default_supplier(), "10")
    customer = factories.create_random_person("en")
    order_no_customer = factories.create_order_with_product(product, factories.get_default_supplier(), 1, 10, shop=shop)
    order_customer = factories.create_order_with_product(product, factories.get_default_supplier(), 2, 9.8, shop=shop)
    order_customer.customer = customer
    order_customer.save()

    orders = [order_no_customer, order_customer]
    for order in orders:
        order.create_payment(order.taxful_total_price)
        order.status = OrderStatus.objects.get_default_complete()
        order.save()

    if taxes:
        factories.get_default_tax()
    else:
        from shuup.core.models import OrderLineTax
        OrderLineTax.objects.all().delete()

    def qb_save(instance, **kwargs):
        instance.Id = uuid4().hex

    def qb_filter(*args, **kwargs):
        return [get_generic_qb_object()]

    with mock.patch("shuup_quickbooks.objects.QuickBooks.using_sales_tax", new_callable=mock.PropertyMock) as prop_mock:
        prop_mock.return_value = pref_using_sales_tax
        from shuup_quickbooks.auth import Oauth2SessionManager
        from shuup_quickbooks.synchronizer import QuickBooksSynchronizer, SyncError

        with override_settings(QUICKBOOKS_SANDBOX_MODE=True):
            with mock.patch("quickbooks.QuickBooks.make_request"):
                with mock.patch("quickbooks.mixins.UpdateMixin.save", new=qb_save):
                    def do_the_test():
                        session_manager = Oauth2SessionManager(
                            client_id="1",
                            client_secret="2",
                            access_token="3",
                            base_url="4"
                        )
                        synchronizer = QuickBooksSynchronizer(shop, "companyID", session_manager)
                        synchronizer.client.company_info.Country = country
                        results = list(synchronizer.synchronize())
                        assert not any([isinstance(result, SyncError) for result in results])

                    if filter_finds_objects:
                        with mock.patch("quickbooks.mixins.ListMixin.filter", new=qb_filter):
                            with mock.patch("quickbooks.mixins.ListMixin.where", new=qb_filter):
                                do_the_test()
                    else:
                        do_the_test()
