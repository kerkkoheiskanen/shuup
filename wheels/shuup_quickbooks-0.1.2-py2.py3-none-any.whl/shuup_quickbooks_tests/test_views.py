# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import pytest
from django.core.urlresolvers import reverse
from django.test import Client
from django.utils.translation import activate
from shuup.testing import factories


@pytest.mark.django_db
def test_auth_callback_view():
    activate("en")
    factories.get_default_shop()
    auth_callback_url = reverse("shuup:quickbooks.auth_callback")

    client = Client()
    response = client.get(auth_callback_url)
    assert response.url.endswith(reverse("shuup_admin:shuup_quickbooks.settings"))

    response = client.get("{}?code=CODEX&realmId=1234&state=http://google.com".format(auth_callback_url))
    assert "http://google.com" in response.url
    assert "code=CODEX" in response.url
    assert "company_id=1234" in response.url
