# -*- coding: utf-8 -*-
# This file is part of Shuup QuickBooks.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json
from datetime import timedelta

import mock
import pytest
from django.utils.timezone import now
from django.utils.translation import activate
from shuup.testing import factories
from shuup.testing.utils import apply_request_middleware


@pytest.mark.django_db
def test_utils(rf):
    activate("en")
    factories.get_default_shop()

    with mock.patch("shuup_quickbooks.utils.get_auth_session_manager") as get_auth_session_mock:
        from shuup_quickbooks.auth import Oauth2SessionManager
        session_manager = Oauth2SessionManager(
            client_id="1",
            client_secret="2",
            access_token="3",
            base_url="4"
        )
        session_manager.refresh_token = "5"
        session_manager.x_refresh_token_expires_in = 2
        session_manager.expires_in = 1
        get_auth_session_mock.return_value = session_manager

        from shuup_quickbooks.utils import get_valid_session_manager

        request = apply_request_middleware(rf.get("/"))
        now_datetime = now()

        # expired on purpose
        quickbooks_auth = {
            "access_token": session_manager.access_token,
            "access_token_expires_at": (now_datetime - timedelta(seconds=session_manager.expires_in)).isoformat(),
            "refresh_token": session_manager.refresh_token,
            "refresh_expires_at": (
                (now_datetime - timedelta(seconds=session_manager.x_refresh_token_expires_in)).isoformat()
            ),
            "company_id": "6"
        }
        request.session["quickbooks_auth"] = quickbooks_auth
        assert get_valid_session_manager(request) is None

        # now with a non expired refresh token
        with mock.patch("requests.post") as post_mock:
            quickbooks_auth.update({
                "refresh_expires_at": (now_datetime + timedelta(days=12)).isoformat()
            })
            request.session["quickbooks_auth"] = quickbooks_auth

            class Response(object):
                status_code = 200
                text = json.dumps({
                    "x_refresh_token_expires_in": 100,
                    "access_token": "dummy",
                    "token_type": "dummy",
                    "refresh_token": "dummy",
                    "expires_in": 100,
                    "id_token": "dummy"
                })
            post_mock.return_value = Response()
            assert get_valid_session_manager(request)
