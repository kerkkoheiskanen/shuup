# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import decimal
from logging import getLogger

from django.conf import settings
from django.utils.text import slugify
from shuup.core import cache
from shuup.core.models import Contact, Supplier

from shuup_multivendor.models import DistanceUnit, VendorContactDistance

LOGGER = getLogger(__name__)
GMAPS_CLIENT = None


def ensure_address_geoposition(address):
    """
    Ensure the geolocation coordinates for the given address.
    Returns whether the address was updated or not.
    """
    # settings not enabled
    if not settings.SHUUP_MULTIVENDOR_ENSURE_ADDRESS_GEOPOSITION or not settings.SHUUP_MULTIVENDOR_GOOGLE_MAPS_KEY:
        return

    result = get_best_geocode_result(address)

    if result:
        prec = decimal.Decimal("0.1") ** 6   # 6 decimal places
        latitude = decimal.Decimal(result["geometry"]["location"]["lat"]).quantize(prec, rounding=decimal.ROUND_DOWN)
        longitude = decimal.Decimal(result["geometry"]["location"]["lng"]).quantize(prec, rounding=decimal.ROUND_DOWN)
    else:
        latitude = None
        longitude = None

    if address.latitude != latitude or address.longitude != longitude:
        address.latitude = latitude
        address.longitude = longitude
        address.save(update_fields=["latitude", "longitude"])
        return True


def recalculate_vendor_distances(vendor):
    # not enabled
    if not settings.SHUUP_MULTIVENDOR_CALCULATE_VENDOR_DISTANCE:
        return

    address_field = "default_{}".format(settings.SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS)
    filters = {
        "%s__latitude__isnull" % address_field: False,
        "%s__longitude__isnull" % address_field: False
    }
    contacts_to_recalculate = Contact.objects.filter(**filters).select_related(address_field).distinct()

    for contact in contacts_to_recalculate:
        _calculate_distance(vendor, contact)


def recalculate_contact_distances(contact):
    # not enabled
    if not settings.SHUUP_MULTIVENDOR_CALCULATE_VENDOR_DISTANCE:
        return

    vendors_to_recalculate = Supplier.objects.filter(
        contact_address__latitude__isnull=False,
        contact_address__longitude__isnull=False
    ).select_related("contact_address")

    for vendor in vendors_to_recalculate:
        _calculate_distance(vendor, contact)


def _calculate_distance(vendor, contact):
    from geopy import distance as geodistance
    vendor_position = (vendor.contact_address.latitude, vendor.contact_address.longitude)
    vendor_distance = None

    address_field = "default_{}".format(settings.SHUUP_MULTIVENDOR_DISTANCE_CONTACT_ADDRESS)
    address = getattr(contact, address_field, None)
    if not address:
        return

    if address.latitude and address.longitude:
        position = (address.latitude, address.longitude)
        distance = geodistance.distance(position, vendor_position)

        if settings.SHUUP_MULTIVENDOR_DISTANCE_UNIT == "mi":
            vendor_distance = distance.miles
        else:
            vendor_distance = distance.km

    if vendor_distance is not None:
        VendorContactDistance.objects.update_or_create(
            contact=contact,
            supplier=vendor,
            defaults=dict(
                distance=vendor_distance,
                unit=DistanceUnit(settings.SHUUP_MULTIVENDOR_DISTANCE_UNIT)
            )
        )


def geocode_address(address):
    address_lines = [
        address.street,
        address.postal_code,
        address.city,
        address.region_code,
        address.region
    ]
    address_line = ",".join([line for line in address_lines if line])
    components = {"country": address.country.code}

    cache_key = slugify("geocode_addr_{}".format(address_line))
    cached_results = cache.get(cache_key)
    if cached_results:
        return cached_results

    global GMAPS_CLIENT
    if not GMAPS_CLIENT:
        import googlemaps
        GMAPS_CLIENT = googlemaps.Client(key=settings.SHUUP_MULTIVENDOR_GOOGLE_MAPS_KEY)

    try:
        results = GMAPS_CLIENT.geocode(address=address_line, components=components)
    except Exception:
        LOGGER.exception("Failed to geocode address %s", address_line)
        return

    if not results:
        LOGGER.warning("No address found for address %s", address_line)
        return []

    # filter results, skipping those without geometry info
    results = [result for result in results if result.get("geometry") and result["geometry"].get("location")]
    cache.set(cache_key, results)
    return results


def get_best_geocode_result(address):
    """
    :type address: shuup.core.models.Address
    """
    results = geocode_address(address)
    if not results:
        return None

    for result in results:
        location_type = result["geometry"].get("location_type")

        if location_type == "ROOFTOP":
            return result
        if location_type == "RANGE_INTERPOLATED":
            return result
        if location_type == "APPROXIMATE":
            return result

    # just the first
    return results[0]
