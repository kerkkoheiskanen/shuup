# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from shuup import configuration

IS_PAYPAL_WITHDRAW_ENABLED = "funds_paypal_withdraw_enabled"
IS_VENDOR_FUND_ENABLED_KEY = "shuup_multivendor:is_vendor_funds_enabled"
IS_WIRE_TRANSFER_WITHDRAW_ENABLED = "funds_wire_transfer_withdraw_enabled"
IS_WIRE_TRANSFER_EU_WITHDRAW_ENABLED = "funds_wire_transfer_eu_withdraw_enabled"
VENDOR_FUNDS_MINIMUM_WITHDRAW_KEY = "shuup_multivendor:minimum_withdraw_funds"
VENDOR_FUNDS_WITHDRAWAL_HELP_TEXT_KEY = "shuup_multivendor:funds_withdraw_help_text"
VENDOR_REVENUE_PERCENTAGE_KEY = "shuup_multivendor:is_vendor_revenue_percentage"


def get_vendor_default_percentage(shop):
    return configuration.get(shop, VENDOR_REVENUE_PERCENTAGE_KEY, default=0)


def get_vendor_revenue_percentage(vendor, shop):
    if not (vendor and vendor.pk and vendor.options):
        return get_vendor_default_percentage(shop)
    return vendor.options.get(VENDOR_REVENUE_PERCENTAGE_KEY, get_vendor_default_percentage(shop))


def is_vendor_funds_enabled(shop):
    return configuration.get(shop, IS_VENDOR_FUND_ENABLED_KEY, default=False)


def set_vendor_funds_enabled(shop, value):
    configuration.set(shop, IS_VENDOR_FUND_ENABLED_KEY, value)


def set_vendor_default_revenue_percentage(shop, value):
    configuration.set(shop, VENDOR_REVENUE_PERCENTAGE_KEY, "{:.2f}".format(value))


def set_vendor_revenue_percentage(vendor, value):
    if not value:
        return

    options = vendor.options or {}
    options.update({VENDOR_REVENUE_PERCENTAGE_KEY: value})
    vendor.options = options
    vendor.save(update_fields=("options",))


def is_withdrawal_line(line):
    if not line:
        return False

    from shuup_multivendor.models import WITHDRAW_ORDER_LINE_ACCOUNTING_IDENTIFIER
    return bool(
        line.accounting_identifier == WITHDRAW_ORDER_LINE_ACCOUNTING_IDENTIFIER or
        (line.parent_line and line.parent_line.accounting_identifier == WITHDRAW_ORDER_LINE_ACCOUNTING_IDENTIFIER)
    )


def is_wire_transfer_withdraw_enabled(shop):
    return configuration.get(shop, IS_WIRE_TRANSFER_WITHDRAW_ENABLED, default=False)


def set_wire_transfer_withdraw_enabled(shop, value):
    configuration.set(shop, IS_WIRE_TRANSFER_WITHDRAW_ENABLED, value)


def is_wire_transfer_eu_withdraw_enabled(shop):
    return configuration.get(shop, IS_WIRE_TRANSFER_EU_WITHDRAW_ENABLED, default=False)


def set_wire_transfer_eu_withdraw_enabled(shop, value):
    configuration.set(shop, IS_WIRE_TRANSFER_EU_WITHDRAW_ENABLED, value)


def is_paypal_withdraw_enabled(shop):
    return configuration.get(shop, IS_PAYPAL_WITHDRAW_ENABLED, default=False)


def set_paypal_withdraw_enabled(shop, value):
    configuration.set(shop, IS_PAYPAL_WITHDRAW_ENABLED, value)


def get_minimum_withdraw_amount(shop):
    return configuration.get(shop, VENDOR_FUNDS_MINIMUM_WITHDRAW_KEY, default=0)


def set_minimum_withdraw_amount(shop, value):
    configuration.set(shop, VENDOR_FUNDS_MINIMUM_WITHDRAW_KEY, "{:.2f}".format(value))


def get_withdraw_help_text(shop):
    return configuration.get(shop, VENDOR_FUNDS_WITHDRAWAL_HELP_TEXT_KEY, default="")


def set_withdraw_help_text(shop, value):
    configuration.set(shop, VENDOR_FUNDS_WITHDRAWAL_HELP_TEXT_KEY, value)
