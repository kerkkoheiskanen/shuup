# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.db import models
from django.utils.translation import ugettext_lazy as _
from shuup.core.models import Shop, Supplier


class SupplierUser(models.Model):
    shop = models.ForeignKey(Shop, related_name="vendor_users")
    supplier = models.ForeignKey(Supplier, related_name="vendor_users")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="vendor_users")
    is_owner = models.BooleanField(verbose_name=_("is owner"), default=False)

    class Meta:
        unique_together = ("shop", "supplier", "user")

    @classmethod
    def get_owner(cls, supplier):
        item = cls.objects.filter(supplier=supplier, is_owner=True).first()
        if item:
            return item.user
