# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db import models
from shuup.core.fields import MoneyValueField
from shuup.core.models import Product, Shop, ShuupModel, Supplier
from shuup.utils.properties import MoneyPropped, PriceProperty


class SupplierPrice(MoneyPropped, ShuupModel):
    shop = models.ForeignKey(Shop, related_name="vendor_prices")
    product = models.ForeignKey(Product, related_name="vendor_prices")
    supplier = models.ForeignKey(Supplier, related_name="vendor_prices")
    amount_value = MoneyValueField()
    amount = PriceProperty("amount_value", "shop.currency", "shop.prices_include_tax")
