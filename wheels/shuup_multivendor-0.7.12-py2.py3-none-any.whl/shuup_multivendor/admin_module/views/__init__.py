# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from .dashboard import SupplierDashboardView
from .orders import OrderLineListView, OrderListView, set_order_line_status
from .pages import MVPageDeleteView, MVPageEditView, MVPageListView
from .products import (
    ProductDeleteView, ProductEditView, ProductListView, SetPriceView,
    ToggleSaleView
)
from .user import LoginAsVendorView
from .vendor import VendorDeleteView, VendorEditView, VendorListView, VendorSettingsView

__all__ = [
    "set_order_line_status",
    "LoginAsVendorView",
    "MVPageDeleteView",
    "MVPageEditView",
    "MVPageListView",
    "OrderLineListView",
    "OrderListView",
    "ProductDeleteView",
    "ProductEditView",
    "ProductListView",
    "SetPriceView",
    "SupplierDashboardView",
    "ToggleSaleView",
    "VendorDeleteView",
    "VendorEditView",
    "VendorListView",
    "VendorSettingsView",
]
