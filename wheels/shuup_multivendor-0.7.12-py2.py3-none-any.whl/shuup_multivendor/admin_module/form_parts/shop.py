# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django import forms
from django.contrib.auth.models import Group
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.admin.forms.fields import Select2MultipleField
from shuup.admin.forms.widgets import QuickAddRelatedObjectMultiSelect
from shuup.admin.shop_provider import get_shop
from shuup.core.models import Label
from shuup.simple_cms.models import Page

from shuup_multivendor.gdpr import (
    get_active_consent_pages, get_possible_consent_pages,
    save_active_consent_pages
)
from shuup_multivendor.utils.configuration import (
    get_completed_status_label_for_shop, get_order_line_labels_for_shop,
    set_completed_status_label_for_shop, set_order_line_labels_for_shop
)
from shuup_multivendor.utils.funds import (
    get_minimum_withdraw_amount, get_vendor_default_percentage,
    get_withdraw_help_text, is_paypal_withdraw_enabled,
    is_vendor_funds_enabled, is_wire_transfer_eu_withdraw_enabled,
    is_wire_transfer_withdraw_enabled, set_minimum_withdraw_amount,
    set_paypal_withdraw_enabled, set_vendor_default_revenue_percentage,
    set_vendor_funds_enabled, set_wire_transfer_eu_withdraw_enabled,
    set_wire_transfer_withdraw_enabled, set_withdraw_help_text
)
from shuup_multivendor.utils.permissions import (
    ensure_staff_permission_group_for_shop,
    ensure_staff_permission_group_permissions,
    ensure_vendor_permission_group_permissions,
    ensure_vendor_permissions_for_shop, get_staff_permission_group_for_shop,
    get_vendor_permission_group_for_shop, set_staff_permission_group_for_shop,
    set_vendor_permission_group_for_shop
)


class QuickAddPageMultiSelect(QuickAddRelatedObjectMultiSelect):
    url = reverse_lazy("shuup_admin:simple_cms.page.new")


class VendorConfigurationForm(forms.Form):
    staff_user_permission_group = forms.ModelChoiceField(
        label=_("Staff user permission group"),
        queryset=Group.objects.all(),
        help_text=_("Set the user group that should be used for staff users")
    )
    vendor_user_permission_group = forms.ModelChoiceField(
        label=_("Vendor user permission group"),
        queryset=Group.objects.all(),
        help_text=_("Set the user group that should be used for vendor users")
    )
    order_line_labels = forms.ModelMultipleChoiceField(
        label=_("Order line status available labels"),
        queryset=Label.objects.all(),
        help_text=_("Select all the label that can be used for order lines"),
        required=False
    )
    completed_status_label = forms.ModelChoiceField(
        label=_("Status that indicates completion"),
        queryset=Label.objects.all(),
        help_text=_(
            "Select the label that indicates the line is completed. "
            "When all lines have this status, the order will be "
            "changed to Complete."
        ),
        required=False
    )
    is_vendor_funds_enabled = forms.BooleanField(
        label=_("Is vendor funds enabled"), required=False,
        help_text=_("Set this to enable vendor funds-feature.")
    )
    default_vendor_revenue_percentage = forms.DecimalField(
        label=_("Default vendor share percentage (percentage vendor can keep from completed sales)"), required=False,
        max_digits=5, decimal_places=2,
        help_text=_(
            "Percentage of sales vendor will can keep for itself."
            "This value can be set per vendor when the vendor funds are "
            "enabled."
        )
    )
    minimum_withdraw_amount = forms.DecimalField(
        label=_("Minimum withdraw amount"), required=False,
        max_digits=36, decimal_places=9,
        help_text=_(
            "Minimum amount that can be withdrawn by vendor "
            "when vendor funds-feature is enabled."
        )
    )
    withdraw_help_text = forms.CharField(
        label=_("Withdraw funds help text"), required=False,
        widget=forms.Textarea,
        help_text=_(
            "Help text to vendor for creating withdrawal for funds. "
            "This text is shown to vendor while submitting withdrawal "
            "request."
        )
    )
    is_wire_transfer_withdraw_enabled = forms.BooleanField(
        label=_("Withdraw funds with USA wire transfer"), required=False,
        help_text=_("Give vendor option to request withdraw with wire transfer.")
    )
    is_wire_transfer_eu_withdraw_enabled = forms.BooleanField(
        label=_("Withdraw funds with EU wire transfer"), required=False,
        help_text=_("Give vendor option to request withdraw with wire transfer.")
    )
    is_paypal_withdraw_enabled = forms.BooleanField(
        label=_("Withdraw funds with PayPal"), required=False,
        help_text=_("Give vendor option to request withdraw with PayPal.")
    )

    def __init__(self, **kwargs):
        self.request = kwargs.pop("request")
        super(VendorConfigurationForm, self).__init__(**kwargs)
        shop = get_shop(self.request)
        consent_field = Select2MultipleField(
            model=Page, required=False, help_text=_("Select required consent pages for vendor.")
        )
        consent_choices = [(p.id, p.title) for p in get_possible_consent_pages(shop)]
        consent_field.required = False
        consent_field.choices = consent_choices
        consent_field.initial = get_active_consent_pages(shop)
        consent_field.widget = QuickAddPageMultiSelect()
        consent_field.widget.choices = consent_choices
        self.fields["consent_pages"] = consent_field


class VendorConfigurationFormPart(FormPart):
    priority = 10
    name = "vendor_configuration"
    form = VendorConfigurationForm

    def get_form_defs(self):
        initial = {}
        if self.object.pk:
            initial = {
                "staff_user_permission_group": get_staff_permission_group_for_shop(self.object),
                "vendor_user_permission_group": get_vendor_permission_group_for_shop(self.object),
                "order_line_labels": [label.pk for label in get_order_line_labels_for_shop(self.object)],
                "completed_status_label": get_completed_status_label_for_shop(self.object),
                "is_vendor_funds_enabled": is_vendor_funds_enabled(self.object),
                "default_vendor_revenue_percentage": get_vendor_default_percentage(self.object),
                "is_wire_transfer_withdraw_enabled": is_wire_transfer_withdraw_enabled(self.object),
                "is_wire_transfer_eu_withdraw_enabled": is_wire_transfer_eu_withdraw_enabled(self.object),
                "is_paypal_withdraw_enabled": is_paypal_withdraw_enabled(self.object),
                "minimum_withdraw_amount": get_minimum_withdraw_amount(self.object),
                "withdraw_help_text": get_withdraw_help_text(self.object)
            }

        yield TemplatedFormDef(
            name=self.name,
            form_class=self.form,
            template_name="shuup_multivendor/admin/form_parts/vendor.jinja",
            required=False,
            kwargs={"initial": initial, "request": self.request}
        )

    def form_valid(self, form):
        vendor_form = form[self.name]

        if vendor_form.has_changed():
            data = vendor_form.cleaned_data
            set_staff_permission_group_for_shop(self.object,  data["staff_user_permission_group"])
            set_vendor_permission_group_for_shop(self.object, data["vendor_user_permission_group"])
            set_order_line_labels_for_shop(self.object, data["order_line_labels"])
            set_completed_status_label_for_shop(self.object, data["completed_status_label"])
            set_vendor_funds_enabled(self.object, data["is_vendor_funds_enabled"])
            set_vendor_default_revenue_percentage(self.object, data["default_vendor_revenue_percentage"])
            set_wire_transfer_withdraw_enabled(self.object, data["is_wire_transfer_withdraw_enabled"])
            set_wire_transfer_eu_withdraw_enabled(self.object, data["is_wire_transfer_eu_withdraw_enabled"])
            set_paypal_withdraw_enabled(self.object, data["is_paypal_withdraw_enabled"])
            set_minimum_withdraw_amount(self.object, data["minimum_withdraw_amount"])
            set_withdraw_help_text(self.object, data["withdraw_help_text"])
            save_active_consent_pages(self.object, data["consent_pages"])

        current_staff_permission_group = get_staff_permission_group_for_shop(self.object)
        if current_staff_permission_group:
            # make sure staff permission group has all the required permissions
            ensure_staff_permission_group_permissions(current_staff_permission_group)
            # add all staff members to the staff permission group
            ensure_staff_permission_group_for_shop(self.object, current_staff_permission_group)

        current_vendor_permission_group = get_vendor_permission_group_for_shop(self.object)
        if current_vendor_permission_group:
            # make sure vendor permission group has all the required permissions
            ensure_vendor_permission_group_permissions(current_vendor_permission_group)
            # ensure all vendor users for this shop has correct permission group
            ensure_vendor_permissions_for_shop(self.object, current_vendor_permission_group)
