# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.conf import settings
from shuup.admin.form_part import FormPart, TemplatedFormDef
from shuup.utils.importing import cached_load

from shuup_multivendor.admin_module.forms.vendor import (
    VendorForm, VendorOpeningPeriodsFormSet, VendorSettingsBaseForm
)


class VendorBaseFormPart(FormPart):
    priority = 1

    def get_form_defs(self):
        yield TemplatedFormDef(
            "base",
            VendorForm,
            template_name="shuup_multivendor/admin/vendor/_edit_base_form.jinja",
            required=True,
            kwargs={
                "instance": self.object,
                "request": self.request,
                "languages": settings.LANGUAGES,
            }
        )

    def form_valid(self, form):
        self.object = form["base"].save()


class VendorSettingsBaseFormPart(VendorBaseFormPart):
    def get_form_defs(self):
        yield TemplatedFormDef(
            "base",
            VendorSettingsBaseForm,
            template_name="shuup_multivendor/admin/vendor/_edit_base_form.jinja",
            required=True,
            kwargs={
                "instance": self.object,
                "request": self.request,
                "languages": settings.LANGUAGES,
            }
        )


class VendorAddressFormPart(FormPart):
    priority = 2

    def get_form_defs(self):
        initial = {}
        yield TemplatedFormDef(
            "address",
            form_class=cached_load("SHUUP_MULTIVENDOR_ADDRESS_FORM"),
            template_name="shuup_multivendor/admin/vendor/_edit_contact_address_form.jinja",
            required=True,
            kwargs={
                "instance": self.object.contact_address,
                "initial": initial
            }
        )

    def form_valid(self, form):
        addr_form = form["address"]
        if addr_form.changed_data:
            addr = addr_form.save()
            setattr(self.object, "contact_address", addr)
            self.object.save()


class VendorOpeningPeriodsFormPart(FormPart):
    priority = 3

    def get_form_defs(self):
        if self.object.options:
            initial = [
                {
                    "day_of_week": period["day_of_week"],
                    "start": period["start"],
                    "end": period["end"]
                }
                for period in self.object.options.get("opening_periods", [])
            ]
        else:
            initial = []

        yield TemplatedFormDef(
            "opening_periods",
            VendorOpeningPeriodsFormSet,
            template_name="shuup_multivendor/admin/vendor/_edit_opening_periods_form.jinja",
            required=False,
            kwargs={
                "initial": initial
            }
        )

    def form_valid(self, form):
        opening_periods_form = form["opening_periods"]
        options = self.object.options or {}
        options["opening_periods"] = []

        for period in opening_periods_form.cleaned_data:
            options["opening_periods"].append({
                "day_of_week": period["day_of_week"],
                "start": period["start"].strftime("%H:%M"),
                "end": period["end"].strftime("%H:%M")
            })

        self.object.options = options
        self.object.save()
