# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Connect.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
import environ

env = environ.Env(DEBUG=(bool, False))

# This is being used the pull connect data from configuration
STRIPE_CONNECT_OAUTH_DATA_KEY = "stripe_connect_oauth_data"

# platform level secrets for connect to use
STRIPE_SECRET_KEY = env('STRIPE_SECRET_KEY', default=None)
STRIPE_OAUTH_CLIENT_ID = env('STRIPE_OAUTH_CLIENT_ID', default=None)

STRIPE_CONNECT_FEE_PERCENTAGE = env('STRIPE_CONNECT_FEE_PERCENTAGE', default=None)

STRIPE_URL_PROVIDER = "shuup_stripe_connect.url_provider:StripeURLProvider"
