# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Connect.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from django import forms
from django.utils.translation import ugettext_lazy as _
from shuup.admin.forms.widgets import TextEditorWidget
from shuup.core.models import TaxClass


class FinalizeForm(forms.Form):
    name = forms.CharField(max_length=128, label=_("Name"), initial="Stripe", required=True)
    description = forms.CharField(
        max_length=256,
        required=False,
        label=_("Description"),
        initial=_("Make your payment in Stripe payment service."),
        widget=TextEditorWidget
    )
    tax_class = forms.ModelChoiceField(
        label=_("Tax Class"),
        required=True,
        queryset=TaxClass.objects.filter(enabled=True)
    )
    price = forms.DecimalField(
        required=False, min_value=0, initial=0,
        label=_("Price"),
        help_text=_("Price of the service")
    )

    def clean_price(self):
        return self.cleaned_data.get("price", None) or 0
