# -*- coding: utf-8 -*-
# This file is part of Shuup Stripe Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the OSL-3.0 license found in the
# LICENSE file in the root directory of this source tree.
from bs4 import BeautifulSoup
from django.test.client import Client
from shuup.testing.factories import (
    create_order_with_product, get_default_product, get_default_supplier,
    get_default_tax_class
)


class SmartClient(Client):
    def soup(self, path, data=None, method="get"):
        response = getattr(self, method)(path=path, data=data)
        assert 200 <= response.status_code <= 299, "Valid status"
        return BeautifulSoup(response.content, "lxml")

    def response_and_soup(self, path, data=None, method="get"):
        response = getattr(self, method)(path=path, data=data)
        return (response, BeautifulSoup(response.content, "lxml"))


def create_order_for_stripe(stripe_payment_processor, identifier=None, unit_price=100):
    product = get_default_product()
    supplier = get_default_supplier()
    order = create_order_with_product(
        product=product, supplier=supplier, quantity=1,
        taxless_base_unit_price=unit_price, tax_rate=0
    )
    payment_method = stripe_payment_processor.create_service(
        identifier, shop=order.shop, tax_class=get_default_tax_class(), enabled=True)
    order.payment_method = payment_method
    order.cache_prices()
    assert order.taxless_total_price.value > 0
    if not order.payment_data:
        order.payment_data = {}
    order.save()
    return order
