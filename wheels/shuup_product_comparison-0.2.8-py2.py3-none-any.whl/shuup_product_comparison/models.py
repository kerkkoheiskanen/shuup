# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db import models
from django.utils.translation import ugettext_lazy as _

from shuup.core.models import Attribute


class ComparableAttribute(models.Model):
    attribute = models.OneToOneField(Attribute,
                                     related_name='comparable', verbose_name=_('attribute'), primary_key=True)
