/**
 * This file is part of Product Comparison.
 *
 * Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
 *
 * This source code is licensed under the AGPLv3 license found in the
 * LICENSE file in the root directory of this source tree.
 */
// make sure jQuery is available
if (typeof window.$ === "function") {
    const ShuupProductComparison = window.ShuupProductComparison;

    window.initializeProductComparison = () => {
        $(".shuup-product-compare-add").off("click").on("click", function(e) {
            e.preventDefault();
            const productId = $(this).attr("data-product-id");
            const reload = $(this).data("reload");
            ShuupProductComparison.addProductToComparison(productId, reload);
        });

        $(document).off("click", ".shuup-product-comparison-remove").on("click", ".shuup-product-comparison-remove", function(e) {
            e.preventDefault();
            const productId = $(this).data("product-id");
            const reload = $(this).data("reload");
            ShuupProductComparison.removeProductFromComparison(productId, reload);
        });

        $(document).off("click", ".shuup-product-comparison-remove-all").on("click", ".shuup-product-comparison-remove-all", function(e) {
            e.preventDefault();
            ShuupProductComparison.removeProductFromComparison("all", false);
        });
    };

    $(document).ready(function() {
        window.initializeProductComparison();
    });
}
