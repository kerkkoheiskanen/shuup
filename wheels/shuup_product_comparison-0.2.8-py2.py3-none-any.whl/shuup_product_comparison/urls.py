# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf.urls import url

from .views import (
    add_product_to_compare, product_comparison_quickview, ProductCompareView,
    remove_product_from_compare
)

urlpatterns = [
    url(r"compare/$", ProductCompareView.as_view(), name="comparison_view"),
    url(r"^compare/add/(?P<pk>\d+)/$", add_product_to_compare, name="comparison_add"),
    url(r"^compare/remove/(?P<pk>\w+)/$", remove_product_from_compare, name="comparison_remove"),
    url(r"^compare/quick-view/$", product_comparison_quickview, name="comparison_quickview"),
]
