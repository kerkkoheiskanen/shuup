# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.notify.base import Event, Variable
from shuup.notify.typology import Email, Model


class MessageReceived(Event):
    identifier = "shuup_messages_message_received"
    name = _("Message Received")
    description = _("This event is triggered for when message is sent.")

    message = Variable(_("Message"), type=Model("shuup_messages.Message"))
    to_email = Variable(_("To Email"), type=Email)
