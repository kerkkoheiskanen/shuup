# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.contrib import messages
from django.core.urlresolvers import reverse
from django.http.response import HttpResponseRedirect
from django.utils.translation import ugettext as _
from django.views.generic import DetailView
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import get_person_contact
from shuup.utils.analog import LogEntryKind

from shuup_messages.models import Message


class ChangeReadStatusBase(DetailView):
    model = Message

    def get_queryset(self):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        qs = Message.objects.filter(deleted=False)
        if shop and shop.staff_members.filter(id=self.request.user.pk).exists():
            return qs.filter(to_shop=shop)
        elif supplier:
            return qs.filter(to_supplier=supplier)
        elif getattr(self.request.user, "is_superuser", False):
            return qs

        return Message.objects.none()


class MarkAsReadAction(ChangeReadStatusBase):
    def _mark_as_read(self, request):
        message = self.get_object()
        message.read = True
        message.read_by = get_person_contact(request.user)
        message.save(update_fields=("read", "read_by"))
        message.add_log_entry("Mark as read", kind=LogEntryKind.EDIT, user=request.user)
        messages.success(request, _("%s has been marked read.") % message)
        return HttpResponseRedirect(reverse("shuup_admin:message.list"))

    def get(self, request, *args, **kwargs):
        return self._mark_as_read(request)


class MarkAsUnreadAction(ChangeReadStatusBase):
    def _mark_as_unread(self, request):
        message = self.get_object()
        message.read = False
        message.read_by = None
        message.save(update_fields=("read", "read_by"))
        message.add_log_entry("Mark as unread", kind=LogEntryKind.EDIT, user=request.user)
        messages.success(request, _("%s has been marked unread.") % message)
        return HttpResponseRedirect(reverse("shuup_admin:message.list"))

    def get(self, request, *args, **kwargs):
        return self._mark_as_unread(request)


class MessageDeleteView(DetailView):
    model = Message

    def get_queryset(self):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        qs = Message.objects.filter(deleted=False)
        if shop and shop.staff_members.filter(id=self.request.user.pk).exists():
            return qs.filter(from_shop=shop)
        elif supplier:
            return qs.filter(from_supplier=supplier)
        elif getattr(self.request.user, "is_superuser", False):
            return qs

    def _soft_delete(self, request):
        message = self.get_object()
        message.soft_delete(user=request.user)
        messages.success(request, _("%s has been deleted.") % message)
        return HttpResponseRedirect(reverse("shuup_admin:message.list"))

    def get(self, request, *args, **kwargs):
        return self._soft_delete(request)
