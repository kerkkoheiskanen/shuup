# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.core.urlresolvers import reverse_lazy
from django.db.models import Q
from django.template.loader import render_to_string
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.admin.utils.permissions import has_permission
from shuup.admin.utils.picotable import (
    Column, DateRangeFilter, MultiFieldTextFilter
)
from shuup.admin.utils.views import PicotableListView
from shuup.core.models import get_person_contact
from shuup.utils.i18n import get_locally_formatted_datetime

from shuup_messages.models import Message


class MessageListView(PicotableListView):
    model = Message
    url_identifier = "messages"

    default_columns = [
        Column("created_on", _("Sent"), display="format_date", filter_config=DateRangeFilter()),
        Column(
            "from", _("From"), display="format_from", raw=True, sortable=False,
            filter_config=MultiFieldTextFilter(
                filter_fields=(
                    "from_shop__translations__public_name",
                    "from_shop__contact_address__email",
                    "from_supplier__name",
                    "from_supplier__contact_address__email",
                    "from_contact__name",
                    "from_contact__email"
                )
            )
        ),
        Column(
            "to", _("To"), display="format_to", raw=True, sortable=False,
            filter_config=MultiFieldTextFilter(
                filter_fields=(
                    "to_shop__translations__public_name",
                    "to_shop__contact_address__email",
                    "to_supplier__name",
                    "to_supplier__contact_address__email",
                    "to_contact__name",
                    "to_contact__email"
                )
            )
        ),
        Column("message", _("Message"), display="format_message", raw=True),
        Column("actions", _("Actions"), display="format_actions", raw=True, sortable=False),
    ]

    mass_actions = []  # TODO: probably mark as read mass action would be useful

    def __init__(self):
        super(MessageListView, self).__init__()
        self.columns = self.default_columns

    def format_date(self, instance, *args, **kwargs):
        return get_locally_formatted_datetime(instance.created_on)

    def format_from(self, instance, *args, **kwargs):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        contact = get_person_contact(self.request.user)

        from_contact = instance.from_contact
        if instance.from_shop:
            if shop and shop == instance.from_shop:
                return instance.from_shop.public_name

            return '<a href=%s>%s</a>' % (
                reverse_lazy("shuup_admin:message.new_to_staff", kwargs={"to_shop_id": instance.from_shop.pk}),
                _("%(shop_name)s (%(contact_name)s)") % {
                    "shop_name": instance.from_shop.public_name,
                    "contact_name": from_contact.name if from_contact else _("Anonymous")
                }
            )
        elif instance.from_supplier:
            if supplier and supplier == instance.from_supplier:
                return instance.from_supplier.name

            return '<a href=%s>%s</a>' % (
                reverse_lazy(
                    "shuup_admin:message.new_to_supplier", kwargs={"to_supplier_id": instance.from_supplier.pk}),
                _("%(supplier_name)s (%(contact_name)s)") % {
                    "supplier_name": instance.from_supplier.name,
                    "contact_name": from_contact.name if from_contact else _("Anonymous")
                }
            )
        elif from_contact and hasattr(from_contact, "user") and getattr(from_contact.user, "is_superuser", False):
            if from_contact == contact:
                return from_contact.name

            return '<a href=%s>%s</a>' % (
                reverse_lazy(
                    "shuup_admin:message.new_to_contact", kwargs={"to_contact_id": from_contact.pk}),
                _("Admin (%(contact_name)s)") % {"contact_name": from_contact.name}
            )
        elif from_contact:
            return _("Contact (%(contact_name)s)") % {"contact_name": from_contact.name}

    def format_to(self, instance, *args, **kwargs):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)

        to_contact = instance.to_contact
        if instance.to_shop:
            if instance.to_shop == shop:
                return instance.to_shop.public_name

            return '<a href=%s>%s</a>' % (
                reverse_lazy("shuup_admin:message.new_to_staff", kwargs={"to_shop_id": instance.to_shop.pk}),
                _("%(shop_name)s (%(contact_name)s)") % {
                    "shop_name": instance.to_shop.public_name,
                    "contact_name": to_contact.name if to_contact else _("Anonymous")
                }
            )
        elif instance.to_supplier:
            if instance.to_supplier == supplier:
                return instance.to_supplier.name

            return '<a href=%s>%s</a>' % (
                reverse_lazy(
                    "shuup_admin:message.new_to_supplier", kwargs={"to_supplier_id": instance.to_supplier.pk}),
                _("%(supplier_name)s (%(contact_name)s)") % {
                    "supplier_name": instance.to_supplier.name,
                    "contact_name": to_contact.name if to_contact else _("Anonymous")
                }
            )
        elif to_contact:
            return instance.to_contact.name or "-"

    def format_message(self, instance, *args, **kwargs):
        return render_to_string("shuup_messages/admin/message.jinja", {
            "message": instance,
            "message_read_action_id": "message-read-action-%s" % instance.pk
        })

    def format_actions(self, instance, *args, **kwargs):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)

        can_mark_as_read = can_mark_as_unread = False
        if shop and (shop.staff_members.filter(id=self.request.user.pk).exists()):
            can_mark_as_read = can_mark_as_unread = bool(shop == instance.to_shop)
        elif supplier:
            can_mark_as_read = can_mark_as_unread = bool(supplier == instance.to_supplier)
        elif getattr(self.request.user, "is_superuser", False):
            can_mark_as_read = can_mark_as_unread = True

        mark_as_read_url = None
        if not instance.read and can_mark_as_read and has_permission(self.request.user, "message.mark_as_read"):
            mark_as_read_url = (
                reverse_lazy("shuup_admin:message.mark_as_read", kwargs={"pk": instance.pk})
                if instance.pk else None
            )

        mark_as_unread_url = None
        if instance.read and can_mark_as_unread and has_permission(self.request.user, "message.mark_as_unread"):
            mark_as_unread_url = (
                reverse_lazy("shuup_admin:message.mark_as_unread", kwargs={"pk": instance.pk})
                if instance.pk else None
            )

        can_delete = False
        if shop and shop.staff_members.filter(id=self.request.user.pk).exists():
            can_delete = bool(shop == instance.from_shop)
        elif supplier:
            can_delete = bool(supplier == instance.from_supplier)
        elif getattr(self.request.user, "is_superuser", False):
            can_delete = True

        delete_url = None
        if can_delete and has_permission(self.request.user, "message.delete"):
            delete_url = (
                reverse_lazy("shuup_admin:message.delete", kwargs={"pk": instance.pk})
                if instance.pk else None
            )

        return render_to_string("shuup_messages/admin/message_actions.jinja", {
            "message": instance,
            "mark_as_read_url": mark_as_read_url,
            "message_read_action_id": "message-read-action-%s" % instance.pk,
            "mark_as_unread_url": mark_as_unread_url,
            "delete_url": delete_url
        })

    def get_queryset(self):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        contact = get_person_contact(self.request.user)
        if (
            shop and (
                getattr(self.request.user, "is_superuser", False) or
                shop.staff_members.filter(id=self.request.user.pk).exists()
            )
        ):
            return Message.objects.filter(
                Q(deleted=False) &
                Q(
                    Q(to_contact=contact) |
                    Q(from_contact=contact) |
                    Q(to_shop=shop) |
                    Q(from_shop=shop)
                )
            )
        elif supplier:
            return Message.objects.filter(
                Q(deleted=False) &
                Q(
                    Q(to_contact=contact) |
                    Q(from_contact=contact) |
                    Q(to_supplier=supplier) |
                    Q(from_supplier=supplier)
                )
            )


class ListWithBaseView(MessageListView):
    template_name = "shuup_messages/admin/no_base_picotable.jinja"

    def get_queryset(self):
        shop = get_shop(self.request)
        supplier = get_supplier(self.request)
        qs = Message.objects.filter(deleted=False)
        if shop and shop.staff_members.filter(id=self.request.user.pk).exists():
            return qs.filter(
               Q(
                    Q(to_shop=shop) |
                    Q(from_shop=shop)
                )
            )
        elif supplier:
            return qs.filter(
               Q(
                    Q(to_supplier=supplier) |
                    Q(from_supplier=supplier)
                )
            )
        elif getattr(self.request.user, "is_superuser", False):
            contact = get_person_contact(self.request.user)
            return qs.filter(
               Q(
                    Q(to_contact=contact) |
                    Q(from_contact=contact)
                )
            )


class MessageListWithShopView(ListWithBaseView):
    def get_queryset(self):
        return super(MessageListWithShopView, self).get_queryset().filter(
            Q(
                Q(to_shop_id=self.kwargs["pk"]) |
                Q(from_shop_id=self.kwargs["pk"])
            )
        ).distinct()


class MessageListWithSupplierView(ListWithBaseView):
    def get_queryset(self):
        return super(MessageListWithSupplierView, self).get_queryset().filter(
            Q(
                Q(to_supplier_id=self.kwargs["pk"]) |
                Q(from_supplier_id=self.kwargs["pk"])
            )
        ).distinct()


class MessageListWithContactView(ListWithBaseView):
    def get_queryset(self):
        return super(MessageListWithContactView, self).get_queryset().filter(
            Q(
                Q(to_contact_id=self.kwargs["pk"]) |
                Q(from_contact_id=self.kwargs["pk"])
            )
        ).distinct()
