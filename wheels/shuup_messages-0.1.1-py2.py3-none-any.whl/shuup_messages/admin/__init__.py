# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.utils.translation import ugettext_lazy as _
from shuup.admin.base import AdminModule, MenuEntry
from shuup.admin.menu import MESSAGES_MENU_CATEGORY
from shuup.admin.utils.permissions import has_permission
from shuup.admin.utils.urls import derive_model_url

from shuup_messages.models import Message


class MessageModule(AdminModule):
    name = _("Messages")

    def get_urls(self):
        from shuup.admin.urls import admin_url
        return [
            admin_url(
                "^messages/$",
                "shuup_messages.admin.list.MessageListView",
                name="message.list"
            ),
            admin_url(
                "^messages/with_shop/(?P<pk>\d+)/$",
                "shuup_messages.admin.list.MessageListWithShopView",
                name="message.list_with_shop"
            ),
            admin_url(
                "^messages/with_supplier/(?P<pk>\d+)/$",
                "shuup_messages.admin.list.MessageListWithSupplierView",
                name="message.list_with_supplier"
            ),
            admin_url(
                "^messages/with_contact/(?P<pk>\d+)/$",
                "shuup_messages.admin.list.MessageListWithContactView",
                name="message.list_with_contact"
            ),
            admin_url(
                "^messages/new/$",
                "shuup_messages.admin.edit.MessageEditView",
                kwargs={"pk": None},
                name="message.new"
            ),
            admin_url(
                "^messages/new/to_vendor/(?P<to_supplier_id>\d+)/$",
                "shuup_messages.admin.edit.MessageEditView",
                kwargs={"pk": None},
                name="message.new_to_supplier"
            ),
            admin_url(
                "^messages/new/to_staff/(?P<to_shop_id>\d+)/$",
                "shuup_messages.admin.edit.MessageEditView",
                kwargs={"pk": None},
                name="message.new_to_staff"
            ),
            admin_url(
                "^messages/new/to_contact/(?P<to_contact_id>\d+)/$",
                "shuup_messages.admin.edit.MessageEditView",
                kwargs={"pk": None},
                name="message.new_to_contact"
            ),
            admin_url(
                "^messages/(?P<pk>\d+)/$",
                "shuup_messages.admin.edit.MessageEditView",
                name="message.edit"
            ),
            admin_url(
                "^messages/(?P<pk>\d+)/mark_as_read/$",
                "shuup_messages.admin.actions.MarkAsReadAction",
                name="message.mark_as_read"
            ),
            admin_url(
                "^messages/(?P<pk>\d+)/mark_as_unread/$",
                "shuup_messages.admin.actions.MarkAsUnreadAction",
                name="message.mark_as_unread"
            ),
            admin_url(
                "^messages/(?P<pk>\d+)/delete/$",
                "shuup_messages.admin.actions.MessageDeleteView",
                name="message.delete"
            )
        ]

    def get_menu_entries(self, request):
        if has_permission(request.user, "message.list"):
            return [
                MenuEntry(
                    text=_("Messages"),
                    icon="fa fa-envelope",
                    url="shuup_admin:message.list",
                    category=MESSAGES_MENU_CATEGORY,
                    ordering=2
                )
            ]

        return []

    def get_model_url(self, object, kind, shop=None):
        if kind in ["new", "edit"]:
            return derive_model_url(Message, "shuup_admin:message", object, kind)
