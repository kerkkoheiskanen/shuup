# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.db.models.signals import post_save

from .models import Message
from .notify_events import MessageReceived


def message_post_save(sender, instance, created, **kwargs):
    if created:
        shop = None
        params = {"message": instance}
        if instance.to_shop:
            params.update({
                "to_email": (instance.to_shop.contact_address.email if instance.to_shop.contact_address else None)
            })
            shop = instance.to_shop
        elif instance.to_supplier:
            params.update({
                "to_email": (
                    instance.to_supplier.contact_address.email if instance.to_supplier.contact_address else None
                )
            })
            shop = instance.to_supplier.shops.first()
        elif instance.to_contact:
            params.update({
                "to_email": instance.to_contact.email
            })
            shop = instance.to_contact.shops.first()

        if shop:
            MessageReceived(**params).run(shop=shop)


post_save.connect(message_post_save, sender=Message, dispatch_uid="shuup_messages_post_save")
