# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import pytest

from django.core.exceptions import ValidationError
from shuup.core.models import MutableAddress
from shuup.testing import factories

from shuup_messages.models import Message


@pytest.mark.django_db
def test_message_create():
    shop = factories.get_default_shop()
    shop_email = "shop@exmple.com"
    shop_phone = "1239876"
    shop.contact_address = MutableAddress.objects.create(
        name="Olympic Stadium",
        street="1 Hellow World Street",
        city="LA",
        country="US",
        email=shop_email,
        phone=shop_phone
    )
    shop.save()

    supplier = factories.get_default_supplier()
    supplier_email = "supplier@exmple.com"
    supplier_phone = "5349876"
    supplier.contact_address = MutableAddress.objects.create(
        name="The Place",
        street="Where is this street?",
        city="Vancity",
        country="CA",
        email=supplier_email,
        phone=supplier_phone
    )
    supplier.save()

    # Supplier sends message to admin
    msg = Message.objects.create(from_supplier=supplier, to_shop=shop, message="hi!")
    assert msg.sender_name == supplier.name
    assert msg.sender_name != supplier.contact_address.name
    assert msg.sender_email == supplier_email
    assert msg.sender_phone == supplier_phone

    # Shop sends message back to supplier
    msg = Message.objects.create(from_shop=shop, to_supplier=supplier, message="hihi!")
    assert msg.sender_name == shop.public_name
    assert msg.sender_name != shop.contact_address.name
    assert msg.sender_email == shop_email
    assert msg.sender_phone == shop_phone


@pytest.mark.django_db
def test_message_create_fails():
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    contact = factories.create_random_person()

    with pytest.raises(ValidationError):
        Message.objects.create(message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(from_shop=shop, message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(from_supplier=supplier, message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(from_contact=contact, message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(to_shop=shop, message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(to_supplier=supplier, message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(to_contact=contact, message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(from_shop=shop, from_supplier=supplier, to_supplier=supplier, message="hello!")

    with pytest.raises(ValidationError):
        Message.objects.create(from_shop=shop, to_shop=shop, to_supplier=supplier, message="hello!")


@pytest.mark.django_db
def test_message_delete():
    shop = factories.get_default_shop()
    supplier = factories.get_default_supplier()
    contact = factories.create_random_person()

    msg = Message.objects.create(from_shop=shop, from_contact=contact, to_shop=shop, message="moi")
    with pytest.raises(NotImplementedError):
        msg.delete()

    assert not msg.deleted
    msg.soft_delete()
    assert msg.deleted







# Test message create with models methods
# Test post save with simple notification

# Test list view queryset
# Test list view with queryset
# While at it test columns

# Test actions

# Test edit automatic read

# Test edit form and template after the create


