# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json
import pytest

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import override_settings
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import (
    get_person_contact, MutableAddress, Shop, ShopStatus, Supplier
)
from shuup.testing import factories
from shuup.testing.utils import apply_request_middleware
from shuup.utils.importing import load

from shuup_messages.models import Message


@pytest.mark.django_db
def test_message_list(rf, admin_user):
    supplier_provider = "shuup.testing.supplier_provider.UsernameSupplierProvider"
    with override_settings(SHUUP_ENABLE_MULTIPLE_SHOPS=True, SHUUP_ADMIN_SUPPLIER_PROVIDER_SPEC=supplier_provider):
        shop_data = [
            {
                "identifier": "shop1",
                "name": "Shop One",
                "shop_email": "shop@example.com",
                "shop_phone": "1239876",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            },
            {
                "identifier": "shop2",
                "name": "Shop Two",
                "shop_email": "shop2p@example.com",
                "shop_phone": "1239876asdfasdf",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            }
        ]

        for data in shop_data:
            shop = factories.get_shop(
                prices_include_tax=True, identifier=data["identifier"], name=data["name"], status=ShopStatus.ENABLED)
            shop_staff_user = factories.create_random_user(username=data["identifier"], is_staff=True)
            shop.staff_members.add(shop_staff_user)
            shop.contact_address = MutableAddress.objects.create(
                name=data["address_name"],
                street=data["address_street"],
                city=["address_city"],
                country=["address_country"],
                email=["shop_email"],
                phone=["shop_phone"]
            )
            shop.save()

        supplier_data = [
            {
                "identifier": "supplier1",
                "name": "New Supplier One",
                "supplier_email": "shop@example.com",
                "supplier_phone": "1239876",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            },
            {
                "identifier": "supplier2",
                "name": "New Supplier Two",
                "supplier_email": "shop2p@example.com",
                "supplier_phone": "1239876asdfasdf",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            }
        ]

        for data in supplier_data:
            supplier = Supplier.objects.create(identifier=data["identifier"], name=data["name"])
            supplier_user = factories.create_random_user(username=data["identifier"], is_staff=True)
            supplier.contact_address = MutableAddress.objects.create(
                name=data["address_name"],
                street=data["address_street"],
                city=["address_city"],
                country=["address_country"],
                email=["supplier_email"],
                phone=["supplier_phone"]
            )
            supplier.save()

        superuser_contact = get_person_contact(admin_user)
        shop1 = Shop.objects.filter(identifier="shop1").first()
        shop_1_staff = shop1.staff_members.first()
        shop2 = Shop.objects.filter(identifier="shop2").first()
        shop_2_staff = shop2.staff_members.first()

        user_model = get_user_model()
        supplier1 = Supplier.objects.filter(identifier="supplier1").first()
        supplier1_user = user_model.objects.filter(username=supplier1.identifier).first()
        supplier2 = Supplier.objects.filter(identifier="supplier2").first()
        supplier2_user = user_model.objects.filter(username=supplier2.identifier).first()

        original_message_count = Message.objects.count()
        view = load("shuup_messages.admin.edit.MessageEditView").as_view()
        request = apply_request_middleware(rf.post("/", data={"message": "hello"}), user=shop_1_staff)
        response = view(request, pk=None, to_supplier_id=supplier1.pk)
        if hasattr(response, "render"):
            response.render()
        assert response.status_code == 302  # Redirect
        assert Message.objects.count() == original_message_count + 1
        assert Message.objects.filter(from_shop=shop1, to_supplier=supplier1).count() == 1

        view = load("shuup_messages.admin.edit.MessageEditView").as_view()
        request = apply_request_middleware(rf.post("/", data={"message": "hello"}), user=supplier1_user)
        response = view(request, pk=None, to_shop_id=shop1.pk)
        if hasattr(response, "render"):
            response.render()
        assert response.status_code == 302  # Redirect
        assert Message.objects.count() == original_message_count + 2
        assert Message.objects.filter(from_supplier=supplier1, to_shop=shop1).count() == 1

        view = load("shuup_messages.admin.edit.MessageEditView").as_view()
        request = apply_request_middleware(rf.post("/", data={"message": "hello"}), user=supplier1_user)
        response = view(request, pk=None, to_contact_id=superuser_contact.pk)
        if hasattr(response, "render"):
            response.render()
        assert response.status_code == 302  # Redirect
        assert Message.objects.count() == original_message_count + 3
        assert Message.objects.filter(from_supplier=supplier1, to_contact=superuser_contact).count() == 1
