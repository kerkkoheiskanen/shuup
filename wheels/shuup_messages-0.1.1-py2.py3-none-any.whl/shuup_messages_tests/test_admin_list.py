# -*- coding: utf-8 -*-
# This file is part of Shuup Messages addon.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import json
import pytest

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.test import override_settings
from shuup.admin.shop_provider import get_shop
from shuup.admin.supplier_provider import get_supplier
from shuup.core.models import (
    get_person_contact, MutableAddress, Shop, ShopStatus, Supplier
)
from shuup.testing import factories
from shuup.testing.utils import apply_request_middleware
from shuup.utils.importing import load

from shuup_messages.models import Message


@pytest.mark.django_db
def test_message_list(rf, admin_user):
    supplier_provider = "shuup.testing.supplier_provider.UsernameSupplierProvider"
    with override_settings(SHUUP_ENABLE_MULTIPLE_SHOPS=True, SHUUP_ADMIN_SUPPLIER_PROVIDER_SPEC=supplier_provider):
        shop_data = [
            {
                "identifier": "shop1",
                "name": "Shop One",
                "shop_email": "shop@example.com",
                "shop_phone": "1239876",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            },
            {
                "identifier": "shop2",
                "name": "Shop Two",
                "shop_email": "shop2p@example.com",
                "shop_phone": "1239876asdfasdf",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            }
        ]

        for data in shop_data:
            shop = factories.get_shop(
                prices_include_tax=True, identifier=data["identifier"], name=data["name"], status=ShopStatus.ENABLED)
            shop_staff_user = factories.create_random_user(username=data["identifier"], is_staff=True)
            shop.staff_members.add(shop_staff_user)
            shop.contact_address = MutableAddress.objects.create(
                name=data["address_name"],
                street=data["address_street"],
                city=["address_city"],
                country=["address_country"],
                email=["shop_email"],
                phone=["shop_phone"]
            )
            shop.save()

        supplier_data = [
            {
                "identifier": "supplier1",
                "name": "New Supplier One",
                "supplier_email": "shop@example.com",
                "supplier_phone": "1239876",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            },
            {
                "identifier": "supplier2",
                "name": "New Supplier Two",
                "supplier_email": "shop2p@example.com",
                "supplier_phone": "1239876asdfasdf",
                "address_name": "Olympic Stadium",
                "address_street": "1 Hellow World Street",
                "address_city": "LA",
                "address_country": "US"
            }
        ]

        for data in supplier_data:
            supplier = Supplier.objects.create(identifier=data["identifier"], name=data["name"])
            supplier_user = factories.create_random_user(username=data["identifier"], is_staff=True)
            supplier.contact_address = MutableAddress.objects.create(
                name=data["address_name"],
                street=data["address_street"],
                city=["address_city"],
                country=["address_country"],
                email=["supplier_email"],
                phone=["supplier_phone"]
            )
            supplier.save()

        superuser_contact = get_person_contact(admin_user)
        contact1 = factories.create_random_person()
        contact2 = factories.create_random_person()

        shop1 = Shop.objects.filter(identifier="shop1").first()
        shop_1_staff = shop1.staff_members.first()
        shop2 = Shop.objects.filter(identifier="shop2").first()
        shop_2_staff = shop2.staff_members.first()

        user_model = get_user_model()
        supplier1 = Supplier.objects.filter(identifier="supplier1").first()
        supplier1_user = user_model.objects.filter(username=supplier1.identifier).first()
        supplier2 = Supplier.objects.filter(identifier="supplier2").first()
        supplier2_user = user_model.objects.filter(username=supplier2.identifier).first()

        Message.objects.create(from_supplier=supplier1, to_shop=shop1, message="hi!")
        Message.objects.create(
            from_shop=shop1, to_supplier=supplier1, message="hihi!",
            read=True, read_by=get_person_contact(supplier1_user)
        )  # Mark one read automatically

        Message.objects.create(from_contact=superuser_contact, to_supplier=supplier2, message="hihi!")
        Message.objects.create(from_supplier=supplier2, to_contact=superuser_contact, message="hihi!")
        Message.objects.create(from_contact=contact2, to_contact=superuser_contact, message="hihi!")

        Message.objects.create(from_contact=contact1, to_shop=shop2, message="hihi!")

        def get_messages_list_data(
                user, expected_count, list_view="shuup_messages.admin.list:MessageListView", pk=None):
            view = load(list_view).as_view()
            request = apply_request_middleware(rf.get("/", {
                "jq": json.dumps({"perPage": 100, "page": 1})
            }), user=user)

            if pk:
                response = view(request, pk=pk)
            else:
                response = view(request)
            assert 200 <= response.status_code < 300

            data = json.loads(response.content.decode("utf-8"))
            assert len(data["items"]) == expected_count
            return data["items"]

        # shop 1 staff has one sent message and one received from supplier 1
        data = get_messages_list_data(shop_1_staff, 2)

        # supplier 1 user has one sent message and one received from shop 1
        data = get_messages_list_data(supplier1_user, 2)

        # supplier 2 user has 1 message from superuser and one to superuser
        data = get_messages_list_data(supplier2_user, 2)

        # superuser can see messages:
        #     from shop 1
        #     as well as 2 extra messages with supplier 2
        #     and one extra message from contact 2
        data = get_messages_list_data(admin_user, 5)

        # shop 2 staff has one message received from contact1
        data = get_messages_list_data(shop_2_staff, 1)

        # send on more message from contact 2 to shop1
        Message.objects.create(from_contact=contact2, to_shop=shop1, message="hihi!")
        data = get_messages_list_data(shop_1_staff, 3)

        # shop 1 user has one message with contact1
        data = get_messages_list_data(
            shop_1_staff, 1, list_view="shuup_messages.admin.list.MessageListWithContactView", pk=contact2.pk)
        
        # shop 1 user does not have messages with contact2
        data = get_messages_list_data(
            shop_1_staff, 0, list_view="shuup_messages.admin.list.MessageListWithContactView", pk=contact1.pk)

        # shop 1 user has two messages with supplier 1
        data = get_messages_list_data(
            shop_1_staff, 2, list_view="shuup_messages.admin.list.MessageListWithSupplierView", pk=supplier1.pk)

        # shop 1 user does not have messages with supplier2
        data = get_messages_list_data(
            shop_1_staff, 0, list_view="shuup_messages.admin.list.MessageListWithSupplierView", pk=supplier2.pk)

        # supplier 1 user has 2 messages from shop 1
        data = get_messages_list_data(
            supplier1_user, 2, list_view="shuup_messages.admin.list.MessageListWithShopView", pk=shop1.pk)

        # supplier 1 user does not have messages from shop 2
        data = get_messages_list_data(
            supplier1_user, 0, list_view="shuup_messages.admin.list.MessageListWithShopView", pk=shop2.pk)

        # supplier 2 user does not have messages with shops
        data = get_messages_list_data(
            supplier2_user, 0, list_view="shuup_messages.admin.list.MessageListWithShopView", pk=shop1.pk)
        data = get_messages_list_data(
            supplier2_user, 0, list_view="shuup_messages.admin.list.MessageListWithShopView", pk=shop2.pk)
