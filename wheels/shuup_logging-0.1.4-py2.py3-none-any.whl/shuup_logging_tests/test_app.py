# -*- coding: utf-8 -*-
import pytest


@pytest.mark.django_db
def test_my_app(rf):
    pass
