# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.contrib import messages
from django.contrib.auth import logout
from django.core.urlresolvers import reverse
from django.http.response import HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _
from shuup.admin.shop_provider import get_shop


class ShuupMultivendorAdminMiddleware(object):
    """
    Handle admin requests and logs out the user if it is in a invalid state like
    being part of vendor user group but not attached to any vendor, or being a staff user
    and part of the staff user group but not a shop staff member
    """

    def process_view(self, request, view_func, view_args, view_kwargs):
        # we only care about Shuup Admin requests
        if (request.resolver_match.app_name == "shuup_admin" and request.user.is_authenticated()):
            from shuup_multivendor.supplier_provider import get_supplier

            # set the `request.vendor` with the current vendor linked to the user
            request.vendor = get_supplier(request)

            if not request.user.is_superuser:
                shop = get_shop(request)

                from shuup_multivendor.utils.permissions import (
                    get_staff_permission_group_for_shop,
                    get_vendor_permission_group_for_shop
                )
                user_groups = request.user.groups.all()

                staff_permission_group = get_staff_permission_group_for_shop(shop)
                if staff_permission_group in user_groups and request.user not in shop.staff_members.all():
                    # user is staff but not linked to the shop
                    logout(request)
                    messages.warning(request, _("User is not linked to any shop."))
                    return HttpResponseRedirect(reverse("shuup_admin:login"))

                vendor_permission_group = get_vendor_permission_group_for_shop(shop)
                if vendor_permission_group in user_groups:
                    if not request.vendor:
                        # request is invalid and no supplier is available for this user
                        logout(request)
                        messages.warning(request, _("User is not linked to any vendor."))
                        return HttpResponseRedirect(reverse("shuup_admin:login"))
