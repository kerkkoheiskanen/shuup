# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django import forms
from django.conf import settings
from django.contrib.auth import get_user_model
from django.db.models import Q
from django.db.transaction import atomic
from django.utils.text import force_text
from django.utils.translation import ugettext_lazy as _
from shuup.admin.forms.widgets import (
    FileDnDUploaderWidget, QuickAddUserMultiSelect
)
from shuup.admin.modules.suppliers.forms import SupplierBaseForm
from shuup.admin.shop_provider import get_shop
from shuup.core.models import SupplierType

from shuup_multivendor.models import DayOfTheWeek, SupplierUser
from shuup_multivendor.signals import vendor_approved
from shuup_multivendor.utils.cache import bump_storefront_caches
from shuup_multivendor.utils.permissions import (
    ensure_vendor_permissions_for_shop
)


class VendorForm(SupplierBaseForm):
    users = forms.IntegerField()

    class Meta(SupplierBaseForm.Meta):
        exclude = None
        fields = ["name", "description", "enabled", "is_approved", "logo", "module_identifier"]

    def __init__(self, *args, **kwargs):
        self.request = kwargs.get("request")
        super(VendorForm, self).__init__(*args, **kwargs)
        self.initial_vendor_approved = self.instance.is_approved

        self.fields["name"].help_text = _("The vendor name.")
        self.fields["logo"].widget = FileDnDUploaderWidget(
            upload_path="/Vendors", kind="images", clearable=True)

        initial_users = (self.instance.vendor_users.all() if self.instance.pk else [])
        self.fields["users"] = forms.ModelMultipleChoiceField(
            required=False,
            label=_("Management users"),
            help_text=_("Select the users that should manage this vendor"),
            queryset=get_user_model().objects.filter(is_superuser=False, vendor_users__isnull=True),
            widget=QuickAddUserMultiSelect(
                attrs={"data-model": "auth.User"},
                choices=[(user.pk, force_text(user)) for user in initial_users]
            )
        )
        shop = get_shop(self.request)

        if self.instance.pk:
            self.fields["users"].initial = get_user_model().objects.filter(
                vendor_users__shop=shop,
                vendor_users__supplier=self.instance
            )
            self.fields["users"].queryset = get_user_model().objects.filter(
                Q(is_superuser=False, vendor_users__isnull=True) |
                Q(vendor_users__shop=shop, vendor_users__supplier=self.instance)
            ).distinct()

        self.fields.pop("module_identifier", None)

    def clean(self):
        data = super(VendorForm, self).clean()
        # TODO: remove this check when user can select the current vendor in use
        for user in data.get("users", []):
            duplicate_check_qs = SupplierUser.objects.filter(user=user)

            if self.instance.pk:
                duplicate_check_qs = duplicate_check_qs.exclude(supplier=self.instance)

            if duplicate_check_qs.exists():
                msg = _("User %(user)s is already being used in another vendor.") % dict(user=user.username)
                self.add_error("users", msg)

        return data

    def save(self, commit=True):
        instance = super(VendorForm, self).save(commit)
        shop = get_shop(self.request)

        with atomic():
            # make sure all attributes are what we expect
            module_identifier = settings.SHUUP_MULTIVENDOR_SUPPLIER_MODULE_IDENTIFIER
            instance.module_identifier = module_identifier
            instance.type = SupplierType.INTERNAL
            instance.stock_managed = bool(module_identifier != "")
            instance.save()
            instance.shops.add(shop)

            if self.cleaned_data.get("users"):
                # create/update the supplier user link
                for user in self.cleaned_data["users"]:
                    SupplierUser.objects.get_or_create(shop=shop, supplier=instance, user=user)
                    # make sure the user is staff so he can login
                    user.is_staff = True
                    # make sure all user is disabled if this vendor is not approved and active otherwise
                    user.is_active = instance.is_approved
                    user.save()

                # delete old users
                SupplierUser.objects.filter(
                    shop=shop,
                    supplier=instance
                ).exclude(
                    user__id__in=[user.pk for user in self.cleaned_data["users"]]
                ).delete()

            # no users in form, check whether it is a field
            elif "users" in self.fields:
                SupplierUser.objects.filter(shop=shop, supplier=instance).delete()

        # check that vendor is approved
        if self.initial_vendor_approved is False and instance.is_approved is True:
            vendor_approved.send(sender=type(self), shop=shop, vendor=instance, request=self.request)

        bump_storefront_caches(shop)
        ensure_vendor_permissions_for_shop(shop)
        return instance


class VendorSettingsBaseForm(VendorForm):
    def __init__(self, *args, **kwargs):
        super(VendorSettingsBaseForm, self).__init__(*args, **kwargs)
        self.fields.pop("is_approved", None)
        self.fields.pop("enabled", None)
        self.fields.pop("users", None)
        self.fields["logo"].widget = FileDnDUploaderWidget(
            upload_path="/Vendors", kind="images", clearable=True, browsable=False)


class PeriodsForm(forms.Form):
    day_of_week = forms.ChoiceField(choices=DayOfTheWeek.choices())
    start = forms.TimeField(widget=forms.TextInput(attrs={"class": "time"}))
    end = forms.TimeField(widget=forms.TextInput(attrs={"class": "time"}))


VendorOpeningPeriodsFormSet = forms.formset_factory(PeriodsForm, extra=0)
