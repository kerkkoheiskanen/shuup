# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.core.urlresolvers import reverse, reverse_lazy
from django.db.transaction import atomic
from django.http.response import Http404
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy as _
from shuup.admin.form_part import FormPartsViewMixin, SaveFormPartsMixin
from shuup.admin.shop_provider import get_shop
from shuup.admin.toolbar import (
    NewActionButton, PostActionButton, Toolbar, URLActionButton
)
from shuup.admin.utils.picotable import (
    Column, Picotable, TextFilter, true_or_false_filter
)
from shuup.admin.utils.urls import NoModelUrl
from shuup.admin.utils.views import CreateOrUpdateView, PicotableListView
from shuup.core.models import Supplier

from shuup_multivendor.admin_module.form_parts.vendor import (
    VendorAddressFormPart, VendorBaseFormPart, VendorOpeningPeriodsFormPart,
    VendorSettingsBaseFormPart
)
from shuup_multivendor.models import SupplierUser
from shuup_multivendor.supplier_provider import get_supplier


class VendorPicotable(Picotable):
    def get_verbose_name_plural(self):
        return _("vendors")


class VendorListView(PicotableListView):
    url_identifier = "shuup_admin:shuup_multivendor.vendor.list"
    model = Supplier
    picotable_class = VendorPicotable
    default_columns = [
        Column(
            "name",
            _("Name"),
            sort_field="name",
            display="name",
            filter_config=TextFilter(
                filter_field="name",
                placeholder=_("Filter by name...")
            )
        ),
        Column("users", _("Management Users"), display="get_vendor_users", sortable=False),
        Column("enabled", _("Enabled"), display="get_enabled", sortable=False, filter_config=true_or_false_filter),
        Column(
            "is_approved",
            _("Is approved"),
            display="get_approved",
            sortable=True,
            filter_config=true_or_false_filter
        )
    ]

    def __init__(self, *args, **kwargs):
        super(VendorListView, self).__init__(*args, **kwargs)
        self.columns = self.default_columns

    def get_enabled(self, instance):
        return _("Yes") if instance.enabled else _("No")

    def get_approved(self, instance):
        return _("Yes") if instance.is_approved else _("No")

    def get_vendor_users(self, instance):
        users = get_user_model().objects.filter(
            vendor_users__shop=get_shop(self.request),
            vendor_users__supplier=instance
        )
        return ", ".join([user.username for user in users])

    def get_context_data(self, **kwargs):
        context = super(VendorListView, self).get_context_data(**kwargs)
        context["title"] = _("Vendors")
        return context

    def get_toolbar(self):
        toolbar = Toolbar.for_view(self)
        toolbar.append(NewActionButton(reverse_lazy("shuup_admin:shuup_multivendor.vendor.new")))
        return toolbar

    def get_object_url(self, instance):
        return reverse("shuup_admin:shuup_multivendor.vendor.edit", kwargs=dict(pk=instance.pk))

    def get_queryset(self):
        return Supplier.objects.filter(shops=get_shop(self.request))


class VendorEditView(SaveFormPartsMixin, FormPartsViewMixin, CreateOrUpdateView):
    model = Supplier
    template_name = "shuup_multivendor/admin/vendor/edit.jinja"
    context_object_name = "vendor"
    base_form_part_classes = [VendorBaseFormPart, VendorAddressFormPart, VendorOpeningPeriodsFormPart]
    form_part_class_provide_key = "admin_vendor_form_part"

    def get_context_data(self, **kwargs):
        context = super(VendorEditView, self).get_context_data(**kwargs)
        if self.object.pk:
            context["title"] = force_text(self.object)
        else:
            context["title"] = _("New Vendor")
        return context

    def get_toolbar(self):
        toolbar = super(VendorEditView, self).get_toolbar()

        supplier_user = SupplierUser.objects.filter(
            shop=get_shop(self.request),
            supplier=self.object,
            user__is_superuser=False,
            user__is_active=True
        )

        if supplier_user.exists():
            toolbar.append(
                PostActionButton(
                    post_url=reverse("shuup_admin:shuup_multivendor.vendor.login-as", kwargs={"pk": self.object.pk}),
                    text=_("Login as vendor user"),
                    extra_css_class="btn-gray"
                )
            )

        return toolbar

    def get_queryset(self):
        return Supplier.objects.filter(shops=get_shop(self.request))

    def get_return_url(self):
        return reverse("shuup_admin:shuup_multivendor.vendor.list")

    def get_new_url(self):
        return reverse("shuup_admin:shuup_multivendor.vendor.new")

    def get_success_url(self):  # noqa (C901)
        next_url = self.request.POST.get("__next")
        try:
            if next_url == "return":
                return self.get_return_url()
            if next_url == "new":
                return self.get_new_url()
        except NoModelUrl:
            pass

        return reverse("shuup_admin:shuup_multivendor.vendor.edit", kwargs=dict(pk=self.object.pk))

    @atomic
    def form_valid(self, form):
        return self.save_form_parts(form)

    def _add_create_or_change_message(self, request, object, is_new):
        messages.success(request,  _("Vendor saved."))


class VendorSettingsView(SaveFormPartsMixin, FormPartsViewMixin, CreateOrUpdateView):
    model = Supplier
    template_name = "shuup_multivendor/admin/vendor/edit.jinja"
    context_object_name = "vendor"
    base_form_part_classes = [VendorSettingsBaseFormPart, VendorAddressFormPart, VendorOpeningPeriodsFormPart]
    form_part_class_provide_key = "admin_vendor_form_part"
    success_url = reverse_lazy("shuup_admin:shuup_multivendor.vendor.settings")

    def get_toolbar(self):
        toolbar = super(VendorSettingsView, self).get_toolbar()
        toolbar.append(
            URLActionButton(
                reverse("shuup:supplier", kwargs=dict(pk=self.object.pk)),
                text=_("Go to vendor page"),
                extra_css_class="btn-primary",
                icon="fa fa-external-link",
            )
        )
        return toolbar

    def get_object(self):
        supplier = get_supplier(self.request)
        if not supplier:
            raise Http404(_("Invalid supplier"))
        return supplier

    def get_queryset(self):
        return Supplier.objects.filter(shops=get_shop(self.request), vendor_users__user=self.request.user)

    @atomic
    def form_valid(self, form):
        return self.save_form_parts(form)

    def _add_create_or_change_message(self, request, object, is_new):
        messages.success(request,  _("Vendor settings saved."))
