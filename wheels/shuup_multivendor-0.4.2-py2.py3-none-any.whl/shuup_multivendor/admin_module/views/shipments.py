# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import six
from django.db.transaction import atomic
from django.http import JsonResponse
from shuup.core.models import Order, Product, Shipment, ShipmentStatus

from shuup_multivendor.supplier_provider import get_supplier


def create_shipment(request, pk=None):
    data = request.POST
    ids = data.get("ids", "").split(",")
    if not len(ids):
        return JsonResponse({"error": True})

    order_id = data.get("order_id")

    assert order_id == pk

    tracking_code = data.get("tracking_code")
    description = data.get("description", "")

    supplier = get_supplier(request)

    # TODO: ensure permissions?
    order = Order.objects.get(pk=pk, shop=request.shop)

    product_ids_to_quantities = dict(
        (orderline.product.id, orderline.quantity)
        for orderline
        in order.lines.filter(pk__in=ids, supplier=supplier)
    )

    product_map = Product.objects.in_bulk(set(product_ids_to_quantities.keys()))
    products_to_quantities = dict(
        (product_map[product_id], quantity)
        for (product_id, quantity)
        in six.iteritems(product_ids_to_quantities)
    )
    with atomic():
        unsaved_shipment = Shipment(
            order=order,
            supplier=supplier,
            tracking_code=tracking_code,
            description=description,
        )
        shipment = order.create_shipment(
            product_quantities=products_to_quantities,
            supplier=supplier,
            shipment=unsaved_shipment
        )
        shipment.status = ShipmentStatus.SENT
        shipment.save()

    return JsonResponse({"ok": True, "shipment_id": shipment.pk})
