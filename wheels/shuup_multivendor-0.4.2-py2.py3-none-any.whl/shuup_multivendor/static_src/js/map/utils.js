import haversine from "haversine";


export function getVendorCoords(vendor) {
    return {
        latitude: parseFloat(vendor.contact_address.latitude),
        longitude: parseFloat(vendor.contact_address.longitude)
    };
}


export function getVendorDistance(vendor, fromLocation) {
    return haversine(getVendorCoords(vendor), fromLocation, {
        unit: window.VENDOR_MAP_SETTINGS.distance_unit
    });
}

export function getFormattedDistance(distance) {
    let suffix = window.VENDOR_MAP_SETTINGS.distance_unit === "km" ? "km" : "mi"
    return interpolate("%s%s", [Number(distance).toFixed(1), suffix])
}
