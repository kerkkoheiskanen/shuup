# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.conf import settings
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from shuup import configuration

from shuup_multivendor.models import SupplierUser


def get_vendor_permission_group_for_shop(shop):
    """
    Returns the configured vendor permission group for a given shop
    """
    vendor_permission_group_id = configuration.get(shop, "vendor_user_permission_group")
    if vendor_permission_group_id:
        return Group.objects.get(pk=vendor_permission_group_id)


def get_staff_permission_group_for_shop(shop):
    """
    Returns the configured staff permission group for a given shop
    """
    staff_permission_group_id = configuration.get(shop, "staff_user_permission_group")
    if staff_permission_group_id:
        return Group.objects.get(pk=staff_permission_group_id)


def set_staff_permission_group_for_shop(shop, permission_group):
    """
    Sets the configured staff permission group for a given shop
    """
    configuration.set(shop, "staff_user_permission_group", permission_group.pk if permission_group else None)


def set_vendor_permission_group_for_shop(shop, permission_group):
    """
    Sets the configured vendor permission group for a given shop
    """
    configuration.set(shop, "vendor_user_permission_group", permission_group.pk if permission_group else None)


def ensure_staff_permission_group_permissions(staff_permission_group):
    """
    Ensure the given staff permission group has all the required permissions
    """
    from shuup.admin.utils.permissions import get_permissions_from_group, set_permissions_for_group
    permissions = get_permissions_from_group(staff_permission_group)
    if len(permissions) == 0:
        set_permissions_for_group(staff_permission_group, settings.STAFF_USER_GROUP_PERMISSIONS)


def ensure_staff_permission_group_for_shop(shop, permission_group):
    """
    Ensure that all staff members for a given shop are in the given permission group
    """
    staff_members = shop.staff_members.all()

    # add all shop staff members to the staff group
    for staff_member in staff_members:
        staff_member.groups.add(permission_group)

    # remove those users which are not part of the staff members anymore but are in staff group
    for user in get_user_model().objects.filter(groups=permission_group):
        if user not in staff_members:
            user.groups.remove(permission_group)


def ensure_vendor_permission_group_permissions(vendor_permission_group):
    """
    Ensure the given vendor permission group has all the required permissions
    """
    from shuup.admin.utils.permissions import get_permissions_from_group, set_permissions_for_group
    permissions = get_permissions_from_group(vendor_permission_group)
    if len(permissions) == 0:
        set_permissions_for_group(vendor_permission_group, settings.VENDOR_USER_GROUP_PERMISSIONS)


def ensure_vendor_permissions_for_shop(shop, vendor_permission_group=None):
    """
    Ensure that all vendor members for a given shop are in the given permission group
    If the permission group is not informed, it will be fetched from configuration
    """
    if vendor_permission_group is None:
        vendor_permission_group = get_vendor_permission_group_for_shop(shop)

    if vendor_permission_group:
        for vendor_user in SupplierUser.objects.filter(shop=shop):
            vendor_user.user.groups.add(vendor_permission_group)

        # remove those users which are attached to the vendor group but are not linked to any vendor
        for user in get_user_model().objects.filter(groups=vendor_permission_group, vendor_users__isnull=True):
            user.groups.remove(vendor_permission_group)
