# -*- coding: utf-8 -*-
# This file is part of Shuup Multivendor Addon.
#
# Copyright (c) 2012-2018, Shuup Inc. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.core.urlresolvers import reverse_lazy
from django.http.response import HttpResponseRedirect
from django.views.generic import FormView, TemplateView

from shuup_multivendor.forms import VendorRegistrationForm
from shuup_multivendor.utils.permissions import (
    ensure_vendor_permissions_for_shop
)


class VendorRegistrationView(FormView):
    template_name = "shuup_multivendor/supplier/registration.jinja"
    form_class = VendorRegistrationForm
    success_url = reverse_lazy("shuup:vendor_registration_complete")

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated():
            return HttpResponseRedirect(reverse_lazy("shuup_admin:dashboard"))
        return super(VendorRegistrationView, self).get(request, *args, **kwargs)

    def form_valid(self, form):
        form.save()
        # make the user created have correct permissions
        ensure_vendor_permissions_for_shop(self.request.shop)
        return super(VendorRegistrationView, self).form_valid(form)

    def get_form_kwargs(self):
        kwargs = super(VendorRegistrationView, self).get_form_kwargs()
        kwargs["request"] = self.request
        return kwargs


class VendorRegistrationCompleteView(TemplateView):
    template_name = "shuup_multivendor/supplier/registration_complete.jinja"
