# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.core.urlresolvers import reverse_lazy
from shuup.admin.forms.widgets import QuickAddRelatedObjectMultiSelect


class QuickAddPlanSelect(QuickAddRelatedObjectMultiSelect):
    url = reverse_lazy("shuup_admin:subscription.plan.new")


class QuickPaymentProcessorPlanSelect(QuickAddRelatedObjectMultiSelect):
    url = reverse_lazy("shuup_admin:subscription.payment_processor_plan.new")
