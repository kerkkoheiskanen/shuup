# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf import settings
from django.utils import translation
from django.utils.timezone import now
from django.utils.translation import ugettext as _
from shuup.core.models import OrderLineType
from shuup.core.order_creator import OrderCreator, OrderSource
from shuup.utils.i18n import is_existing_language

from ..checkout import SubscriptionBasket


def post_process_subscription_order(order, source, **kwargs):
    if isinstance(source, SubscriptionBasket) and source.plan:
        source.create_subscriptions_for_order(order)


def handle_payment_created(instance, **kwargs):
    """
    Handle subscription payment created event.

    :type instance: shuup_subscriptions.models.SubscriptionPayment
    :rtype: None
    """
    create_recurring_order_for_subscription(instance.subscription, instance)


def create_recurring_order_for_subscription(subscription, payment):
    """
    Create recurring order for a subscription.

    :type subscription: shuup_subscriptions.models.Subscription
    :type payment: shuup_subscriptions.models.SubscriptionPayment
    :rtype: None
    """
    with translation.override(_get_order_language(subscription.order)):
        if not subscription.order.payments.exists():
            # The first payment goes to the original subscription order
            order = subscription.order
        else:
            # Create a new order for following payments
            order = _create_order_from_subscription(subscription)

        _pay_order_via_subscription_payment(order, payment)


def _get_order_language(order):
    if order.language and is_existing_language(order.language):
        return order.language
    return settings.LANGUAGE_CODE


class AlwaysOrderableOrderSource(OrderSource):
    def verify_orderability(self):
        pass


def _create_order_from_subscription(subscription):
    # Create an OrderSource with base data from the original subscription order
    source = AlwaysOrderableOrderSource(subscription.order.shop)
    source.update_from_order(subscription.order)
    source.creator = None
    source.modified_by = None
    source.order_date = now()

    source.add_line(
        type=OrderLineType.OTHER,
        sku="SO",  # Subscription Order
        text=_(
            "Automatically created order for "
            "subscription {subscription_id}").format(
                subscription_id=subscription.pk))

    # Add the subscription line to order
    subs_product = subscription.ordered_in_line.product
    source.add_line(
        type=OrderLineType.OTHER,
        base_unit_price=subscription.plan.amount,
        quantity=subscription.ordered_in_line.quantity,
        tax_class=(subs_product.tax_class if subs_product else None),
        text=subscription.subject)

    # Add the products from the subscription to the order
    for item in subscription.get_contents():
        line = source.add_line(
            type=OrderLineType.PRODUCT,
            product=item.product, supplier=item.supplier,
            sku=item.product.sku,
            text=item.product.safe_translation_getter('name'),
            quantity=item.quantity)
        assert line.price.value == 0

    assert source.total_price == subscription.plan.amount

    # Create the order
    creator = OrderCreator()
    order = creator.create_order(source)

    return order


def _pay_order_via_subscription_payment(order, payment):
    """
    Create a payment to order from a subscription payment.

    :type order: shuup.core.models.Order
    :type payment: shuup_subscriptions.models.SubscriptionPayment
    """
    order.create_payment(
        amount=payment.amount,
        payment_identifier=payment.payment_identifier,
        description=payment.description)
    order.add_log_entry(
        _("Paid via subscription payment {payment_id}").format(
            payment_id=(payment.payment_identifier or payment.pk)))
