# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.utils.translation import ugettext_lazy as _
from shuup.admin.menu import ORDERS_MENU_CATEGORY, PRODUCTS_MENU_CATEGORY
from shuup.admin.modules.products.views.edit_package import (
    ProductPackageViewToolbar)
from shuup.apps.provides import get_provide_objects
from shuup.core.utils.menu import MainMenuUpdater


def get_service_for_identifier(service_identifier):
    for sc in get_provide_objects("subscription_plan_service"):
        if sc.identifier == service_identifier:
            return sc
    return None


def get_service_choices(empty=True):
    choices = [(sc.identifier, sc.name) for sc in get_provide_objects("subscription_plan_service")]
    if empty:
        return [("", _("Select a service"))] + choices
    return choices


class ProductSubscriptionViewToolbar(ProductPackageViewToolbar):
    button_text = _("Clear subscription")
    confirm_text = _("Are you sure? This will remove all products from subscription.")


class SubscriptionMainMenuUpdater(MainMenuUpdater):
    updates = {
        PRODUCTS_MENU_CATEGORY: [{"identifier": "subscriptions", "title": _("Subscriptions")}],
        ORDERS_MENU_CATEGORY: [{"identifier": "subscriptions", "title": _("Subscriptions")}]
    }
