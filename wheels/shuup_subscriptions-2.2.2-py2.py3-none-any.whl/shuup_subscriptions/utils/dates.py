# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import calendar
import datetime

from django.utils.formats import date_format


def format_date(date, format_type='SHORT_DATE_FORMAT'):
    return date_format(date, format_type) if date else ''


def add_years_to_date(date, years):
    """
    Modified from: http://stackoverflow.com/questions/15741618/add-one-year-in-current-date-python

    Return a date that's `years` years after the date (or datetime)
    object `d`. Return the same calendar date (month and day) in the
    destination year, if it exists, otherwise use the following day
    (thus changing February 29 to March 1).

    :param date: date to add years
    :param months: years to be added
    :return: new date with number of years added to it
    """
    try:
        return date.replace(year=date.year + years)
    except ValueError:
        return date + (datetime.datetime(date.year + years, 1, 1) - datetime.datetime(date.year, 1, 1))


def add_months_to_date(date, months):
    """
    Modified from: http://stackoverflow.com/questions/4130922/
    how-to-increment-datetime-by-custom-months-in-python-without-using-library

    :param date: date to add months
    :param months: months to be added
    :return: new date with number of months added to it
    """
    month = date.month - 1 + months
    year = int(date.year + month / 12)
    month = month % 12 + 1
    day = min(date.day, calendar.monthrange(year, month)[1])
    return date.replace(year=year, month=month, day=day)


def add_plan_interval_to_date(interval, date, multiplier=1):
    """
    :param interval: PlanInterval enum value
    :return: datetime.timedelta for plan interval
    """
    if not interval:
        return date
    from shuup_subscriptions.enums import PlanInterval

    if interval == PlanInterval.YEAR:
        return add_years_to_date(date, 1 * multiplier)
    elif interval == PlanInterval.MONTH:
        return add_months_to_date(date, 1 * multiplier)
    elif interval == PlanInterval.TWO_WEEKS:
        return date + datetime.timedelta(days=14)
    elif interval == PlanInterval.WEEK:
        return date + datetime.timedelta(weeks=1*multiplier)
    elif interval == PlanInterval.DAY:
        return date + datetime.timedelta(days=1*multiplier)
