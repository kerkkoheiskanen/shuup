# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from django.conf.urls import url
from django.contrib.auth.decorators import login_required

from .checkout import SubscriptionCheckoutView
from .views import SubscriptionDetailView, SubscriptionListView

urlpatterns = [
    url('^subscriptions/$',
        login_required(SubscriptionListView.as_view()), name='subscription.list'),
    url('^subscriptions/(?P<pk>.+)/$',
        login_required(SubscriptionDetailView.as_view()), name='subscription.detail'),
    url(r'^subscription-checkout/(?P<product_id>\d+)/$',
        SubscriptionCheckoutView.as_view(), name="subscription_checkout"),
    url(r'^subscription-checkout/(?P<product_id>\d+)/(?P<phase>.+)/$',
        SubscriptionCheckoutView.as_view(), name='subscription_checkout'),
]
