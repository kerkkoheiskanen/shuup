# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals, with_statement

import datetime

import pytz
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.transaction import atomic
from django.utils.text import slugify
from django.utils.timezone import now
from django.utils.translation import ugettext_lazy as _
from enumfields import EnumField
from parler.managers import TranslatableQuerySet
from parler.models import TranslatedFields
from shuup.core.excs import (
    NoProductsToShipException, NoShippingAddressException)
from shuup.core.fields import CurrencyField, MoneyValueField
from shuup.core.models import (
    AbstractPayment, Contact, OrderLine, Product, ServiceBehaviorComponent,
    Shipment, Shop, ShuupModel, TranslatableShuupModel)
from shuup.utils.i18n import format_money
from shuup.utils.importing import cached_load
from shuup.utils.properties import MoneyPropped, PriceProperty
from six import python_2_unicode_compatible

from .enums import PlanInterval
from .utils import add_plan_interval_to_date, format_date


class PlanQuerySet(TranslatableQuerySet):

    def active(self):  # pragma: no cover
        return self.filter(is_active=True)


@python_2_unicode_compatible
class Plan(MoneyPropped, TranslatableShuupModel):

    shop = models.ForeignKey(Shop, related_name="plans")
    # todo: rename to products
    products = models.ManyToManyField(Product, related_name="plans")

    is_active = models.BooleanField(verbose_name=_("is active"), default=False)

    amount_value = MoneyValueField()
    amount = PriceProperty("amount_value", "shop.currency", "shop.prices_include_tax")

    interval = EnumField(PlanInterval, verbose_name=_("interval"), default=PlanInterval.MONTH)

    trial_period = EnumField(
        PlanInterval, verbose_name=_(u"Free trial"), max_length=20,
        default=None, blank=True, null=True
    )

    commission = models.DecimalField(
        verbose_name=_(u"Commission percentage"),
        max_digits=5,
        decimal_places=2,
        default=0.00,
        validators=[MinValueValidator(0.00), MaxValueValidator(100.00)]
    )

    translations = TranslatedFields(
        name=models.CharField(blank=True, max_length=128, verbose_name=_('name'), help_text=_(
            "Choose a title for your plan."
        )),
        description=models.TextField(blank=True, verbose_name=_('description'), help_text=_(
            "Write a description for your plan."
        )),
    )

    class Meta:
        verbose_name = _("plan")
        verbose_name_plural = _("plans")

    objects = PlanQuerySet.as_manager()

    def get_price(self, processor):
        return self.amount

    def get_commission_amount(self, sales):
        """
        :param sales: sales in provider currency
        :return: commission for sales
        """
        return sales * self.commission / 100.0

    def get_price_formatted(self):
        price = (format_money(self.amount) if self.amount is not None else '')
        template = "{price} {interval}"
        return template.format(price=price, interval=self.interval)

    def get_free_trial_end_date(self, subscription):
        if not self.trial_period:
            return None
        from shuup_subscriptions.utils import add_plan_interval_to_date
        return add_plan_interval_to_date(self.trial_period, subscription.start_date)

    def get_payments(self, subscription, start_datetime, end_datetime):
        for date in self.get_payment_dates(start_datetime, end_datetime):
            if self.is_in_trial_period(date):
                yield (date, self.amount_value * (1 - self.trial_period_discount_percentage))
            else:
                yield (date, self.amount_value)

    def get_payment_dates(self, subscription, start_datetime, end_datetime):
        return subscription.get_payment_dates(start_datetime, end_datetime)

    @property
    def unique_key(self):
        return slugify("%s-%s" % (self.amount_value, self.pk))

    def is_valid_for_shop_and_product(self, shop, product):
        return (
            self.shop == shop and
            self.products.filter(pk=product.pk).exists() and
            self.is_active)

    def __str__(self):
        name = self.safe_translation_getter('name')
        price = (format_money(self.amount) if self.amount is not None else '')
        template = ("{name}, " if name else '') + "{price} {interval}"
        return template.format(name=name, price=price, interval=self.interval)


class Subscription(ShuupModel):
    customer = models.ForeignKey(
        Contact, blank=True, null=True,
        on_delete=models.CASCADE,
        related_name="customer_subscriptions",
        verbose_name=_('customer')
    )
    subscriber = models.ForeignKey(
        Contact, blank=True, null=True,
        on_delete=models.CASCADE,
        related_name="subscriber_subscriptions",
        verbose_name=_('subscriber')
    )

    creator = models.ForeignKey(
        settings.AUTH_USER_MODEL, blank=True, null=True,
        on_delete=models.CASCADE,
        related_name="subscriptions_created",
        verbose_name=_('creator')
    )

    plan = models.ForeignKey(Plan, on_delete=models.PROTECT)
    currency = CurrencyField(default=settings.SHUUP_HOME_CURRENCY, verbose_name=_("currency"), help_text=_(
        "The primary subscription currency."
    ))

    ordered_in_line = models.OneToOneField(
        OrderLine, related_name='subscription')

    start_date = models.DateTimeField(verbose_name=_("start date"), editable=False)
    end_date = models.DateTimeField(verbose_name=_("end date"), null=True, blank=True, editable=False)

    created_on = models.DateTimeField(auto_now_add=True, db_index=True, editable=False,
                                      verbose_name=_('created on'))
    updated_on = models.DateTimeField(auto_now=True, db_index=True, editable=False, verbose_name=_('updated on'))

    class Meta:
        ordering = ('created_on',)
        verbose_name = _("subscription")
        verbose_name_plural = _("subscriptions")

    def __str__(self):
        return "{subject} / {plan} / {customer} {start}-{end}".format(
            subject=self.subject, plan=self.plan, customer=self.customer,
            start=format_date(self.start_date), end=format_date(self.end_date))

    @property
    def subject(self):
        return self.ordered_in_line.text

    @property
    def active(self):
        return not bool(self.end_date)

    @property
    def order(self):
        return self.ordered_in_line.order

    def get_contents(self):
        lines = self.order.lines.filter(parent_line=self.ordered_in_line)
        for line in lines:
            yield line

    @property
    def image(self):
        product = self.ordered_in_line.product
        if product:
            return product.primary_image
        contents = list(self.get_contents())
        if len(contents) == 1:
            return contents[0].product.primary_image
        return None

    @property
    def fully_paid(self):
        """
        see if subscription is fully paid between self.start_date and today using self.plan.get_payments
        :param start_date:
        :return:
        """
        return None

    def get_payments(self, start_date=None, end_date=None):
        q = models.Q(subscription=self)
        if end_date:
            q &= models.Q(created_on__lte=end_date)
        if start_date:
            q &= models.Q(created_on__gte=start_date)
        return SubscriptionPayment.objects.filter(q).order_by("-created_on")

    @property
    def last_payment(self):
        payments = self.get_payments()
        if payments.exists():
            return payments.first()
        return None

    @property
    def next_payment_date(self):
        last_payment = self.last_payment
        if last_payment:
            return add_plan_interval_to_date(self.plan.interval, last_payment.created_on)
        else:
            return self.start_date

    @property
    def open_amount(self):
        """
        :return: self.get_payments(self.start_date, now) - sum(self.get_payments)
        """
        end_date = now()
        actually_paid = sum([p.amount for p in self.get_payments(self.start_date, end_date) if p.amount]) or 0
        total_payment_amount = sum([p.amount for p in self.get_payments() if p.amount]) or 0
        return self.plan.shop.create_price(actually_paid - total_payment_amount)

    def create_payment(self, amount, **kwargs):
        return SubscriptionPayment.objects.create(amount_value=amount.value, subscription=self, **kwargs)

    @atomic
    def create_shipment(self, product_quantities, supplier=None, shipment=None):
        """
        Create a shipment for this order from `product_quantities`.
        `product_quantities` is expected to be a dict mapping Product instances to quantities.

        Only quantities over 0 are taken into account, and if the mapping is empty or has no quantity value
        over 0, `NoProductsToShipException` will be raised.

        Orders without a shipping address defined, will raise `NoShippingAddressException`.

        :param product_quantities: a dict mapping Product instances to quantities to ship
        :type product_quantities: dict[shuup.shop.models.Product, decimal.Decimal]
        :param supplier: Optional Supplier for this product. No validation is made
        :param shipment: Optional unsaved Shipment for ShipmentProduct's. If not given
                         Shipment is created based on supplier parameter.
        :raises: NoProductsToShipException, NoShippingAddressException
        :return: Saved, complete Shipment object
        :rtype: shuup.core.models.Shipment
        """
        order = self.ordered_in_line.order
        if not product_quantities or not any(quantity > 0 for quantity in product_quantities.values()):
            raise NoProductsToShipException(
                "No products to ship (`quantities` is empty or has no quantity over 0).")

        if order.shipping_address is None:
            raise NoShippingAddressException("Shipping address is not set on this order")

        assert (supplier or shipment)
        if shipment:
            assert shipment.subscription == self
        else:
            # from ._shipments import SubscriptionShipment
            shipment = SubscriptionShipment(order=None, subscription=self, supplier=supplier)
        shipment.save()

        if not supplier:
            supplier = shipment.supplier

        supplier.get_module().ship_products(shipment, product_quantities)

        self.add_log_entry(_(u"Shipment #%d created.") % shipment.id)
        self.update_shipping_status()

        # subscription_shipment_created.send(sender=type(self), order=self, shipment=shipment)
        return shipment

    def cancel(self, user, end_date, skip_suspend=False):
        if end_date:
            self.end_date = end_date
            self.save()
        from shuup_subscriptions.signals import subscription_cancelled
        subscription_cancelled.send(sender=self.__class__, subscription=self, user=user, skip_suspend=skip_suspend)

    def get_next_invoicing_date(self):
        return self.get_current_invoicing_period()[1]

    def get_current_period(self):
        """
        Get date range of current invoicing period.

        :rtype: (datetime.datetime, datetime.datetime)
        """
        from shuup_subscriptions.utils import add_plan_interval_to_date
        last_payment = self.last_payment
        start = (last_payment.end_date if last_payment else self.start_date)
        end = add_plan_interval_to_date(self.plan.interval, start)
        return (start, end)

    def get_payment_dates(self, start_datetime, end_datetime):
        days = (end_datetime - start_datetime).days

        return_values = []
        if not days:
            return_values.append(self._get_for_date(start_datetime))
        else:
            for day in range(days):
                adjusted_today = start_datetime + datetime.timedelta(days=day)
                date, amount = self._get_for_date(adjusted_today)
                if amount:
                    return_values.append((date, amount))
        return return_values

    def is_in_trial_period(self, date):
        """
        Is given date inside the trial period range
        """
        trial_provider = cached_load("SUBSCRIPTION_TRIAL_PROVIDER")(subscription=self)
        return trial_provider.is_in_trial_period(date)

    def get_free_trial_end_date(self):
        trial_provider = cached_load("SUBSCRIPTION_TRIAL_PROVIDER")(subscription=self)
        return trial_provider.get_free_trial_end_date()

    def _get_for_date(self, date):
        # TODO: TWO_WEEKS
        amount = 0
        if self.plan.interval == PlanInterval.YEARLY:
            # today = now()
            days = (date - datetime.datetime(date.year, 1, 1, 0, 0, 0, 0, pytz.UTC)).days + 1
            amount = self.plan.amount_value if days == self.day_number else 0
        elif self.plan.interval == PlanInterval.MONTHLY:
            amount = self.plan.amount_value if date.day == self.day_number else 0
        elif self.plan.interval == PlanInterval.WEEKLY:
            amount = self.plan.amount_value if (date.weekday() + 1) == self.day_number else 0
        elif self.plan.interval == PlanInterval.DAILY:
            amount = self.plan.amount_value
        return (date, amount)


class SubscriptionPayment(AbstractPayment):

    subscription = models.ForeignKey(
        Subscription, related_name='payments', on_delete=models.PROTECT, verbose_name=_('subscription'))

    class Meta:
        verbose_name = _('subscription payment')
        verbose_name_plural = _('subscription payments')

    @property
    def currency(self):
        return self.subscription.currency


class SubscriptionShipment(Shipment):
    subscription = models.ForeignKey(
        Subscription, blank=True, null=True, related_name='shipments', on_delete=models.PROTECT,
        verbose_name=_("subscription"))


class SubscriptionProductsOnlyComponent(ServiceBehaviorComponent):
    name = _("Subscription products only availability")
    help_text = _("Limit service availability to baskets containing subscription products")

    def get_unavailability_reasons(self, service, source):
        from .checkout import SubscriptionBasket
        if not isinstance(source, SubscriptionBasket):
            yield ValidationError(_("Service is only available for subscription baskets"))
