# -*- coding: utf-8 -*-
# This file is part of Shuup Subscriptions Addon.
#
# Copyright (c) 2012-2017, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
from __future__ import unicode_literals

from django.db.models import Q
from django.utils import timezone
from django.utils.translation import ugettext as _
from shuup.core.models import OrderLineType, ProductMode
from shuup.front.basket.objects import BaseBasket
from shuup.utils.iterables import first

from ..models import Plan, Subscription
from ..processors import SubscriptionProcessor


class SubscriptionBasket(BaseBasket):

    def __init__(self, request, basket_name="subscription_basket", shop=None):
        super(SubscriptionBasket, self).__init__(request, basket_name, shop)

    def create_subscriptions_for_order(self, order):
        subscription_parent_lines = list(
            self._find_subscription_parent_lines_from_order(order))

        if not subscription_parent_lines:
            raise ValueError('Not a subscription order: {!r}'.format(order))

        result = []
        for (basket_line, ordered_in_line) in subscription_parent_lines:
            result.append(
                self._create_subscription_for_line(ordered_in_line))
        return result

    def _find_subscription_parent_lines_from_order(self, order):
        parent_basket_line = self.get_subscription_parent_line()
        matching_order_lines = order.lines.filter(
            Q(sku=parent_basket_line.sku, text=parent_basket_line.text) & (
                Q(type=OrderLineType.PRODUCT,
                  product__mode=ProductMode.SUBSCRIPTION) |
                Q(type=OrderLineType.OTHER)))
        for order_line in matching_order_lines:
            yield (parent_basket_line, order_line)

    def _create_subscription_for_line(self, ordered_in_line):
        subscription = Subscription.objects.create(
            ordered_in_line=ordered_in_line,
            customer=(self.customer if self.customer else None),
            subscriber=(self.orderer if self.orderer else None),
            creator=(self.creator if self.creator and
                     not self.creator.is_anonymous() else None),
            plan=self.plan,
            currency=self.currency,
            start_date=timezone.now(),
        )
        return subscription

    def get_subscription_lines(self, parent_line=None):
        for line in self.get_lines():
            if line.get('is_subscription_line') and (
                    parent_line is None or
                    line.parent_line_id == parent_line.line_id):
                yield line

    def get_subscription_product(self):
        """
        Get the subscription product in the basket, if there is one.

        :rtype: shuup.core.models.Product|None
        """
        line = self.get_subscription_parent_line()
        return line.product if line else None

    def get_subscription_parent_line(self):
        """
        Get the subscription parent line in the basket, if there is one.

        :rtype: shuup.front.basket.objects.BasketLine|None
        """
        return first(
            line for line in self.get_lines()
            if line.get('is_subscription_parent'))

    @property
    def plan(self):
        """
        The subscription plan selected for this basket.

        :rtype: Plan|None
        """
        return self._get_object(Plan, self.plan_id) if self.plan_id else None

    @property
    def plan_id(self):
        return self._load().setdefault('plan_id', None)

    def set_plan_by_id(self, plan_id):
        plan = self._get_object(Plan, plan_id) if plan_id else None
        return self.set_plan(plan)

    def set_plan(self, plan):
        if plan == self.plan:
            return False
        self._update_fee_line(plan)
        self._load()["plan_id"] = plan.pk if plan else None
        self.uncache()
        return True

    def clear_plan(self):
        return self.set_plan(None)

    def _update_fee_line(self, new_plan):
        if self.plan:
            # Delete old fee line, if it exists
            self.delete_line('plan_{}_fee'.format(self.plan.pk))
        if not new_plan:
            return
        price = new_plan.get_price(self)
        line = self.get_subscription_parent_line()
        if line:
            self._set_line_unit_price(line, price)
        else:
            line = self.add_line(
                line_id='plan_{}_fee'.format(new_plan.pk),
                type=OrderLineType.OTHER,
                quantity=1,
                base_unit_price=price,
                text=_("Subscription Fee"),
                extra={'is_subscription_parent': True})
        self._handle_line_addition(line)

    def _set_line_unit_price(self, line, price):
        line.update(base_unit_price=price, discount_amount=self.zero_price)
        self._add_or_replace_line(line)

    def add_line(self, **kwargs):
        line = super(SubscriptionBasket, self).add_line(**kwargs)
        self._handle_line_addition(line)
        return line

    def add_product(self, supplier, shop, product, quantity, *args, **kwargs):
        line = super(SubscriptionBasket, self).add_product(
            supplier, shop, product, quantity, *args, **kwargs)
        self._handle_line_addition(line)
        return line

    def _handle_line_addition(self, line):
        if line.product and line.product.mode == ProductMode.SUBSCRIPTION:
            line.update(**{'is_subscription_parent': True})
            self._add_or_replace_line(line)
            self._add_subscription_product_contents(line)

    def _add_subscription_product_contents(self, line):
        assert line.product.mode == ProductMode.SUBSCRIPTION
        product = line.product
        quantity_map = product.get_package_child_to_quantity_map()
        for (child_product, child_quantity) in quantity_map.items():
            child_line = self.add_product(
                supplier=line.supplier,
                shop=line.shop,
                product=child_product,
                quantity=(line.quantity * child_quantity),
                parent_line=line,
                extra={'is_subscription_line': True})
            self._set_line_unit_price(child_line, self.zero_price)
            assert child_line.price.value == 0

    def get_available_shipping_methods(self):
        if self.has_shippable_lines():
            return super(SubscriptionBasket, self).get_available_shipping_methods()
        return []

    def get_available_payment_methods(self):
        methods = []
        for sub_processor in SubscriptionProcessor.get_supported_processors(self.plan):
            for payment_method in sub_processor.get_payment_methods():
                methods.append(payment_method)
        return methods
