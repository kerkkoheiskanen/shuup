# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from django.utils.encoding import force_text
from django.utils.translation import ugettext as _
from django.views.generic.edit import FormView
from shuup.front.checkout import (
    BasicServiceCheckoutPhaseProvider, CheckoutPhaseViewMixin)
from shuup.utils.excs import Problem
from shuup_stripe.checkout_forms import StripeTokenForm

from .models import StripeSubscriptionPaymentProcessor
from .utils import get_amount_info


class StripeSubscriptionPhase(CheckoutPhaseViewMixin, FormView):
    service = None  # Injected by the method phase
    identifier = "subscription_stripe"
    title = "Stripe"
    template_name = "shuup_stripe_subscriptions/checkout_phase.jinja"
    form_class = StripeTokenForm

    def get_stripe_context(self):
        payment_processor = self.service.payment_processor
        publishable_key = payment_processor.publishable_key
        secret_key = payment_processor.secret_key
        if not (publishable_key and secret_key):
            raise Problem(
                _("Please configure Stripe keys for payment processor %s.") %
                payment_processor)

        config = {
            "publishable_key": publishable_key,
            "name": force_text(self.request.shop),
            "description": force_text(_("Purchase")),
        }

        config.update(get_amount_info(self.basket.plan.amount))
        return config

    def get_context_data(self, **kwargs):
        context = super(StripeSubscriptionPhase, self).get_context_data(**kwargs)
        context["stripe"] = self.get_stripe_context()
        return context

    def is_valid(self):
        return "token" in self.storage.get("stripe", {})

    def form_valid(self, form):
        self.storage["stripe"] = {
            "token": form.cleaned_data.get("stripeToken"),
            "token_type": form.cleaned_data.get("stripeTokenType"),
            "email": form.cleaned_data.get("stripeEmail"),
        }
        return super(StripeSubscriptionPhase, self).form_valid(form)

    def process(self):
        self.basket.payment_data["stripe"] = self.storage["stripe"]


class SubscriptionPhaseProvider(BasicServiceCheckoutPhaseProvider):
    phase_class = StripeSubscriptionPhase
    service_provider_class = StripeSubscriptionPaymentProcessor
