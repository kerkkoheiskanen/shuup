# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from __future__ import unicode_literals

import decimal
from collections import defaultdict

from django.core.urlresolvers import reverse
from shuup.core.models import Shop
from shuup.utils.money import Money

ZERO_DECIMAL_CURRENCIES = (
    # https://support.stripe.com/questions/which-zero-decimal-currencies-does-stripe-support
    "BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA",
    "PYG", "RWF", "VND", "VUV", "XAF", "XOF", "XPF"
)

_MULT_AND_PREC_MAP = defaultdict((lambda: (100, decimal.Decimal('0.01'))), {
    currency: (1, decimal.Decimal('1'))
    for currency in ZERO_DECIMAL_CURRENCIES
})


def get_amount_info(amount):
    """
    Create Stripe amount and currency data from a Money object.

    >>> assert get_amount_info(Money('123.45', 'EUR')) == {
    ...     'amount': 12345, 'currency': 'EUR'}

    >>> assert get_amount_info(Money('123.45', 'JPY')) == {
    ...     'amount': 123, 'currency': 'JPY'}

    :type amount: Money
    :rtype: dictp
    """
    (multiplier, _) = _MULT_AND_PREC_MAP[amount.currency]
    return {
        "currency": amount.currency,
        "amount": int(amount.value * multiplier),
    }


def stripe_amount_to_money(stripe_data, field='amount'):
    """
    Create a Money object from Stripe amount and currency data.

    >>> assert stripe_amount_to_money(
    ...     {'amount': 123, 'currency': 'EUR'}) == Money('1.23', 'EUR')

    >>> assert stripe_amount_to_money(
    ...     {'amount': 123, 'currency': 'JPY'}) == Money('123', 'JPY')

    >>> assert stripe_amount_to_money(
    ...     {'amount': -42, 'currency': 'USD'}) == Money('-0.42', 'USD')

    :type stripe_data: dict
    :rtype: Money
    """
    pences = stripe_data[field]
    currency = stripe_data['currency'].upper()
    (multiplier, prec) = _MULT_AND_PREC_MAP[currency]
    amount = (decimal.Decimal(pences) / multiplier).quantize(prec) if pences > 0 else decimal.Decimal(pences)
    return Money(amount, currency)


def get_webhook_url_format():
    uri = reverse('shuup:stripe-subscriptions-webhook',
                  kwargs={'slug': 'XSLUGX'})
    domain = get_shop_domain()
    if domain.endswith('/') and uri.startswith('/'):
        uri = uri[1:]
    return domain + uri.replace('XSLUGX', '{slug}')


def get_shop_domain():
    shop = Shop.objects.first()
    domain = (shop.domain if shop else '') or ''
    if domain and not domain.startswith(('http://', 'https://')):
        return 'http://' + domain
    return domain
