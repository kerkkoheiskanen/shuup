# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.
import stripe

from shuup_stripe_subscriptions.enums import InvoiceStatus
from shuup_stripe_subscriptions.models import (
    StripeSubscription, StripeSubscriptionPaymentProcessor)


def handle_subscription_cancel(sender, subscription, user, **kwargs):
    stripe_subscription = StripeSubscription.objects.get(subscription=subscription)
    processor = StripeSubscriptionPaymentProcessor.objects.first()
    # cancel subscription
    sub = stripe.Subscription.retrieve(stripe_subscription.external_id, processor.secret_key)
    sub.delete()

    # mark all current invoices void
    for pending_invoice in subscription.invoices.filter(status=InvoiceStatus.PENDING):
        pending_invoice.status = InvoiceStatus.CANCELLED
        pending_invoice.save()
