# -*- coding: utf-8 -*-
# This file is part of Shuup.
#
# Copyright (c) 2012-2019, Shoop Commerce Ltd. All rights reserved.
#
# This source code is licensed under the SHUUP® ENTERPRISE EDITION -
# END USER LICENSE AGREEMENT executed by Anders Innovations Inc. DBA as Shuup
# and the Licensee.

from __future__ import unicode_literals

from django.db import models
from django.utils.six import python_2_unicode_compatible


@python_2_unicode_compatible
class StripedModel(models.Model):
    external_id = models.CharField(verbose_name="remote id", max_length=200, blank=True, null=True)

    def __str__(self):
        return '{}/{}'.format(self.pk, self.external_id)

    @classmethod
    def get_for_stripe_id(cls, stripe_id):
        return cls.objects.filter(external_id=stripe_id).first()

    class Meta:
        abstract = True
